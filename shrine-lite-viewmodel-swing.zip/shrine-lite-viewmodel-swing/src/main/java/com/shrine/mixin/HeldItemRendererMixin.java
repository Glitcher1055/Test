package com.shrine.mixin;

import com.shrine.SwingAnimFx;
import com.shrine.ViewModelFx;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Visual > ViewModel and Swing Animation: both work on the matrix of the first-person hand. */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {

    /** Before vanilla places the hand: our offset / scale / rotation first, then the custom swing on top of it. */
    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"))
    private void shrine$hand(AbstractClientPlayerEntity player, float tickProgress, float pitch, Hand hand,
                             float swingProgress, ItemStack item, float equipProgress, MatrixStack matrices,
                             OrderedRenderCommandQueue queue, int light, CallbackInfo ci) {
        Arm arm = hand == Hand.MAIN_HAND ? player.getMainArm() : player.getMainArm().getOpposite();
        ViewModelFx.apply(matrices, arm);
        SwingAnimFx.apply(matrices, arm, swingProgress);
    }

    /** While a custom swing runs, the vanilla swing movement of that arm is skipped. */
    @Inject(method = "applySwingOffset", at = @At("HEAD"), cancellable = true)
    private void shrine$noVanillaSwing(MatrixStack matrices, Arm arm, float swingProgress, CallbackInfo ci) {
        if (SwingAnimFx.cancelVanilla(arm)) ci.cancel();
    }
}

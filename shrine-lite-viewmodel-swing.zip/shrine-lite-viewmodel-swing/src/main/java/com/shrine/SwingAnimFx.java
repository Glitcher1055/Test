package com.shrine;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Arm;
import net.minecraft.util.Util;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.RotationAxis;

/**
 * Visual > "Swing Animation": 13 swing animations for the first-person hand.
 *
 * Vanilla swing progress only tells us WHEN a swing starts. From that moment the animation runs on its own clock,
 * so "Duration" can make it longer or shorter than the vanilla 6 ticks. While it runs, the vanilla swing offset
 * is switched off (HeldItemRendererMixin -> cancelVanilla), so the two never fight.
 * "Only On Target": the custom animation plays only when the crosshair is on a player; in the air it stays vanilla.
 */
public final class SwingAnimFx {
    private SwingAnimFx() {}

    public static final String KEY = "visual.swing", K_STYLE = "visual.swing.style", K_STR = "visual.swing.str",
            K_DUR = "visual.swing.dur", K_TARGET = "visual.swing.target";
    private static final float BASE_MS = 380f;     // length of one swing at Duration x1.0

    /** Per-arm state: 0 = right arm, 1 = left arm. */
    private static final class St { boolean active, hold; long start; float prev; }
    private static final St[] ST = {new St(), new St()};
    private static final float[] POSE = new float[6];

    public static boolean enabled() { return ShrineCfg.bool(KEY, false); }
    static int style() { return Math.max(0, Math.min(SwingMath.STYLES.length - 1, ShrineCfg.integer(K_STYLE, 1))); }
    static float strength() { return Math.max(0.2f, Math.min(2f, ShrineCfg.num(K_STR, 1f))); }
    static float duration() { return Math.max(0.2f, Math.min(3f, ShrineCfg.num(K_DUR, 1f))); }

    static void reset() {
        ShrineCfg.setInt(K_STYLE, 1);
        ShrineCfg.setNum(K_STR, 1f);
        ShrineCfg.setNum(K_DUR, 1f);
        ShrineCfg.setBool(K_TARGET, false);
        ShrineCfg.save();
    }

    private static boolean eligible() {
        if (!ShrineCfg.bool(K_TARGET, false)) return true;
        return MinecraftClient.getInstance().crosshairTarget instanceof EntityHitResult hit
                && hit.getEntity() instanceof PlayerEntity;
    }

    /**
     * Called at the start of the first-person item render for one hand, before vanilla transforms.
     * @param vanillaSwing vanilla swing progress of this hand (0 = not swinging)
     */
    public static void apply(MatrixStack m, Arm arm, float vanillaSwing) {
        St s = ST[arm == Arm.RIGHT ? 0 : 1];
        int style = style();
        if (!enabled() || style == 0) {              // off or "Standard": plain vanilla
            s.active = false; s.hold = false; s.prev = vanillaSwing;
            return;
        }
        long now = Util.getMeasuringTimeMs();
        // a swing begins when progress leaves 0, or jumps back (clicking again before the last swing is done)
        boolean began = vanillaSwing > 0f && (s.prev <= 0f || vanillaSwing < s.prev - 0.001f);
        if (began) {
            if (eligible()) { s.active = true; s.hold = true; s.start = now; }
            else { s.active = false; s.hold = false; }
        }
        s.prev = vanillaSwing;
        if (s.hold && !s.active && vanillaSwing <= 0f) s.hold = false;
        if (!s.active) return;

        float p = (now - s.start) / (BASE_MS * duration());
        if (p >= 1f) {
            s.active = false;
            if (vanillaSwing <= 0f) s.hold = false;
            return;
        }
        float side = arm == Arm.RIGHT ? 1f : -1f, str = strength();
        SwingMath.pose(style, p, side, POSE);
        m.translate(POSE[0] * str, POSE[1] * str, POSE[2] * str);
        float px = side * 0.56f, py = -0.52f, pz = -0.72f;      // where vanilla holds the item
        m.translate(px, py, pz);
        if (POSE[4] != 0f) m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(POSE[4] * str));
        if (POSE[3] != 0f) m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(POSE[3] * str));
        if (POSE[5] != 0f) m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(POSE[5] * str));
        m.translate(-px, -py, -pz);
    }

    /** True while the vanilla swing offset of this arm must be skipped. */
    public static boolean cancelVanilla(Arm arm) {
        return enabled() && ST[arm == Arm.RIGHT ? 0 : 1].hold;
    }
}

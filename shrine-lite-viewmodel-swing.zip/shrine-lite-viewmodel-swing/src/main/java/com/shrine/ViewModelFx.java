package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.RotationAxis;
import org.lwjgl.glfw.GLFW;

import java.util.Locale;

import static com.shrine.Gfx.*;

/**
 * Visual > "ViewModel": the first-person hand and its item can be moved, scaled and rotated, each hand separately.
 *
 * Editing happens right in the chat:
 *   double click on the item in the hand  - selects it (it gets a glowing ring)
 *   drag with the left mouse button       - moves the hand
 *   mouse wheel                           - size,   Shift + wheel - closer / farther
 *   chat command ".viewmodel reset"       - back to normal (also: ".viewmodel on" / ".viewmodel off")
 * Values are saved at once and the same numbers are editable on the settings page (sliders).
 *
 * Config units (all whole-number friendly for sliders): x / y / z in 1/100 of a world unit, size in percent,
 * rotation in degrees. Positive x moves the hand right and positive y up, whichever hand it is.
 */
public final class ViewModelFx {
    private ViewModelFx() {}

    public static final String KEY = "visual.vm", K_PAGE = "visual.vm.page";
    static final String[] FIELDS = {"x", "y", "z", "s", "rx", "ry", "rz"};
    static final float[] DEF = {0f, 0f, 0f, 100f, 0f, 0f, 0f};

    static String key(boolean right, String field) { return "visual.vm." + (right ? "r." : "l.") + field; }
    static float get(boolean right, int i) { return ShrineCfg.num(key(right, FIELDS[i]), DEF[i]); }
    static void set(boolean right, int i, float v) { ShrineCfg.setNum(key(right, FIELDS[i]), v); }

    public static boolean enabled() { return ShrineCfg.bool(KEY, false); }

    static void reset() {
        for (int h = 0; h < 2; h++) for (int i = 0; i < FIELDS.length; i++) set(h == 0, i, DEF[i]);
        selected = null; dragging = false; dirty = false;
        ShrineCfg.save();
    }

    // ------------------------------------------------------------------ render hook (called from HeldItemRendererMixin)

    /** Runs before vanilla places the hand, so every vanilla animation (equip, swing, use) still plays on top. */
    public static void apply(MatrixStack m, Arm arm) {
        if (!enabled()) return;
        boolean right = arm == Arm.RIGHT;
        float x = get(right, 0) / 100f, y = get(right, 1) / 100f, z = get(right, 2) / 100f;
        float s = Math.max(0.05f, get(right, 3) / 100f);
        float rx = get(right, 4), ry = get(right, 5), rz = get(right, 6);
        if (x == 0f && y == 0f && z == 0f && s == 1f && rx == 0f && ry == 0f && rz == 0f) return;
        m.translate(x, y, z);
        float side = right ? 1f : -1f;
        float px = side * 0.56f, py = -0.52f, pz = -0.72f;      // where vanilla holds the item: rotate / scale around it
        m.translate(px, py, pz);
        if (ry != 0f) m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(ry));
        if (rx != 0f) m.multiply(RotationAxis.POSITIVE_X.rotationDegrees(rx));
        if (rz != 0f) m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(rz));
        m.scale(s, s, s);
        m.translate(-px, -py, -pz);
    }

    // ------------------------------------------------------------------ chat editor

    private static Arm selected;                     // the hand being edited, null = none
    private static boolean dragging, dirty;
    private static double lastX, lastY, lastClickX, lastClickY;
    private static long lastClickAt;

    /** Screen pixels per 1/100 unit: the hand sits ~0.8 units away, the vertical field of view is 70 degrees. */
    private static float pxPerCenti(int screenH) { return 0.00893f * screenH; }

    /** Centre of the item on screen (GUI-scaled pixels) for the given hand, including its current offset. */
    private static float[] center(Arm arm, int w, int h) {
        boolean right = arm == Arm.RIGHT;
        float k = pxPerCenti(h);
        float cx = w * (right ? 0.71f : 0.29f) + get(right, 0) * k;
        float cy = h * 0.77f - get(right, 1) * k;
        return new float[]{cx, cy};
    }

    private static float radius(Arm arm, int h) {
        return 0.17f * h * Math.max(0.7f, get(arm == Arm.RIGHT, 3) / 100f);
    }

    /** A hand can be edited when something is in it (the main hand also when empty - the bare arm is drawn). */
    private static boolean editable(ClientPlayerEntity p, Arm arm) {
        if (p == null) return false;
        Hand hand = arm == p.getMainArm() ? Hand.MAIN_HAND : Hand.OFF_HAND;
        return hand == Hand.MAIN_HAND || !p.getStackInHand(hand).isEmpty();
    }

    /** @return true when the click belongs to the editor, so the chat must not handle it */
    static boolean chatClick(Click click) {
        if (!enabled() || click.button() != 0) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        double x = click.x(), y = click.y();
        long now = Util.getMeasuringTimeMs();
        boolean dbl = now - lastClickAt < 350 && Math.hypot(x - lastClickX, y - lastClickY) < 24;
        lastClickAt = now; lastClickX = x; lastClickY = y;

        Arm hit = null;
        double best = Double.MAX_VALUE;
        for (Arm a : new Arm[]{Arm.RIGHT, Arm.LEFT}) {
            if (!editable(mc.player, a)) continue;
            float[] c = center(a, w, h);
            double d = Math.hypot(x - c[0], y - c[1]);
            if (d < radius(a, h) && d < best) { best = d; hit = a; }
        }
        if (hit == null) return false;
        if (dbl) {
            selected = selected == hit ? null : hit;
            dragging = false;
            if (selected == null) flush();
            return true;
        }
        if (selected == hit) { dragging = true; lastX = x; lastY = y; return true; }
        return false;
    }

    /** @return true when the wheel was used by the editor, so the chat must not scroll */
    static boolean chatScroll(double vertical) {
        if (!enabled() || selected == null || vertical == 0) return false;
        boolean right = selected == Arm.RIGHT;
        long win = MinecraftClient.getInstance().getWindow().getHandle();
        boolean shift = GLFW.glfwGetKey(win, GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(win, GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
        if (shift) set(right, 2, clamp(get(right, 2) + (float) vertical * 4f, -150f, 150f));
        else set(right, 3, clamp(get(right, 3) * (1f + 0.06f * (float) Math.signum(vertical)), 20f, 300f));
        dirty = true;
        return true;
    }

    /** While the left button is held the hand follows the cursor (polled every frame, no drag event needed). */
    private static void pollDrag(MinecraftClient mc) {
        if (!dragging || selected == null) return;
        Window win = mc.getWindow();
        boolean down = GLFW.glfwGetMouseButton(win.getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        if (!down) { dragging = false; flush(); return; }
        double mx = mc.mouse.getScaledX(win), my = mc.mouse.getScaledY(win);
        float k = 1f / pxPerCenti(win.getScaledHeight());
        boolean right = selected == Arm.RIGHT;
        set(right, 0, clamp(get(right, 0) + (float) (mx - lastX) * k, -150f, 150f));
        set(right, 1, clamp(get(right, 1) - (float) (my - lastY) * k, -150f, 150f));
        lastX = mx; lastY = my;
        dirty = true;
    }

    private static void flush() { if (dirty) { ShrineCfg.save(); dirty = false; } }
    private static float clamp(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }

    // ------------------------------------------------------------------ chat command

    private static void say(String s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.inGameHud != null) mc.inGameHud.getChatHud().addMessage(Text.literal(s));
    }

    private static boolean command(String message) {
        String m = message.trim().toLowerCase(Locale.ROOT);
        if (!m.equals(".viewmodel") && !m.startsWith(".viewmodel ")) return true;   // not ours: send as usual
        String arg = m.substring(".viewmodel".length()).trim();
        switch (arg) {
            case "reset" -> { reset(); say("ViewModel: обе руки сброшены"); }
            case "on" -> { ShrineCfg.setBool(KEY, true); ShrineCfg.save(); say("ViewModel: включён"); }
            case "off" -> { ShrineCfg.setBool(KEY, false); ShrineCfg.save(); say("ViewModel: выключен"); }
            default -> say("ViewModel: .viewmodel reset | on | off");
        }
        return false;                                                                // consumed, nothing goes to the server
    }

    // ------------------------------------------------------------------ overlay (ring, size bubble, hint)

    public static void register() {
        ClientSendMessageEvents.ALLOW_CHAT.register(ViewModelFx::command);
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "viewmodel"),
                (ctx, tick) -> render(ctx));
    }

    private static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!(mc.currentScreen instanceof ChatScreen)) {                    // chat closed: finish editing
            if (selected != null || dragging) { selected = null; dragging = false; flush(); }
            return;
        }
        if (!enabled()) return;
        pollDrag(mc);

        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        float k = h / Scene.REF_H;
        TextRenderer tr = mc.textRenderer;
        float t = Util.getMeasuringTimeMs() / 1000f;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        for (Arm a : new Arm[]{Arm.RIGHT, Arm.LEFT}) {
            if (!editable(mc.player, a)) continue;
            float[] c = center(a, w, h);
            float vx = c[0] / k, vy = c[1] / k, r = radius(a, h) / k;
            if (a == selected) {
                float pulse = 0.75f + 0.25f * (float) Math.sin(t * 4f);
                centered(ctx, GLOW, vx, vy, r * 3.2f, r * 3.2f, argb(0.45f * pulse, ACCENT));
                centered(ctx, RING, vx, vy, r * 2f, r * 2f, argb(0.9f * pulse, ACCENT));
                // size bubble: the wheel value, like a tooltip above the item
                boolean right = a == Arm.RIGHT;
                String size = String.format(Locale.ROOT, "×%.1f", get(right, 3) / 100f);
                float bw = 108f, bh = 30f, bx = vx - bw / 2f, by = vy - r - 44f;
                box(ctx, RR, bx - 1, by - 1, bw + 2, bh + 2, 16, argb(0.55f, ACCENT));
                box(ctx, RR, bx, by, bw, bh, 15, argb(0.9f, 0x150A0F));
                text(ctx, tr, Fnt.UI_B, size, bx + 16, by + bh / 2f, argb(1f, 0xFFFFFF));
                text(ctx, tr, Fnt.TINY_B, "колёсико", bx + 54, by + bh / 2f, argb(0.5f, 0xFFFFFF));
            } else if (selected == null) {
                textC(ctx, tr, Fnt.TINY_B, "2× клик - двигать руку", vx, vy - r - 14f, argb(0.45f, 0xFFFFFF));
            }
        }
        ctx.getMatrices().popMatrix();
    }
}

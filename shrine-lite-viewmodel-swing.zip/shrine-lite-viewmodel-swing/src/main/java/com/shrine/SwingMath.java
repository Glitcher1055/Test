package com.shrine;

/**
 * The 13 swing animations as pure math (no Minecraft classes, so it can be unit-tested).
 *
 * pose() fills out[] with { dx, dy, dz, rx, ry, rz } for progress p in 0..1:
 *   dx / dy / dz  hand offset in world units (camera space: +x right, +y up, -z forward),
 *   rx / ry / rz  rotation in degrees around the hand.
 * Every style starts and ends at zero, so the hand returns exactly to its idle pose.
 * side is +1 for the right arm and -1 for the left one, so the motion mirrors.
 */
final class SwingMath {
    private SwingMath() {}

    static final String[] STYLES = {"Standard", "Lunge", "Jelly", "Spear", "Down", "Swing", "Swing 2",
            "Bonk", "Circle", "Shift", "Realism", "Slap", "Spin"};

    /** Keyframes (t0, v0, t1, v1, ...) with t ascending from 0 to 1; smooth easing between neighbours. */
    static float kf(float p, float... kv) {
        if (p <= kv[0]) return kv[1];
        for (int i = 0; i + 3 < kv.length; i += 2) {
            float t0 = kv[i], v0 = kv[i + 1], t1 = kv[i + 2], v1 = kv[i + 3];
            if (p <= t1) {
                float u = (p - t0) / (t1 - t0);
                u = u * u * (3f - 2f * u);
                return v0 + (v1 - v0) * u;
            }
        }
        return kv[kv.length - 1];
    }

    static void pose(int style, float p, float side, float[] out) {
        java.util.Arrays.fill(out, 0f);
        p = Math.max(0f, Math.min(1f, p));
        float e = (float) Math.sin(Math.PI * p);              // 0 -> 1 -> 0 bump
        switch (style) {
            case 1 -> {                                        // Lunge: the whole hand pushes forward
                out[2] = kf(p, 0, 0, .35f, -.5f, 1, 0);
                out[1] = kf(p, 0, 0, .35f, -.08f, 1, 0);
                out[3] = kf(p, 0, 0, .35f, -18, 1, 0);
                out[4] = side * 10f * e;
            }
            case 2 -> {                                        // Jelly: wobbles like rubber
                float w = (float) (Math.sin(p * Math.PI * 7) * Math.pow(1 - p, 1.5));
                out[5] = side * 28f * w;
                out[3] = -20f * e + 14f * w;
                out[2] = -.2f * e;
                out[0] = side * .04f * w;
            }
            case 3 -> {                                        // Spear: short pull back, then a thrust
                out[2] = kf(p, 0, 0, .2f, .14f, .42f, -.95f, 1, 0);
                out[3] = kf(p, 0, 0, .2f, 8, .42f, -70, 1, 0);
                out[1] = kf(p, 0, 0, .42f, .05f, 1, 0);
                out[4] = kf(p, 0, 0, .42f, side * -8f, 1, 0);
            }
            case 4 -> {                                        // Down: raise, then chop down
                out[3] = kf(p, 0, 0, .25f, 26, .5f, -72, 1, 0);
                out[1] = kf(p, 0, 0, .25f, .12f, .5f, -.18f, 1, 0);
                out[2] = kf(p, 0, 0, .5f, -.3f, 1, 0);
            }
            case 5 -> {                                        // Swing: horizontal slash
                out[4] = kf(p, 0, 0, .28f, side * 38f, .62f, side * -72f, 1, 0);
                out[5] = kf(p, 0, 0, .62f, side * -26f, 1, 0);
                out[0] = kf(p, 0, 0, .28f, side * .12f, .62f, side * -.32f, 1, 0);
                out[2] = kf(p, 0, 0, .62f, -.25f, 1, 0);
                out[3] = kf(p, 0, 0, .62f, -30, 1, 0);
            }
            case 6 -> {                                        // Swing 2: diagonal slash
                out[5] = kf(p, 0, 0, .3f, side * 40f, .65f, side * -55f, 1, 0);
                out[3] = kf(p, 0, 0, .3f, 20, .65f, -55, 1, 0);
                out[4] = kf(p, 0, 0, .65f, side * -30f, 1, 0);
                out[1] = kf(p, 0, 0, .3f, .1f, .65f, -.12f, 1, 0);
            }
            case 7 -> {                                        // Bonk: overhead slam
                out[3] = kf(p, 0, 0, .35f, 38, .5f, -85, .7f, -70, 1, 0);
                out[1] = kf(p, 0, 0, .35f, .28f, .5f, -.2f, 1, 0);
                out[2] = kf(p, 0, 0, .5f, -.35f, 1, 0);
            }
            case 8 -> {                                        // Circle: the hand draws a loop
                double a = 2 * Math.PI * p;
                out[0] = (float) (.28 * Math.sin(a));
                out[1] = (float) (.28 * (1 - Math.cos(a)));
                out[2] = -.2f * e;
                out[5] = (float) (side * -35 * Math.sin(a));
            }
            case 9 -> {                                        // Shift: slides sideways across the screen
                out[0] = side * -.55f * e;
                out[4] = side * -25f * e;
                out[5] = side * 15f * e;
                out[2] = -.15f * e;
            }
            case 10 -> {                                       // Realism: heavy, with wind-up and follow-through
                out[2] = kf(p, 0, 0, .3f, .18f, .55f, -.55f, 1, 0);
                out[1] = kf(p, 0, 0, .3f, .06f, .55f, -.1f, 1, 0);
                out[3] = kf(p, 0, 0, .3f, 14, .55f, -48, 1, 0);
                out[5] = kf(p, 0, 0, .55f, side * -12f, 1, 0);
                out[4] = kf(p, 0, 0, .55f, side * 10f, 1, 0);
            }
            case 11 -> {                                       // Slap: flat sweep with the back of the hand
                out[5] = kf(p, 0, 0, .25f, side * 35f, .5f, side * -70f, 1, 0);
                out[4] = kf(p, 0, 0, .5f, side * -55f, 1, 0);
                out[0] = kf(p, 0, 0, .25f, side * .2f, .5f, side * -.45f, 1, 0);
                out[2] = kf(p, 0, 0, .5f, -.2f, 1, 0);
                out[3] = kf(p, 0, 0, .5f, -20, 1, 0);
            }
            case 12 -> {                                       // Spin: the item does a full turn
                out[4] = kf(p, 0, 0, 1, side * 360f);
                out[3] = -20f * e;
                out[2] = -.2f * e;
            }
            default -> { }                                     // 0 = Standard: vanilla swing
        }
    }
}

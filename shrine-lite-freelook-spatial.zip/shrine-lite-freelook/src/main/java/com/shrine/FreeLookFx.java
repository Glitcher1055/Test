package com.shrine;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWScrollCallback;

import java.util.Locale;

/**
 * Player > "FreeLook": hold a key (Left Alt by default, changeable in Controls) and the camera orbits around the
 * player while the player keeps looking where he looked. Let go and the camera flies back smoothly.
 *
 * How it works (see mixin/CameraMixin and mixin/EntityLookMixin):
 *  - while FreeLook is on, mouse movement changes OUR yaw / pitch instead of the player's (Entity.changeLookDirection is skipped),
 *  - Camera.update asks the player for yaw / pitch -> during that call we answer with the FreeLook angles,
 *    so vanilla third person places the camera behind / in front of them by itself,
 *  - the distance of vanilla third person is replaced with ours (animated: "fly out" and "return"),
 *  - the mouse wheel changes the distance while the key is held (GLFW scroll callback, no mixin needed).
 * Because the player's own rotation never changes, the crosshair, attacks and movement stay on the real direction.
 */
public final class FreeLookFx {
    private FreeLookFx() {}

    public static final String KEY = "player.freelook", K_MODE = "player.freelook.mode", K_VIEW = "player.freelook.view",
            K_DIST = "player.freelook.dist", K_SMOOTH = "player.freelook.smooth", K_RETURN = "player.freelook.return",
            K_FLY = "player.freelook.fly", K_SCROLL = "player.freelook.scroll", K_INVERT = "player.freelook.invert",
            K_PUSH = "player.freelook.push";

    private static final int OFF = 0, ACTIVE = 1, RETURN = 2;
    private static int state = OFF;
    private static boolean toggled, cameraPass, scrollHooked;
    private static KeyBinding key;
    private static GLFWScrollCallback prevScroll;
    private static Perspective orig = Perspective.FIRST_PERSON;
    private static float camYaw, camPitch, tgtYaw, tgtPitch, dist, scrollDist;
    private static long lastMs;

    // ---------- settings ----------
    public static boolean enabled() { return ShrineCfg.bool(KEY, false); }
    private static int view() { return Math.max(0, Math.min(2, ShrineCfg.integer(K_VIEW, 0))); }   // 0 back, 1 front, 2 eyes
    private static float baseDist() { return MathHelper.clamp(ShrineCfg.num(K_DIST, 4f), 1f, 12f); }
    private static float val(String k, float def) { return MathHelper.clamp(ShrineCfg.num(k, def), 0f, 100f); }
    private static float ease(float rate, float dt) { return 1f - (float) Math.exp(-rate * dt); }

    static void reset() {
        ShrineCfg.setInt(K_MODE, 0);
        ShrineCfg.setInt(K_VIEW, 0);
        ShrineCfg.setNum(K_DIST, 4f);
        ShrineCfg.setNum(K_SMOOTH, 51f);
        ShrineCfg.setNum(K_RETURN, 45f);
        ShrineCfg.setNum(K_FLY, 89f);
        ShrineCfg.setBool(K_SCROLL, true);
        ShrineCfg.setBool(K_INVERT, false);
        ShrineCfg.setBool(K_PUSH, false);
        ShrineCfg.save();
    }

    static String keyName() {
        try { return key != null ? key.getBoundKeyLocalizedText().getString() : "Left Alt"; }
        catch (Throwable t) { return "Left Alt"; }
    }

    // ---------- state for the mixins ----------
    public static boolean active() { return state != OFF; }
    public static float dist() { return dist; }
    public static float yaw() { return camYaw; }
    public static float pitch() { return camPitch; }
    public static boolean pushThrough() { return state != OFF && ShrineCfg.bool(K_PUSH, false); }
    public static boolean isPlayer(Object e) { return e != null && e == MinecraftClient.getInstance().player; }
    /** True only while Camera.update runs: the player then "has" the FreeLook angles. */
    public static boolean overriding(Object e) { return cameraPass && isPlayer(e); }

    // ---------- registration ----------
    public static void register(KeyBinding.Category cat) {
        key = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.shrine.freelook", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_LEFT_ALT, cat));
        ClientTickEvents.END_CLIENT_TICK.register(FreeLookFx::tick);
    }

    // ---------- key handling (once per tick) ----------
    private static void tick(MinecraftClient c) {
        hookScroll(c);
        if (key == null) return;
        boolean toggleMode = ShrineCfg.integer(K_MODE, 0) == 1;
        boolean can = enabled() && c.player != null && c.world != null && c.currentScreen == null;
        boolean want;
        if (toggleMode) {
            while (key.wasPressed()) { if (can) toggled = !toggled; else hint(c); }
            if (!can) toggled = false;
            want = toggled;
        } else {
            while (key.wasPressed()) hint(c);
            toggled = false;
            want = can && key.isPressed();
        }
        if (c.player == null || !enabled()) {
            if (state != OFF) finish(c);
            return;
        }
        if (want && state != ACTIVE) begin(c);
        else if (!want && state == ACTIVE) state = RETURN;
    }

    /** Key pressed while the function is switched off in the menu: tell the player why nothing happens. */
    private static void hint(MinecraftClient c) {
        if (enabled() || c.player == null || c.currentScreen != null || c.inGameHud == null) return;
        c.inGameHud.setOverlayMessage(Text.literal("FreeLook выключен: Right Shift - Player - FreeLook"), false);
    }

    private static void begin(MinecraftClient c) {
        if (state == OFF) {
            orig = c.options.getPerspective();
            camYaw = tgtYaw = c.player.getYaw();
            camPitch = tgtPitch = c.player.getPitch();
            dist = orig == Perspective.FIRST_PERSON ? 0f : 4f;     // start from what the player sees now
        } else {                                                    // key pressed again while flying back
            tgtYaw = camYaw;
            tgtPitch = camPitch;
        }
        scrollDist = baseDist();
        Perspective p = switch (view()) {
            case 1 -> Perspective.THIRD_PERSON_FRONT;
            case 2 -> Perspective.FIRST_PERSON;
            default -> Perspective.THIRD_PERSON_BACK;
        };
        c.options.setPerspective(p);
        state = ACTIVE;
        lastMs = Util.getMeasuringTimeMs();
        if (c.inGameHud != null) c.inGameHud.setOverlayMessage(Text.literal("FreeLook: включён"), false);
    }

    private static void finish(MinecraftClient c) {
        if (state != OFF && c != null && c.options != null) c.options.setPerspective(orig);
        state = OFF;
        cameraPass = false;
        toggled = false;
    }

    // ---------- per frame: called at the start of Camera.update ----------
    public static void frame() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (state == OFF) {
            // Spatial Inventory: the camera slides over the shoulder while a container is open and flies back after
            if (c.player != null && SpatialInvFx.camStep(c)) {
                camYaw = c.player.getYaw() + SpatialInvFx.yawOff();
                camPitch = MathHelper.clamp(c.player.getPitch() + SpatialInvFx.pitchOff(), -90f, 90f);
                cameraPass = true;
            }
            return;
        }
        if (c.player == null) { finish(c); return; }
        long now = Util.getMeasuringTimeMs();
        float dt = MathHelper.clamp((now - lastMs) / 1000f, 0f, 0.1f);
        lastMs = now;

        if (state == ACTIVE) {
            float s = val(K_SMOOTH, 51f);
            float ks = s <= 0.5f ? 1f : ease(2f + 38f * (1f - s / 100f), dt);       // 0 = instant, 100 = very floaty
            camYaw += MathHelper.wrapDegrees(tgtYaw - camYaw) * ks;
            camPitch += (tgtPitch - camPitch) * ks;
            float goal = view() == 2 ? 0f : scrollDist;
            dist += (goal - dist) * ease(2f + val(K_FLY, 89f) * 0.2f, dt);
        } else {
            float kr = ease(2f + val(K_RETURN, 45f) * 0.2f, dt);
            float py = c.player.getYaw(), pp = c.player.getPitch();
            float goal = orig == Perspective.FIRST_PERSON ? 0f : 4f;
            camYaw += MathHelper.wrapDegrees(py - camYaw) * kr;
            camPitch += (pp - camPitch) * kr;
            dist += (goal - dist) * kr;
            if (Math.abs(MathHelper.wrapDegrees(py - camYaw)) < 0.3f && Math.abs(pp - camPitch) < 0.3f
                    && Math.abs(goal - dist) < 0.05f) finish(c);
        }
        cameraPass = state != OFF;
    }

    public static void endFrame() { cameraPass = false; }

    // ---------- mouse ----------
    /** Mouse movement while FreeLook is held. Returns true when the player's own rotation must NOT change. */
    public static boolean look(double dx, double dy) {
        if (state != ACTIVE) return false;
        float inv = ShrineCfg.bool(K_INVERT, false) ? -1f : 1f;
        tgtYaw += (float) dx * 0.15f;
        tgtPitch = MathHelper.clamp(tgtPitch + (float) dy * 0.15f * inv, -90f, 90f);
        return true;
    }

    /** Wheel changes the camera distance while FreeLook is held (instead of scrolling the hotbar). */
    private static boolean scroll(double dy) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (state != ACTIVE || c.currentScreen != null || view() == 2 || !ShrineCfg.bool(K_SCROLL, true)) return false;
        scrollDist = MathHelper.clamp(scrollDist - (float) dy * 0.5f, 1f, 12f);
        if (c.inGameHud != null)
            c.inGameHud.setOverlayMessage(Text.literal(String.format(Locale.ROOT, "Дистанция камеры: %.1f", scrollDist)), false);
        return true;
    }

    /** Wraps the game's own scroll callback: ours first, everything else goes to vanilla untouched. */
    private static void hookScroll(MinecraftClient c) {
        if (scrollHooked || c.getWindow() == null) return;
        scrollHooked = true;
        try {
            long handle = c.getWindow().getHandle();
            prevScroll = GLFW.glfwSetScrollCallback(handle, (w, xo, yo) -> {
                if (scroll(yo)) return;
                if (prevScroll != null) prevScroll.invoke(w, xo, yo);
            });
        } catch (Throwable ignored) { }
    }
}

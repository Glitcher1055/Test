package com.shrine;

import com.shrine.Gfx.Fnt;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.MessageScreen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.ingame.AbstractSignEditScreen;
import net.minecraft.client.gui.screen.ingame.BookEditScreen;
import net.minecraft.client.gui.screen.ingame.BookScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.GameOptionsScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.widget.CheckboxWidget;
import net.minecraft.client.gui.widget.PressableWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextWidget;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.util.Util;

/**
 * PS5 look for the world creation flow ("Создание мира", game rules, experiments, data packs, world editing):
 * while {@link #active} is true, those screens get the Shrine backdrop and their buttons / fields / tabs
 * are drawn as glass pills. The mixins only call into this class.
 */
public final class WorldCreateFx {
    private WorldCreateFx() {}

    /** True while a world creation / editing screen (or a sub-screen of it) is open. */
    public static boolean active;

    /** True on the Settings screens (Настройки and its sub-screens): list-row look instead of pills. */
    public static boolean settings() {
        Screen s = MinecraftClient.getInstance().currentScreen;
        return s instanceof GameOptionsScreen || s instanceof OptionsScreen;
    }

    /** True whenever the PS5 skin should be applied (world creation flow or settings). */
    public static boolean skin() { return active || settings() || pause() || menuLike(); }

    /**
     * Every other menu-type screen (confirmations, "Сохранение мира", disconnected, resource packs, ...) gets the
     * PS5 look too. Screens you play in (inventories, chat, books, signs, death) and our own screens are left alone.
     */
    public static boolean menuLike() {
        Screen s = MinecraftClient.getInstance().currentScreen;
        if (s == null) return false;
        String cn = s.getClass().getName();   // F3+F4 game mode switcher: a transient in-game overlay, keep it vanilla
        if (cn.equals("net.minecraft.class_5289") || cn.equals("net.minecraft.client.gui.screen.GameModeSwitcherScreen")) return false;
        return !(s instanceof HandledScreen<?> || s instanceof ChatScreen || s instanceof BookScreen
                || s instanceof BookEditScreen || s instanceof AbstractSignEditScreen || s instanceof DeathScreen
                || s instanceof TitleScreen || s instanceof ConnectScreen || s instanceof GameMenuScreen
                || s instanceof ShrineMenuScreen || s instanceof PsMultiplayerScreen
                || s instanceof PsSingleplayerScreen || s instanceof WarningScreen);
    }

    /** A "message" screen: nothing to click, only a title ("Сохранение мира", "Подготовка..."). Drawn with a spinner. */
    public static boolean messageScreen() {
        Screen s = MinecraftClient.getInstance().currentScreen;
        if (s == null || active || settings() || pause() || !menuLike()) return false;
        if (s instanceof MessageScreen) return true;     // its title is a NarratedMultilineTextWidget, not a TextWidget
        for (Element e : s.children()) if (!(e instanceof TextWidget)) return false;
        return true;
    }

    /** True on the in-game pause menu ("Меню"): PS5 control-center cards instead of vanilla buttons. */
    public static boolean pause() { return MinecraftClient.getInstance().currentScreen instanceof GameMenuScreen; }

    /** Mouse position (GUI units) of the frame being drawn; set by the background mixin. */
    public static int mx, my;

    /** The vanilla centered title sits in the first ~28 GUI px: on settings screens we draw our own at the left. */
    public static boolean isHeaderTitle(ClickableWidget w) { return settings() ? w.getY() < 28 : (pause() || messageScreen()); }

    // ---------- main "Настройки" page: vertical list with icons, like the PS5 settings ----------
    private static final Map<ClickableWidget, Identifier> ICONS = new IdentityHashMap<>();
    private static final String[] KEYS = {"options.online", "options.skinCustomisation", "options.sounds", "options.video",
            "options.controls", "options.language", "options.chat", "options.resourcepack", "options.accessibility",
            "options.telemetry", "options.credits_and_attribution"};
    private static final Identifier[] KEY_ICONS = {Gfx.ICO_ONLINE, Gfx.ICO_SKIN, Gfx.ICO_SOUND, Gfx.ICO_VIDEO,
            Gfx.ICO_CONTROLS, Gfx.ICO_LANGUAGE, Gfx.I_CHAT, Gfx.ICO_PACK, Gfx.ICO_ACCESS, Gfx.ICO_DATA, Gfx.ICO_INFO};

    /**
     * Re-lays out the vanilla Settings buttons as one vertical list (the buttons stay the real vanilla ones,
     * so every click still opens the right screen). Called after the screen has been initialised.
     */
    public static void layoutSettings(Screen screen) {
        ICONS.clear();
        float k = screen.height / Scene.REF_H;
        if (k <= 0f) return;
        float vw = screen.width / k;
        List<ClickableWidget> rows = new ArrayList<>();
        ClickableWidget done = null;
        String doneText = ScreenTexts.DONE.getString();
        for (ClickableWidget w : Screens.getButtons(screen)) {
            if (w instanceof TextWidget) {                    // vanilla centered title: we draw our own at the left
                if (w.getY() < 28) w.visible = false;
                continue;
            }
            if (w instanceof SliderWidget) { w.visible = false; continue; }   // FOV is also in the video settings
            if (!(w instanceof PressableWidget)) continue;
            String m = w.getMessage().getString();
            if (m.isEmpty()) { w.visible = false; continue; }                  // difficulty lock icon
            if (m.equals(doneText)) done = w; else rows.add(w);
        }
        rows.sort((a, b) -> a.getY() != b.getY() ? Integer.compare(a.getY(), b.getY()) : Integer.compare(a.getX(), b.getX()));

        float listW = Math.min(vw * 0.68f, 760f), x0 = (vw - listW) / 2f + 20f;
        float top = 96f, bottom = 462f;
        float rowH = Math.min(46f, (bottom - top) / Math.max(1, rows.size()));
        for (int i = 0; i < rows.size(); i++) {
            ClickableWidget w = rows.get(i);
            w.setX(Math.round(x0 * k));
            w.setY(Math.round((top + i * rowH) * k));
            w.setWidth(Math.max(40, Math.round(listW * k)));
            w.setHeight(Math.max(12, Math.round(rowH * k)));
            Identifier icon = Gfx.I_GEAR;
            String m = w.getMessage().getString();
            for (int j = 0; j < KEYS.length; j++) {
                if (m.equals(Text.translatable(KEYS[j]).getString())) { icon = KEY_ICONS[j]; break; }
            }
            ICONS.put(w, icon);
        }
        if (done != null) {
            float dw = 300f, dh = 38f;
            done.setX(Math.round((vw - dw) / 2f * k));
            done.setY(Math.round(486f * k));
            done.setWidth(Math.round(dw * k));
            done.setHeight(Math.round(dh * k));
        }
    }

    private static final Scene SCENE = new Scene();
    private static int sw, sh;
    static { SCENE.instantBackdrop = true; }   // continues the backdrop of the previous Shrine screen

    public static void backdrop(DrawContext ctx, Screen s, float delta) {
        if (s.width != sw || s.height != sh) {
            sw = s.width; sh = s.height;
            SCENE.init(sw, sh);
        }
        if (pause()) { pauseBackdrop(ctx, s, delta); return; }
        SCENE.begin(ctx, 0, 0, delta);
        SCENE.stars(ctx, delta);
        if (s instanceof GameOptionsScreen || s instanceof OptionsScreen) {
            Gfx.text(ctx, MinecraftClient.getInstance().textRenderer, Fnt.TITLE, s.getTitle().getString(), 54f, 45f, Gfx.argb(1f, 0xFFFFFF));
        } else if (messageScreen()) {
            // spinner + title in the middle, like the PS5 "please wait" screens
            TextRenderer tr = MinecraftClient.getInstance().textRenderer;
            float cx = SCENE.vw / 2f, cy = 250f;
            int n = 10;
            float head = (SCENE.time * 5f) % n;
            for (int i = 0; i < n; i++) {
                float ang = (float) (i * Math.PI * 2 / n) - 1.5708f;
                float trail = ((head - i) % n + n) % n / n;          // 0 = brightest dot
                float a = 0.15f + 0.85f * (1f - trail);
                Gfx.centered(ctx, Gfx.DISC, cx + (float) Math.cos(ang) * 22f, cy + (float) Math.sin(ang) * 22f,
                        7f, 7f, Gfx.argb(a, 0xFFFFFF));
            }
            String title = s.getTitle().getString();
            if (title.isEmpty()) title = "Подождите…";
            Gfx.textC(ctx, tr, Fnt.TITLE, title, cx, 310f, Gfx.argb(1f, 0xFFFFFF));
        }
        SCENE.end(ctx);
    }

    // ---------- pause menu: PS5 control-center cards ----------
    private static final class Card {
        final boolean exit; final Identifier icon; final String sub; float anim;
        Card(boolean exit, Identifier icon, String sub) { this.exit = exit; this.icon = icon; this.sub = sub; }
    }
    private static final Map<ClickableWidget, Card> CARDS = new IdentityHashMap<>();
    private static final List<ClickableWidget> ORDER = new ArrayList<>();
    private static ClickableWidget exitBtn;
    private static int pauseSel;
    private static float lastPx, lastPy;
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");
    // translation key -> {subtitle}; icon in the parallel array. Order here = order of the cards.
    private static final String[] P_KEYS = {"menu.returnToGame", "gui.advancements", "menu.options", "menu.shareToLan",
            "gui.stats", "menu.sendFeedback", "menu.reportBugs"};
    private static final String[] P_SUBS = {"Продолжить", "Прогресс", "Игра и управление", "Для друзей",
            "Ваши данные", "Ссылка", "Ссылка"};
    private static final Identifier[] P_ICONS = {Gfx.I_ENTER, Gfx.I_ACTIVITY, Gfx.I_GEAR, Gfx.I_FRIENDS,
            Gfx.ICO_DATA, Gfx.I_CHAT, Gfx.ICO_INFO};
    private static final String[] EXIT_KEYS = {"menu.returnToMenu", "menu.disconnect"};

    /** Called after the pause screen is initialised: sorts the vanilla buttons into cards + the exit button. */
    public static void initPause(Screen screen) {
        CARDS.clear(); ORDER.clear(); exitBtn = null; pauseSel = 0;
        List<ClickableWidget> found = new ArrayList<>();
        for (ClickableWidget w : Screens.getButtons(screen)) {
            if (!(w instanceof PressableWidget)) continue;
            if (w.getMessage().getString().isEmpty()) { w.visible = false; continue; }
            found.add(w);
        }
        List<ClickableWidget> cards = new ArrayList<>();
        for (ClickableWidget w : found) {
            String m = w.getMessage().getString();
            boolean exit = false;
            for (String k : EXIT_KEYS) if (m.equals(Text.translatable(k).getString())) exit = true;
            if (exit) { exitBtn = w; CARDS.put(w, new Card(true, null, "")); continue; }
            Identifier icon = Gfx.ICO_INFO; String sub = "";
            for (int i = 0; i < P_KEYS.length; i++) {
                if (m.equals(Text.translatable(P_KEYS[i]).getString())) { icon = P_ICONS[i]; sub = P_SUBS[i]; break; }
            }
            CARDS.put(w, new Card(false, icon, sub));
            cards.add(w);
        }
        cards.sort((a, b) -> Integer.compare(rank(a), rank(b)));
        ORDER.addAll(cards);
    }

    private static int rank(ClickableWidget w) {
        String m = w.getMessage().getString();
        for (int i = 0; i < P_KEYS.length; i++) if (m.equals(Text.translatable(P_KEYS[i]).getString())) return i;
        return 100 + w.getY();
    }

    private static int lerp(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    /** Dimmed game behind, title + clock on top, and the cards laid out (selected one is bigger). */
    private static void pauseBackdrop(DrawContext ctx, Screen s, float delta) {
        float k = SCENE.k;
        if (k <= 0f) return;
        float vw = s.width / k;
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;

        // --- selection: hover (only when the mouse moved) or keyboard focus ---
        float px = mx / k, py = my / k;
        boolean moved = Math.abs(px - lastPx) + Math.abs(py - lastPy) > 1f;
        lastPx = px; lastPy = py;
        for (int i = 0; i < ORDER.size(); i++) {
            ClickableWidget w = ORDER.get(i);
            if (moved && mx >= w.getX() && mx <= w.getX() + w.getWidth() && my >= w.getY() && my <= w.getY() + w.getHeight()) pauseSel = i;
            else if (w.isFocused()) pauseSel = i;
        }
        // --- layout (virtual units -> GUI px) ---
        final float SMALL_W = 150f, BIG_W = 210f, SMALL_H = 190f, BIG_H = 250f, GAP = 10f, X0 = 60f, BOTTOM = 450f;
        int n = ORDER.size();
        float natural = n * SMALL_W + (BIG_W - SMALL_W) + Math.max(0, n - 1) * GAP;
        float sc = Math.min(1f, (vw - 2 * X0) / Math.max(1f, natural));
        float x = X0;
        for (int i = 0; i < n; i++) {
            ClickableWidget w = ORDER.get(i);
            Card c = CARDS.get(w);
            c.anim += ((i == pauseSel ? 1f : 0f) - c.anim) * Math.min(1f, delta * 0.35f);
            float cw = (SMALL_W + (BIG_W - SMALL_W) * c.anim) * sc, ch = (SMALL_H + (BIG_H - SMALL_H) * c.anim) * sc;
            w.setX(Math.round(x * k)); w.setY(Math.round((BOTTOM - ch) * k));
            w.setWidth(Math.max(20, Math.round(cw * k))); w.setHeight(Math.max(20, Math.round(ch * k)));
            x += cw + GAP * sc;
        }
        if (exitBtn != null) {
            float ew = 250f, eh = 40f;
            exitBtn.setX(Math.round((vw - X0 - ew) * k)); exitBtn.setY(Math.round(486f * k));
            exitBtn.setWidth(Math.round(ew * k)); exitBtn.setHeight(Math.round(eh * k));
        }

        // --- drawing ---
        ctx.fillGradient(0, 0, s.width, s.height, 0xA8060106, 0xF0120308);
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        Gfx.blit(ctx, Gfx.BEAM, 0, 0, Math.round(vw), Math.round(Scene.REF_H), Gfx.argb(0.30f, Gfx.ACCENT));
        Gfx.text(ctx, tr, Fnt.TITLE, s.getTitle().getString(), 54f, 45f, Gfx.argb(1f, 0xFFFFFF));
        String clock = LocalDateTime.now().format(CLOCK);
        int cw = Gfx.width(tr, Fnt.UI, clock);
        float clockX = vw - 55f - cw;
        Gfx.text(ctx, tr, Fnt.UI, clock, clockX, 45f, Gfx.argb(0.92f, 0xFFFFFF));
        float avCx = clockX - 28f;
        Gfx.centered(ctx, Gfx.DISC, avCx, 45f, 30, 30, Gfx.argb(0.95f, Gfx.ACCENT));
        String name = MinecraftClient.getInstance().getSession().getUsername();
        Gfx.textC(ctx, tr, Fnt.TINY_B, (name == null || name.isEmpty()) ? "?" : name.substring(0, 1).toUpperCase(), avCx, 45f, Gfx.argb(1f, 0xFFFFFF));
        ctx.getMatrices().popMatrix();
    }

    /** Draws one pause card (or the exit pill). @return false if this widget is not part of the pause layout. */
    private static boolean card(DrawContext ctx, TextRenderer tr, ClickableWidget w, float k) {
        Card c = CARDS.get(w);
        if (c == null) return false;
        float x = w.getX() / k, y = w.getY() / k, ww = w.getWidth() / k, hh = w.getHeight() / k;
        String msg = w.getMessage().getString();
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        if (c.exit) {
            boolean hov = w.isHovered() || w.isFocused();
            Gfx.box(ctx, Gfx.RR, x, y, ww, hh, hh / 2f, Gfx.argb(hov ? 0.75f : 0.58f, 0xB03A3A));
            Gfx.box(ctx, Gfx.RR_RING, x, y, ww, hh, hh / 2f, Gfx.argb(hov ? 0.55f : 0.28f, 0xFFFFFF));
            label(ctx, tr, msg, x, y, ww, hh, Gfx.argb(1f, 0xFFB0B0));
            ctx.getMatrices().popMatrix();
            return true;
        }
        float t = c.anim, r = 22f;
        if (t > 0.02f) Gfx.centered(ctx, Gfx.GLOW, x + ww / 2f, y + hh / 2f, ww * 1.9f, hh * 1.5f, Gfx.argb(0.30f * t, Gfx.ACCENT));
        Gfx.box(ctx, Gfx.RR, x, y, ww, hh, r, Gfx.argb(0.62f + 0.30f * t, lerp(0x2C2430, 0xB02633, t)));
        // icon in a white rounded square, top left
        Gfx.box(ctx, Gfx.RR, x + 14f, y + 14f, 32f, 32f, 10f, Gfx.argb(0.96f, 0xFFFFFF));
        Gfx.centered(ctx, c.icon, x + 30f, y + 30f, 18f, 18f, Gfx.argb(1f, 0x14101A));
        // subtitle + title at the bottom (title wraps to two lines / shrinks when the card is narrow)
        float avail = ww - 28f;
        Fnt[] tries = {t > 0.5f ? Fnt.UI_B : Fnt.UI, Fnt.LABEL, Fnt.SMALL};
        Fnt font = Fnt.SMALL; String[] lines = {msg};
        outer:
        for (Fnt f : tries) {
            String[] ls = wrap(tr, f, msg, avail);
            for (String l : ls) if (Gfx.width(tr, f, l) > avail) continue outer;
            font = f; lines = ls; break;
        }
        float lh = font.size + 6f, ty = y + hh - 22f - (lines.length - 1) * lh;
        for (int i = 0; i < lines.length; i++) Gfx.text(ctx, tr, font, lines[i], x + 14f, ty + i * lh, Gfx.argb(1f, 0xFFFFFF));
        if (!c.sub.isEmpty()) Gfx.text(ctx, tr, Fnt.LABEL, c.sub, x + 14f, ty - lh + 2f - 8f, Gfx.argb(0.60f, 0xFFFFFF));
        if (t > 0.02f) Gfx.box(ctx, Gfx.RR_RING, x - 4 * t, y - 4 * t, ww + 8 * t, hh + 8 * t, r + 4 * t, Gfx.argb(0.60f * t, 0xFFFFFF));
        ctx.getMatrices().popMatrix();
        return true;
    }

    private static String[] wrap(TextRenderer tr, Fnt f, String s, float avail) {
        if (Gfx.width(tr, f, s) <= avail) return new String[]{s};
        int mid = s.length() / 2, best = -1;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == ' ' && (best < 0 || Math.abs(i - mid) < Math.abs(best - mid))) best = i;
        }
        if (best < 0) return new String[]{s};
        return new String[]{s.substring(0, best), s.substring(best + 1)};
    }

    // ---------- widget skins (all drawn on the virtual canvas, so they match the other Shrine screens) ----------
    public static void button(DrawContext ctx, ClickableWidget w) {
        float k = SCENE.k;
        if (k <= 0f) return;
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        if (pause() && card(ctx, tr, w, k)) return;
        if (settings()) { row(ctx, tr, w, k); return; }
        float x = w.getX() / k, y = w.getY() / k, ww = w.getWidth() / k, hh = w.getHeight() / k;
        boolean on = w.active, hov = on && w.isHovered();
        float a = on ? 1f : 0.45f;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        Gfx.box(ctx, Gfx.RR, x, y, ww, hh, hh / 2f, Gfx.argb((hov ? 0.30f : 0.15f) * a, 0xFFFFFF));
        Gfx.box(ctx, Gfx.RR_RING, x, y, ww, hh, hh / 2f, Gfx.argb((hov ? 0.75f : 0.20f) * a, 0xFFFFFF));
        label(ctx, tr, w.getMessage().getString(), x, y, ww, hh, Gfx.argb((hov ? 1f : 0.92f) * a, 0xFFFFFF));
        ctx.getMatrices().popMatrix();
    }

    public static void tab(DrawContext ctx, ClickableWidget w, boolean selected) {
        float k = SCENE.k;
        if (k <= 0f) return;
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        float x = w.getX() / k, y = w.getY() / k, ww = w.getWidth() / k, hh = w.getHeight() / k;
        boolean hov = w.isHovered();
        float ph = Math.min(hh, 36f), py = y + (hh - ph) / 2f;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        if (selected) Gfx.box(ctx, Gfx.RR, x + 6f, py, ww - 12f, ph, ph / 2f, Gfx.argb(0.96f, 0xFFFFFF));
        label(ctx, tr, w.getMessage().getString(), x, y, ww, hh,
                selected ? Gfx.argb(1f, 0x14101A) : Gfx.argb(hov ? 1f : 0.80f, 0xFFFFFF));
        ctx.getMatrices().popMatrix();
    }

    public static void field(DrawContext ctx, TextFieldWidget f) {
        float k = SCENE.k;
        if (k <= 0f) return;
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        float x = f.getX() / k, y = f.getY() / k, ww = f.getWidth() / k, hh = f.getHeight() / k;
        boolean focused = f.isFocused();
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        Gfx.box(ctx, Gfx.RR, x, y, ww, hh, hh / 2.6f, Gfx.argb(0.09f, 0xFFFFFF));
        Gfx.box(ctx, Gfx.RR_RING, x, y, ww, hh, hh / 2.6f, Gfx.argb(focused ? 0.70f : 0.16f, 0xFFFFFF));

        String t = f.getText();
        float cy = y + hh / 2f, tx = x + 14f, avail = ww - 28f;
        boolean blink = ((int) (Util.getMeasuringTimeMs() / 450L)) % 2 == 0;
        int start = 0;
        while (start < t.length() - 1 && Gfx.width(tr, Fnt.LABEL, t.substring(start)) > avail) start++;
        if (!t.isEmpty()) Gfx.text(ctx, tr, Fnt.LABEL, t.substring(start), tx, cy, Gfx.argb(1f, 0xFFFFFF));
        if (focused && blink) {
            int cur = Math.max(start, Math.min(t.length(), f.getCursor()));
            float cx = tx + (t.isEmpty() ? 0 : Gfx.width(tr, Fnt.LABEL, t.substring(start, cur)));
            ctx.fill(Math.round(cx), Math.round(cy - 9), Math.round(cx) + 2, Math.round(cy + 9), Gfx.argb(0.95f, 0xFFFFFF));
        }
        ctx.getMatrices().popMatrix();
    }

    /** Centered label that shrinks to a smaller font if it does not fit. */
    private static void label(DrawContext ctx, TextRenderer tr, String s, float x, float y, float w, float h, int color) {
        Fnt font = Gfx.width(tr, Fnt.UI, s) <= w - 16f ? Fnt.UI
                : (Gfx.width(tr, Fnt.LABEL, s) <= w - 12f ? Fnt.LABEL : Fnt.SMALL);
        Gfx.textC(ctx, tr, font, s, x + w / 2f, y + h / 2f, color);
    }

    /** PS5 settings row: no fill, thin separator, outlined when hovered, label left, value right. */
    private static void row(DrawContext ctx, TextRenderer tr, ClickableWidget w, float k) {
        float x = w.getX() / k, y = w.getY() / k, ww = w.getWidth() / k, hh = w.getHeight() / k;
        String msg = w.getMessage().getString();
        boolean on = w.active, hov = on && (w.isHovered() || w.isFocused());
        float a = on ? 1f : 0.40f;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        if (ScreenTexts.DONE.getString().equals(msg)) {
            Gfx.box(ctx, Gfx.RR, x, y, ww, hh, hh / 2f, Gfx.argb((hov ? 1f : 0.96f) * a, 0xFFFFFF));
            label(ctx, tr, msg, x, y, ww, hh, Gfx.argb(a, 0x14101A));
        } else if (ScreenTexts.CANCEL.getString().equals(msg) || ScreenTexts.BACK.getString().equals(msg)) {
            Gfx.box(ctx, Gfx.RR, x, y, ww, hh, hh / 2f, Gfx.argb((hov ? 0.30f : 0.15f) * a, 0xFFFFFF));
            Gfx.box(ctx, Gfx.RR_RING, x, y, ww, hh, hh / 2f, Gfx.argb((hov ? 0.75f : 0.20f) * a, 0xFFFFFF));
            label(ctx, tr, msg, x, y, ww, hh, Gfx.argb(a, 0xFFFFFF));
        } else {
            float r = Math.min(hh / 2.4f, 10f);
            if (hov) {
                Gfx.box(ctx, Gfx.RR, x, y, ww, hh, r, Gfx.argb(0.07f * a, 0xFFFFFF));
                Gfx.box(ctx, Gfx.RR_RING, x, y, ww, hh, r, Gfx.argb(0.80f * a, 0xFFFFFF));
            } else {
                ctx.fill(Math.round(x + 6f), Math.round(y + hh) - 1, Math.round(x + ww - 6f), Math.round(y + hh), Gfx.argb(0.12f * a, 0xFFFFFF));
            }
            Identifier icon = ICONS.get(w);
            if (icon != null) {
                String lab = msg.replaceAll("(…|\\.\\.\\.)$", "");
                Gfx.centered(ctx, icon, x + 34f, y + hh / 2f, Math.min(28f, hh * 0.72f), Math.min(28f, hh * 0.72f),
                        Gfx.argb((hov ? 1f : 0.92f) * a, 0xFFFFFF));
                Gfx.text(ctx, tr, Fnt.UI, lab, x + 70f, y + hh / 2f, Gfx.argb((hov ? 1f : 0.92f) * a, 0xFFFFFF));
                ctx.getMatrices().popMatrix();
                return;
            }
            String label = msg, value = null;
            int c = msg.indexOf(": ");
            if (c > 0 && c < msg.length() - 2) { label = msg.substring(0, c); value = msg.substring(c + 2); }
            Fnt font = Gfx.width(tr, Fnt.UI, msg) + 40f <= ww ? Fnt.UI : Fnt.LABEL;
            int col = Gfx.argb((hov ? 1f : 0.92f) * a, 0xFFFFFF);
            Gfx.text(ctx, tr, font, label, x + 16f, y + hh / 2f, col);
            if (value != null) {
                Gfx.text(ctx, tr, font, value, x + ww - 16f - Gfx.width(tr, font, value), y + hh / 2f, Gfx.argb(0.62f * a, 0xFFFFFF));
            } else if (w instanceof CheckboxWidget cb) {
                float cx = x + ww - 28f, cy = y + hh / 2f;
                Gfx.centered(ctx, Gfx.DISC, cx, cy, 20f, 20f, Gfx.argb(0.18f * a, 0xFFFFFF));
                if (cb.isChecked()) Gfx.centered(ctx, Gfx.DISC, cx, cy, 12f, 12f, Gfx.argb(a, 0xFFFFFF));
            }
        }
        ctx.getMatrices().popMatrix();
    }
}

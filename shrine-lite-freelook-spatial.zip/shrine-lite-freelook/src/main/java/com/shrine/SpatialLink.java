package com.shrine;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

/**
 * Visual = the bundled Spatial GUI mod (inventories / containers as a 3D plane, tilt, camera swing) + YetAnotherConfigLib.
 * Both ship unmodified inside our jar (META-INF/jars). Right Shift opens Spatial GUI's own YACL settings screen.
 * Reflection only: no compile-time dependency on the nested jars, and no Mod Menu needed.
 */
final class SpatialLink {
    private SpatialLink() {}

    static void open(MinecraftClient c) {
        Screen s = config(c.currentScreen);
        if (s != null) c.setScreen(s);
        else if (c.inGameHud != null)
            c.inGameHud.setOverlayMessage(net.minecraft.text.Text.literal("Spatial GUI не найден в сборке"), false);
    }

    /** SpatialGUIConfig.HANDLER.generateGui().generateScreen(parent) */
    static Screen config(Screen parent) {
        try {
            Class<?> cfg = Class.forName("org.tastytrash.spatialGUI.client.SpatialGUIConfig");
            Field f = cfg.getDeclaredField("HANDLER");
            f.setAccessible(true);
            Object handler = f.get(null);
            Method gen = null;
            for (Method m : handler.getClass().getMethods())
                if (m.getName().equalsIgnoreCase("generateGui") && m.getParameterCount() == 0) gen = m;
            Object lib = gen.invoke(handler);
            Method scr = null;
            for (Method m : lib.getClass().getMethods())
                if (m.getName().equals("generateScreen") && m.getParameterCount() == 1 && !Modifier.isStatic(m.getModifiers())) scr = m;
            return (Screen) scr.invoke(lib, parent);
        } catch (Throwable t) {
            return null;
        }
    }
}

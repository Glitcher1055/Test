package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.joml.Matrix3x2f;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import static com.shrine.Gfx.*;

/**
 * "Траектории полёта": landing marker for ender pearls, snowballs, eggs, potions, XP bottles, arrows and tridents.
 * Shows where the thing will land BEFORE you throw it (item in hand / bow being drawn / loaded crossbow) and
 * for projectiles already in the air (yours and other players'). The marker turns red when the projectile
 * would hit a living target.
 *
 * Drawn as a 2D HUD overlay: 3D points are projected to the screen by hand (camera position, yaw / pitch, FOV),
 * so no world-render API is needed. First person only.
 */
final class TrajectoryFx {
    private TrajectoryFx() {}

    static final String K_ON = "fx.traj", K_LEN = "fx.traj.len", K_TIME = "fx.traj.time", K_PRED = "fx.traj.predict",
            K_OTH = "fx.traj.others", K_LINE = "fx.traj.line", K_RED = "fx.traj.red", K_SIZE = "fx.traj.size",
            K_COL = "fx.traj.color";

    private static final Identifier ARCS = tex("mark_arcs"), RING_T = tex("mark_ring"), DOT_T = tex("mark_dot"),
            TIMER = tex("ico_timer");
    private static final int HIT_RED = 0xFF3A3A;
    private static final Vec3d UP = new Vec3d(0, 1, 0);

    static void init() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "trajectory"),
                TrajectoryFx::render);
    }

    // ---------------------------------------------------------------- camera / projection

    private static final class Cam {
        Vec3d pos, fwd, right, up;
        float f, cx, cy;

        /** {screenX, screenY, depth} or null when the point is behind the camera. */
        float[] proj(Vec3d p) {
            Vec3d d = p.subtract(pos);
            double z = d.dotProduct(fwd);
            if (z < 0.05) return null;
            double x = d.dotProduct(right), y = d.dotProduct(up);
            return new float[]{(float) (cx + x / z * f), (float) (cy - y / z * f), (float) z};
        }
    }

    // ---------------------------------------------------------------- simulation

    private record Shot(double speed, double gravity, double roll, boolean arrow) {}

    private static final class Result {
        final List<Vec3d> pts = new ArrayList<>();
        Vec3d end, normal = UP;
        LivingEntity target;
        double ticks;
    }

    private static String path(net.minecraft.item.Item it) { return Registries.ITEM.getId(it).getPath(); }

    /** What the player would throw / shoot right now, or null. */
    private static Shot held(ClientPlayerEntity p) {
        for (Hand hand : Hand.values()) {
            ItemStack st = p.getStackInHand(hand);
            if (st.isEmpty()) continue;
            boolean using = p.isUsingItem() && p.getActiveItem().getItem() == st.getItem();
            switch (path(st.getItem())) {
                case "ender_pearl", "snowball", "egg" -> { return new Shot(1.5, 0.03, 0, false); }
                case "splash_potion", "lingering_potion" -> { return new Shot(0.5, 0.05, -20, false); }
                case "experience_bottle" -> { return new Shot(0.7, 0.07, -20, false); }
                case "trident" -> { if (using) return new Shot(2.5, 0.05, 0, true); }
                case "bow" -> {
                    if (using) {
                        float pull = BowItem.getPullProgress(p.getItemUseTime());
                        if (pull >= 0.1f) return new Shot(pull * 3.0, 0.05, 0, true);
                    }
                }
                case "crossbow" -> { if (CrossbowItem.isCharged(st)) return new Shot(3.15, 0.05, 0, true); }
                default -> { }
            }
        }
        return null;
    }

    private static Result sim(ClientWorld w, Entity shooter, Entity skip, Vec3d pos, Vec3d vel, double grav,
                              boolean arrow, int steps, List<LivingEntity> targets) {
        Result r = new Result();
        r.pts.add(pos);
        for (int i = 0; i < steps; i++) {
            Vec3d next = pos.add(vel);
            BlockHitResult bh = w.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER,
                    RaycastContext.FluidHandling.NONE, shooter));
            boolean blockHit = bh.getType() != HitResult.Type.MISS;
            double best = blockHit ? bh.getPos().squaredDistanceTo(pos) : Double.MAX_VALUE;
            LivingEntity hitE = null;
            Vec3d hitP = null;
            for (LivingEntity e : targets) {
                if (e == skip) continue;
                Optional<Vec3d> o = e.getBoundingBox().expand(0.3).raycast(pos, next);
                if (o.isPresent()) {
                    double d = o.get().squaredDistanceTo(pos);
                    if (d < best) { best = d; hitE = e; hitP = o.get(); }
                }
            }
            double len = Math.max(1.0e-6, vel.length());
            if (hitE != null) {
                r.end = hitP; r.target = hitE; r.normal = UP;
                r.ticks = i + Math.sqrt(best) / len;
                r.pts.add(hitP);
                return r;
            }
            if (blockHit) {
                r.end = bh.getPos();
                r.normal = new Vec3d(bh.getSide().getOffsetX(), bh.getSide().getOffsetY(), bh.getSide().getOffsetZ());
                r.ticks = i + Math.sqrt(best) / len;
                r.pts.add(r.end);
                return r;
            }
            pos = next;
            r.pts.add(pos);
            boolean water = w.getFluidState(BlockPos.ofFloored(pos)).isIn(FluidTags.WATER);
            double drag = water ? (arrow ? 0.6 : 0.8) : 0.99;
            vel = vel.multiply(drag).subtract(0, grav, 0);
            if (pos.y < w.getBottomY() - 8) break;
        }
        return r;
    }

    // ---------------------------------------------------------------- frame

    private static void render(DrawContext ctx, RenderTickCounter counter) {
        if (!ShrineCfg.bool(K_ON, true)) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null || mc.options.hudHidden || !mc.options.getPerspective().isFirstPerson()) return;
        float tp = counter.getTickProgress(false);

        Cam cam = new Cam();
        cam.pos = p.getCameraPosVec(tp);
        double yaw = Math.toRadians(p.getYaw(tp)), pit = Math.toRadians(p.getPitch(tp));
        cam.fwd = new Vec3d(-Math.sin(yaw) * Math.cos(pit), -Math.sin(pit), Math.cos(yaw) * Math.cos(pit));
        cam.right = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
        cam.up = cam.right.crossProduct(cam.fwd);
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        double fov = mc.options.getFov().getValue();
        cam.f = (float) ((sh / 2.0) / Math.tan(Math.toRadians(fov) / 2.0));
        cam.cx = sw / 2f;
        cam.cy = sh / 2f;

        int steps = Math.max(10, Math.round(ShrineCfg.num(K_LEN, 120f)));
        List<LivingEntity> targets = new ArrayList<>();
        for (Entity e : w.getEntities()) {
            if (e instanceof LivingEntity le && le != p && le.isAlive() && !le.isSpectator()
                    && le.squaredDistanceTo(p) < 90 * 90 && targets.size() < 64) targets.add(le);
        }

        // projectiles already in the air (yours and other players')
        if (ShrineCfg.bool(K_OTH, true)) {
            int shown = 0;
            for (Entity e : w.getEntities()) {
                if (shown >= 10) break;
                if (!(e instanceof ProjectileEntity pe) || e.squaredDistanceTo(p) > 96 * 96) continue;
                double grav; boolean arrow = false;
                switch (Registries.ENTITY_TYPE.getId(e.getType()).getPath()) {
                    case "ender_pearl", "snowball", "egg" -> grav = 0.03;
                    case "splash_potion", "lingering_potion", "potion" -> grav = 0.05;
                    case "experience_bottle" -> grav = 0.07;
                    case "arrow", "spectral_arrow", "trident" -> { grav = 0.05; arrow = true; }
                    default -> { continue; }
                }
                Vec3d v = e.getVelocity();
                if (v.lengthSquared() < 0.0025) continue;           // stuck in a block / standing still
                Result r = sim(w, e, pe.getOwner(), e.getLerpedPos(tp), v, grav, arrow, steps, targets);
                draw(ctx, mc, cam, r, p);
                shown++;
            }
        }

        // what you are about to throw
        if (ShrineCfg.bool(K_PRED, true)) {
            Shot s = held(p);
            if (s != null) {
                double ya = yaw, pi = pit, ro = Math.toRadians(s.roll());
                Vec3d dir = new Vec3d(-Math.sin(ya) * Math.cos(pi), -Math.sin(pi + ro), Math.cos(ya) * Math.cos(pi))
                        .normalize().multiply(s.speed());
                Vec3d pv = p.getVelocity();
                dir = dir.add(pv.x, p.isOnGround() ? 0 : pv.y, pv.z);
                Vec3d start = p.getCameraPosVec(tp).subtract(0, 0.1, 0);
                Result r = sim(w, p, p, start, dir, s.gravity(), s.arrow(), steps, targets);
                draw(ctx, mc, cam, r, p);
            }
        }
    }

    // ---------------------------------------------------------------- drawing

    private static void draw(DrawContext ctx, MinecraftClient mc, Cam cam, Result r, ClientPlayerEntity me) {
        boolean red = r.target != null && ShrineCfg.bool(K_RED, true);
        int idx = Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, ShrineCfg.integer(K_COL, 7)));
        int col = red ? HIT_RED : ShrineGui.PALETTE[idx];

        // dotted line from you to the landing point
        if (ShrineCfg.bool(K_LINE, true) && r.pts.size() > 1) {
            int n = r.pts.size();
            float[] prev = null;
            int dots = 0;
            for (int i = 0; i < n && dots < 700; i++) {
                float[] cur = cam.proj(r.pts.get(i));
                if (cur != null && prev != null) {
                    float dx = cur[0] - prev[0], dy = cur[1] - prev[1];
                    float dist = (float) Math.sqrt(dx * dx + dy * dy);
                    if (dist < 400f) {
                        int m = Math.max(1, (int) (dist / 4f));
                        for (int j = 0; j < m; j++) {
                            float t = (float) j / m;
                            float fade = Math.min(1f, (i + t) / Math.max(6f, n * 0.25f));
                            centered(ctx, DISC, prev[0] + dx * t, prev[1] + dy * t, 2.4f, 2.4f, argb(0.6f * fade, 0xFFFFFF));
                            dots++;
                        }
                    }
                }
                prev = cur;
            }
        }
        if (r.end == null) return;

        // ground (or wall) marker: three layers, affinely mapped onto the surface plane
        float size = 0.55f * Math.max(0.3f, ShrineCfg.num(K_SIZE, 1f));
        Vec3d at = r.target != null ? new Vec3d(r.end.x, r.target.getY(), r.end.z) : r.end.add(r.normal.multiply(0.02));
        Vec3d n = r.target != null ? UP : r.normal;
        Vec3d h = Math.abs(n.y) > 0.9 ? new Vec3d(1, 0, 0) : new Vec3d(0, 1, 0);
        Vec3d u = n.crossProduct(h).normalize(), v = n.crossProduct(u).normalize();
        float time = Util.getMeasuringTimeMs() / 1000f;
        float pulse = red ? 0.85f + 0.15f * (float) Math.sin(time * 9f) : 1f;

        float[] c = cam.proj(at);
        if (c == null) return;
        float radiusPx = 0f;
        for (int layer = 0; layer < 3; layer++) {
            float spin = layer == 0 ? time * 1.4f : layer == 1 ? 0f : -time * 1.4f + 0.785f;
            float s = layer == 0 ? 1f : layer == 1 ? 0.56f : 0.30f;
            Vec3d ur = u.multiply(Math.cos(spin)).add(v.multiply(Math.sin(spin))).multiply(size);
            Vec3d vr = v.multiply(Math.cos(spin)).subtract(u.multiply(Math.sin(spin))).multiply(size);
            float[] a = cam.proj(at.add(ur)), b = cam.proj(at.add(vr));
            if (a == null || b == null) return;
            float ax = a[0] - c[0], ay = a[1] - c[1], bx = b[0] - c[0], by = b[1] - c[1];
            radiusPx = Math.max(radiusPx, (float) Math.max(Math.hypot(ax, ay), Math.hypot(bx, by)));
            if (radiusPx > 600f) return;
            var m = ctx.getMatrices();
            m.pushMatrix();
            m.translate(c[0], c[1]);
            m.mul(new Matrix3x2f(ax / 32f * s, ay / 32f * s, bx / 32f * s, by / 32f * s, 0f, 0f));
            if (layer == 0) blit(ctx, ARCS, -32, -32, 64, 64, argb(0.95f * pulse, col));
            else if (layer == 1) blit(ctx, RING_T, -32, -32, 64, 64, argb(0.9f, 0xFFFFFF));
            else blit(ctx, DOT_T, -32, -32, 64, 64, argb(0.95f * pulse, col));
            m.popMatrix();
        }

        // labels above the marker: "в цель" and flight time
        var tr = mc.textRenderer;
        float ly = c[1] - Math.max(radiusPx * 0.6f, 6f) - 16f;
        if (ShrineCfg.bool(K_TIME, true)) {
            String ts = String.format(Locale.ROOT, "%.1f", r.ticks / 20.0).replace('.', ',') + "s";
            float tw = width(tr, Fnt.TINY_B, ts), pw = tw + 32f;
            float px = c[0] - pw / 2f;
            box(ctx, RR, px, ly - 9, pw, 18, 9, argb(0.90f, 0x0E0B14));
            box(ctx, RR_RING, px, ly - 9, pw, 18, 9, argb(0.16f, 0xFFFFFF));
            centered(ctx, TIMER, px + 11, ly, 9, 9, argb(1f, HIT_RED));
            text(ctx, tr, Fnt.TINY_B, ts, px + 21, ly, argb(1f, 0xFFFFFF));
            ly -= 22f;
        }
        if (red) {
            String s = "в цель";
            float pw = width(tr, Fnt.TINY_B, s) + 22f, px = c[0] - pw / 2f;
            box(ctx, RR, px, ly - 9, pw, 18, 9, argb(0.96f, 0xE5384D));
            textC(ctx, tr, Fnt.TINY_B, s, c[0], ly, argb(1f, 0xFFFFFF));
        }
    }
}

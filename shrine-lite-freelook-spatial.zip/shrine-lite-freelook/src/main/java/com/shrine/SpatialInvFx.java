package com.shrine;

import com.shrine.mixin.HandledScreenAccess;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.util.Util;
import org.joml.Matrix3x2f;

import java.lang.reflect.Constructor;
import java.lang.reflect.RecordComponent;

import static com.shrine.Gfx.*;

/**
 * Visual > "Spatial Inventory": inventory / chest / crafting open as a floating panel inside the world instead of a dim overlay.
 *  - no dark background or blur: the world stays visible (ScreenBackgroundMixin),
 *  - the panel unfolds (swings in from the side) when it opens,
 *  - it tilts after the cursor (flat affine tilt, same trick the old floating screen used),
 *  - the camera slides over the shoulder while it is open and flies back smoothly after it closes (FreeLookFx.frame -> camStep),
 *  - Shrine glass frame behind the vanilla texture.
 * Mouse input is mapped back through the inverse of the tilt (HandledScreenMixin), so slots stay clickable.
 */
public final class SpatialInvFx {
    private SpatialInvFx() {}

    public static final String KEY = "visual.spatialinv", K_TILT = "visual.spatialinv.tilt", K_CAM = "visual.spatialinv.cam",
            K_GLASS = "visual.spatialinv.glass", K_STR = "visual.spatialinv.str";

    // panel transform: x' = ta*dx + tc*dy, y' = tb*dx + td*dy around (cx, cy), then shifted by (ox, bob)
    private static Screen cur;
    private static long openedMs, lastMs, camMs;
    private static float tYaw, tPitch, ta = 1f, tb, tc, td = 1f, cx, cy, ox, bob, open;
    private static float camK;
    private static boolean pushed, mapped;
    private static int rx, ry;
    private static Constructor<Click> clickCtor;
    private static RecordComponent[] clickComps;

    public static boolean enabled() { return ShrineCfg.bool(KEY, false); }
    public static boolean on(Object screen) { return screen instanceof HandledScreen<?> && enabled(); }
    /** Mixins ask this before touching anything. */
    public static boolean active() { return mapped && on(MinecraftClient.getInstance().currentScreen); }

    static void register() {}   // nothing to tick: everything runs from render / Camera.update

    public static void hook(Screen screen) {
        ScreenEvents.beforeRender(screen).register((s, ctx, mx, my, dt) -> before(s, ctx, mx, my));
        ScreenEvents.afterRender(screen).register((s, ctx, mx, my, dt) -> after(ctx));
        ScreenEvents.remove(screen).register(s -> { mapped = false; });
    }

    private static float clampf(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }

    // ---------------- panel ----------------
    private static void before(Screen s, DrawContext ctx, int mx, int my) {
        pushed = false;
        mapped = false;
        rx = mx; ry = my;
        if (!on(s) || !(s instanceof HandledScreenAccess acc)) return;
        long now = Util.getMeasuringTimeMs();
        if (s != cur) { cur = s; openedMs = now; lastMs = 0; tYaw = 0f; tPitch = 0f; }
        float dt = lastMs == 0 ? 0.016f : Math.min(0.1f, (now - lastMs) / 1000f);
        lastMs = now;

        int pw = acc.shrine$bgW(), ph = acc.shrine$bgH(), px = acc.shrine$x(), py = acc.shrine$y();
        cx = px + pw / 2f; cy = py + ph / 2f;

        float t = Math.min(1f, (now - openedMs) / 420f);
        open = 1f - (1f - t) * (1f - t) * (1f - t);                 // ease-out cubic

        float str = ShrineCfg.bool(K_TILT, true) ? clampf(ShrineCfg.num(K_STR, 50f), 0f, 100f) / 50f : 0f;
        float sec = (now - openedMs) / 1000f;
        float wantYaw = (clampf((mx - cx) / 200f, -1f, 1f) * 9f + (float) Math.sin(sec * 0.7f) * 1.8f) * str;
        float wantPit = (-clampf((my - cy) / 130f, -1f, 1f) * 5f + (float) Math.cos(sec * 0.9f) * 1.1f) * str;
        float sm = 1f - (float) Math.exp(-7f * dt);
        tYaw += (wantYaw - tYaw) * sm;
        tPitch += (wantPit - tPitch) * sm;

        float un = 1f - open;                                        // 1 = folded, 0 = open
        float yaw = (float) Math.toRadians(tYaw - un * 52f);         // swings in from the side while unfolding
        float pit = (float) Math.toRadians(tPitch);
        float sc = (0.80f + 0.20f * open) * (1f - Math.abs((float) Math.sin(yaw)) * 0.04f);
        ta = (float) Math.cos(yaw) * sc;
        tb = (float) Math.sin(yaw) * 0.20f;
        tc = (float) Math.sin(pit) * 0.20f;
        td = (float) Math.cos(pit) * sc;
        ox = -un * 26f;
        bob = str > 0f ? (float) Math.sin(sec * 1.3f) * 1.6f : 0f;

        // the vanilla screen gets the cursor in panel space; the transform below puts it back under the real cursor
        float[] l = toLocal(mx, my);
        rx = Math.round(l[0]); ry = Math.round(l[1]);
        mapped = true;

        ctx.getMatrices().pushMatrix();
        pushed = true;
        ctx.getMatrices().translate(cx + ox, cy + bob);
        ctx.getMatrices().mul(new Matrix3x2f(ta, tb, tc, td, 0f, 0f));
        ctx.getMatrices().translate(-cx, -cy);

        if (ShrineCfg.bool(K_GLASS, true)) {
            float x = px - 8f, y = py - 8f, w = pw + 16f, h = ph + 16f;
            box(ctx, RR, x + 5, y + 14, w - 2, h, 16, argb(0.30f * open, 0x000000));        // floating shadow
            box(ctx, RR, x, y, w, h, 14, argb(0.66f * open, 0x07080C));                     // glass body
            box(ctx, RR_RING, x, y, w, h, 14, argb(0.55f * open, ACCENT));                  // accent ring
            box(ctx, RR_RING, x + 1, y + 1, w - 2, h - 2, 13, argb(0.10f * open, 0xFFFFFF)); // soft inner edge
        }
    }

    private static void after(DrawContext ctx) {
        if (pushed) { ctx.getMatrices().popMatrix(); pushed = false; }
    }

    /** Real cursor (scaled gui units) -> position on the flat panel (undoes the tilt). */
    private static float[] toLocal(double mx, double my) {
        float ux = (float) mx - (cx + ox), uy = (float) my - (cy + bob);
        float det = ta * td - tb * tc;
        if (Math.abs(det) < 1e-4f) return new float[]{(float) mx, (float) my};
        return new float[]{cx + (td * ux - tc * uy) / det, cy + (-tb * ux + ta * uy) / det};
    }

    // ---------------- input mapping (called from HandledScreenMixin) ----------------
    public static int mapX(int mx) { return active() ? rx : mx; }
    public static int mapY(int my) { return active() ? ry : my; }

    /**
     * Click / release / drag arrive in real cursor coordinates: rebuild the record with panel-space x / y.
     * Built by reflection (the first two double components are x and y), any failure leaves the click untouched.
     */
    public static Click remap(Click c) {
        if (!active()) return c;
        try {
            float[] l = toLocal(c.x(), c.y());
            if (clickComps == null) clickComps = Click.class.getRecordComponents();
            RecordComponent[] rc = clickComps;
            if (clickCtor == null) {
                Class<?>[] types = new Class<?>[rc.length];
                for (int i = 0; i < rc.length; i++) types[i] = rc[i].getType();
                clickCtor = Click.class.getDeclaredConstructor(types);
                clickCtor.setAccessible(true);
            }
            Object[] args = new Object[rc.length];
            int d = 0;
            for (int i = 0; i < rc.length; i++) {
                Object v = rc[i].getAccessor().invoke(c);
                if (rc[i].getType() == double.class && d < 2) v = (double) l[d++];
                args[i] = v;
            }
            return clickCtor.newInstance(args);
        } catch (Throwable t) {
            return c;
        }
    }

    // ---------------- camera (called from FreeLookFx.frame, once per Camera.update) ----------------
    /** Moves the over-the-shoulder progress; true while the camera is not back at rest. */
    public static boolean camStep(MinecraftClient c) {
        long now = Util.getMeasuringTimeMs();
        float dt = camMs == 0 ? 0.016f : Math.min(0.1f, (now - camMs) / 1000f);
        camMs = now;
        boolean want = enabled() && ShrineCfg.bool(K_CAM, true) && c.currentScreen instanceof HandledScreen<?>;
        float goal = want ? 1f : 0f;
        float rate = want ? 5f : 4f;                                  // slides out a bit faster than it returns
        camK += (goal - camK) * (1f - (float) Math.exp(-rate * dt));
        if (!want && camK < 0.002f) camK = 0f;
        return camK > 0f;
    }

    public static float yawOff() { return camK * 15f; }
    public static float pitchOff() { return camK * -3f; }
}

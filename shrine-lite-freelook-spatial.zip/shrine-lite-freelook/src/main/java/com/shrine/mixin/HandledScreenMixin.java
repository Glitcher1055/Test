package com.shrine.mixin;

import com.shrine.SpatialInvFx;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Visual > Spatial Inventory: cursor and clicks are mapped back through the panel tilt so slots stay clickable. */
@Mixin(HandledScreen.class)
public abstract class HandledScreenMixin {

    @ModifyVariable(method = "render", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
    private int shrine$mouseX(int mx) { return SpatialInvFx.mapX(mx); }

    @ModifyVariable(method = "render", at = @At("HEAD"), argsOnly = true, ordinal = 1, require = 0)
    private int shrine$mouseY(int my) { return SpatialInvFx.mapY(my); }

    @ModifyVariable(method = {"mouseClicked", "mouseReleased", "mouseDragged"}, at = @At("HEAD"), argsOnly = true, require = 0)
    private Click shrine$click(Click c) { return SpatialInvFx.remap(c); }
}

package com.shrine.mixin;

import com.shrine.SpatialInvFx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Visual > Spatial Inventory: no dim / blur behind the panel, the world stays visible. */
@Mixin(Screen.class)
public abstract class ScreenBackgroundMixin {

    @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true, require = 0)
    private void shrine$noDim(DrawContext context, int mouseX, int mouseY, float deltaTicks, CallbackInfo ci) {
        if (SpatialInvFx.on(this)) ci.cancel();
    }
}

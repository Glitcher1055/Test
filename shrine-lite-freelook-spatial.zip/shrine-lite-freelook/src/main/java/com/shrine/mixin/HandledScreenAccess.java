package com.shrine.mixin;

import net.minecraft.client.gui.screen.ingame.HandledScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Panel rectangle of any container screen (for the Spatial Inventory frame and tilt pivot). */
@Mixin(HandledScreen.class)
public interface HandledScreenAccess {
    @Accessor("x") int shrine$x();
    @Accessor("y") int shrine$y();
    @Accessor("backgroundWidth") int shrine$bgW();
    @Accessor("backgroundHeight") int shrine$bgH();
}

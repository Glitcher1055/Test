package com.shrine;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Synced lyrics of one song. Source: a .lrc file with the same name next to the mp3 ("song.mp3" + "song.lrc"),
 * optionally downloaded once from lrclib.net (opt-in toggle in the music settings) and saved as that .lrc file.
 * Plain LRC gives a time per line; words are timed by their length. Enhanced LRC (word tags like {@code <00:12.50>}) is
 * used as is.
 */
final class Lyrics {

    static final class Line {
        final float start; float end; final String text; final String[] words; final float[] ws;   // ws: start time of every word
        Line(float start, String text, String[] words, float[] ws) { this.start = start; this.text = text; this.words = words; this.ws = ws; }
        boolean blank() { return words.length == 0; }
    }

    final List<Line> lines = new ArrayList<>();

    // ---------- query ----------
    /** Index of the line that started last before {@code t}; -1 before the first line. */
    int index(float t) {
        int lo = 0, hi = lines.size() - 1, res = -1;
        while (lo <= hi) {
            int mid = (lo + hi) >>> 1;
            if (lines.get(mid).start <= t) { res = mid; lo = mid + 1; } else hi = mid - 1;
        }
        return res;
    }

    /** Index of the word being sung in the line at time t; -1 before the first word. */
    static int wordAt(Line l, float t) {
        int r = -1;
        for (int i = 0; i < l.ws.length; i++) if (l.ws[i] <= t) r = i;
        return r;
    }

    // ---------- parsing ----------
    private static final Pattern STAMP = Pattern.compile("\\[(\\d{1,3}):(\\d{1,2})(?:[.:](\\d{1,3}))?]");
    private static final Pattern WORD_TAG = Pattern.compile("<(\\d{1,3}):(\\d{1,2})(?:[.:](\\d{1,3}))?>");
    private static final Pattern OFFSET = Pattern.compile("^\\[offset:\\s*(-?\\d+)\\s*]", Pattern.CASE_INSENSITIVE);

    private static float secs(String m, String s, String f) {
        float v = Integer.parseInt(m) * 60f + Integer.parseInt(s);
        if (f != null) v += Integer.parseInt(f) / (float) Math.pow(10, f.length());
        return v;
    }

    static Lyrics parse(String lrc) {
        Lyrics ly = new Lyrics();
        float offset = 0f;
        for (String raw : lrc.split("\\r?\\n")) {
            String row = raw.trim();
            if (row.isEmpty()) continue;
            Matcher om = OFFSET.matcher(row);
            if (om.find()) { try { offset = Integer.parseInt(om.group(1)) / 1000f; } catch (Throwable ignored) { } continue; }
            Matcher m = STAMP.matcher(row);
            List<Float> stamps = new ArrayList<>();
            int end = 0;
            while (m.find() && m.start() == end) {
                try { stamps.add(secs(m.group(1), m.group(2), m.group(3))); } catch (Throwable ignored) { }
                end = m.end();
            }
            if (stamps.isEmpty()) continue;                 // metadata like [ar:...], [ti:...]
            String body = row.substring(end).trim();
            for (float st : stamps) ly.lines.add(build(st - offset, body));
            if (ly.lines.size() > 4000) break;
        }
        ly.lines.sort(Comparator.comparingDouble(l -> l.start));
        // line ends: next line start; a very long line is cut so words don't crawl across a long pause
        for (int i = 0; i < ly.lines.size(); i++) {
            Line l = ly.lines.get(i);
            float next = i + 1 < ly.lines.size() ? ly.lines.get(i + 1).start : l.start + 6f;
            l.end = l.blank() ? next : Math.min(next, l.start + 10f);
            if (!l.blank() && isPlain(l)) retime(l);
        }
        return ly;
    }

    /** Plain lines carry provisional negative word times (set in build()); enhanced lines have real ones. */
    private static boolean isPlain(Line l) { return l.ws.length > 0 && l.ws[0] < 0f; }

    /** Builds a line; plain text gets provisional (negative) word times that retime() replaces. */
    private static Line build(float start, String body) {
        if (WORD_TAG.matcher(body).find()) {
            List<String> w = new ArrayList<>();
            List<Float> t = new ArrayList<>();
            Matcher m = WORD_TAG.matcher(body);
            int pos = 0;
            float cur = start;
            while (m.find()) {
                String seg = body.substring(pos, m.start()).trim();
                if (!seg.isEmpty()) for (String piece : seg.split("\\s+")) { w.add(piece); t.add(cur); }
                try { cur = secs(m.group(1), m.group(2), m.group(3)); } catch (Throwable ignored) { }
                pos = m.end();
            }
            String tail = body.substring(pos).trim();
            if (!tail.isEmpty()) for (String piece : tail.split("\\s+")) { w.add(piece); t.add(cur); }
            if (!w.isEmpty()) {
                float[] ws = new float[w.size()];
                for (int i = 0; i < ws.length; i++) ws[i] = Math.max(0f, t.get(i));
                return new Line(start, String.join(" ", w), w.toArray(new String[0]), ws);
            }
        }
        body = WORD_TAG.matcher(body).replaceAll("").trim();
        String[] words = body.isEmpty() ? new String[0] : body.split("\\s+");
        float[] ws = new float[words.length];
        java.util.Arrays.fill(ws, -1f);
        return new Line(start, body, words, ws);
    }

    /** Spread the words of a plain line over its duration, longer words get more time. */
    private static void retime(Line l) {
        int n = l.words.length;
        float total = 0f;
        for (String w : l.words) total += w.length() + 1;
        float span = Math.max(0.3f, (l.end - l.start) * 0.9f), acc = 0f;
        for (int i = 0; i < n; i++) {
            l.ws[i] = l.start + span * acc / total;
            acc += l.words[i].length() + 1;
        }
    }

    // ---------- files ----------
    static Path fileFor(MusicPlayer.Track t) {
        String f = t.file;
        String base = f.toLowerCase(Locale.ROOT).endsWith(".mp3") ? f.substring(0, f.length() - 4) : f;
        return t.path.resolveSibling(base + ".lrc");
    }

    static String decode(byte[] b) {
        int off = b.length >= 3 && (b[0] & 0xFF) == 0xEF && (b[1] & 0xFF) == 0xBB && (b[2] & 0xFF) == 0xBF ? 3 : 0;
        try {
            return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                    .decode(ByteBuffer.wrap(b, off, b.length - off)).toString();
        } catch (CharacterCodingException e) {
            return new String(b, off, b.length - off, Charset.forName("windows-1251"));
        }
    }

    static Lyrics load(Path p) throws Exception {
        if (Files.size(p) > (1 << 20)) throw new IllegalStateException("файл текста слишком большой");
        Lyrics ly = parse(decode(Files.readAllBytes(p)));
        return ly.lines.isEmpty() ? null : ly;
    }

    // ---------- lrclib.net (opt-in) ----------
    private static String enc(String s) { return URLEncoder.encode(s, StandardCharsets.UTF_8); }

    /** One request to lrclib.net/api/search; returns the synced lyrics of the best match or null. */
    static String fetch(String title, String artist, float duration) throws Exception {
        String q = artist.isEmpty() ? "q=" + enc(title) : "track_name=" + enc(title) + "&artist_name=" + enc(artist);
        HttpClient c = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(6)).followRedirects(HttpClient.Redirect.NORMAL).build();
        HttpRequest rq = HttpRequest.newBuilder(URI.create("https://lrclib.net/api/search?" + q))
                .timeout(Duration.ofSeconds(10)).header("User-Agent", "Shrine-mod/1.0").GET().build();
        HttpResponse<String> rs = c.send(rq, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        if (rs.statusCode() != 200) return null;
        JsonElement root = JsonParser.parseString(rs.body());
        if (!root.isJsonArray()) return null;
        JsonArray arr = root.getAsJsonArray();
        String best = null;
        double bestDiff = Double.MAX_VALUE;
        for (JsonElement e : arr) {
            if (!e.isJsonObject()) continue;
            JsonObject o = e.getAsJsonObject();
            JsonElement sl = o.get("syncedLyrics");
            if (sl == null || sl.isJsonNull() || sl.getAsString().isBlank()) continue;
            double d = duration > 0f && o.has("duration") && !o.get("duration").isJsonNull()
                    ? Math.abs(o.get("duration").getAsDouble() - duration) : 0d;
            if (d < bestDiff) { bestDiff = d; best = sl.getAsString(); }
        }
        return best;
    }
}

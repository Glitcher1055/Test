package com.shrine;

import net.minecraft.util.Identifier;

/** Generated texture table. Sizes are in texels; textures are rendered at K x 1080p reference size. */
public final class Textures {
    public static final float K = 1.5f;

    public static final class Tex {
        public final Identifier id; public final int w, h;
        Tex(String name, int w, int h) {
            this.id = Identifier.of("shrine", "textures/gui/" + name + ".png"); this.w = w; this.h = h;
        }
    }

    public static final Tex DOT = new Tex("dot", 64, 64);
    public static final Tex ORB = new Tex("orb", 128, 128);
    public static final Tex BEAM = new Tex("beam", 1024, 576);
    public static final Tex BTN_IDLE = new Tex("btn_idle", 384, 384);
    public static final Tex BTN_FOCUS = new Tex("btn_focus", 384, 384);
    public static final Tex ICON_GEAR = new Tex("icon_gear", 96, 96);
    public static final Tex ICON_PERSON = new Tex("icon_person", 96, 96);
    public static final Tex ICON_GROUP = new Tex("icon_group", 96, 96);
    public static final Tex LABEL_SETTINGS = new Tex("label_settings", 213, 62);
    public static final Tex LABEL_SINGLE = new Tex("label_single", 315, 62);
    public static final Tex LABEL_MULTI = new Tex("label_multi", 264, 62);
    public static final Tex SUBTITLE = new Tex("subtitle", 502, 66);
    public static final Tex FOOTER = new Tex("footer", 359, 41);
    public static final Tex TITLE = new Tex("title", 1255, 126);
    public static final Tex COLON = new Tex("colon", 25, 64);
    public static final Tex COMMA = new Tex("comma", 25, 64);
    public static final Tex[] DIGITS = {new Tex("d0", 29, 64), new Tex("d1", 29, 64), new Tex("d2", 29, 64), new Tex("d3", 29, 64), new Tex("d4", 29, 64), new Tex("d5", 29, 64), new Tex("d6", 29, 64), new Tex("d7", 29, 64), new Tex("d8", 29, 64), new Tex("d9", 29, 64)};
    public static final Tex[] WEEKDAYS = {new Tex("day0", 294, 64), new Tex("day1", 185, 64), new Tex("day2", 148, 64), new Tex("day3", 180, 64), new Tex("day4", 195, 64), new Tex("day5", 193, 64), new Tex("day6", 287, 64)};

    /** Button canvas / disc size in texels (disc diameter = 240). */
    public static final float BTN_DISC = 240f;

    private Textures() {}
}

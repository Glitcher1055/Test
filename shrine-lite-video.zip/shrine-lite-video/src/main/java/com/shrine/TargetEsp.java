package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.Vec3d;

import static com.shrine.Gfx.*;

/**
 * Target > "Таргет": a ghost model with a wireframe, the distance number and a selectable effect around the entity
 * you look at (like the target ESP of many visual mods).
 *
 * Everything is drawn as a 2D overlay: the 3D points are projected to the screen by hand (camera position, yaw, pitch,
 * FOV from the options), so no world-render API is needed. The same drawing code runs in the game and in the preview
 * on the settings page - only the {@link Proj} differs.
 */
final class TargetEsp {
    private TargetEsp() {}

    static final String KEY = "target.esp", K_FX = "target.esp.fx", K_GHOST = "target.esp.ghost",
            K_DIST = "target.esp.dist", K_COLOR = "target.esp.color";

    static final String[] FX = {"Нет", "Осколки", "Кольцо", "Два кольца", "Пульс", "Цепь", "Вихрь", "Крестики", "Искры", "Орбиты"};
    static final String[] FX_DESC = {
            "Только призрачная модель",
            "Светящиеся ромбики разлетаются от тела",
            "Кольцо поднимается и опускается по телу",
            "Два кольца навстречу друг другу",
            "Волны расходятся по земле",
            "Цепь из звеньев вокруг пояса",
            "Светлые огоньки с хвостом кружат вокруг",
            "Крестики всплывают вокруг цели",
            "Мелкие искры поднимаются вверх",
            "Три орбиты с летящими шарами"};

    static int fx() { return Math.max(0, Math.min(FX.length - 1, ShrineCfg.integer(K_FX, 1))); }
    static int color() {
        int i = Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, ShrineCfg.integer(K_COLOR, 6)));
        return ShrineGui.PALETTE[i];
    }

    // ---------- projection ----------
    /** Maps an offset from the target's feet (world axes, blocks) to the screen: out = {x, y, pixelsPerBlock}. */
    interface Proj { boolean p(double dx, double dy, double dz, float[] out); }

    /** Size and facing of what is drawn. */
    record Body(float h, float w, float yaw, boolean biped) {}

    // ---------- the in-game element ----------
    private static LivingEntity last;
    private static long seen;

    static void register() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "target_esp"),
                (ctx, tick) -> render(ctx, tick.getTickProgress(false)));
    }

    private static void render(DrawContext ctx, float td) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.options.hudHidden) return;
        if (!ShrineCfg.bool(KEY, false)) { last = null; return; }
        if (!mc.options.getPerspective().isFirstPerson()) return;   // the projection below is a first-person camera

        Entity looked = mc.targetedEntity;
        LivingEntity target = looked instanceof LivingEntity le && !(looked instanceof ArmorStandEntity) ? le : null;
        long now = Util.getMeasuringTimeMs();
        if (target != null) { last = target; seen = now; }
        if (last == null) return;
        float a = target != null ? 1f : 1f - (now - seen) / 350f;
        if (a <= 0f || last.isRemoved() || !last.isAlive()) { last = null; return; }
        a = 1f - (1f - a) * (1f - a);

        final Vec3d cam = mc.player.getCameraPosVec(td);
        double yr = Math.toRadians(mc.player.getYaw(td)), pr = Math.toRadians(mc.player.getPitch(td));
        final double fx = -Math.sin(yr) * Math.cos(pr), fy = -Math.sin(pr), fz = Math.cos(yr) * Math.cos(pr);
        final double rx = -Math.cos(yr), rz = -Math.sin(yr);
        final double ux = -rz * fy, uy = rz * fx - rx * fz, uz = rx * fy;
        final double W = ctx.getScaledWindowWidth(), H = ctx.getScaledWindowHeight();
        final double tanHalf = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        final Vec3d base = last.getLerpedPos(td);

        Proj proj = (dx, dy, dz, o) -> {
            double x = base.x + dx - cam.x, y = base.y + dy - cam.y, z = base.z + dz - cam.z;
            double zc = x * fx + y * fy + z * fz;
            if (zc < 0.1) return false;
            double xc = x * rx + z * rz, yc = x * ux + y * uy + z * uz;
            double k = (H / 2.0) / (zc * tanHalf);
            o[0] = (float) (W / 2.0 + xc * k);
            o[1] = (float) (H / 2.0 - yc * k);
            o[2] = (float) k;
            return true;
        };

        boolean biped = last instanceof PlayerEntity || last instanceof ZombieEntity || last instanceof AbstractSkeletonEntity;
        Body body = new Body(last.getHeight(), last.getWidth(), last.getBodyYaw(), biped);
        scene(ctx, mc.textRenderer, proj, body, fx(), ShrineCfg.bool(K_GHOST, true), ShrineCfg.bool(K_DIST, true),
                mc.player.distanceTo(last), color(), a, Util.getMeasuringTimeMs() / 1000f);
    }

    // ---------- the scene (shared with the preview) ----------
    static void scene(DrawContext ctx, TextRenderer tr, Proj pr, Body b, int fx, boolean ghost, boolean dist,
                      float distance, int rgb, float a, float t) {
        if (a <= 0.01f) return;
        if (ghost) ghost(ctx, pr, b, rgb, a);
        Fx f = new Fx(ctx, pr, b, rgb, a, t);
        switch (fx) {
            case 1 -> f.shards();
            case 2 -> f.ring(b.h * tri(t * 0.55f), b.w * 0.55f + 0.35f, 0.05f, a);
            case 3 -> f.twoRings();
            case 4 -> f.pulse();
            case 5 -> f.chain();
            case 6 -> f.wisps();
            case 7 -> f.crosses();
            case 8 -> f.sparks();
            case 9 -> f.orbits();
            default -> { }
        }
        if (dist) {
            float[] o = new float[3];
            if (pr.p(0, b.h * 0.55, 0, o)) textC(ctx, tr, Fnt.SMALL, String.format("%.2f", distance), o[0], o[1], argb(a * 0.95f, 0xFFFFFF));
        }
    }

    // ---------- helpers ----------
    private static float tri(float x) { float f = x - (float) Math.floor(x); return 1f - Math.abs(2f * f - 1f); }

    private static float hash(int n) {
        n = (n << 13) ^ n;
        return ((n * (n * n * 15731 + 789221) + 1376312589) & 0x7fffffff) / 2147483647f;
    }

    private static int mix(int c1, int c2, float k) {
        int r = Math.round(((c1 >> 16) & 255) * (1 - k) + ((c2 >> 16) & 255) * k);
        int g = Math.round(((c1 >> 8) & 255) * (1 - k) + ((c2 >> 8) & 255) * k);
        int bl = Math.round((c1 & 255) * (1 - k) + (c2 & 255) * k);
        return (r << 16) | (g << 8) | bl;
    }

    /** Thin line of any angle and thickness (the matrix is scaled down 4x so the int fill gets 0.25 precision). */
    static void line(DrawContext ctx, float x1, float y1, float x2, float y2, float th, int color) {
        float dx = x2 - x1, dy = y2 - y1;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 0.01f) return;
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(x1, y1);
        m.rotate((float) Math.atan2(dy, dx));
        m.scale(0.25f, 0.25f);
        int t = Math.max(1, Math.round(th * 2f));
        ctx.fill(0, -t, Math.round(len * 4f) + 1, t, color);
        m.popMatrix();
    }

    /** Filled rectangle w x h centered on (x, y) and rotated. */
    static void quad(DrawContext ctx, float x, float y, float w, float h, float rot, int color) {
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.rotate(rot);
        m.scale(0.25f, 0.25f);
        int hw = Math.max(1, Math.round(w * 2f)), hh = Math.max(1, Math.round(h * 2f));
        ctx.fill(-hw, -hh, hw, hh, color);
        m.popMatrix();
    }

    // ---------- ghost model ----------
    // x0, x1, y0, y1, z0, z1 of a 1.8-block-tall player
    private static final float[][] PARTS = {
            {-0.22f, 0.22f, 1.35f, 1.80f, -0.22f, 0.22f},   // head
            {-0.25f, 0.25f, 0.70f, 1.35f, -0.13f, 0.13f},   // torso
            {0.25f, 0.50f, 0.70f, 1.35f, -0.13f, 0.13f},    // arm
            {-0.50f, -0.25f, 0.70f, 1.35f, -0.13f, 0.13f},  // arm
            {0.00f, 0.25f, 0.00f, 0.70f, -0.13f, 0.13f},    // leg
            {-0.25f, 0.00f, 0.00f, 0.70f, -0.13f, 0.13f}};  // leg

    private static void ghost(DrawContext ctx, Proj pr, Body b, int rgb, float a) {
        float[][] parts;
        if (b.biped()) {
            float s = b.h() / 1.8f;
            parts = new float[PARTS.length][6];
            for (int i = 0; i < PARTS.length; i++) for (int j = 0; j < 6; j++) parts[i][j] = PARTS[i][j] * s;
        } else {
            float hw = b.w() / 2f;
            parts = new float[][]{{-hw, hw, 0f, b.h(), -hw, hw}};
        }
        double ya = Math.toRadians(b.biped() ? b.yaw() : 0f), cs = Math.cos(ya), sn = Math.sin(ya);
        float[] o = new float[3];
        float[] px = new float[8], py = new float[8];
        int fill = argb(0.16f * a, rgb), edge = argb(0.60f * a, mix(rgb, 0xFFFFFF, 0.5f));
        for (float[] p : parts) {
            boolean ok = true;
            float minx = 1e9f, miny = 1e9f, maxx = -1e9f, maxy = -1e9f;
            for (int i = 0; i < 8 && ok; i++) {
                float lx = (i & 1) == 0 ? p[0] : p[1], ly = (i & 2) == 0 ? p[2] : p[3], lz = (i & 4) == 0 ? p[4] : p[5];
                double dx = -lx * cs - lz * sn, dz = -lx * sn + lz * cs;
                if (!pr.p(dx, ly, dz, o)) { ok = false; break; }
                px[i] = o[0]; py[i] = o[1];
                minx = Math.min(minx, o[0]); maxx = Math.max(maxx, o[0]);
                miny = Math.min(miny, o[1]); maxy = Math.max(maxy, o[1]);
            }
            if (!ok) continue;
            ctx.fill(Math.round(minx), Math.round(miny), Math.round(maxx), Math.round(maxy), fill);
            for (int i = 0; i < 8; i++)
                for (int bit = 1; bit <= 4; bit <<= 1)
                    if ((i & bit) == 0) line(ctx, px[i], py[i], px[i | bit], py[i | bit], 0.7f, edge);
        }
    }

    // ---------- effects ----------
    private static final class Fx {
        final DrawContext ctx; final Proj pr; final Body b; final int rgb, core; final float a, t;
        final float[] o = new float[3];

        Fx(DrawContext ctx, Proj pr, Body b, int rgb, float a, float t) {
            this.ctx = ctx; this.pr = pr; this.b = b; this.rgb = rgb; this.a = a; this.t = t;
            this.core = mix(rgb, 0xFFFFFF, 0.65f);
        }

        boolean pt(double dx, double dy, double dz) { return pr.p(dx, dy, dz, o); }

        /** Soft glowing dot. */
        void spot(float x, float y, float s, float al) {
            if (al <= 0.01f) return;
            s = Math.max(1f, s);
            centered(ctx, GLOW, x, y, s * 3.2f, s * 3.2f, argb(al * 0.55f, rgb));
            centered(ctx, DISC, x, y, s, s, argb(al, core));
        }

        void ring(float y, float r, float thM, float al) {
            final int N = 40;
            float px = 0, py = 0;
            boolean has = false;
            for (int i = 0; i <= N; i++) {
                double an = Math.PI * 2 * i / N;
                if (!pt(Math.cos(an) * r, y, Math.sin(an) * r)) { has = false; continue; }
                float x = o[0], yy = o[1], s = o[2];
                if (has) {
                    line(ctx, px, py, x, yy, Math.max(1.2f, thM * s * 2.6f), argb(al * 0.22f, rgb));
                    line(ctx, px, py, x, yy, Math.max(0.7f, thM * s), argb(al, core));
                }
                px = x; py = yy; has = true;
            }
        }

        void twoRings() {
            float k = tri(t * 0.5f), r = b.w * 0.55f + 0.35f;
            ring(b.h * k, r, 0.045f, a);
            ring(b.h * (1f - k), r, 0.045f, a);
        }

        void pulse() {
            for (int k = 0; k < 2; k++) {
                float p = t * 0.8f + k * 0.5f;
                p -= (float) Math.floor(p);
                ring(0.03f, 0.25f + p * 1.1f, 0.035f, a * (float) Math.pow(1f - p, 1.5));
            }
        }

        void shards() {
            final int N = 24;
            for (int i = 0; i < N; i++) {
                float ph = t / 1.5f + i / (float) N;
                int cyc = (int) Math.floor(ph);
                float p = ph - cyc;
                int sd = i * 977 + cyc * 131;
                float an = hash(sd) * 6.2832f, rr = b.w * 0.5f * (0.3f + 0.7f * hash(sd + 1));
                float y0 = b.h * (0.05f + 0.85f * hash(sd + 2));
                float out = rr + p * (0.5f + 0.8f * hash(sd + 3));
                float yy = y0 + p * (0.5f * hash(sd + 4) - 0.1f);
                if (!pt(Math.cos(an) * out, yy, Math.sin(an) * out)) continue;
                float al = a * (float) Math.pow(Math.sin(Math.PI * p), 0.6);
                float sz = (0.10f + 0.16f * hash(sd + 5)) * (1f - 0.5f * p) * o[2];
                float spin = p * (4f + 4f * hash(sd + 6)) + hash(sd + 7) * 6f;
                centered(ctx, GLOW, o[0], o[1], sz * 3f, sz * 3f, argb(al * 0.5f, rgb));
                quad(ctx, o[0], o[1], sz, sz * (0.35f + 0.65f * (float) Math.abs(Math.cos(spin))),
                        (hash(sd + 8) - 0.5f) * 2f + 0.6f, argb(al, core));
            }
        }

        void chain() {
            final int N = 26;
            float ang0 = t * 1.3f, r = 0.62f, y = b.h * 0.5f + 0.08f * (float) Math.sin(t * 2.1f);
            for (int i = 0; i < N; i++) {
                float an = ang0 + 6.2832f * i / N, an2 = an + 0.05f;
                if (!pt(Math.cos(an) * r, y, Math.sin(an) * r)) continue;
                float x = o[0], yy = o[1], s = o[2];
                if (!pt(Math.cos(an2) * r, y, Math.sin(an2) * r)) continue;
                float tang = (float) Math.atan2(o[1] - yy, o[0] - x);
                boolean big = (i & 1) == 0;
                float len = (big ? 0.13f : 0.07f) * s, wid = (big ? 0.065f : 0.04f) * s;
                centered(ctx, GLOW, x, yy, len * 2.6f, len * 2.6f, argb(a * 0.35f, rgb));
                quad(ctx, x, yy, len, wid, big ? tang : tang + 1.5708f, argb(a, core));
            }
        }

        void wisps() {
            for (int w = 0; w < 7; w++) {
                for (int j = 0; j < 10; j++) {
                    float tt = t - j * 0.04f;
                    float ang = tt * (1.4f + 0.5f * hash(w)) + w * 2.4f, r = 0.5f + 0.3f * hash(w + 9);
                    float y = b.h * (0.15f + 0.7f * hash(w + 3)) + 0.12f * (float) Math.sin(tt * 2f + w);
                    if (!pt(Math.cos(ang) * r, y, Math.sin(ang) * r)) continue;
                    float k = 1f - j / 10f;
                    spot(o[0], o[1], 0.07f * k * o[2] + 0.8f, a * k);
                }
            }
        }

        void crosses() {
            final int N = 9;
            for (int i = 0; i < N; i++) {
                float ph = t / 2.2f + i / (float) N;
                int cyc = (int) Math.floor(ph);
                float p = ph - cyc;
                int sd = i * 7 + cyc * 131;
                float an = hash(sd) * 6.2832f, r = 0.5f + 0.5f * hash(sd + 1);
                float y = b.h * (0.1f + 0.8f * hash(sd + 2)) + p * 0.3f;
                if (!pt(Math.cos(an) * r, y, Math.sin(an) * r)) continue;
                float al = a * (float) Math.sin(Math.PI * p);
                float len = 0.14f * o[2], th = Math.max(0.8f, len * 0.16f), rot = p * 4f + hash(sd + 3) * 3f;
                centered(ctx, GLOW, o[0], o[1], len * 2.4f, len * 2.4f, argb(al * 0.35f, rgb));
                quad(ctx, o[0], o[1], len, th, rot, argb(al, core));
                quad(ctx, o[0], o[1], len, th, rot + 1.5708f, argb(al, core));
            }
        }

        void sparks() {
            final int N = 30;
            for (int i = 0; i < N; i++) {
                float ph = t / 1.6f + i / (float) N;
                int cyc = (int) Math.floor(ph);
                float p = ph - cyc;
                int sd = i * 53 + cyc * 211;
                float an = hash(sd) * 6.2832f, r = b.w * 0.8f * hash(sd + 1) + 0.1f;
                float y = p * b.h * 1.1f;
                if (!pt(Math.cos(an) * r, y, Math.sin(an) * r)) continue;
                spot(o[0], o[1], (0.03f + 0.03f * hash(sd + 2)) * o[2], a * (float) Math.sin(Math.PI * p));
            }
        }

        void orbits() {
            final float tau = 0.9f, R = 0.75f;
            for (int i = 0; i < 3; i++) {
                float phi = i * 1.0472f;
                double ux = Math.cos(phi), uz = Math.sin(phi);
                double vx = -Math.sin(phi) * Math.cos(tau), vy = Math.sin(tau), vz = Math.cos(phi) * Math.cos(tau);
                for (int j = 0; j < 12; j++) {
                    float tt = t - j * 0.035f;
                    float th = tt * (2.0f + 0.4f * i) + i * 2.1f;
                    double c = Math.cos(th) * R, s = Math.sin(th) * R;
                    if (!pt(c * ux + s * vx, b.h * 0.55 + s * vy, c * uz + s * vz)) continue;
                    float k = 1f - j / 12f;
                    spot(o[0], o[1], 0.085f * k * o[2] + 0.8f, a * k);
                }
            }
        }
    }
}

package com.shrine.mixin;

import com.shrine.WorldCreateFx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.TextWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Settings screens: the vanilla centered title is hidden, the Shrine backdrop draws it at the top left. */
@Mixin(TextWidget.class)
public class TextWidgetMixin {
    @Inject(method = "renderWidget", at = @At("HEAD"), cancellable = true)
    private void shrine$render(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (WorldCreateFx.isHeaderTitle((ClickableWidget) (Object) this)) ci.cancel();
    }
}

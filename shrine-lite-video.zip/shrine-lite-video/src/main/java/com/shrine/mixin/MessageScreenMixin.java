package com.shrine.mixin;

import com.shrine.WorldCreateFx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.MessageScreen;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * "Сохранение мира", "Подготовка ресурсов..." and the other message screens override renderBackground themselves
 * (blurred world + a black bordered box) without calling Screen.renderBackground, so the general background mixin
 * never sees them. This one replaces that background with the Shrine backdrop (stars, spinner, title).
 */
@Mixin(MessageScreen.class)
public class MessageScreenMixin {
    @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true)
    private void shrine$background(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!WorldCreateFx.skin()) return;
        WorldCreateFx.mx = mouseX;
        WorldCreateFx.my = mouseY;
        WorldCreateFx.backdrop(ctx, (Screen) (Object) this, delta);
        ci.cancel();
    }
}

package com.shrine.mixin;

import com.shrine.WorldCreateFx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** World creation flow: replace the vanilla (dirt / blurred) background with the Shrine backdrop. */
@Mixin(Screen.class)
public class WorldCreateBackgroundMixin {
    @Inject(method = "renderBackground", at = @At("HEAD"), cancellable = true)
    private void shrine$background(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!WorldCreateFx.skin()) return;
        WorldCreateFx.mx = mouseX;
        WorldCreateFx.my = mouseY;
        WorldCreateFx.backdrop(ctx, (Screen) (Object) this, delta);
        ci.cancel();
    }
}

package com.shrine.mixin;

import com.shrine.ConnectView;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.world.LevelLoadingScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** The "Загрузка территории..." screen (after connecting / when opening a world) gets the same PS5 look. */
@Mixin(LevelLoadingScreen.class)
public class LevelLoadingScreenMixin {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void shrine$render(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        ConnectView.render(ctx, mc, mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight(), mouseX, mouseY, delta, true);
        ci.cancel();
    }
}

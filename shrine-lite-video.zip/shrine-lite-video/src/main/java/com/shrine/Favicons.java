package com.shrine;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import java.io.ByteArrayInputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/** Turns a server's favicon bytes (filled in by the ping) into a registered texture. */
final class Favicons {
    private Favicons() {}

    private static final Map<String, Integer> HASHES = new HashMap<>();
    private static final Map<String, Identifier> IDS = new HashMap<>();

    static Identifier get(MinecraftClient mc, ServerInfo info) {
        byte[] bytes = info.getFavicon();
        if (bytes == null || bytes.length == 0) return null;
        String key = info.address;
        int hash = Arrays.hashCode(bytes);
        Integer old = HASHES.get(key);
        if (old != null && old == hash) return IDS.get(key);
        HASHES.put(key, hash);
        IDS.remove(key);
        try (ByteArrayInputStream in = new ByteArrayInputStream(bytes)) {
            NativeImage image = NativeImage.read(in);
            Identifier id = Identifier.of("shrine",
                    "favicon/" + Integer.toHexString(key.hashCode()) + "_" + Integer.toHexString(hash));
            mc.getTextureManager().registerTexture(id, new NativeImageBackedTexture(() -> "shrine favicon", image));
            IDS.put(key, id);
            return id;
        } catch (Exception e) {
            return null;
        }
    }
}

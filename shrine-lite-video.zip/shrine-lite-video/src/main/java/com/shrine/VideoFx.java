package com.shrine;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Visual > "Видеофон": the bundled clip plays as the backdrop of the main menu.
 *
 * Minecraft cannot play video files, so the clip is pre-converted (tools/build_video.py) into one resource,
 * assets/shrine/video/frames.bin: a 20 fps sequence of small JPEG frames. Every frame is decoded on demand and
 * shown as a one-frame texture; the playback position is taken from the clock, so the clip always runs at real
 * speed and loops. Only the frame that is on screen is kept in memory.
 */
final class VideoFx {
    private VideoFx() {}

    static final String KEY = "visual.video", K_OPACITY = "visual.video.opacity";

    private static final String RES = "/assets/shrine/video/frames.bin";
    private static final int MAGIC = 0x53564944;                 // "SVID"
    private static final Identifier ID = Identifier.of("shrine", "video/frame");
    private static final long START = Util.getMeasuringTimeMs();

    private static byte[][] frames;                              // JPEG bytes per frame, loaded once
    private static int fps = 20, tw = 216, th = 384;             // frame size from the header
    private static boolean loadFailed;
    private static int shown = -1;                               // index of the frame in the texture
    private static boolean registered;

    static boolean enabled() { return ShrineCfg.bool(KEY, false); }
    static float opacity() { return Math.max(0f, Math.min(1f, ShrineCfg.num(K_OPACITY, 0.6f))); }

    /** Aspect of one frame (w / h) - used by the settings preview to show the clip without cropping. */
    static float aspect() { return (float) tw / th; }

    private static synchronized void load() {
        if (frames != null || loadFailed) return;
        try (InputStream raw = VideoFx.class.getResourceAsStream(RES)) {
            if (raw == null) throw new IOException("missing " + RES);
            DataInputStream in = new DataInputStream(new BufferedInputStream(raw));
            if (in.readInt() != MAGIC) throw new IOException("bad magic");
            int n = in.readInt();
            fps = Math.max(1, in.readInt());
            tw = in.readInt();
            th = in.readInt();
            int[] len = new int[n];
            for (int i = 0; i < n; i++) len[i] = in.readInt();
            byte[][] f = new byte[n][];
            for (int i = 0; i < n; i++) f[i] = in.readNBytes(len[i]);
            frames = f;
        } catch (IOException e) {
            loadFailed = true;
        }
    }

    /** Decodes one JPEG frame. NativeImage.read handles JPEG on current builds; ImageIO is the fallback. */
    private static NativeImage decode(byte[] jpg) throws IOException {
        try {
            return NativeImage.read(new ByteArrayInputStream(jpg));
        } catch (RuntimeException notReadable) {
            BufferedImage bi = ImageIO.read(new ByteArrayInputStream(jpg));
            if (bi == null) throw new IOException("frame is not an image");
            ByteArrayOutputStream png = new ByteArrayOutputStream();
            ImageIO.write(bi, "png", png);
            return NativeImage.read(new ByteArrayInputStream(png.toByteArray()));
        }
    }

    /** Puts the frame for the current moment into the texture (only when the frame index changes). */
    private static void ensureFrame() {
        load();
        if (frames == null || frames.length == 0) return;
        long ms = Util.getMeasuringTimeMs() - START;
        int idx = (int) ((ms * fps / 1000L) % frames.length);
        if (registered && idx == shown) return;
        try {
            NativeImage img = decode(frames[idx]);
            MinecraftClient mc = MinecraftClient.getInstance();
            if (registered) mc.getTextureManager().destroyTexture(ID);
            mc.getTextureManager().registerTexture(ID, new NativeImageBackedTexture(() -> "shrine video", img));
            registered = true;
            shown = idx;
        } catch (IOException | RuntimeException e) {
            loadFailed = true;      // broken resource: stop trying, the menu simply shows no video
            frames = null;
        }
    }

    /**
     * Draws the clip into a rectangle, cropped to fill it (like CSS "object-fit: cover"), at alpha a.
     * Call it with (w, h) in the same units as the rest of the screen.
     */
    static void draw(DrawContext ctx, float x, float y, float w, float h, float a) {
        if (a <= 0.01f || w <= 0f || h <= 0f) return;
        ensureFrame();
        if (!registered) return;
        float s = Math.max(w / tw, h / th);
        int rw = Math.min(tw, Math.round(w / s)), rh = Math.min(th, Math.round(h / s));
        int u = (tw - rw) / 2, v = (th - rh) / 2;
        ctx.drawTexture(RenderPipelines.GUI_TEXTURED, ID, Math.round(x), Math.round(y), u, v,
                Math.max(1, Math.round(w)), Math.max(1, Math.round(h)), rw, rh, tw, th, Gfx.argb(a, 0xFFFFFF));
    }
}

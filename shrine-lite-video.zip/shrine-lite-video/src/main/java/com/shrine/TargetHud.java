package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.util.Locale;

import static com.shrine.Gfx.*;

/**
 * Target > "Здоровье цели": a panel with name, health and gear of the living entity (player, mob, animal) you look at.
 * Four looks ({@link #DESIGNS}); position and size are saved in the config and edited in {@link HudEditScreen}.
 * It only shows what the server already sends to the client.
 */
final class TargetHud {
    private TargetHud() {}

    static final String KEY = "hud.health", KEY_ARMOR = "hud.armor";
    static final String K_DESIGN = "target.design", K_X = "target.x", K_Y = "target.y", K_SCALE = "target.scale";
    static final String[] DESIGNS = {"Классика", "Круг", "Минимал", "Компакт"};
    static final float DEFAULT_TOP = 300f;

    /** What a panel shows. Real entity or demo values. */
    static final class Data {
        String name = "";
        float hp, max = 20f, shown, abs, dist;
        AbstractClientPlayerEntity skinOf;     // null: letter instead of a skin
        final ItemStack[] gear = new ItemStack[6];   // main hand, off hand, head, chest, legs, feet
        { java.util.Arrays.fill(gear, ItemStack.EMPTY); }
    }

    private static final EquipmentSlot[] SLOTS = {EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND, EquipmentSlot.HEAD,
            EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    private static LivingEntity last;
    private static long seen;
    private static float shown = -1f;
    private static final Data live = new Data();

    static void register() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "target_hud"),
                (ctx, tick) -> render(ctx));
    }

    // ---------- settings ----------
    static int design() { return Math.max(0, Math.min(DESIGNS.length - 1, ShrineCfg.integer(K_DESIGN, 0))); }
    static float posX() { return ShrineCfg.num(K_X, 0f); }
    static float posY() { return ShrineCfg.num(K_Y, 0f); }
    static float scale() { return Math.max(0.5f, Math.min(2.5f, ShrineCfg.num(K_SCALE, 1f))); }

    /** Fake data for the previews and the position editor. */
    static Data demo() {
        MinecraftClient mc = MinecraftClient.getInstance();
        Data d = new Data();
        d.name = mc.player != null ? mc.player.getName().getString() : "Steve";
        d.hp = d.shown = 17f; d.max = 20f; d.dist = 3.4f;
        d.skinOf = mc.player;
        d.gear[0] = new ItemStack(Items.DIAMOND_SWORD);
        d.gear[1] = new ItemStack(Items.SHIELD);
        d.gear[2] = new ItemStack(Items.DIAMOND_HELMET);
        d.gear[3] = new ItemStack(Items.DIAMOND_CHESTPLATE);
        d.gear[4] = new ItemStack(Items.DIAMOND_LEGGINGS);
        d.gear[5] = new ItemStack(Items.DIAMOND_BOOTS);
        return d;
    }

    /** Panel size in virtual units for a design. */
    static float[] size(int design, boolean gear) {
        return switch (design) {
            case 1 -> new float[]{250f, gear ? 96f : 60f};
            case 2 -> new float[]{300f, 68f};
            case 3 -> new float[]{190f, 62f};
            default -> new float[]{268f, gear ? 124f : 92f};
        };
    }

    // ---------- the in-game element ----------
    private static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.currentScreen != null || mc.options.hudHidden) return;
        if (!ShrineCfg.bool(KEY, true)) { last = null; return; }

        Entity looked = mc.targetedEntity;
        LivingEntity target = looked instanceof LivingEntity le && !(looked instanceof ArmorStandEntity) ? le : null;
        long now = Util.getMeasuringTimeMs();
        if (target != null) {
            if (last != target) { last = target; shown = target.getHealth(); }
            seen = now;
        }
        if (last == null) return;
        float a = target != null ? 1f : 1f - (now - seen) / 320f;
        if (a <= 0f || last.isRemoved()) { last = null; return; }
        a = 1f - (1f - a) * (1f - a);

        float hp = Math.max(0f, last.getHealth());
        shown += (hp - shown) * 0.18f;
        Data d = live;
        d.name = last.getName().getString();
        d.hp = hp; d.max = Math.max(1f, last.getMaxHealth()); d.shown = shown; d.abs = last.getAbsorptionAmount();
        d.dist = mc.player.distanceTo(last);
        d.skinOf = last instanceof AbstractClientPlayerEntity pl ? pl : null;
        for (int i = 0; i < SLOTS.length; i++) d.gear[i] = last.getEquippedStack(SLOTS[i]);

        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        float k = h / Scene.REF_H, vw = w / k;
        drawAt(ctx, mc.textRenderer, vw, d, a, 8f * (1f - a));
    }

    /** Draws the panel at its configured position and size (virtual canvas, must be inside a scale(k) matrix or draws itself). */
    static void drawAt(DrawContext ctx, TextRenderer tr, float vw, Data d, float a, float slide) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int h = mc.getWindow().getScaledHeight();
        float k = h / Scene.REF_H;
        int design = design();
        boolean gear = ShrineCfg.bool(KEY_ARMOR, true);
        float[] sz = size(design, gear);
        float s = scale();
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        ctx.getMatrices().translate(vw / 2f + posX(), DEFAULT_TOP + posY() + slide);
        ctx.getMatrices().scale(s, s);
        ctx.getMatrices().translate(-sz[0] / 2f, 0f);
        panel(ctx, tr, design, gear, d, a);
        ctx.getMatrices().popMatrix();
    }

    // ---------- the panel designs (origin = top-left corner, virtual units) ----------
    static void panel(DrawContext ctx, TextRenderer tr, int design, boolean gear, Data d, float a) {
        float[] sz = size(design, gear);
        float W = sz[0], H = sz[1];
        float ratio = Math.max(0f, Math.min(1f, d.hp / d.max));
        float fillRatio = Math.max(0f, Math.min(1f, d.shown / d.max));
        int c = mix(0xFF4D5D, 0x5DE08A, ratio);
        String name = d.name;

        switch (design) {
            case 1 -> {   // "Круг": head + name + distance, round health gauge at the right, slots below
                glass(ctx, W, H, a, 16);
                head(ctx, tr, d, 12, 12, 36, a);
                text(ctx, tr, Fnt.UI_B, cut(name, 12), 58, 24, argb(a, 0xFFFFFF));
                text(ctx, tr, Fnt.SMALL, "Дист: " + String.format(Locale.ROOT, "%.1f", d.dist) + " м", 58, 43, argb(0.75f * a, 0xFFFFFF));
                float gx = W - 38f, gy = 30f;
                centered(ctx, RING, gx, gy, 46, 46, argb(0.28f * a, 0xFFFFFF));
                final int N = 30;
                for (int i = 0; i < N; i++) {
                    double ang = -Math.PI / 2 + i * 2 * Math.PI / N;
                    boolean on = (i + 0.5f) / N <= fillRatio;
                    centered(ctx, DISC, gx + (float) Math.cos(ang) * 20f, gy + (float) Math.sin(ang) * 20f, on ? 4.2f : 2.6f, on ? 4.2f : 2.6f,
                            argb((on ? 1f : 0.22f) * a, 0xFFFFFF));
                }
                textC(ctx, tr, Fnt.UI_B, String.valueOf((int) Math.ceil(d.hp)), gx, gy, argb(a, 0xFFFFFF));
                if (gear) {
                    float sx = 12, sy = 62, sw = 24, g = (W - 24 - sw * 6) / 5f;
                    for (int i = 0; i < 6; i++) slot(ctx, d.gear[i], sx + i * (sw + g), sy, sw, 1.0f, a);
                }
            }
            case 2 -> {   // "Минимал": wide dark pill, head, name, small armor row, vertical bar + red number
                glass(ctx, W, H, a, 18);
                head(ctx, tr, d, 12, 12, 44, a);
                text(ctx, tr, Fnt.UI_B, cut(name, 16), 66, 26, argb(a, 0xFFFFFF));
                if (gear) {
                    for (int i = 2; i < 6; i++) {
                        ItemStack st = d.gear[i];
                        if (st.isEmpty() || a < 0.5f) continue;
                        item(ctx, st, 66 + (i - 2) * 20f, 38f, 0.75f);
                    }
                }
                float bx = W - 84f, by = 14f, bh = 40f;
                box(ctx, RR, bx, by, 4, bh, 2, argb(0.14f * a, 0xFFFFFF));
                float fh = Math.max(4f, bh * fillRatio);
                box(ctx, RR, bx, by + bh - fh, 4, fh, 2, argb(a, c));
                String num = String.valueOf((int) Math.ceil(d.hp));
                text(ctx, tr, Fnt.UI_B, num, W - 18 - width(tr, Fnt.UI_B, num), H / 2f, argb(a, c));
            }
            case 3 -> {   // "Компакт": small card, name, hp number, thin bar along the bottom
                glass(ctx, W, H, a, 14);
                head(ctx, tr, d, 12, 10, 34, a);
                text(ctx, tr, Fnt.UI_B, cut(name, 11), 54, 22, argb(a, 0xFFFFFF));
                text(ctx, tr, Fnt.SMALL, String.format(Locale.ROOT, "%.1f", d.hp), 54, 40, argb(0.7f * a, 0xFFFFFF));
                float bx = 12, bw = W - 24, by = H - 11;
                box(ctx, RR, bx, by, bw, 4, 2, argb(0.18f * a, 0xFFFFFF));
                box(ctx, RR, bx, by, Math.max(4f, bw * fillRatio), 4, 2, argb(a, 0xFFFFFF));
            }
            default -> {  // "Классика": head, name, distance, hp, segmented pill bar, six slots
                glass(ctx, W, H, a, 18);
                head(ctx, tr, d, 14, 14, 44, a);
                text(ctx, tr, Fnt.UI_B, cut(name, 14), 70, 26, argb(a, 0xFFFFFF));
                text(ctx, tr, Fnt.SMALL, "Дист: " + String.format(Locale.ROOT, "%.1f", d.dist) + " м", 70, 46, argb(0.5f * a, 0xFFFFFF));
                String hpText = (int) Math.ceil(d.hp) + " / " + (int) Math.ceil(d.max) + (d.abs > 0f ? " +" + (int) Math.ceil(d.abs) : "");
                text(ctx, tr, Fnt.UI_B, hpText, W - 16 - width(tr, Fnt.UI_B, hpText), 26, argb(a, d.abs > 0f ? 0xFFD24D : 0xFFFFFF));
                final int SEG = 13;
                float bx = 14, bw = W - 28, gap = 4f, sw = (bw - gap * (SEG - 1)) / SEG, by = 68;
                for (int i = 0; i < SEG; i++) {
                    float sx = bx + i * (sw + gap);
                    box(ctx, RR, sx, by, sw, 12, 6, argb(0.12f * a, 0xFFFFFF));
                    float fill = Math.max(0f, Math.min(1f, d.shown / d.max * SEG - i));
                    if (fill > 0.02f) {
                        centered(ctx, GLOW, sx + sw * fill / 2f, by + 6, sw * fill + 14, 26, argb(0.30f * a, c));
                        box(ctx, RR, sx, by, Math.max(8f, sw * fill), 12, 6, argb(a, c));
                    }
                }
                if (gear) {
                    float sz2 = 30f, g = (bw - sz2 * 6) / 5f, sy = 90;
                    for (int i = 0; i < 6; i++) slot(ctx, d.gear[i], bx + i * (sz2 + g), sy, sz2, 1.4f, a);
                }
            }
        }
    }

    private static void glass(DrawContext ctx, float W, float H, float a, float r) {
        box(ctx, RR, -1, -1, W + 2, H + 2, r + 1, argb(0.50f * a, ACCENT));
        box(ctx, RR, 0, 0, W, H, r, argb(0.88f * a, 0x150A0F));
    }

    private static String cut(String s, int n) { return s.length() > n ? s.substring(0, n - 1) + "…" : s; }

    private static void head(DrawContext ctx, TextRenderer tr, Data d, float x, float y, float s, float a) {
        box(ctx, RR, x - 2, y - 2, s + 4, s + 4, 11, argb(0.5f * a, 0x000000));
        if (d.skinOf != null) {
            PlayerSkinDrawer.draw(ctx, d.skinOf.getSkin(), Math.round(x), Math.round(y), Math.round(s), argb(a, 0xFFFFFF));
        } else {
            box(ctx, RR, x, y, s, s, 9, argb(0.9f * a, 0x5A2A33));
            textC(ctx, tr, Fnt.TITLE_B, d.name.isEmpty() ? "?" : d.name.substring(0, 1).toUpperCase(), x + s / 2f, y + s / 2f, argb(a, 0xFFFFFF));
        }
    }

    private static void slot(DrawContext ctx, ItemStack st, float x, float y, float size, float iconScale, float a) {
        box(ctx, RR, x, y, size, size, 9, argb(0.40f * a, 0x000000));
        box(ctx, RR_RING, x, y, size, size, 9, argb(0.10f * a, 0xFFFFFF));
        if (st == null || st.isEmpty() || a < 0.5f) return;
        item(ctx, st, x + (size - 16f * iconScale) / 2f, y + (size - 16f * iconScale) / 2f, iconScale);
    }

    private static void item(DrawContext ctx, ItemStack st, float x, float y, float s) {
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(x, y);
        ctx.getMatrices().scale(s, s);
        ctx.drawItem(st, 0, 0);
        ctx.getMatrices().popMatrix();
    }

    private static int mix(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }
}

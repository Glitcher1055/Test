#!/usr/bin/env python3
"""
Converts a video into the menu backdrop resource used by VideoFx.java.

    python3 tools/build_video.py input.mp4

Needs ffmpeg on PATH. Writes src/main/resources/assets/shrine/video/frames.bin:
  int32 magic 'SVID', int32 frame count, int32 fps, int32 width, int32 height,
  int32 length of each frame, then the JPEG bytes of every frame (all big-endian).
"""
import glob, os, struct, subprocess, sys, tempfile

FPS, W, H = 20, 216, 384
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..",
                   "src", "main", "resources", "assets", "shrine", "video", "frames.bin")

def main() -> None:
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    src = sys.argv[1]
    with tempfile.TemporaryDirectory() as tmp:
        subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-i", src,
                        "-vf", f"fps={FPS},scale={W}:{H}:flags=lanczos",
                        "-q:v", "5", os.path.join(tmp, "%04d.jpg")], check=True)
        blobs = [open(f, "rb").read() for f in sorted(glob.glob(os.path.join(tmp, "*.jpg")))]
    data = bytearray(struct.pack(">5i", 0x53564944, len(blobs), FPS, W, H))
    for b in blobs:
        data += struct.pack(">i", len(b))
    for b in blobs:
        data += b
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "wb") as f:
        f.write(data)
    print(f"{len(blobs)} frames, {len(data) / 1e6:.1f} MB -> {os.path.normpath(OUT)}")

if __name__ == "__main__":
    main()

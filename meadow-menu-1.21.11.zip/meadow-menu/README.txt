Meadow Menu - Fabric 1.21.11 (Java 21)

Build:   gradle wrapper (once, if no gradlew)  ->  ./gradlew build
Output:  build/libs/meadow-menu-1.0.0.jar  -> .minecraft/mods (with Fabric API 0.141.1+1.21.11)

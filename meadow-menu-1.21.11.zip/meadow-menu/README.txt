Meadow Menu - Fabric 1.21.11 (Java 21)

Build:   gradle wrapper (once, if no gradlew)  ->  ./gradlew build
Output:  build/libs/meadow-menu-1.0.0.jar  -> .minecraft/mods (with Fabric API 0.141.1+1.21.11)

Screens: main menu -> "Сетевая игра" opens the PS5-style server screen (reads your saved servers),
"Играть" connects and the connecting screen is restyled through ConnectScreenMixin.
Use "+" tile or "..." button to open the vanilla server list for adding / editing servers.

Startup: logo + loading bar -> photosensitivity warning -> bokeh transition -> menu (click skips). Plays once per launch.
Server screen: "+" tile = add server, "..." = edit / delete (changes are saved to your real servers list).

--- Update: leaving a server ---
* "Отключиться" в игре теперь ведёт на наш экран "Сетевая игра" (ванильный список серверов подменяется).
* "Играть": экран плавно гаснет, фон остаётся, дальше плавно появляется "Подключение к миру...".
* Кнопка "Отмена" на экране подключения нарисована в стиле PS5.

--- Update: exit animation + singleplayer tab ---
* ExitFx: при выходе из мира последний кадр игры сжимается в карточку, затем появляется экран с выбранным миром/сервером.
* PsSingleplayerScreen: вкладка "Одиночная игра" в стиле PS5 (плитки миров, "Играть", меню "...", плитка "+").
* LevelLoadingScreenMixin: экран "Загрузка территории" оформлен как экран подключения.

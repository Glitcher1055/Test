Meadow Menu - Fabric 1.21.11 (Java 21)

Build:   gradle wrapper (once, if no gradlew)  ->  ./gradlew build
Output:  build/libs/meadow-menu-1.0.0.jar  -> .minecraft/mods (with Fabric API 0.141.1+1.21.11)

Screens: main menu -> "Сетевая игра" opens the PS5-style server screen (reads your saved servers),
"Играть" connects and the connecting screen is restyled through ConnectScreenMixin.
Use "+" tile or "..." button to open the vanilla server list for adding / editing servers.

Startup: logo + loading bar -> photosensitivity warning -> bokeh transition -> menu (click skips). Plays once per launch.
Server screen: "+" tile = add server, "..." = edit / delete (changes are saved to your real servers list).

--- Update: leaving a server ---
* "Отключиться" в игре теперь ведёт на наш экран "Сетевая игра" (ванильный список серверов подменяется).
* "Играть": экран плавно гаснет, фон остаётся, дальше плавно появляется "Подключение к миру...".
* Кнопка "Отмена" на экране подключения нарисована в стиле PS5.

--- Update: exit animation + singleplayer tab ---
* ExitFx: при выходе из мира последний кадр игры сжимается в карточку, затем появляется экран с выбранным миром/сервером.
* PsSingleplayerScreen: вкладка "Одиночная игра" в стиле PS5 (плитки миров, "Играть", меню "...", плитка "+").
* LevelLoadingScreenMixin: экран "Загрузка территории" оформлен как экран подключения.

--- Update: создание мира в стиле PS5 ---
* WorldCreateFx + 4 миксина: пока открыт экран создания мира (и его подэкраны: правила, эксперименты, наборы данных,
  изменение мира), фон заменяется на Shrine, а кнопки, вкладки и поля рисуются как стеклянные плашки.
* Флаг WorldCreateFx.active включается в MeadowClient (AFTER_INIT) и выключается на экранах Shrine / при входе в мир.

--- Update: настройки в стиле PS5 ---
* Экран "Настройки" и его подэкраны (графика, звук, управление, чат, язык и т.д.): фон Shrine, заголовок слева сверху,
  кнопки как строки списка (разделитель, рамка при наведении, подпись слева, значение справа), "Готово" - белая плашка.
* Определяется автоматически: текущий экран - OptionsScreen / GameOptionsScreen (WorldCreateFx.settings()).

--- Update: главная страница настроек как в PS5 ---
* WorldCreateFx.layoutSettings: после открытия "Настроек" ванильные кнопки выстраиваются в один вертикальный список
  с иконками слева (ico_*.png), ползунок FOV скрыт (он есть в настройках графики), ванильный заголовок скрыт.

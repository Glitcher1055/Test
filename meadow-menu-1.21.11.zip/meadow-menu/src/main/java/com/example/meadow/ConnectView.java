package com.example.meadow;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Util;

/** PS5-style "Подключение к миру..." drawn over vanilla's ConnectScreen (see ConnectScreenMixin). */
public final class ConnectView {
    private ConnectView() {}

    private static final Scene SCENE = new Scene();
    private static long lastRender;

    public static void render(DrawContext ctx, MinecraftClient mc, int w, int h, int mxReal, int myReal, float delta) {
        long now = Util.getMeasuringTimeMs();
        if (SCENE.w != w || SCENE.h != h || now - lastRender > 600) SCENE.init(w, h); // fresh fade-in on each connect
        lastRender = now;

        SCENE.begin(ctx, mxReal, myReal, delta);
        SCENE.stars(ctx, delta);
        float f = SCENE.fade();
        float cx = SCENE.vw / 2f;

        Gfx.centered(ctx, Gfx.GLOW, cx, 226f, 300f, 220f, Gfx.argb(0.22f * f, Gfx.ACCENT));
        if (PsState.favicon != null) {
            Gfx.centered(ctx, PsState.favicon, cx, 226f, 96f, 96f, Gfx.argb(f, 0xFFFFFF));
        } else if (PsState.initials != null) {
            Gfx.textC(ctx, mc.textRenderer, Gfx.Fnt.HUGE, PsState.initials, cx, 226f, Gfx.argb(f, PsState.color));
        } else {
            Gfx.centered(ctx, Gfx.LOGO, cx, 226f, 90f, 90f, Gfx.argb(f, Gfx.ACCENT));
        }

        int dots = (int) ((SCENE.time * 2.2f) % 4);
        String text = "Подключение к миру" + ".".repeat(dots);
        float pulse = 0.75f + 0.25f * (float) Math.sin(SCENE.time * 3f);
        // fixed-width anchor so the text does not jitter while the dots change
        float x = cx - Gfx.width(mc.textRenderer, Gfx.Fnt.TITLE, "Подключение к миру...") / 2f;
        Gfx.text(ctx, mc.textRenderer, Gfx.Fnt.TITLE, text, x, 307f, Gfx.argb(pulse * f, 0xFF8A8A));
        SCENE.end(ctx);
    }
}

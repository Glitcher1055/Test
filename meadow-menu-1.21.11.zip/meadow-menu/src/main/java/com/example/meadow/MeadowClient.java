package com.example.meadow;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;

public class MeadowClient implements ClientModInitializer {
    private static boolean introDone; // splash + warning play once per launch
    @Override
    public void onInitializeClient() {
        // The last game frame is still in the framebuffer when the connection closes: grab it for the exit animation.
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ExitFx.capture(client));

        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            // Every time the vanilla title screen opens, swap it for ours.
            // Leaving a SINGLEPLAYER world lands here: open our "Одиночная игра" with that world selected.
            if (screen instanceof TitleScreen title) {
                client.execute(() -> {
                    if (client.currentScreen == title) {
                        String world = ExitFx.take("world");
                        if (world != null) {
                            introDone = true;
                            client.setScreen(new PsSingleplayerScreen(title, world));
                            return;
                        }
                        Screen menu = new MeadowMenuScreen(title);
                        client.setScreen(introDone ? menu : new WarningScreen(menu));
                        introDone = true;
                    }
                });
            }
            // Leaving a SERVER makes vanilla open ITS OWN server list. Swap it for our "Сетевая игра"
            // with the server we just left selected.
            else if (screen.getClass() == MultiplayerScreen.class) {
                client.execute(() -> {
                    if (client.currentScreen == screen) {
                        introDone = true;
                        client.setScreen(new PsMultiplayerScreen(new TitleScreen(), ExitFx.take("server")));
                    }
                });
            }
        });
    }
}

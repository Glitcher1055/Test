package com.example.meadow;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;

public class MeadowClient implements ClientModInitializer {
    private static boolean introDone; // splash + warning play once per launch
    @Override
    public void onInitializeClient() {
        // Every time the vanilla title screen opens, swap it for ours.
        // "Back" buttons return to the TitleScreen, which gets swapped again -> always lands on our menu.
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof TitleScreen title) {
                client.execute(() -> {
                    if (client.currentScreen == title) {
                        Screen menu = new MeadowMenuScreen(title);
                        client.setScreen(introDone ? menu : new WarningScreen(menu));
                        introDone = true;
                    }
                });
            }
        });
    }
}

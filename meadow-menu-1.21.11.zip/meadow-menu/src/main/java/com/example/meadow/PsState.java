package com.example.meadow;

/** What the connecting screen should show (set when the player presses "Играть"). */
final class PsState {
    private PsState() {}
    static String initials;   // null -> show the Shrine logo instead
    static int color = 0xFFFFFF;
}

package com.example.meadow;

import com.example.meadow.Gfx.Fnt;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.util.Util;

import static com.example.meadow.Gfx.*;

/**
 * Glass dialog for adding / editing / deleting a server. Typing is handled by vanilla TextFieldWidgets
 * (so keyboard, paste and selection just work); we only draw them ourselves in the PS5 style.
 */
final class ServerDialog {
    enum Mode { ADD, EDIT, DELETE }

    static final String[] POLICY_NAMES = {"Спрашивать", "Вкл.", "Выкл."};

    final Mode mode;
    final TextFieldWidget nameField, addrField;   // null in DELETE mode
    final ServerInfo target;                       // null in ADD mode
    final String subtitle;
    int policy;                                    // 0 prompt, 1 enabled, 2 disabled
    private final long openedAt = Util.getMeasuringTimeMs();

    private float x, y, w, h;
    private float[] rClose = new float[4], rName = new float[4], rAddr = new float[4],
            rPolicy = new float[4], rOk = new float[4];

    ServerDialog(Mode mode, TextFieldWidget nameField, TextFieldWidget addrField, int policy,
                 String subtitle, ServerInfo target) {
        this.mode = mode; this.nameField = nameField; this.addrField = addrField;
        this.policy = policy; this.subtitle = subtitle; this.target = target;
    }

    float alpha() {
        float t = Math.min(1f, (Util.getMeasuringTimeMs() - openedAt) / 200f);
        return 1f - (1f - t) * (1f - t);
    }

    boolean okEnabled() { return mode == Mode.DELETE || !addrField.getText().isBlank(); }

    private String title() {
        return switch (mode) { case ADD -> "Добавление сервера"; case EDIT -> "Изменение сервера"; case DELETE -> "Удаление сервера"; };
    }

    private String okText() {
        return switch (mode) { case ADD -> "Добавить"; case EDIT -> "Сохранить"; case DELETE -> "Удалить"; };
    }

    void draw(DrawContext ctx, TextRenderer tr, float vw, float mx, float my, float a, float time) {
        boolean del = mode == Mode.DELETE;
        w = 400f; h = del ? 156f : 266f;
        x = (vw - w) / 2f;
        y = (Scene.REF_H - h) / 2f - 8f + (1f - a) * 14f;

        box(ctx, RR, x - 1, y - 1, w + 2, h + 2, 27, argb(0.10f * a, 0xFFFFFF));
        box(ctx, RR, x, y, w, h, 26, argb(0.97f * a, 0x1A1116));
        text(ctx, tr, Fnt.UI_B, title(), x + 24, y + 33, argb(a, 0xFFFFFF));

        // red close button
        float cx = x + w - 30, cy = y + 33;
        boolean hc = Gfx.inside(mx, my, cx - 14, cy - 14, 28, 28);
        centered(ctx, DISC, cx, cy, 22, 22, argb((hc ? 1f : 0.88f) * a, 0xFF6B6B));
        textC(ctx, tr, Fnt.TINY_B, "×", cx, cy - 0.5f, argb(a, 0x2A0A0A));
        rClose = new float[]{cx - 14, cy - 14, 28, 28};

        if (del) {
            text(ctx, tr, Fnt.LABEL, subtitle, x + 24, y + 74, argb(0.60f * a, 0xFFFFFF));
            rOk = new float[]{x + 20, y + 96, w - 40, 42};
            boolean ho = Gfx.inside(mx, my, rOk[0], rOk[1], rOk[2], rOk[3]);
            box(ctx, RR, rOk[0], rOk[1], rOk[2], rOk[3], 21, argb((ho ? 0.75f : 0.58f) * a, 0xB03A3A));
            box(ctx, RR_RING, rOk[0], rOk[1], rOk[2], rOk[3], 21, argb((ho ? 0.55f : 0.28f) * a, 0xFFFFFF));
            textC(ctx, tr, Fnt.UI_B, okText(), rOk[0] + rOk[2] / 2, rOk[1] + rOk[3] / 2, argb(a, 0xFFB0B0));
            return;
        }

        rName = new float[]{x + 20, y + 62, w - 40, 42};
        rAddr = new float[]{x + 20, y + 112, w - 40, 42};
        rPolicy = new float[]{x + 20, y + 162, w - 40, 38};
        rOk = new float[]{x + 20, y + 208, w - 40, 42};

        drawField(ctx, tr, nameField, "Название сервера", rName, a, time);
        drawField(ctx, tr, addrField, "IP сервера", rAddr, a, time);

        boolean hp = Gfx.inside(mx, my, rPolicy[0], rPolicy[1], rPolicy[2], rPolicy[3]);
        box(ctx, RR, rPolicy[0], rPolicy[1], rPolicy[2], rPolicy[3], 19, argb((hp ? 0.30f : 0.20f) * a, 0xFFFFFF));
        textC(ctx, tr, Fnt.LABEL, "Ресурспак: " + POLICY_NAMES[policy], rPolicy[0] + rPolicy[2] / 2,
                rPolicy[1] + rPolicy[3] / 2, argb(0.92f * a, 0xFFFFFF));

        boolean en = okEnabled();
        boolean ho = en && Gfx.inside(mx, my, rOk[0], rOk[1], rOk[2], rOk[3]);
        if (ho) box(ctx, RR_RING, rOk[0] - 4, rOk[1] - 4, rOk[2] + 8, rOk[3] + 8, 25, argb(0.55f * a, 0xFFFFFF));
        box(ctx, RR, rOk[0], rOk[1], rOk[2], rOk[3], 21, argb((en ? 0.97f : 0.18f) * a, 0xFFFFFF));
        textC(ctx, tr, Fnt.UI_B, okText(), rOk[0] + rOk[2] / 2, rOk[1] + rOk[3] / 2,
                argb(en ? a : 0.45f * a, en ? 0x14101A : 0xFFFFFF));
    }

    private void drawField(DrawContext ctx, TextRenderer tr, TextFieldWidget f, String placeholder,
                           float[] r, float a, float time) {
        boolean focused = f.isFocused();
        box(ctx, RR, r[0], r[1], r[2], r[3], 14, argb(0.09f * a, 0xFFFFFF));
        box(ctx, RR_RING, r[0], r[1], r[2], r[3], 14, argb((focused ? 0.70f : 0.16f) * a, 0xFFFFFF));

        String t = f.getText();
        float cy = r[1] + r[3] / 2f, tx = r[0] + 16f, avail = r[2] - 32f;
        if (t.isEmpty()) {
            if (!focused) text(ctx, tr, Fnt.LABEL, placeholder, tx, cy, argb(0.38f * a, 0xFFFFFF));
            else if (((int) (time * 2.2f)) % 2 == 0) ctx.fill(Math.round(tx), Math.round(cy - 9), Math.round(tx) + 2, Math.round(cy + 9), argb(0.9f * a, 0xFFFFFF));
            return;
        }
        int start = 0;
        while (start < t.length() - 1 && width(tr, Fnt.LABEL, t.substring(start)) > avail) start++;
        text(ctx, tr, Fnt.LABEL, t.substring(start), tx, cy, argb(a, 0xFFFFFF));
        if (focused && ((int) (time * 2.2f)) % 2 == 0) {
            int cur = Math.max(start, Math.min(t.length(), f.getCursor()));
            float cx = tx + width(tr, Fnt.LABEL, t.substring(start, cur));
            ctx.fill(Math.round(cx), Math.round(cy - 9), Math.round(cx) + 2, Math.round(cy + 9), argb(0.95f * a, 0xFFFFFF));
        }
    }

    /** @return 0 = handled, nothing to do; 1 = close dialog; 2 = confirm */
    int click(double mx, double my, Screen screen) {
        if (hit(rClose, mx, my)) return 1;
        if (mode == Mode.DELETE) return hit(rOk, mx, my) ? 2 : 0;
        if (hit(rName, mx, my)) { focus(screen, nameField); return 0; }
        if (hit(rAddr, mx, my)) { focus(screen, addrField); return 0; }
        if (hit(rPolicy, mx, my)) { policy = (policy + 1) % POLICY_NAMES.length; return 0; }
        if (hit(rOk, mx, my) && okEnabled()) return 2;
        return 0;
    }

    private void focus(Screen screen, TextFieldWidget f) {
        nameField.setFocused(f == nameField);
        addrField.setFocused(f == addrField);
        screen.setFocused(f);
    }

    private static boolean hit(float[] r, double mx, double my) {
        return r[2] > 0 && Gfx.inside(mx, my, r[0], r[1], r[2], r[3]);
    }
}

package com.example.meadow.mixin;

import com.example.meadow.WorldCreateFx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.TabButtonWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** The "Игра / Мир / Прочее" tabs: the selected one is a white pill, like the Shrine top bar. */
@Mixin(TabButtonWidget.class)
public class TabButtonWidgetMixin {
    @Inject(method = "renderWidget", at = @At("HEAD"), cancellable = true)
    private void shrine$render(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!WorldCreateFx.active) return;
        TabButtonWidget self = (TabButtonWidget) (Object) this;
        WorldCreateFx.tab(ctx, (ClickableWidget) self, self.isCurrentTab());
        ci.cancel();
    }
}

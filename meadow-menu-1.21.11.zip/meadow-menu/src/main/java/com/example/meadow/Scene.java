package com.example.meadow;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Util;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Animated backdrop (gradient, light beam, starfield) on a virtual 540-unit-high canvas. */
final class Scene {
    static final float REF_H = 540f;
    private static final int STARS = 190, BOKEH = 16;

    float k = 1f, vw = 960f, time, mx, my;
    int w, h;
    boolean instantBackdrop;   // true: beam/stars do not fade in again (used by the connecting screen)
    long openedAt = Util.getMeasuringTimeMs();
    private final Random rnd = new Random(7L);
    private final List<Star> stars = new ArrayList<>();

    void init(int w, int h) {
        this.w = w; this.h = h;
        k = h / REF_H;
        vw = w / k;
        openedAt = Util.getMeasuringTimeMs();
        stars.clear();
        for (int i = 0; i < STARS + BOKEH; i++) {
            boolean bokeh = i >= STARS;
            float depth = bokeh ? 0.35f + rnd.nextFloat() * 0.4f : 0.2f + rnd.nextFloat() * 0.8f;
            float size = bokeh ? 26f + rnd.nextFloat() * 34f : 4f + depth * 5f;
            stars.add(new Star(rnd.nextFloat() * vw, rnd.nextFloat() * REF_H, depth, size, rnd.nextFloat() * 6.28f, bokeh));
        }
    }

    float fade() {
        float f = Math.min(1f, (Util.getMeasuringTimeMs() - openedAt) / 700f);
        return 1f - (1f - f) * (1f - f);
    }

    private float bg() { return instantBackdrop ? 1f : fade(); }

    /** Draws full-screen layers, then switches the matrix to the virtual canvas. Pair with end(). */
    void begin(DrawContext ctx, int mxReal, int myReal, float delta) {
        time += delta / 20f;
        float f = bg();
        float pulse = 0.88f + 0.12f * (float) Math.sin(time * 1.2f);
        ctx.fillGradient(0, 0, w, h, 0xFF0C0205, 0xFF1E0509);
        Gfx.blit(ctx, Gfx.BEAM, 0, 0, w, h, Gfx.argb(0.80f * pulse * f, Gfx.ACCENT));
        Gfx.blit(ctx, Gfx.BEAM, 0, 0, w, h, Gfx.argb(0.22f * pulse * f, 0xFFFFFF));
        mx = mxReal / k;
        my = myReal / k;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
    }

    void end(DrawContext ctx) { ctx.getMatrices().popMatrix(); }

    void stars(DrawContext ctx, float delta) {
        float f = bg();
        float px = (mx - vw / 2f) / vw, py = (my - REF_H / 2f) / REF_H;
        for (Star s : stars) {
            s.y += s.depth * (s.bokeh ? 0.35f : 0.75f) * delta;
            if (s.y > REF_H + s.size) { s.y = -s.size; s.x = rnd.nextFloat() * vw; }
            float tw = 0.4f + 0.6f * Math.abs((float) Math.sin(time * (s.bokeh ? 0.8f : 1.9f) + s.phase));
            float x = s.x - px * 36f * s.depth, y = s.y - py * 20f * s.depth;
            if (s.bokeh) Gfx.centered(ctx, Gfx.GLOW, x, y, s.size * 1.6f, s.size * 1.6f, Gfx.argb(0.10f * tw * f, Gfx.ACCENT));
            else Gfx.centered(ctx, Gfx.DOT, x, y, s.size, s.size,
                    Gfx.argb(0.95f * tw * f, s.depth > 0.8f ? Gfx.ACCENT : 0xFFFFFF));
        }
    }

    private static final class Star {
        float x, y, depth, size, phase; boolean bokeh;
        Star(float x, float y, float depth, float size, float phase, boolean bokeh) {
            this.x = x; this.y = y; this.depth = depth; this.size = size; this.phase = phase; this.bokeh = bokeh;
        }
    }
}

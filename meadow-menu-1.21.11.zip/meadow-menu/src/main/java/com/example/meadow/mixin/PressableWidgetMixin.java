package com.example.meadow.mixin;

import com.example.meadow.WorldCreateFx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.PressableWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Buttons and cycling buttons ("Режим игры", "Вкл/Выкл", ...) become glass pills in the world creation flow. */
@Mixin(PressableWidget.class)
public class PressableWidgetMixin {
    @Inject(method = "renderWidget", at = @At("HEAD"), cancellable = true)
    private void shrine$render(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!WorldCreateFx.active) return;
        WorldCreateFx.button(ctx, (ClickableWidget) (Object) this);
        ci.cancel();
    }
}

package com.example.meadow.mixin;

import com.example.meadow.WorldCreateFx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.TextFieldWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Text fields ("Название мира", seed) are drawn as glass fields in the world creation flow. */
@Mixin(TextFieldWidget.class)
public class TextFieldWidgetMixin {
    @Inject(method = "renderWidget", at = @At("HEAD"), cancellable = true)
    private void shrine$render(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        if (!WorldCreateFx.active) return;
        WorldCreateFx.field(ctx, (TextFieldWidget) (Object) this);
        ci.cancel();
    }
}

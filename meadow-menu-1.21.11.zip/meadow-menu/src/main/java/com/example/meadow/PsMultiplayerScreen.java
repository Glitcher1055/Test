package com.example.meadow;

import com.example.meadow.Gfx.Fnt;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.option.ServerList;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static com.example.meadow.Gfx.*;

/** PS5-style "Сетевая игра": tabs, a row of server tiles, a detail view with Play, and home widgets. */
public final class PsMultiplayerScreen extends Screen {

    private static final float LEFT = 54f, TOP = 99f, SMALL = 66f, BIG = 108f, GAP = 7f, RIGHT_PAD = 55f;
    private static final int[] PALETTE = {0xE8C21A, 0x35B8F0, 0xFFFFFF, 0xFF5A5A, 0x7CE08A, 0xFFA24A, 0xD9A0FF};
    private static final int HOME = 0, SERVER = 1, ADD = 2;
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm", Locale.ROOT);

    private final Screen parent;
    private final Scene scene = new Scene();
    private final List<Entry> entries = new ArrayList<>();
    private int sel;
    private long selAt;
    private float scroll, scrollTarget, lastMx, lastMy;

    // clickable regions of the current frame (virtual coordinates)
    private float[] singleRect = new float[4], backRect = new float[4], gearRect = new float[4];
    private float[] playRect = new float[4], dotsRect = new float[4];

    public PsMultiplayerScreen(Screen parent) {
        super(Text.literal("Shrine"));
        this.parent = parent;
    }

    // ---------- data ----------
    private static final class Entry {
        final int kind; final String name; final ServerInfo info; final String initials; final int color;
        float anim, x, y, w, h;
        Entry(int kind, String name, ServerInfo info) {
            this.kind = kind; this.name = name; this.info = info;
            this.initials = kind == SERVER ? initialsOf(name) : "";
            this.color = kind == SERVER ? PALETTE[Math.floorMod(name.hashCode(), PALETTE.length)] : 0xFFFFFF;
        }
        boolean contains(double mx, double my) { return Gfx.inside(mx, my, x, y, w, h); }
    }

    private static String initialsOf(String n) {
        n = n.trim();
        if (n.isEmpty()) return "?";
        String[] p = n.split("[\\s._\\-]+");
        if (p.length >= 2 && !p[0].isEmpty() && !p[1].isEmpty()) {
            return ("" + p[0].charAt(0) + p[1].charAt(0)).toUpperCase(Locale.ROOT);
        }
        return n.substring(0, Math.min(2, n.length())).toUpperCase(Locale.ROOT);
    }

    @Override
    protected void init() {
        scene.init(width, height);
        entries.clear();
        entries.add(new Entry(HOME, "Домашняя", null));
        ServerList list = new ServerList(client);
        list.loadFile();
        for (int i = 0; i < list.size(); i++) {
            ServerInfo si = list.get(i);
            String n = (si.name == null || si.name.isBlank()) ? si.address : si.name;
            entries.add(new Entry(SERVER, n, si));
        }
        entries.add(new Entry(ADD, "Добавить сервер", null));
        sel = 0;
        selAt = Util.getMeasuringTimeMs();
        scroll = scrollTarget = 0f;
        for (int i = 0; i < entries.size(); i++) entries.get(i).anim = i == sel ? 1f : 0f;
    }

    private void select(int i) {
        if (i == sel) return;
        sel = i;
        selAt = Util.getMeasuringTimeMs();
        ensureVisible();
    }

    private void ensureVisible() {
        float xs = LEFT;
        for (int i = 0; i < sel; i++) xs += SMALL + GAP;
        float total = LEFT + entries.size() * (SMALL + GAP) + (BIG - SMALL);
        float maxScroll = Math.max(0f, total - (scene.vw - 40f));
        if (xs + BIG - scrollTarget > scene.vw - 40f) scrollTarget = xs + BIG - (scene.vw - 40f);
        if (xs - scrollTarget < LEFT) scrollTarget = xs - LEFT;
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget));
    }

    // ---------- render ----------
    @Override
    public void render(DrawContext ctx, int mxReal, int myReal, float delta) {
        scene.begin(ctx, mxReal, myReal, delta);
        float mx = scene.mx, my = scene.my, f = scene.fade();
        scene.stars(ctx, delta);

        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i);
            e.anim += ((i == sel ? 1f : 0f) - e.anim) * Math.min(1f, delta * 0.35f);
        }
        scroll += (scrollTarget - scroll) * Math.min(1f, delta * 0.3f);
        float x = LEFT - scroll;
        for (Entry e : entries) {
            float s = SMALL + (BIG - SMALL) * e.anim;
            e.x = x; e.y = TOP; e.w = s; e.h = s;
            x += s + GAP;
        }

        // hover selects (like on the console), but only when the cursor actually moved
        boolean moved = Math.abs(mx - lastMx) + Math.abs(my - lastMy) > 1f;
        lastMx = mx; lastMy = my;
        if (moved) {
            for (int i = 0; i < entries.size(); i++) {
                if (entries.get(i).contains(mx, my)) { select(i); break; }
            }
        }

        drawTopBar(ctx, mx, my, f);
        for (Entry e : entries) drawTile(ctx, e, f);

        Entry se = entries.get(sel);
        float sa = Math.min(1f, (Util.getMeasuringTimeMs() - selAt) / 260f);
        sa = 1f - (1f - sa) * (1f - sa);
        drawSelectedLabel(ctx, se, f * sa);

        playRect = new float[4]; dotsRect = new float[4];
        if (se.kind == HOME) drawHomeWidgets(ctx, f * sa);
        else drawDetail(ctx, se, mx, my, f * sa, sa);
        scene.end(ctx);
    }

    private void drawTopBar(DrawContext ctx, float mx, float my, float f) {
        float cy = 45f;
        String t1 = "Одиночная игра", t2 = "Сетевая игра";
        int w1 = width(textRenderer, Fnt.UI, t1), w2 = width(textRenderer, Fnt.UI, t2);
        boolean h1 = Gfx.inside(mx, my, LEFT - 8, cy - 17, w1 + 16, 34);
        text(ctx, textRenderer, Fnt.UI, t1, LEFT, cy, argb((h1 ? 1f : 0.85f) * f, 0xFFFFFF));
        singleRect = new float[]{LEFT - 8, cy - 17, w1 + 16, 34};

        float px = LEFT + w1 + 28f, pw = w2 + 34f;
        box(ctx, RR, px, cy - 17, pw, 34, 17, argb(0.96f * f, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.UI, t2, px + 17, cy, argb(f, 0x14101A));
        backRect = new float[]{px, cy - 17, pw, 34};

        String clock = LocalDateTime.now().format(CLOCK);
        int cw = width(textRenderer, Fnt.UI, clock);
        float clockX = scene.vw - RIGHT_PAD - cw;
        text(ctx, textRenderer, Fnt.UI, clock, clockX, cy, argb(0.92f * f, 0xFFFFFF));

        float avCx = clockX - 28f;
        centered(ctx, DISC, avCx, cy, 30, 30, argb(0.95f * f, ACCENT));
        String name = client.getSession().getUsername();
        String letter = (name == null || name.isEmpty()) ? "?" : name.substring(0, 1).toUpperCase(Locale.ROOT);
        textC(ctx, textRenderer, Fnt.TINY_B, letter, avCx, cy, argb(f, 0xFFFFFF));

        float gx = avCx - 46f;
        boolean hg = Gfx.inside(mx, my, gx - 16, cy - 16, 32, 32);
        centered(ctx, I_GEAR, gx, cy, 22, 22, argb((hg ? 1f : 0.82f) * f, 0xFFFFFF));
        gearRect = new float[]{gx - 16, cy - 16, 32, 32};
    }

    private void drawTile(DrawContext ctx, Entry e, float f) {
        float a = e.anim, s = e.w, x = e.x, y = e.y, r = s * 0.2f;
        if (a > 0.02f) centered(ctx, GLOW, x + s / 2, y + s / 2, s * 1.9f, s * 1.9f, argb(0.30f * a * f, ACCENT));
        if (e.kind == HOME) box(ctx, RR, x, y, s, s, r, argb(0.92f * f, 0xB02633));
        else box(ctx, RR, x, y, s, s, r, argb((0.62f + 0.20f * a) * f, 0x2C2430));

        float cx = x + s / 2, cy = y + s / 2;
        if (e.kind == HOME) {
            centered(ctx, LOGO, cx, cy, s * 0.55f, s * 0.55f, argb(0.96f * f, 0xFFFFFF));
        } else if (e.kind == ADD) {
            textC(ctx, textRenderer, a > 0.5f ? Fnt.TILE_L : Fnt.TILE_S, "+", cx, cy, argb(0.8f * f, 0xFFFFFF));
        } else {
            textC(ctx, textRenderer, a > 0.5f ? Fnt.TILE_L : Fnt.TILE_S, e.initials, cx, cy, argb(f, e.color));
        }
        if (a > 0.02f) box(ctx, RR_RING, x - 4 * a, y - 4 * a, s + 8 * a, s + 8 * a, r + 4 * a, argb(0.60f * a * f, 0xFFFFFF));
    }

    private void drawSelectedLabel(DrawContext ctx, Entry se, float f) {
        float lx = se.x + se.w + 10f, cy = 196f;
        if (se.kind == ADD) {
            text(ctx, textRenderer, Fnt.TITLE, se.name, lx, cy, argb(f, 0xFFFFFF));
            return;
        }
        int pw = width(textRenderer, Fnt.TINY_B, "Shrine") + 22;
        box(ctx, RR, lx, cy - 13, pw, 26, 13, argb(0.95f * f, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.TINY_B, "Shrine", lx + pw / 2f, cy, argb(f, 0x14101A));
        text(ctx, textRenderer, Fnt.TITLE, se.name, lx + pw + 9, cy, argb(f, 0xFFFFFF));
    }

    private void drawHomeWidgets(DrawContext ctx, float f) {
        float xr = scene.vw - RIGHT_PAD;
        card(ctx, xr - 304, 278, 304, 104, I_CHAT, "Сообщения", 0x3B82F6, "Пока нет диалогов", f, 0.07f);
        card(ctx, xr - 304, 395, 304, 94, I_FRIENDS, "Друзья онлайн", 0x34D17A, "Никого нет в сети", f, 0.07f);
        card(ctx, xr - 704, 380, 384, 109, I_ACTIVITY, "Активность друзей", -1, "Пока никого из друзей нет в сети", f, 0.09f);
    }

    private void card(DrawContext ctx, float x, float y, float w, float h, net.minecraft.util.Identifier icon,
                      String title, int dot, String hint, float f, float fillAlpha) {
        box(ctx, RR, x, y, w, h, 22, argb(fillAlpha * 1.4f * f, 0xFFE0E0));
        box(ctx, RR, x, y, w, h, 22, argb(0.05f * f, ACCENT));
        centered(ctx, icon, x + 28, y + 27, 20, 20, argb(0.95f * f, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.LABEL, title, x + 50, y + 27, argb(0.95f * f, 0xFFFFFF));
        if (dot >= 0) {
            centered(ctx, DISC, x + w - 44, y + 27, 11, 11, argb(f, dot));
            text(ctx, textRenderer, Fnt.UI_B, "0", x + w - 30, y + 27, argb(f, 0xFFFFFF));
        }
        text(ctx, textRenderer, Fnt.LABEL, hint, x + 16, y + h - 34, argb(0.50f * f, 0xFFFFFF));
    }

    private void drawDetail(DrawContext ctx, Entry se, float mx, float my, float f, float sa) {
        float off = (1f - sa) * 10f, dx = 98f;
        boolean add = se.kind == ADD;
        text(ctx, textRenderer, Fnt.NAME_B, se.name, dx, 270 + off, argb(f, 0xFFFFFF));
        String sub = add ? "Откроется список серверов" : "IP: " + se.info.address;
        text(ctx, textRenderer, Fnt.LABEL, sub, dx, 304 + off, argb(0.55f * f, 0xFFFFFF));

        // Play / Open pill with outer ring
        float px = 104f, py = 430f + off, pw = 177f, ph = 41f;
        boolean hp = Gfx.inside(mx, my, px - 6, py - 6, pw + 12, ph + 12);
        box(ctx, RR_RING, px - 6, py - 6, pw + 12, ph + 12, 26, argb((hp ? 0.95f : 0.45f) * f, 0xFFFFFF));
        box(ctx, RR, px, py, pw, ph, 20.5f, argb((hp ? 1f : 0.96f) * f, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.UI_B, add ? "Открыть" : "Играть", px + 30, py + ph / 2f, argb(f, 0x14101A));
        box(ctx, RR, px + pw - 40, py + 7, 27, 27, 8, argb(f, 0x14101A));
        centered(ctx, I_ENTER, px + pw - 26.5f, py + 20.5f, 16, 16, argb(f, 0xFFFFFF));
        playRect = new float[]{px - 6, py - 6, pw + 12, ph + 12};

        if (!add) {
            float dcx = 320f, dcy = py + ph / 2f;
            boolean hd = Gfx.inside(mx, my, dcx - 23, dcy - 23, 46, 46);
            centered(ctx, DISC, dcx, dcy, 46, 46, argb((hd ? 0.26f : 0.14f) * f, 0xFFFFFF));
            for (int i = -1; i <= 1; i++) centered(ctx, DISC, dcx + i * 11f, dcy, 6, 6, argb(0.9f * f, 0xFFFFFF));
            dotsRect = new float[]{dcx - 23, dcy - 23, 46, 46};
        }

        // big icon on the right
        float bx = scene.vw - RIGHT_PAD - 154f, by = 259f + off;
        box(ctx, RR, bx, by, 154, 154, 26, argb(0.12f * f, 0xFFFFFF));
        if (add) textC(ctx, textRenderer, Fnt.HUGE, "+", bx + 77, by + 77, argb(0.8f * f, 0xFFFFFF));
        else textC(ctx, textRenderer, Fnt.HUGE, se.initials, bx + 77, by + 77, argb(f, se.color));
    }

    // ---------- actions ----------
    private void play(Entry e) {
        PsState.initials = e.initials;
        PsState.color = e.color;
        ServerAddress addr = ServerAddress.parse(e.info.address);
        ConnectScreen.connect(this, client, addr, e.info, false, null);
    }

    private static boolean hit(float[] r, double mx, double my) {
        return r[2] > 0 && Gfx.inside(mx, my, r[0], r[1], r[2], r[3]);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() == 0) {
            double mx = click.x() / scene.k, my = click.y() / scene.k;
            if (hit(singleRect, mx, my)) { client.setScreen(new SelectWorldScreen(this)); return true; }
            if (hit(backRect, mx, my)) { close(); return true; }
            if (hit(gearRect, mx, my)) { client.setScreen(new OptionsScreen(this, client.options)); return true; }

            Entry se = entries.get(sel);
            if (hit(playRect, mx, my)) {
                if (se.kind == SERVER) play(se);
                else if (se.kind == ADD) client.setScreen(new MultiplayerScreen(this));
                return true;
            }
            if (se.kind == SERVER && hit(dotsRect, mx, my)) { client.setScreen(new MultiplayerScreen(this)); return true; }

            for (int i = 0; i < entries.size(); i++) {
                if (entries.get(i).contains(mx, my)) { select(i); return true; }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        float total = LEFT + entries.size() * (SMALL + GAP) + (BIG - SMALL);
        float maxScroll = Math.max(0f, total - (scene.vw - 40f));
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget - (float) (verticalAmount + horizontalAmount) * 70f));
        return true;
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void close() { client.setScreen(parent); }
}

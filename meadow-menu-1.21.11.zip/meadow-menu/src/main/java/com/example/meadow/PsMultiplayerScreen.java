package com.example.meadow;

import com.example.meadow.Gfx.Fnt;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.MultiplayerServerListPinger;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.option.ServerList;
import net.minecraft.network.NetworkingBackend;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static com.example.meadow.Gfx.*;

/**
 * PS5-style "Сетевая игра": tabs, a row of server tiles, a detail view with Play, home widgets,
 * and add / edit / delete dialogs (works on your real saved server list).
 */
public final class PsMultiplayerScreen extends Screen {

    private static final float LEFT = 54f, TOP = 99f, SMALL = 66f, BIG = 108f, GAP = 7f, RIGHT_PAD = 55f;
    private static final int[] PALETTE = {0xE8C21A, 0x35B8F0, 0xFFFFFF, 0xFF5A5A, 0x7CE08A, 0xFFA24A, 0xD9A0FF};
    private static final int HOME = 0, SERVER = 1, ADD = 2;
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm", Locale.ROOT);
    private static final ServerInfo.ResourcePackPolicy[] POLICY = {
            ServerInfo.ResourcePackPolicy.PROMPT, ServerInfo.ResourcePackPolicy.ENABLED, ServerInfo.ResourcePackPolicy.DISABLED};

    private final Screen parent;
    private final Scene scene = new Scene();
    private final List<Entry> entries = new ArrayList<>();
    private ServerList serverList;
    private MultiplayerServerListPinger pinger;
    private ServerDialog dialog;
    private boolean menuOpen;
    private Entry playing;      // server being joined: the screen fades out first, then we connect
    private long playAt;
    private int sel;
    private long selAt;
    private float scroll, scrollTarget, lastMx, lastMy;

    // clickable regions of the current frame (virtual coordinates)
    private float[] singleRect = new float[4], backRect = new float[4], gearRect = new float[4];
    private float[] playRect = new float[4], dotsRect = new float[4], menuEdit = new float[4], menuDel = new float[4];

    private final String selectAddr;   // server to pre-select (the one we just left)

    public PsMultiplayerScreen(Screen parent) { this(parent, null); }

    public PsMultiplayerScreen(Screen parent, String selectAddr) {
        super(Text.literal("Shrine"));
        this.parent = parent;
        this.selectAddr = selectAddr;
    }

    // ---------- data ----------
    private static final class Entry {
        final int kind; final String name; final ServerInfo info; final String initials; final int color;
        float anim, x, y, w, h;
        long born;          // creation time, for the "pop in" of newly added servers
        Identifier icon;    // real server favicon, once the ping delivers it
        Entry(int kind, String name, ServerInfo info) {
            this.kind = kind; this.name = name; this.info = info;
            this.initials = kind == SERVER ? initialsOf(name) : "";
            this.color = kind == SERVER ? PALETTE[Math.floorMod(name.hashCode(), PALETTE.length)] : 0xFFFFFF;
        }
        boolean contains(double mx, double my) { return Gfx.inside(mx, my, x, y, w, h); }
    }

    private static String initialsOf(String n) {
        n = n.trim();
        if (n.isEmpty()) return "?";
        String[] p = n.split("[\\s._\\-]+");
        if (p.length >= 2 && !p[0].isEmpty() && !p[1].isEmpty()) {
            return ("" + p[0].charAt(0) + p[1].charAt(0)).toUpperCase(Locale.ROOT);
        }
        return n.substring(0, Math.min(2, n.length())).toUpperCase(Locale.ROOT);
    }

    @Override
    protected void init() {
        scene.init(width, height);
        if (ExitFx.active) scene.delayMs = 350;
        serverList = new ServerList(client);
        serverList.loadFile();
        buildEntries(0);
        if (selectAddr != null) {
            for (int i = 0; i < entries.size(); i++) {
                ServerInfo si = entries.get(i).info;
                if (si != null && selectAddr.equals(si.address)) { buildEntries(i); break; }
            }
        }
        selAt = Util.getMeasuringTimeMs();
        scroll = scrollTarget = 0f;

        if (pinger != null) pinger.cancel();
        pinger = new MultiplayerServerListPinger();
        for (Entry e : entries) if (e.kind == SERVER) ping(e.info);

        if (dialog != null) attachFields();   // screen was resized while a dialog was open
    }

    private void buildEntries(int select) {
        entries.clear();
        entries.add(new Entry(HOME, "Домашняя", null));
        for (int i = 0; i < serverList.size(); i++) {
            ServerInfo si = serverList.get(i);
            String n = (si.name == null || si.name.isBlank()) ? si.address : si.name;
            entries.add(new Entry(SERVER, n, si));
        }
        entries.add(new Entry(ADD, "Добавить сервер", null));
        sel = Math.max(0, Math.min(entries.size() - 1, select));
        for (int i = 0; i < entries.size(); i++) entries.get(i).anim = i == sel ? 1f : 0f;
        menuOpen = false;
        ensureVisible();
    }

    private void ping(ServerInfo si) {
        try {
            pinger.add(si, () -> {}, () -> {}, NetworkingBackend.remote(client.options.shouldUseNativeTransport()));
        } catch (Exception ignored) {
            // unreachable / bad address: the tile just shows "Не в сети"
        }
    }

    private void select(int i) {
        if (i == sel) return;
        sel = i;
        selAt = Util.getMeasuringTimeMs();
        menuOpen = false;
        ensureVisible();
    }

    private void ensureVisible() {
        float xs = LEFT;
        for (int i = 0; i < sel; i++) xs += SMALL + GAP;
        float total = LEFT + entries.size() * (SMALL + GAP) + (BIG - SMALL);
        float maxScroll = Math.max(0f, total - (scene.vw - 40f));
        if (xs + BIG - scrollTarget > scene.vw - 40f) scrollTarget = xs + BIG - (scene.vw - 40f);
        if (xs - scrollTarget < LEFT) scrollTarget = xs - LEFT;
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget));
    }

    // ---------- dialogs ----------
    private TextFieldWidget newField(String text, int max) {
        TextFieldWidget f = new TextFieldWidget(textRenderer, 0, 0, 200, 20, Text.empty());
        f.setMaxLength(max);
        f.setText(text);
        return f;
    }

    private void openDialog(ServerDialog.Mode mode, ServerInfo target) {
        menuOpen = false;
        TextFieldWidget n = null, a = null;
        int pol = 0;
        if (mode != ServerDialog.Mode.DELETE) {
            n = newField(target == null ? "" : target.name, 40);
            a = newField(target == null ? "" : target.address, 80);
            if (target != null) {
                for (int i = 0; i < POLICY.length; i++) if (POLICY[i] == target.getResourcePackPolicy()) pol = i;
            }
        }
        String sub = target == null ? "" : ((target.name == null || target.name.isBlank() ? target.address : target.name)
                + " пропадёт из списка серверов");
        dialog = new ServerDialog(mode, n, a, pol, sub, target);
        attachFields();
        if (n != null) { n.setFocused(true); setFocused(n); }
    }

    private void attachFields() {
        clearChildren();
        if (dialog != null && dialog.nameField != null) {
            addDrawableChild(dialog.nameField);
            addDrawableChild(dialog.addrField);
        }
    }

    private void closeDialog() {
        dialog = null;
        clearChildren();
        setFocused(null);
    }

    private void confirmDialog() {
        ServerDialog d = dialog;
        if (d == null) return;
        switch (d.mode) {
            case ADD -> {
                String addr = d.addrField.getText().trim();
                if (addr.isEmpty()) return;
                String name = d.nameField.getText().trim();
                if (name.isEmpty()) name = "Сервер Minecraft";
                ServerInfo si = new ServerInfo(name, addr, ServerInfo.ServerType.OTHER);
                si.setResourcePackPolicy(POLICY[d.policy]);
                serverList.add(si, false);
                serverList.saveFile();
                closeDialog();
                buildEntries(serverList.size());
                entries.get(sel).born = Util.getMeasuringTimeMs();
                selAt = Util.getMeasuringTimeMs();
                ping(si);
            }
            case EDIT -> {
                ServerInfo si = d.target;
                String addr = d.addrField.getText().trim();
                if (addr.isEmpty()) return;
                String name = d.nameField.getText().trim();
                si.name = name.isEmpty() ? "Сервер Minecraft" : name;
                si.address = addr;
                si.setResourcePackPolicy(POLICY[d.policy]);
                serverList.saveFile();
                int keep = sel;
                closeDialog();
                buildEntries(keep);
                ping(si);
            }
            case DELETE -> {
                serverList.remove(d.target);
                serverList.saveFile();
                int keep = Math.max(0, sel - 1);
                closeDialog();
                buildEntries(keep);
            }
        }
    }

    // ---------- render ----------
    @Override
    public void render(DrawContext ctx, int mxReal, int myReal, float delta) {
        float out = 1f;
        if (playing != null) {
            out = 1f - (Util.getMeasuringTimeMs() - playAt) / 320f;
            if (out <= 0f) { Entry p = playing; playing = null; connectTo(p); return; }
        }
        scene.begin(ctx, mxReal, myReal, delta);
        float mx = scene.mx, my = scene.my, f = scene.fade() * out;
        scene.stars(ctx, delta);

        if (pinger != null) pinger.tick();
        for (Entry e : entries) if (e.kind == SERVER) e.icon = Favicons.get(client, e.info);

        // entrance: top bar, then tiles one by one (left -> right), then the body
        long now = Util.getMeasuringTimeMs();
        float t = (now - scene.openedAt - scene.delayMs) / 1000f;
        float fTop = f * ease((t - 0.12f) / 0.40f);
        float fBody = f * ease((t - 0.40f) / 0.45f);

        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i);
            e.anim += ((i == sel ? 1f : 0f) - e.anim) * Math.min(1f, delta * 0.35f);
        }
        scroll += (scrollTarget - scroll) * Math.min(1f, delta * 0.3f);
        float x = LEFT - scroll;
        for (Entry e : entries) {
            float s = SMALL + (BIG - SMALL) * e.anim;
            e.x = x; e.y = TOP; e.w = s; e.h = s;
            x += s + GAP;
        }

        // hover selects (like on the console), but only when the cursor actually moved
        boolean moved = Math.abs(mx - lastMx) + Math.abs(my - lastMy) > 1f;
        lastMx = mx; lastMy = my;
        if (moved && dialog == null && !menuOpen) {
            for (int i = 0; i < entries.size(); i++) {
                if (entries.get(i).contains(mx, my)) { select(i); break; }
            }
        }

        drawTopBar(ctx, mx, my, fTop);
        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i);
            float p = ease((t - 0.05f * Math.min(i, 10)) / 0.38f);
            if (e.born > 0) p = Math.min(p, ease((now - e.born) / 320f));   // new server pops in
            drawTile(ctx, e, f * p, -16f * (1f - p));
        }

        Entry se = entries.get(sel);
        float sa = Math.min(1f, (now - selAt) / 260f);
        sa = 1f - (1f - sa) * (1f - sa);
        drawSelectedLabel(ctx, se, fBody * sa);

        playRect = new float[4]; dotsRect = new float[4]; menuEdit = new float[4]; menuDel = new float[4];
        if (se.kind == HOME) drawHomeWidgets(ctx, fBody * sa);
        else if (se.kind == SERVER) drawDetail(ctx, se, mx, my, fBody * sa, sa);
        if (menuOpen && se.kind == SERVER && dialog == null) drawMenu(ctx, mx, my, fBody * sa);

        if (ExitFx.active) ExitFx.draw(ctx, client, scene.vw, se.x, se.y, se.w, se.h);

        if (dialog != null) {
            float da = dialog.alpha();
            ctx.fill(0, 0, Math.round(scene.vw) + 2, Math.round(Scene.REF_H) + 2, argb(0.66f * da, 0x050105));
            dialog.draw(ctx, textRenderer, scene.vw, mx, my, da, scene.time);
        }
        scene.end(ctx);
    }

    private void drawTopBar(DrawContext ctx, float mx, float my, float f) {
        float cy = 45f;
        String t1 = "Одиночная игра", t2 = "Сетевая игра";
        int w1 = width(textRenderer, Fnt.UI, t1), w2 = width(textRenderer, Fnt.UI, t2);
        boolean h1 = Gfx.inside(mx, my, LEFT - 8, cy - 17, w1 + 16, 34);
        text(ctx, textRenderer, Fnt.UI, t1, LEFT, cy, argb((h1 ? 1f : 0.85f) * f, 0xFFFFFF));
        singleRect = new float[]{LEFT - 8, cy - 17, w1 + 16, 34};

        float px = LEFT + w1 + 28f, pw = w2 + 34f;
        box(ctx, RR, px, cy - 17, pw, 34, 17, argb(0.96f * f, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.UI, t2, px + 17, cy, argb(f, 0x14101A));
        backRect = new float[]{px, cy - 17, pw, 34};

        String clock = LocalDateTime.now().format(CLOCK);
        int cw = width(textRenderer, Fnt.UI, clock);
        float clockX = scene.vw - RIGHT_PAD - cw;
        text(ctx, textRenderer, Fnt.UI, clock, clockX, cy, argb(0.92f * f, 0xFFFFFF));

        float avCx = clockX - 28f;
        centered(ctx, DISC, avCx, cy, 30, 30, argb(0.95f * f, ACCENT));
        String name = client.getSession().getUsername();
        String letter = (name == null || name.isEmpty()) ? "?" : name.substring(0, 1).toUpperCase(Locale.ROOT);
        textC(ctx, textRenderer, Fnt.TINY_B, letter, avCx, cy, argb(f, 0xFFFFFF));

        float gx = avCx - 46f;
        boolean hg = Gfx.inside(mx, my, gx - 16, cy - 16, 32, 32);
        centered(ctx, I_GEAR, gx, cy, 22, 22, argb((hg ? 1f : 0.82f) * f, 0xFFFFFF));
        gearRect = new float[]{gx - 16, cy - 16, 32, 32};
    }

    private void drawTile(DrawContext ctx, Entry e, float f, float dx) {
        float a = e.anim, s = e.w, x = e.x + dx, y = e.y, r = s * 0.2f;
        if (a > 0.02f) centered(ctx, GLOW, x + s / 2, y + s / 2, s * 1.9f, s * 1.9f, argb(0.30f * a * f, ACCENT));
        if (e.kind == HOME) box(ctx, RR, x, y, s, s, r, argb(0.92f * f, 0xB02633));
        else box(ctx, RR, x, y, s, s, r, argb((0.62f + 0.20f * a) * f, 0x2C2430));

        float cx = x + s / 2, cy = y + s / 2;
        if (e.kind == HOME) {
            centered(ctx, LOGO, cx, cy, s * 0.55f, s * 0.55f, argb(0.96f * f, 0xFFFFFF));
        } else if (e.kind == ADD) {
            textC(ctx, textRenderer, a > 0.5f ? Fnt.TILE_L : Fnt.TILE_S, "+", cx, cy, argb(0.8f * f, 0xFFFFFF));
        } else if (e.icon != null) {
            float in = s * 0.07f;
            blit(ctx, e.icon, Math.round(x + in), Math.round(y + in), Math.round(s - 2 * in), Math.round(s - 2 * in), argb(f, 0xFFFFFF));
        } else {
            textC(ctx, textRenderer, a > 0.5f ? Fnt.TILE_L : Fnt.TILE_S, e.initials, cx, cy, argb(f, e.color));
        }
        if (a > 0.02f) box(ctx, RR_RING, x - 4 * a, y - 4 * a, s + 8 * a, s + 8 * a, r + 4 * a, argb(0.60f * a * f, 0xFFFFFF));
    }

    private void drawSelectedLabel(DrawContext ctx, Entry se, float f) {
        float lx = se.x + se.w + 10f, cy = 196f;
        if (se.kind == ADD) {
            text(ctx, textRenderer, Fnt.TITLE, se.name, lx, cy + 14, argb(f, 0xFFFFFF));
            return;
        }
        int pw = width(textRenderer, Fnt.TINY_B, "Shrine") + 22;
        box(ctx, RR, lx, cy - 13, pw, 26, 13, argb(0.95f * f, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.TINY_B, "Shrine", lx + pw / 2f, cy, argb(f, 0x14101A));
        text(ctx, textRenderer, Fnt.TITLE, se.name, lx + pw + 9, cy, argb(f, 0xFFFFFF));
    }

    private void drawHomeWidgets(DrawContext ctx, float f) {
        float xr = scene.vw - RIGHT_PAD;
        card(ctx, xr - 304, 278, 304, 104, I_CHAT, "Сообщения", 0x3B82F6, "Пока нет диалогов", f, 0.07f);
        card(ctx, xr - 304, 395, 304, 94, I_FRIENDS, "Друзья онлайн", 0x34D17A, "Никого нет в сети", f, 0.07f);
        card(ctx, xr - 704, 380, 384, 109, I_ACTIVITY, "Активность друзей", -1, "Пока никого из друзей нет в сети", f, 0.09f);
    }

    private void card(DrawContext ctx, float x, float y, float w, float h, Identifier icon,
                      String title, int dot, String hint, float f, float fillAlpha) {
        box(ctx, RR, x, y, w, h, 22, argb(fillAlpha * 1.4f * f, 0xFFE0E0));
        box(ctx, RR, x, y, w, h, 22, argb(0.05f * f, ACCENT));
        centered(ctx, icon, x + 28, y + 27, 20, 20, argb(0.95f * f, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.LABEL, title, x + 50, y + 27, argb(0.95f * f, 0xFFFFFF));
        if (dot >= 0) {
            centered(ctx, DISC, x + w - 44, y + 27, 11, 11, argb(f, dot));
            text(ctx, textRenderer, Fnt.UI_B, "0", x + w - 30, y + 27, argb(f, 0xFFFFFF));
        }
        text(ctx, textRenderer, Fnt.LABEL, hint, x + 16, y + h - 34, argb(0.50f * f, 0xFFFFFF));
    }

    private void drawDetail(DrawContext ctx, Entry se, float mx, float my, float f, float sa) {
        float off = (1f - sa) * 10f, dx = 98f;
        text(ctx, textRenderer, Fnt.NAME_B, se.name, dx, 270 + off, argb(f, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.LABEL, "IP: " + se.info.address, dx, 304 + off, argb(0.55f * f, 0xFFFFFF));

        // online pill under the IP
        String st = String.valueOf(se.info.getStatus());
        String pc = se.info.playerCountLabel == null ? "" : se.info.playerCountLabel.getString();
        String ot; int dotColor;
        if (st.contains("UNREACHABLE")) { ot = "Не в сети"; dotColor = 0xFF5A5A; }
        else if (!pc.isBlank()) { ot = pc.replace("/", " / "); dotColor = 0x34D17A; }
        else { ot = "Опрашивание сервера..."; dotColor = 0x9A9AA8; }
        float oy = 324f + off, ow = width(textRenderer, Fnt.UI, ot) + 46f;
        box(ctx, RR, dx, oy, ow, 34, 17, argb(0.14f * f, 0xFFFFFF));
        centered(ctx, DISC, dx + 20, oy + 17, 10, 10, argb(f, dotColor));
        text(ctx, textRenderer, Fnt.UI, ot, dx + 34, oy + 17, argb(0.95f * f, 0xFFFFFF));

        // Play pill with outer ring
        float px = 104f, py = 430f + off, pw = 177f, ph = 41f;
        boolean hp = dialog == null && Gfx.inside(mx, my, px - 6, py - 6, pw + 12, ph + 12);
        box(ctx, RR_RING, px - 6, py - 6, pw + 12, ph + 12, 26, argb((hp ? 0.95f : 0.45f) * f, 0xFFFFFF));
        box(ctx, RR, px, py, pw, ph, 20.5f, argb((hp ? 1f : 0.96f) * f, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.UI_B, "Играть", px + 30, py + ph / 2f, argb(f, 0x14101A));
        box(ctx, RR, px + pw - 40, py + 7, 27, 27, 8, argb(f, 0x14101A));
        centered(ctx, I_ENTER, px + pw - 26.5f, py + 20.5f, 16, 16, argb(f, 0xFFFFFF));
        playRect = new float[]{px - 6, py - 6, pw + 12, ph + 12};

        // "..." button -> edit / delete menu
        float dcx = 320f, dcy = py + ph / 2f;
        boolean hd = dialog == null && Gfx.inside(mx, my, dcx - 23, dcy - 23, 46, 46);
        centered(ctx, DISC, dcx, dcy, 46, 46, argb((hd || menuOpen ? 0.26f : 0.14f) * f, 0xFFFFFF));
        for (int i = -1; i <= 1; i++) centered(ctx, DISC, dcx + i * 11f, dcy, 6, 6, argb(0.9f * f, 0xFFFFFF));
        dotsRect = new float[]{dcx - 23, dcy - 23, 46, 46};

        // big icon on the right
        float bx = scene.vw - RIGHT_PAD - 154f, by = 259f + off;
        box(ctx, RR, bx, by, 154, 154, 26, argb(0.12f * f, 0xFFFFFF));
        if (se.icon != null) blit(ctx, se.icon, Math.round(bx + 12), Math.round(by + 12), 130, 130, argb(f, 0xFFFFFF));
        else textC(ctx, textRenderer, Fnt.HUGE, se.initials, bx + 77, by + 77, argb(f, se.color));
    }

    private void drawMenu(DrawContext ctx, float mx, float my, float f) {
        float x = 300f, w = 176f, rowH = 40f, h = rowH * 2 + 16f, y = 430f - 10f - h;
        box(ctx, RR, x - 1, y - 1, w + 2, h + 2, 19, argb(0.12f * f, 0xFFFFFF));
        box(ctx, RR, x, y, w, h, 18, argb(0.97f * f, 0x1A1116));
        menuEdit = new float[]{x + 8, y + 8, w - 16, rowH};
        menuDel = new float[]{x + 8, y + 8 + rowH, w - 16, rowH};
        boolean he = Gfx.inside(mx, my, menuEdit[0], menuEdit[1], menuEdit[2], menuEdit[3]);
        boolean hd = Gfx.inside(mx, my, menuDel[0], menuDel[1], menuDel[2], menuDel[3]);
        if (he) box(ctx, RR, menuEdit[0], menuEdit[1], menuEdit[2], menuEdit[3], 12, argb(0.12f * f, 0xFFFFFF));
        if (hd) box(ctx, RR, menuDel[0], menuDel[1], menuDel[2], menuDel[3], 12, argb(0.16f * f, 0xFF5A5A));
        text(ctx, textRenderer, Fnt.UI, "Изменить", x + 24, menuEdit[1] + rowH / 2, argb(f, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.UI, "Удалить", x + 24, menuDel[1] + rowH / 2, argb(f, 0xFF8A8A));
    }

    // ---------- actions ----------
    private void play(Entry e) {
        if (playing != null) return;
        menuOpen = false;
        playing = e;
        playAt = Util.getMeasuringTimeMs();
    }

    private void connectTo(Entry e) {
        PsState.initials = e.initials;
        PsState.color = e.color;
        PsState.favicon = e.icon;
        ExitFx.remember("server", e.info.address);
        ServerAddress addr = ServerAddress.parse(e.info.address);
        ConnectScreen.connect(this, client, addr, e.info, false, null);
    }

    private static boolean hit(float[] r, double mx, double my) {
        return r[2] > 0 && Gfx.inside(mx, my, r[0], r[1], r[2], r[3]);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (playing != null) return true;
        if (click.button() == 0) {
            double mx = click.x() / scene.k, my = click.y() / scene.k;

            if (dialog != null) {
                int r = dialog.click(mx, my, this);
                if (r == 1) closeDialog();
                else if (r == 2) confirmDialog();
                return true;
            }
            Entry se = entries.get(sel);
            if (menuOpen) {
                if (hit(menuEdit, mx, my)) openDialog(ServerDialog.Mode.EDIT, se.info);
                else if (hit(menuDel, mx, my)) openDialog(ServerDialog.Mode.DELETE, se.info);
                else menuOpen = false;
                return true;
            }

            if (hit(singleRect, mx, my)) { client.setScreen(new PsSingleplayerScreen(parent)); return true; }
            if (hit(backRect, mx, my)) { close(); return true; }
            if (hit(gearRect, mx, my)) { client.setScreen(new OptionsScreen(this, client.options)); return true; }
            if (se.kind == SERVER && hit(playRect, mx, my)) { play(se); return true; }
            if (se.kind == SERVER && hit(dotsRect, mx, my)) { menuOpen = true; return true; }

            for (int i = 0; i < entries.size(); i++) {
                Entry e = entries.get(i);
                if (e.contains(mx, my)) {
                    select(i);
                    if (e.kind == ADD) openDialog(ServerDialog.Mode.ADD, null);
                    return true;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (dialog != null) return true;
        float total = LEFT + entries.size() * (SMALL + GAP) + (BIG - SMALL);
        float maxScroll = Math.max(0f, total - (scene.vw - 40f));
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget - (float) (verticalAmount + horizontalAmount) * 70f));
        return true;
    }

    private static float ease(float x) {
        x = Math.max(0f, Math.min(1f, x));
        return 1f - (1f - x) * (1f - x);
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void removed() {
        if (pinger != null) pinger.cancel();
    }

    @Override
    public void close() {
        if (dialog != null) { closeDialog(); return; }
        if (menuOpen) { menuOpen = false; return; }
        client.setScreen(parent);
    }
}

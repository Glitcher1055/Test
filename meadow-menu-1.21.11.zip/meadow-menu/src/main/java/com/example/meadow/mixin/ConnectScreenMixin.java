package com.example.meadow.mixin;

import com.example.meadow.ConnectView;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Drawable;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.widget.ClickableWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ConnectScreen.class)
public class ConnectScreenMixin {
    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void shrine$render(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        MinecraftClient mc = MinecraftClient.getInstance();
        int w = mc.getWindow().getScaledWidth();
        int h = mc.getWindow().getScaledHeight();
        ConnectView.render(ctx, mc, w, h, mouseX, mouseY, delta);
        // keep vanilla's own widgets (the Cancel button) visible on top of our background
        for (Element e : ((Screen) (Object) this).children()) {
            if (e instanceof ClickableWidget cw) ConnectView.drawButton(ctx, mc, cw);
            else if (e instanceof Drawable d) d.render(ctx, mouseX, mouseY, delta);
        }
        ci.cancel();
    }
}

package com.shrine;

import com.shrine.Gfx.Fnt;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.CreateWorldScreen;
import net.minecraft.client.gui.screen.world.EditWorldScreen;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import net.minecraft.world.level.storage.LevelStorage;
import net.minecraft.world.level.storage.LevelSummary;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import static com.shrine.Gfx.*;

/**
 * PS5-style "Одиночная игра": a row of world tiles, a detail view with Play, "..." menu (edit / delete)
 * and a "+" tile to create a world. Same look, animations and exit effect as the multiplayer screen.
 */
public final class PsSingleplayerScreen extends Screen {

    private static final float LEFT = 54f, TOP = 99f, SMALL = 66f, BIG = 108f, GAP = 7f, RIGHT_PAD = 55f;
    private static final int[] PALETTE = {0xE8C21A, 0x35B8F0, 0xFFFFFF, 0xFF5A5A, 0x7CE08A, 0xFFA24A, 0xD9A0FF};
    private static final int WORLD = 1, ADD = 2;
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm", Locale.ROOT);
    private static final DateTimeFormatter PLAYED = DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm", Locale.ROOT);

    private final Screen parent;
    private final String selectKey;          // world folder to pre-select (the one we just left)
    private final Scene scene = new Scene();
    private float[] avRect = new float[4];   // round avatar: opens the account picker
    private final List<Entry> entries = new ArrayList<>();
    private List<LevelSummary> worlds = new ArrayList<>();
    private ServerDialog dialog;             // only used for "delete world" confirmation
    private boolean menuOpen;
    private int sel;
    private long selAt;
    private float scroll, scrollTarget, lastMx, lastMy;
    private Entry playing;                   // world being opened: the screen fades out first
    private long playAt;

    private float[] multiRect = new float[4], backRect = new float[4], gearRect = new float[4];
    private float[] playRect = new float[4], dotsRect = new float[4], menuEdit = new float[4], menuDel = new float[4];

    public PsSingleplayerScreen(Screen parent) { this(parent, null); }

    public PsSingleplayerScreen(Screen parent, String selectKey) {
        super(Text.literal("Shrine"));
        this.parent = parent;
        this.selectKey = selectKey;
    }

    // ---------- data ----------
    private static final class Entry {
        final int kind; final String name; final LevelSummary summary; final String initials; final int color;
        float anim, x, y, w, h;
        long born;
        Entry(int kind, String name, LevelSummary summary) {
            this.kind = kind; this.name = name; this.summary = summary;
            this.initials = kind == WORLD ? initialsOf(name) : "";
            this.color = kind == WORLD ? PALETTE[Math.floorMod(name.hashCode(), PALETTE.length)] : 0xFFFFFF;
        }
        boolean contains(double mx, double my) { return Gfx.inside(mx, my, x, y, w, h); }
    }

    private static String initialsOf(String n) {
        n = n.trim();
        if (n.isEmpty()) return "?";
        String[] p = n.split("[\\s._\\-]+");
        if (p.length >= 2 && !p[0].isEmpty() && !p[1].isEmpty()) {
            return ("" + p[0].charAt(0) + p[1].charAt(0)).toUpperCase(Locale.ROOT);
        }
        return n.substring(0, Math.min(2, n.length())).toUpperCase(Locale.ROOT);
    }

    private static String nameOf(LevelSummary s) {
        String n = s.getDisplayName();
        return (n == null || n.isBlank()) ? s.getName() : n;
    }

    private static String modeRu(LevelSummary s) {
        String m = String.valueOf(s.getGameMode());
        return switch (m.toUpperCase(Locale.ROOT)) {
            case "SURVIVAL" -> "Выживание";
            case "CREATIVE" -> "Творческий";
            case "ADVENTURE" -> "Приключение";
            case "SPECTATOR" -> "Наблюдатель";
            default -> "Мир";
        };
    }

    @Override
    protected void init() {
        scene.init(width, height);
        if (ExitFx.active) scene.delayMs = 350;
        scroll = scrollTarget = 0f;
        selAt = Util.getMeasuringTimeMs();
        buildEntries(selectKey);          // just the "+" tile until the list arrives
        loadWorlds();
    }

    private void loadWorlds() {
        try {
            LevelStorage storage = client.getLevelStorage();
            storage.loadSummaries(storage.getLevelList()).thenAcceptAsync(list -> {
                List<LevelSummary> sorted = new ArrayList<>(list);
                Collections.sort(sorted);
                worlds = sorted;
                String keep = (sel >= 0 && sel < entries.size() && entries.get(sel).summary != null)
                        ? entries.get(sel).summary.getName() : selectKey;
                buildEntries(keep);
                selAt = Util.getMeasuringTimeMs();
            }, client).exceptionally(t -> null);
        } catch (Exception ignored) {
            // the folder could not be read: only the "+" tile is shown
        }
    }

    private void buildEntries(String selectName) {
        entries.clear();
        for (LevelSummary s : worlds) entries.add(new Entry(WORLD, nameOf(s), s));
        entries.add(new Entry(ADD, "Создать мир", null));
        sel = 0;
        if (selectName != null) {
            for (int i = 0; i < entries.size(); i++) {
                LevelSummary s = entries.get(i).summary;
                if (s != null && selectName.equals(s.getName())) { sel = i; break; }
            }
        }
        for (int i = 0; i < entries.size(); i++) entries.get(i).anim = i == sel ? 1f : 0f;
        menuOpen = false;
        ensureVisible();
    }

    private void select(int i) {
        if (i == sel) return;
        sel = i;
        selAt = Util.getMeasuringTimeMs();
        menuOpen = false;
        ensureVisible();
    }

    private void ensureVisible() {
        float xs = LEFT;
        for (int i = 0; i < sel; i++) xs += SMALL + GAP;
        float total = LEFT + entries.size() * (SMALL + GAP) + (BIG - SMALL);
        float maxScroll = Math.max(0f, total - (scene.vw - 40f));
        if (xs + BIG - scrollTarget > scene.vw - 40f) scrollTarget = xs + BIG - (scene.vw - 40f);
        if (xs - scrollTarget < LEFT) scrollTarget = xs - LEFT;
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget));
    }

    // ---------- render ----------
    @Override
    public void render(DrawContext ctx, int mxReal, int myReal, float delta) {
        float out = 1f;
        if (playing != null) {
            out = 1f - (Util.getMeasuringTimeMs() - playAt) / 320f;
            if (out <= 0f) { Gfx.cover(ctx, width, height); Entry p = playing; playing = null; openWorld(p); return; }
        }
        scene.begin(ctx, mxReal, myReal, delta);
        float mx = scene.mx, my = scene.my, f = scene.fade() * out;
        scene.stars(ctx, delta);

        long now = Util.getMeasuringTimeMs();
        float t = (now - scene.openedAt - scene.delayMs) / 1000f;
        float fTop = f * ease((t - 0.12f) / 0.40f);
        float fBody = f * ease((t - 0.40f) / 0.45f);

        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i);
            e.anim += ((i == sel ? 1f : 0f) - e.anim) * Math.min(1f, delta * 0.35f);
        }
        scroll += (scrollTarget - scroll) * Math.min(1f, delta * 0.3f);
        float x = LEFT - scroll;
        for (Entry e : entries) {
            float s = SMALL + (BIG - SMALL) * e.anim;
            e.x = x; e.y = TOP; e.w = s; e.h = s;
            x += s + GAP;
        }

        boolean moved = Math.abs(mx - lastMx) + Math.abs(my - lastMy) > 1f;
        lastMx = mx; lastMy = my;
        if (moved && dialog == null && !menuOpen && playing == null) {
            for (int i = 0; i < entries.size(); i++) {
                if (entries.get(i).contains(mx, my)) { select(i); break; }
            }
        }

        drawTopBar(ctx, mx, my, fTop);
        for (int i = 0; i < entries.size(); i++) {
            Entry e = entries.get(i);
            float p = ease((t - 0.05f * Math.min(i, 10)) / 0.38f);
            if (e.born > 0) p = Math.min(p, ease((now - e.born) / 320f));
            drawTile(ctx, e, f * p, -16f * (1f - p));
        }

        Entry se = entries.get(sel);
        float sa = Math.min(1f, (now - selAt) / 260f);
        sa = 1f - (1f - sa) * (1f - sa);
        drawSelectedLabel(ctx, se, fBody * sa);

        playRect = new float[4]; dotsRect = new float[4]; menuEdit = new float[4]; menuDel = new float[4];
        if (se.kind == WORLD) drawDetail(ctx, se, mx, my, fBody * sa, sa);
        else drawCreateHint(ctx, fBody * sa);
        if (menuOpen && se.kind == WORLD && dialog == null) drawMenu(ctx, mx, my, fBody * sa);

        if (ExitFx.active) ExitFx.draw(ctx, client, scene.vw, se.x, se.y, se.w, se.h);

        if (dialog != null) {
            float da = dialog.alpha();
            ctx.fill(0, 0, Math.round(scene.vw) + 2, Math.round(Scene.REF_H) + 2, argb(0.66f * da, 0x050105));
            dialog.draw(ctx, textRenderer, scene.vw, mx, my, da, scene.time);
        }
        scene.end(ctx);
    }

    private void drawTopBar(DrawContext ctx, float mx, float my, float f) {
        float cy = 45f;
        String t1 = "Одиночная игра", t2 = "Сетевая игра";
        int w1 = width(textRenderer, Fnt.UI, t1), w2 = width(textRenderer, Fnt.UI, t2);

        float p1 = LEFT - 17f, pw1 = w1 + 34f;
        box(ctx, RR, p1, cy - 17, pw1, 34, 17, argb(0.96f * f, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.UI, t1, p1 + 17, cy, argb(f, 0x14101A));
        backRect = new float[]{p1, cy - 17, pw1, 34};

        float x2 = p1 + pw1 + 12f;
        boolean h2 = Gfx.inside(mx, my, x2 - 8, cy - 17, w2 + 16, 34);
        text(ctx, textRenderer, Fnt.UI, t2, x2, cy, argb((h2 ? 1f : 0.85f) * f, 0xFFFFFF));
        multiRect = new float[]{x2 - 8, cy - 17, w2 + 16, 34};

        String clock = LocalDateTime.now().format(CLOCK);
        int cw = width(textRenderer, Fnt.UI, clock);
        float clockX = scene.vw - RIGHT_PAD - cw;
        text(ctx, textRenderer, Fnt.UI, clock, clockX, cy, argb(0.92f * f, 0xFFFFFF));

        float avCx = clockX - 28f;
        centered(ctx, DISC, avCx, cy, 30, 30, argb(0.95f * f, ACCENT));
        String name = client.getSession().getUsername();
        String letter = (name == null || name.isEmpty()) ? "?" : name.substring(0, 1).toUpperCase(Locale.ROOT);
        textC(ctx, textRenderer, Fnt.TINY_B, letter, avCx, cy, argb(f, 0xFFFFFF));
        avRect = new float[]{avCx - 16, cy - 16, 32, 32};
        if (Ias.available() && dialog == null && Gfx.inside(mx, my, avRect[0], avRect[1], avRect[2], avRect[3]))
            centered(ctx, RING, avCx, cy, 40, 40, argb(0.95f * f, 0xFFFFFF));   // click: switch account

        float gx = avCx - 46f;
        boolean hg = Gfx.inside(mx, my, gx - 16, cy - 16, 32, 32);
        centered(ctx, I_GEAR, gx, cy, 22, 22, argb((hg ? 1f : 0.82f) * f, 0xFFFFFF));
        gearRect = new float[]{gx - 16, cy - 16, 32, 32};
    }

    private void drawTile(DrawContext ctx, Entry e, float f, float dx) {
        float a = e.anim, s = e.w, x = e.x + dx, y = e.y, r = s * 0.2f;
        if (a > 0.02f) centered(ctx, GLOW, x + s / 2, y + s / 2, s * 1.9f, s * 1.9f, argb(0.30f * a * f, ACCENT));
        box(ctx, RR, x, y, s, s, r, argb((0.62f + 0.20f * a) * f, 0x2C2430));
        float cx = x + s / 2, cy = y + s / 2;
        if (e.kind == ADD) {
            textC(ctx, textRenderer, a > 0.5f ? Fnt.TILE_L : Fnt.TILE_S, "+", cx, cy, argb(0.8f * f, 0xFFFFFF));
        } else {
            textC(ctx, textRenderer, a > 0.5f ? Fnt.TILE_L : Fnt.TILE_S, e.initials, cx, cy, argb(f, e.color));
        }
        if (a > 0.02f) box(ctx, RR_RING, x - 4 * a, y - 4 * a, s + 8 * a, s + 8 * a, r + 4 * a, argb(0.60f * a * f, 0xFFFFFF));
    }

    private void drawSelectedLabel(DrawContext ctx, Entry se, float f) {
        float lx = se.x + se.w + 10f, cy = 196f;
        if (se.kind == ADD) {
            text(ctx, textRenderer, Fnt.TITLE, se.name, lx, cy + 14, argb(f, 0xFFFFFF));
            return;
        }
        String badge = modeRu(se.summary);
        int pw = width(textRenderer, Fnt.TINY_B, badge) + 22;
        box(ctx, RR, lx, cy - 13, pw, 26, 13, argb(0.95f * f, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.TINY_B, badge, lx + pw / 2f, cy, argb(f, 0x14101A));
        text(ctx, textRenderer, Fnt.TITLE, se.name, lx + pw + 9, cy, argb(f, 0xFFFFFF));
    }

    private void drawCreateHint(DrawContext ctx, float f) {
        float dx = 98f;
        text(ctx, textRenderer, Fnt.NAME_B, "Новый мир", dx, 270, argb(f, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.LABEL, worlds.isEmpty() ? "У вас пока нет миров, нажмите «+», чтобы создать первый"
                : "Нажмите «+», чтобы создать ещё один мир", dx, 304, argb(0.55f * f, 0xFFFFFF));
    }

    private void drawDetail(DrawContext ctx, Entry se, float mx, float my, float f, float sa) {
        float off = (1f - sa) * 10f, dx = 98f;
        LevelSummary s = se.summary;
        text(ctx, textRenderer, Fnt.NAME_B, se.name, dx, 270 + off, argb(f, 0xFFFFFF));
        String when = LocalDateTime.ofInstant(Instant.ofEpochMilli(s.getLastPlayed()), ZoneId.systemDefault()).format(PLAYED);
        text(ctx, textRenderer, Fnt.LABEL, s.getLastPlayed() > 0 ? "Последняя игра: " + when : "Ещё не открывался",
                dx, 304 + off, argb(0.55f * f, 0xFFFFFF));

        boolean locked = s.isLocked();
        String ot = locked ? "Мир открыт в другом окне" : modeRu(s);
        int dotColor = locked ? 0xFF5A5A : 0x34D17A;
        float oy = 324f + off, ow = width(textRenderer, Fnt.UI, ot) + 46f;
        box(ctx, RR, dx, oy, ow, 34, 17, argb(0.14f * f, 0xFFFFFF));
        centered(ctx, DISC, dx + 20, oy + 17, 10, 10, argb(f, dotColor));
        text(ctx, textRenderer, Fnt.UI, ot, dx + 34, oy + 17, argb(0.95f * f, 0xFFFFFF));

        float px = 104f, py = 430f + off, pw = 177f, ph = 41f;
        boolean hp = dialog == null && !locked && Gfx.inside(mx, my, px - 6, py - 6, pw + 12, ph + 12);
        float pa = locked ? 0.35f : 1f;
        box(ctx, RR_RING, px - 6, py - 6, pw + 12, ph + 12, 26, argb((hp ? 0.95f : 0.45f) * pa * f, 0xFFFFFF));
        box(ctx, RR, px, py, pw, ph, 20.5f, argb((hp ? 1f : 0.96f) * pa * f, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.UI_B, "Играть", px + 30, py + ph / 2f, argb(pa * f, 0x14101A));
        box(ctx, RR, px + pw - 40, py + 7, 27, 27, 8, argb(pa * f, 0x14101A));
        centered(ctx, I_ENTER, px + pw - 26.5f, py + 20.5f, 16, 16, argb(pa * f, 0xFFFFFF));
        playRect = new float[]{px - 6, py - 6, pw + 12, ph + 12};

        float dcx = 320f, dcy = py + ph / 2f;
        boolean hd = dialog == null && Gfx.inside(mx, my, dcx - 23, dcy - 23, 46, 46);
        centered(ctx, DISC, dcx, dcy, 46, 46, argb((hd || menuOpen ? 0.26f : 0.14f) * f, 0xFFFFFF));
        for (int i = -1; i <= 1; i++) centered(ctx, DISC, dcx + i * 11f, dcy, 6, 6, argb(0.9f * f, 0xFFFFFF));
        dotsRect = new float[]{dcx - 23, dcy - 23, 46, 46};

        float bx = scene.vw - RIGHT_PAD - 154f, by = 259f + off;
        box(ctx, RR, bx, by, 154, 154, 26, argb(0.12f * f, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.HUGE, se.initials, bx + 77, by + 77, argb(f, se.color));
    }

    private void drawMenu(DrawContext ctx, float mx, float my, float f) {
        float x = 300f, w = 176f, rowH = 40f, h = rowH * 2 + 16f, y = 430f - 10f - h;
        box(ctx, RR, x - 1, y - 1, w + 2, h + 2, 19, argb(0.12f * f, 0xFFFFFF));
        box(ctx, RR, x, y, w, h, 18, argb(0.97f * f, 0x1A1116));
        menuEdit = new float[]{x + 8, y + 8, w - 16, rowH};
        menuDel = new float[]{x + 8, y + 8 + rowH, w - 16, rowH};
        boolean he = Gfx.inside(mx, my, menuEdit[0], menuEdit[1], menuEdit[2], menuEdit[3]);
        boolean hd = Gfx.inside(mx, my, menuDel[0], menuDel[1], menuDel[2], menuDel[3]);
        if (he) box(ctx, RR, menuEdit[0], menuEdit[1], menuEdit[2], menuEdit[3], 12, argb(0.12f * f, 0xFFFFFF));
        if (hd) box(ctx, RR, menuDel[0], menuDel[1], menuDel[2], menuDel[3], 12, argb(0.16f * f, 0xFF5A5A));
        text(ctx, textRenderer, Fnt.UI, "Изменить", x + 24, menuEdit[1] + rowH / 2, argb(f, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.UI, "Удалить", x + 24, menuDel[1] + rowH / 2, argb(f, 0xFF8A8A));
    }

    // ---------- actions ----------
    private void play(Entry e) {
        if (playing != null || e.summary.isLocked()) return;
        menuOpen = false;
        playing = e;
        playAt = Util.getMeasuringTimeMs();
    }

    private void openWorld(Entry e) {
        String name = e.summary.getName();
        PsState.initials = e.initials;
        PsState.color = e.color;
        PsState.favicon = null;
        ExitFx.remember("world", name);
        client.createIntegratedServerLoader().start(name, () -> client.setScreen(new PsSingleplayerScreen(parent, name)));
    }

    private void createWorld() {
        WorldCreateFx.active = true;
        CreateWorldScreen.show(client, () -> client.setScreen(new PsSingleplayerScreen(parent)));
    }

    private void editWorld(Entry e) {
        String name = e.summary.getName();
        try {
            LevelStorage.Session session = client.getLevelStorage().createSession(name);
            WorldCreateFx.active = true;
            client.setScreen(EditWorldScreen.create(client, session, changed -> {
                try { session.close(); } catch (Exception ignored) { }
                client.setScreen(new PsSingleplayerScreen(parent, name));
            }));
        } catch (Exception ignored) {
            // world is locked or unreadable: stay on this screen
        }
    }

    private void askDelete(Entry e) {
        menuOpen = false;
        dialog = new ServerDialog(ServerDialog.Mode.DELETE, null, null, 0, e.name + " будет удалён навсегда", null);
        dialog.titleOverride = "Удаление мира";
    }

    private void confirmDelete() {
        Entry e = entries.get(sel);
        dialog = null;
        if (e.summary == null) return;
        try (LevelStorage.Session session = client.getLevelStorage().createSession(e.summary.getName())) {
            session.deleteSessionLock();
        } catch (Exception ignored) {
            // could not delete (world in use): the list below is simply reloaded
        }
        int keep = Math.max(0, sel - 1);
        String keepName = keep < entries.size() && entries.get(keep).summary != null ? entries.get(keep).summary.getName() : null;
        worlds = new ArrayList<>(worlds);
        worlds.remove(e.summary);
        buildEntries(keepName);
        selAt = Util.getMeasuringTimeMs();
        loadWorlds();
    }

    private static boolean hit(float[] r, double mx, double my) {
        return r[2] > 0 && Gfx.inside(mx, my, r[0], r[1], r[2], r[3]);
    }

    // ---------- input ----------
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (playing != null) return true;
        if (click.button() == 0) {
            double mx = click.x() / scene.k, my = click.y() / scene.k;

            if (dialog != null) {
                int r = dialog.click(mx, my, this);
                if (r == 1) dialog = null;
                else if (r == 2) confirmDelete();
                return true;
            }
            Entry se = entries.get(sel);
            if (menuOpen) {
                if (hit(menuEdit, mx, my)) editWorld(se);
                else if (hit(menuDel, mx, my)) askDelete(se);
                else menuOpen = false;
                return true;
            }

            if (Ias.available() && hit(avRect, mx, my)) { client.setScreen(new PsAccountScreen(this)); return true; }
            if (hit(multiRect, mx, my)) { client.setScreen(new PsMultiplayerScreen(parent)); return true; }
            if (hit(backRect, mx, my)) { close(); return true; }
            if (hit(gearRect, mx, my)) { client.setScreen(new OptionsScreen(this, client.options)); return true; }
            if (se.kind == WORLD && hit(playRect, mx, my)) { play(se); return true; }
            if (se.kind == WORLD && hit(dotsRect, mx, my)) { menuOpen = true; return true; }

            for (int i = 0; i < entries.size(); i++) {
                Entry e = entries.get(i);
                if (e.contains(mx, my)) {
                    select(i);
                    if (e.kind == ADD) createWorld();
                    return true;
                }
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (dialog != null) return true;
        float total = LEFT + entries.size() * (SMALL + GAP) + (BIG - SMALL);
        float maxScroll = Math.max(0f, total - (scene.vw - 40f));
        scrollTarget = Math.max(0f, Math.min(maxScroll, scrollTarget - (float) (verticalAmount + horizontalAmount) * 70f));
        return true;
    }

    private static float ease(float x) {
        x = Math.max(0f, Math.min(1f, x));
        return 1f - (1f - x) * (1f - x);
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void close() {
        if (dialog != null) { dialog = null; return; }
        if (menuOpen) { menuOpen = false; return; }
        client.setScreen(parent);
    }
}

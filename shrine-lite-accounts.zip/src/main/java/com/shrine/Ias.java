package com.shrine;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.function.Consumer;

/**
 * Thin reflection bridge to In-Game Account Switcher (IAS, the unmodified mod is nested in our jar).
 * IAS keeps the account list and does the real sign-in (Microsoft tokens, session swap); this mod only draws the
 * PS5-style picker on top of it. Without IAS {@link #available()} is false and the avatar simply stays decoration.
 *
 * Used IAS API:
 *  - IASStorage.ACCOUNTS (List&lt;Account&gt;), IAS.saveStorage(), IAS.executor()
 *  - Account.name() / canLogin() / login(LoginHandler, Runnable), OfflineAccount(String name, UUID skin), OfflineAccount.uuid(String)
 *  - LoginData(String name, UUID uuid, String token, boolean online), IASMinecraft.account(MinecraftClient, LoginData)
 *  - MicrosoftCryptPopupScreen(Screen parent, Consumer&lt;Account&gt;)  - IAS's own "add Microsoft account" flow
 */
final class Ias {
    private Ias() {}

    /** One stored account. {@code raw} is the IAS Account object (kept as Object on purpose). */
    record Acc(Object raw, String name, boolean offline, boolean canLogin) {}

    /** Receives the progress of one sign-in. All methods are called on the client thread, except password(). */
    interface Listener {
        boolean cancelled();
        void stage(String text);
        CompletableFuture<String> password();   // called on an IAS thread: hop to the client thread yourself
        void success();
        void error(String message);
    }

    private static boolean tried, ok;
    private static Field fAccounts;
    private static Method mSave, mName, mCanLogin, mLogin, mUuidOf, mAccount, mExecutor, mFriendly, mKey;
    private static Constructor<?> kOffline, kLoginData, kCrypt;
    private static Class<?> cOffline, cHandler;

    static boolean available() {
        if (tried) return ok;
        tried = true;
        try {
            if (!FabricLoader.getInstance().isModLoaded("ias")) return false;
            Class<?> cIas = Class.forName("ru.vidtu.ias.IAS");
            Class<?> cStorage = Class.forName("ru.vidtu.ias.config.IASStorage");
            Class<?> cAccount = Class.forName("ru.vidtu.ias.account.Account");
            Class<?> cLoginData = Class.forName("ru.vidtu.ias.auth.LoginData");
            Class<?> cIasMc = Class.forName("ru.vidtu.ias.IASMinecraft");
            cOffline = Class.forName("ru.vidtu.ias.account.OfflineAccount");
            cHandler = Class.forName("ru.vidtu.ias.auth.handlers.LoginHandler");
            if ((Boolean) cIas.getMethod("disabled").invoke(null)) return false;
            fAccounts = cStorage.getField("ACCOUNTS");
            mSave = cIas.getMethod("saveStorage");
            mExecutor = cIas.getMethod("executor");
            mName = cAccount.getMethod("name");
            mCanLogin = cAccount.getMethod("canLogin");
            mLogin = cAccount.getMethod("login", cHandler, Runnable.class);
            kOffline = cOffline.getConstructor(String.class, UUID.class);
            mUuidOf = cOffline.getMethod("uuid", String.class);
            kLoginData = cLoginData.getConstructor(String.class, UUID.class, String.class, boolean.class);
            mAccount = cIasMc.getMethod("account", MinecraftClient.class, cLoginData);
            ok = true;
        } catch (Throwable t) {
            ok = false;
            return false;
        }
        try {   // optional parts: the Microsoft add flow and the friendly error texts
            Class<?> c = Class.forName("ru.vidtu.ias.screen.MicrosoftCryptPopupScreen");
            kCrypt = c.getDeclaredConstructor(Screen.class, Consumer.class);
            kCrypt.setAccessible(true);
        } catch (Throwable ignored) { kCrypt = null; }
        try {
            Class<?> c = Class.forName("ru.vidtu.ias.utils.exceptions.FriendlyException");
            mFriendly = c.getMethod("friendlyInChain", Throwable.class);
            mKey = c.getMethod("key");
        } catch (Throwable ignored) { mFriendly = null; }
        return ok;
    }

    static boolean canAddMicrosoft() { return available() && kCrypt != null; }

    @SuppressWarnings("unchecked")
    private static List<Object> storage() throws Exception { return (List<Object>) fAccounts.get(null); }

    /** Copy of the stored accounts, in IAS order. */
    static List<Acc> accounts() {
        List<Acc> out = new ArrayList<>();
        if (!available()) return out;
        try {
            for (Object o : new ArrayList<>(storage())) {
                out.add(new Acc(o, (String) mName.invoke(o), cOffline.isInstance(o), (Boolean) mCanLogin.invoke(o)));
            }
        } catch (Throwable ignored) { }
        return out;
    }

    /** Adds an offline account by nickname. Returns an error text, or null when added. */
    static String addOffline(String nick) {
        if (!available()) return "IAS не найден";
        String n = nick == null ? "" : nick.trim();
        if (n.length() < 3 || n.length() > 16) return "Ник: от 3 до 16 символов";
        if (!n.matches("[A-Za-z0-9_]+")) return "Только буквы, цифры и _";
        try {
            List<Object> list = storage();
            for (Object o : list) {
                if (cOffline.isInstance(o) && ((String) mName.invoke(o)).equalsIgnoreCase(n)) return "Такой аккаунт уже есть";
            }
            list.add(kOffline.newInstance(n, null));
            mSave.invoke(null);
            return null;
        } catch (Throwable t) {
            return "Не удалось добавить";
        }
    }

    static void remove(Acc a) {
        if (!available() || a == null) return;
        try {
            storage().remove(a.raw());
            mSave.invoke(null);
        } catch (Throwable ignored) { }
    }

    /** Opens IAS's own "sign in with Microsoft" flow; when it finishes IAS returns to {@code back}. */
    static boolean addMicrosoft(Screen back) {
        if (!canAddMicrosoft()) return false;
        try {
            Consumer<Object> handler = acc -> {
                try {
                    List<Object> list = storage();
                    list.remove(acc);
                    list.add(acc);
                    mSave.invoke(null);
                } catch (Throwable ignored) { }
            };
            MinecraftClient.getInstance().setScreen((Screen) kCrypt.newInstance(back, handler));
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    /** Signs in with a stored account (offline: instantly; Microsoft: IAS refreshes the tokens, may ask for a password). */
    static void login(Acc a, Listener l) {
        MinecraftClient mc = MinecraftClient.getInstance();
        try {
            if (a.offline() || !a.canLogin()) {
                apply(mc, kLoginData.newInstance(a.name(), mUuidOf.invoke(null, a.name()), "ias:offline", false), l);
                return;
            }
            Object handler = Proxy.newProxyInstance(cHandler.getClassLoader(), new Class<?>[]{cHandler}, (proxy, m, args) -> {
                switch (m.getName()) {
                    case "cancelled":
                        return l.cancelled();
                    case "stage": {
                        String key = (String) args[0];
                        Object[] va = args.length > 1 && args[1] instanceof Object[] oa ? oa : new Object[0];
                        mc.execute(() -> l.stage(Text.translatable(key, va).getString()));
                        return null;
                    }
                    case "password":
                        return l.password();
                    case "success": {
                        Object data = args[0];
                        mc.execute(() -> {
                            try { mSave.invoke(null); } catch (Throwable ignored) { }
                            apply(mc, data, l);
                        });
                        return null;
                    }
                    case "error": {
                        Throwable t = (Throwable) args[0];
                        mc.execute(() -> l.error(message(t)));
                        return null;
                    }
                    case "toString":
                        return "ShrineLoginHandler";
                    case "hashCode":
                        return System.identityHashCode(proxy);
                    case "equals":
                        return proxy == args[0];
                    default:
                        return null;
                }
            });
            Executor ex = (Executor) mExecutor.invoke(null);
            ex.execute(() -> {
                try {
                    mLogin.invoke(a.raw(), handler, (Runnable) () -> { });
                } catch (Throwable t) {
                    mc.execute(() -> l.error(message(t.getCause() != null ? t.getCause() : t)));
                }
            });
        } catch (Throwable t) {
            l.error(message(t));
        }
    }

    /** Swaps the game session (IAS does the work, we only wait for it). */
    private static void apply(MinecraftClient mc, Object loginData, Listener l) {
        try {
            CompletableFuture<?> f = (CompletableFuture<?>) mAccount.invoke(null, mc, loginData);
            f.whenCompleteAsync((v, t) -> {
                if (t != null) l.error(message(t));
                else l.success();
            }, mc);
        } catch (Throwable t) {
            l.error(message(t));
        }
    }

    private static String message(Throwable t) {
        try {
            if (mFriendly != null) {
                Object fe = mFriendly.invoke(null, t);
                if (fe != null) return Text.translatable((String) mKey.invoke(fe)).getString();
            }
        } catch (Throwable ignored) { }
        return "Не удалось войти";
    }
}

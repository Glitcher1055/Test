package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import static com.shrine.Gfx.*;

/**
 * "Траектории полёта": landing marker for ender pearls, snowballs, eggs, potions, XP bottles, arrows and tridents.
 * Shows where the thing will land BEFORE you throw it (item in hand / bow being drawn / loaded crossbow) and
 * for projectiles already in the air (yours and other players'). The marker turns red when the projectile
 * would hit a living target.
 *
 * Drawn as a 2D HUD overlay: 3D points are projected to the screen by hand (camera position, yaw / pitch, FOV),
 * so no world-render API is needed. First person only.
 *
 * Look: a glowing line, and on the landing point a rotating segmented ring + inner white ring + diamond that lies
 * on the surface, follows the aim smoothly, turns red (with a screen vignette) when it would hit someone, and a
 * multishot crossbow draws three lines / three marks.
 */
final class TrajectoryFx {
    private TrajectoryFx() {}

    static final String K_ON = "fx.traj", K_LEN = "fx.traj.len", K_TIME = "fx.traj.time", K_PRED = "fx.traj.predict",
            K_OTH = "fx.traj.others", K_LINE = "fx.traj.line", K_RED = "fx.traj.red", K_SIZE = "fx.traj.size",
            K_COL = "fx.traj.color", K_MULTI = "fx.traj.multi", K_VIG = "fx.traj.vignette";

    private static final Identifier TIMER = tex("ico_timer");
    private static final int ICON_RED = 0xFF3A5E;
    private static final Vec3d UP = new Vec3d(0, 1, 0);

    static void init() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "trajectory"),
                TrajectoryFx::render);
    }

    // ---------------------------------------------------------------- camera / projection

    private static final class Cam {
        Vec3d pos, fwd, right, up;
        float f, cx, cy;

        /** {screenX, screenY, depth} or null when the point is behind the camera. */
        float[] proj(Vec3d p) {
            Vec3d d = p.subtract(pos);
            double z = d.dotProduct(fwd);
            if (z < 0.05) return null;
            double x = d.dotProduct(right), y = d.dotProduct(up);
            return new float[]{(float) (cx + x / z * f), (float) (cy - y / z * f), (float) z};
        }
    }

    // ---------------------------------------------------------------- simulation

    private record Shot(double speed, double gravity, double roll, boolean arrow) {}

    private static final class Result {
        final List<Vec3d> pts = new ArrayList<>();
        Vec3d end, normal = UP;
        LivingEntity target;
        double ticks;
    }

    private static String path(net.minecraft.item.Item it) { return Registries.ITEM.getId(it).getPath(); }

    /** What the player would throw / shoot right now, or null. */
    private static Shot held(ClientPlayerEntity p) {
        for (Hand hand : Hand.values()) {
            ItemStack st = p.getStackInHand(hand);
            if (st.isEmpty()) continue;
            boolean using = p.isUsingItem() && p.getActiveItem().getItem() == st.getItem();
            switch (path(st.getItem())) {
                case "ender_pearl", "snowball", "egg" -> { return new Shot(1.5, 0.03, 0, false); }
                case "splash_potion", "lingering_potion" -> { return new Shot(0.5, 0.05, -20, false); }
                case "experience_bottle" -> { return new Shot(0.7, 0.07, -20, false); }
                case "trident" -> { if (using) return new Shot(2.5, 0.05, 0, true); }
                case "bow" -> {
                    if (using) {
                        float pull = BowItem.getPullProgress(p.getItemUseTime());
                        if (pull >= 0.1f) return new Shot(pull * 3.0, 0.05, 0, true);
                    }
                }
                case "crossbow" -> { if (CrossbowItem.isCharged(st)) return new Shot(3.15, 0.05, 0, true); }
                default -> { }
            }
        }
        return null;
    }

    private static Result sim(ClientWorld w, Entity shooter, Entity skip, Vec3d pos, Vec3d vel, double grav,
                              boolean arrow, int steps, List<LivingEntity> targets) {
        Result r = new Result();
        r.pts.add(pos);
        for (int i = 0; i < steps; i++) {
            Vec3d next = pos.add(vel);
            BlockHitResult bh = w.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER,
                    RaycastContext.FluidHandling.NONE, shooter));
            boolean blockHit = bh.getType() != HitResult.Type.MISS;
            double best = blockHit ? bh.getPos().squaredDistanceTo(pos) : Double.MAX_VALUE;
            LivingEntity hitE = null;
            Vec3d hitP = null;
            for (LivingEntity e : targets) {
                if (e == skip) continue;
                Optional<Vec3d> o = e.getBoundingBox().expand(0.3).raycast(pos, next);
                if (o.isPresent()) {
                    double d = o.get().squaredDistanceTo(pos);
                    if (d < best) { best = d; hitE = e; hitP = o.get(); }
                }
            }
            double len = Math.max(1.0e-6, vel.length());
            if (hitE != null) {
                r.end = hitP; r.target = hitE; r.normal = UP;
                r.ticks = i + Math.sqrt(best) / len;
                r.pts.add(hitP);
                return r;
            }
            if (blockHit) {
                r.end = bh.getPos();
                r.normal = new Vec3d(bh.getSide().getOffsetX(), bh.getSide().getOffsetY(), bh.getSide().getOffsetZ());
                r.ticks = i + Math.sqrt(best) / len;
                r.pts.add(r.end);
                return r;
            }
            pos = next;
            r.pts.add(pos);
            boolean water = w.getFluidState(BlockPos.ofFloored(pos)).isIn(FluidTags.WATER);
            double drag = water ? (arrow ? 0.6 : 0.8) : 0.99;
            vel = vel.multiply(drag).subtract(0, grav, 0);
            if (pos.y < w.getBottomY() - 8) break;
        }
        return r;
    }

    // ---------------------------------------------------------------- frame

    /** Frame state for the smooth follow / red fade of the marker of your own shot. */
    private static Vec3d smooth;
    private static long smoothT, redT;
    private static float redA;

    private static void render(DrawContext ctx, RenderTickCounter counter) {
        if (!ShrineCfg.bool(K_ON, true)) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null || mc.options.hudHidden || !mc.options.getPerspective().isFirstPerson()) return;
        float tp = counter.getTickProgress(false);

        Cam cam = new Cam();
        cam.pos = p.getCameraPosVec(tp);
        double yaw = Math.toRadians(p.getYaw(tp)), pit = Math.toRadians(p.getPitch(tp));
        cam.fwd = new Vec3d(-Math.sin(yaw) * Math.cos(pit), -Math.sin(pit), Math.cos(yaw) * Math.cos(pit));
        cam.right = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
        cam.up = cam.right.crossProduct(cam.fwd);
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        double fov = mc.options.getFov().getValue();
        cam.f = (float) ((sh / 2.0) / Math.tan(Math.toRadians(fov) / 2.0));
        cam.cx = sw / 2f;
        cam.cy = sh / 2f;

        int steps = Math.max(10, Math.round(ShrineCfg.num(K_LEN, 120f)));
        List<LivingEntity> targets = new ArrayList<>();
        for (Entity e : w.getEntities()) {
            if (e instanceof LivingEntity le && le != p && le.isAlive() && !le.isSpectator()
                    && le.squaredDistanceTo(p) < 90 * 90 && targets.size() < 64) targets.add(le);
        }

        // projectiles already in the air (yours and other players')
        if (ShrineCfg.bool(K_OTH, true)) {
            int shown = 0;
            for (Entity e : w.getEntities()) {
                if (shown >= 10) break;
                if (!(e instanceof ProjectileEntity pe) || e.squaredDistanceTo(p) > 96 * 96) continue;
                double grav; boolean arrow = false;
                switch (Registries.ENTITY_TYPE.getId(e.getType()).getPath()) {
                    case "ender_pearl", "snowball", "egg" -> grav = 0.03;
                    case "splash_potion", "lingering_potion", "potion" -> grav = 0.05;
                    case "experience_bottle" -> grav = 0.07;
                    case "arrow", "spectral_arrow", "trident" -> { grav = 0.05; arrow = true; }
                    default -> { continue; }
                }
                Vec3d v = e.getVelocity();
                if (v.lengthSquared() < 0.0025) continue;           // stuck in a block / standing still
                Result r = sim(w, e, pe.getOwner(), e.getLerpedPos(tp), v, grav, arrow, steps, targets);
                draw(ctx, mc, cam, List.of(r), false);
                shown++;
            }
        }

        // what you are about to throw
        if (ShrineCfg.bool(K_PRED, true)) {
            Shot s = held(p);
            if (s != null) {
                double ya = yaw, pi = pit, ro = Math.toRadians(s.roll());
                Vec3d dir = new Vec3d(-Math.sin(ya) * Math.cos(pi), -Math.sin(pi + ro), Math.cos(ya) * Math.cos(pi))
                        .normalize().multiply(s.speed());
                Vec3d pv = p.getVelocity();
                Vec3d start = p.getCameraPosVec(tp).subtract(0, 0.1, 0);
                List<Result> group = new ArrayList<>();
                // main line first (it owns the timer and the red state), then multishot side lines
                group.add(sim(w, p, p, start, dir.add(pv.x, p.isOnGround() ? 0 : pv.y, pv.z), s.gravity(), s.arrow(), steps, targets));
                if (s.arrow() && s.speed() > 3.0 && ShrineCfg.bool(K_MULTI, true) && multishot(p)) {
                    for (int sgn = -1; sgn <= 1; sgn += 2) {
                        Vec3d d2 = rotate(dir, cam.up, Math.toRadians(10.0 * sgn));
                        group.add(sim(w, p, p, start, d2.add(pv.x, p.isOnGround() ? 0 : pv.y, pv.z), s.gravity(), s.arrow(), steps, targets));
                    }
                }
                draw(ctx, mc, cam, group, true);
            } else {
                redA = 0f;
            }
        }
    }

    /** A loaded crossbow with Multishot holds three projectiles. */
    private static boolean multishot(ClientPlayerEntity p) {
        for (Hand hand : Hand.values()) {
            ItemStack st = p.getStackInHand(hand);
            if (st.isEmpty() || !path(st.getItem()).equals("crossbow")) continue;
            ChargedProjectilesComponent c = st.get(DataComponentTypes.CHARGED_PROJECTILES);
            if (c != null && c.getProjectiles().size() >= 3) return true;
        }
        return false;
    }

    /** Rodrigues rotation of v around the unit axis by ang. */
    private static Vec3d rotate(Vec3d v, Vec3d axis, double ang) {
        double c = Math.cos(ang), s = Math.sin(ang);
        return v.multiply(c).add(axis.crossProduct(v).multiply(s)).add(axis.multiply(axis.dotProduct(v) * (1 - c)));
    }

    // ---------------------------------------------------------------- drawing

    /**
     * pline stamps a th x th square on every pixel, so stamps overlap ~th times: pick the per-stamp alpha that
     * gives the wanted TOTAL alpha.
     */
    private static int ac(float total, int rgb, int th) {
        total = Math.max(0f, Math.min(0.999f, total));
        return argb(1f - (float) Math.pow(1f - total, 1.0 / Math.max(1, th)), rgb);
    }

    private static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = Math.round(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = Math.round(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = Math.round((a & 255) + ((b & 255) - (a & 255)) * t);
        return (r << 16) | (g << 8) | bl;
    }

    /** Straight line in PHYSICAL pixels (call inside the 1/guiScale matrix) so it stays crisp. */
    private static void pline(DrawContext ctx, float x0, float y0, float x1, float y1, float s, int th, int color) {
        float dx = (x1 - x0) * s, dy = (y1 - y0) * s;
        int n = Math.max(1, (int) Math.ceil(Math.max(Math.abs(dx), Math.abs(dy))));
        if (n > 3000) return;
        float px = x0 * s, py = y0 * s;
        for (int i = 0; i <= n; i++) {
            int ix = Math.round(px + dx * i / n), iy = Math.round(py + dy * i / n);
            ctx.fill(ix, iy, ix + th, iy + th, color);
        }
    }

    private static Vec3d pt(Vec3d c, Vec3d u, Vec3d v, double r, double a) {
        return c.add(u.multiply(Math.cos(a) * r)).add(v.multiply(Math.sin(a) * r));
    }

    private static Vec3d lerp(Vec3d a, Vec3d b, double t) { return a.add(b.subtract(a).multiply(t)); }

    private static void arc(DrawContext ctx, Cam cam, Vec3d c, Vec3d u, Vec3d v, double r, double a0, double a1,
                            int seg, float s, int th, int argb) {
        float[] prev = null;
        for (int i = 0; i <= seg; i++) {
            float[] cur = cam.proj(pt(c, u, v, r, a0 + (a1 - a0) * i / seg));
            if (prev != null && cur != null) pline(ctx, prev[0], prev[1], cur[0], cur[1], s, th, argb);
            prev = cur;
        }
    }

    /** Glowing line: wide soft pass + bright whitish core, fading in from the throw point. */
    private static void line(DrawContext ctx, Cam cam, Result r, int col, float s, int th, boolean head) {
        int n = r.pts.size();
        if (n < 2) return;
        int core = mix(col, 0xFFFFFF, 0.6f);
        float[] prev = null;
        for (int i = 0; i < n; i++) {
            float[] cur = cam.proj(r.pts.get(i));
            if (cur != null && prev != null && Math.abs(cur[0] - prev[0]) + Math.abs(cur[1] - prev[1]) < 900f) {
                float f = Math.min(1f, i / Math.max(6f, n * 0.2f));
                pline(ctx, prev[0], prev[1], cur[0], cur[1], s, th + 4, ac(0.16f * f, col, th + 4));
                pline(ctx, prev[0], prev[1], cur[0], cur[1], s, th + 1, ac(0.35f * f, col, th + 1));
                pline(ctx, prev[0], prev[1], cur[0], cur[1], s, th, ac(0.95f * f, core, th));
            }
            prev = cur;
        }
        if (head) {
            float[] h = cam.proj(r.pts.get(0));
            if (h != null) pline(ctx, h[0], h[1], h[0] + 0.05f, h[1], s, th + 3, ac(0.95f, 0xFFFFFF, th + 3));
        }
    }

    /** Landing mark lying on the surface. Returns {screenX, topY} for the labels, or null if not visible. */
    private static float[] marker(DrawContext ctx, Cam cam, Vec3d c, Vec3d n, double b, float s, int th, int col,
                                  float pulse, float time, boolean disc) {
        float[] cp = cam.proj(c);
        if (cp == null) return null;
        Vec3d h = Math.abs(n.y) > 0.9 ? new Vec3d(1, 0, 0) : new Vec3d(0, 1, 0);
        Vec3d u = n.crossProduct(h).normalize(), v = n.crossProduct(u).normalize();
        double rOut = b * 1.6, rIn = b * 0.85, rDia = b * 0.34;
        float rot = time * 1.7f;

        if (disc) {   // faint translucent fill
            for (double rr = rOut * 0.18; rr < rOut * 0.9; rr += rOut * 0.17) {
                arc(ctx, cam, c, u, v, rr, 0, Math.PI * 2, 28, s, th + 5, ac(0.085f, col, th + 5));
            }
        }
        // outer ring: four rotating arcs
        for (int i = 0; i < 4; i++) {
            double a0 = rot + i * Math.PI / 2.0, a1 = a0 + Math.toRadians(58);
            arc(ctx, cam, c, u, v, rOut, a0, a1, 12, s, th + 5, ac(0.20f * pulse, col, th + 5));
            arc(ctx, cam, c, u, v, rOut, a0, a1, 12, s, th + 2, ac(0.95f * pulse, col, th + 2));
        }
        // inner white ring that breathes
        float br = 0.72f + 0.2f * (float) Math.sin(time * 3f);
        arc(ctx, cam, c, u, v, rIn, 0, Math.PI * 2, 36, s, th + 3, ac(0.10f, 0xFFFFFF, th + 3));
        arc(ctx, cam, c, u, v, rIn, 0, Math.PI * 2, 36, s, th, ac(br, 0xFFFFFF, th));
        // diamond in the center, filled by hatching
        double ang = Math.PI / 4.0;
        Vec3d d0 = pt(c, u, v, rDia, ang), d1 = pt(c, u, v, rDia, ang + Math.PI / 2),
                d2 = pt(c, u, v, rDia, ang + Math.PI), d3 = pt(c, u, v, rDia, ang + Math.PI * 1.5);
        for (int i = 0; i <= 7; i++) {
            float[] a = cam.proj(lerp(d0, d1, i / 7.0)), bb = cam.proj(lerp(d3, d2, i / 7.0));
            if (a != null && bb != null) pline(ctx, a[0], a[1], bb[0], bb[1], s, th + 1, ac(0.95f * pulse, col, th + 1));
        }
        // faint light columns along the rim
        for (int i = 0; i < 6; i++) {
            Vec3d base = pt(c, u, v, rOut * 0.92, i * Math.PI / 3.0 + rot * 0.3);
            float[] prev = cam.proj(base);
            for (int k = 1; k <= 6; k++) {
                float[] cur = cam.proj(base.add(n.multiply(0.12 * k)));
                if (prev != null && cur != null) {
                    pline(ctx, prev[0], prev[1], cur[0], cur[1], s, th, ac(0.11f * (1f - (k - 1) / 6f), 0xFFFFFF, th));
                }
                prev = cur;
            }
        }
        float top = Float.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            float[] q = cam.proj(pt(c, u, v, rOut, i * Math.PI / 4.0));
            if (q != null) top = Math.min(top, q[1]);
        }
        return new float[]{cp[0], top == Float.MAX_VALUE ? cp[1] : top};
    }

    private static void vignette(DrawContext ctx, float a) {
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight(), n = 22, st = 3;
        for (int i = 0; i < n; i++) {
            float f = 1f - i / (float) n, al = a * 0.30f * f * f;
            if (al <= 0.003f) continue;
            int c = argb(al, ICON_RED);
            ctx.fill(0, i * st, w, (i + 1) * st, c);
            ctx.fill(0, h - (i + 1) * st, w, h - i * st, c);
            ctx.fill(i * st, (i + 1) * st, (i + 1) * st, h - (i + 1) * st, c);
            ctx.fill(w - (i + 1) * st, (i + 1) * st, w - i * st, h - (i + 1) * st, c);
        }
    }

    private static Vec3d center(Result r) {
        return r.target != null ? new Vec3d(r.end.x, r.target.getY(), r.end.z).add(UP.multiply(0.02))
                : r.end.add(r.normal.multiply(0.02));
    }

    /** group.get(0) is the main shot (timer + red state); the rest are multishot side lines. */
    private static void draw(DrawContext ctx, MinecraftClient mc, Cam cam, List<Result> group, boolean own) {
        Result r = group.get(0);
        boolean hit = r.target != null && ShrineCfg.bool(K_RED, true);
        int idx = Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, ShrineCfg.integer(K_COL, 7)));
        int accent = ShrineGui.PALETTE[idx];
        float s = (float) mc.getWindow().getScaleFactor();
        int th = s >= 3f ? 2 : 1;
        long now = Util.getMeasuringTimeMs();
        float time = now / 1000f;

        float k;
        if (own) {
            float dt = Math.min(0.1f, Math.max(0f, (now - redT) / 1000f));
            redT = now;
            redA += ((hit ? 1f : 0f) - redA) * Math.min(1f, dt * 12f);
            if (redA < 0.01f && !hit) redA = 0f;
            k = redA;
        } else {
            k = hit ? 1f : 0f;
        }
        int main = mix(accent, ICON_RED, k);
        float pulse = hit ? 0.75f + 0.25f * (float) Math.sin(time * 10f) : 1f;

        if (own && k > 0.02f && ShrineCfg.bool(K_VIG, true)) vignette(ctx, k);

        float[] anchor = null;
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.scale(1f / s, 1f / s);

        if (ShrineCfg.bool(K_LINE, true)) {
            for (int i = 0; i < group.size(); i++) line(ctx, cam, group.get(i), main, s, th, i == 0 && !own);
        }
        if (r.end != null) {
            float size = Math.max(0.3f, ShrineCfg.num(K_SIZE, 1f));
            Vec3d at = center(r);
            if (own) {   // marker glides after the aim instead of jumping
                float dt = Math.max(0f, (now - smoothT) / 1000f);
                if (smooth == null || dt > 0.3f || smooth.squaredDistanceTo(at) > 64) smooth = at;
                else smooth = smooth.add(at.subtract(smooth).multiply(1.0 - Math.exp(-dt * 18.0)));
                smoothT = now;
                at = smooth;
            }
            anchor = marker(ctx, cam, at, r.target != null ? UP : r.normal, 0.3 * size, s, th, main, pulse, time, true);
            for (int i = 1; i < group.size(); i++) {
                Result e = group.get(i);
                if (e.end == null) continue;
                marker(ctx, cam, center(e), e.target != null ? UP : e.normal, 0.3 * size * 0.8, s, th,
                        mix(accent, ICON_RED, e.target != null ? 1f : 0f), 1f, time, false);
            }
        }
        m.popMatrix();
        if (anchor == null) return;

        // small labels above the marker: flight time, and "в цель" over it
        var tr = mc.textRenderer;
        float cx = anchor[0], ly = anchor[1] - 11f;
        if (ShrineCfg.bool(K_TIME, true)) {
            String ts = String.format(Locale.ROOT, "%.1f", r.ticks / 20.0).replace('.', ',') + "s";
            float pw = width(tr, Fnt.TINY_B, ts) + 24f, px = cx - pw / 2f;
            box(ctx, RR, px, ly - 7, pw, 14, 7, argb(0.92f, 0x0A0710));
            centered(ctx, TIMER, px + 9, ly, 7, 7, argb(1f, ICON_RED));
            text(ctx, tr, Fnt.TINY_B, ts, px + 16, ly, argb(0.95f, 0xFFFFFF));
            ly -= 16f;
        }
        if (hit) {
            String t = "в цель";
            float pw = width(tr, Fnt.TINY_B, t) + 16f, px = cx - pw / 2f;
            box(ctx, RR, px, ly - 6.5f, pw, 13, 6.5f, argb(0.95f, 0xE5384D));
            textC(ctx, tr, Fnt.TINY_B, t, cx, ly, argb(1f, 0xFFFFFF));
        }
    }
}

package com.shrine;

import com.shrine.Predictions.Cam;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import static com.shrine.Gfx.*;

/**
 * Target > "Kill Effect": an animation that plays where an enemy you hit has just died.
 *
 * Detection: every entity you attack is remembered for a few seconds; when its health reaches zero the effect starts
 * at its position. Modes: soul ascension, abyss grip, star burst, fire vortex, cards.
 *
 * Drawing: a 2D overlay like {@link TargetEsp}. World points are projected to the screen by hand; the "models" (a
 * humanoid made of boxes, hands, cards) are lit, rotated boxes whose faces are sorted by depth and filled as polygons.
 */
final class KillEffect {
    private KillEffect() {}

    static final String KEY = "target.kill", K_MODE = "target.kill.mode", K_COLOR = "target.kill.color",
            K_SIZE = "target.kill.size", K_DETAIL = "target.kill.detail";
    static final String[] MODES = {"Восхождение души", "Хватка бездны", "Звёздный взрыв", "Огненный смерч", "Карты"};
    static final String[] DETAIL = {"Низкая", "Средняя", "Высокая"};
    private static final float[] DETAIL_MUL = {0.5f, 1f, 1.7f};
    private static final float[] DURATION = {2.8f, 3.2f, 2.4f, 2.8f, 3.2f};
    private static final double TAU = Math.PI * 2.0;
    private static final long REMEMBER_MS = 8000L;
    private static final int MAX_ACTIVE = 6;

    /** One running effect. */
    private static final class Fx {
        final double x, y, z, w, h;
        final float yaw, size, detail;
        final int mode, rgb;
        final long seed, t0;

        Fx(double x, double y, double z, double w, double h, float yaw) {
            this.x = x; this.y = y; this.z = z; this.w = w; this.h = Math.max(0.4, h); this.yaw = yaw;
            this.mode = Math.max(0, Math.min(MODES.length - 1, ShrineCfg.integer(K_MODE, 0)));
            int ci = Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, ShrineCfg.integer(K_COLOR, 4)));
            this.rgb = ShrineGui.PALETTE[ci];
            this.size = Math.max(0.5f, Math.min(2.0f, ShrineCfg.num(K_SIZE, 1f)));
            this.detail = DETAIL_MUL[Math.max(0, Math.min(DETAIL_MUL.length - 1, ShrineCfg.integer(K_DETAIL, 1)))];
            this.seed = System.nanoTime();
            this.t0 = Util.getMeasuringTimeMs();
        }
    }

    private static final class Tracked {
        final LivingEntity e;
        long hitAt;
        // last state seen while the target was still alive (used when a server just removes a dying player)
        double x, y, z, w = 0.6, h = 1.8;
        float yaw, hp = 20f, maxHp = 20f;
        Tracked(LivingEntity e) { this.e = e; snap(); }
        void snap() {
            x = e.getX(); y = e.getY(); z = e.getZ(); w = e.getWidth(); h = e.getHeight(); yaw = e.getYaw();
            hp = e.getHealth(); maxHp = Math.max(1f, e.getMaxHealth());
        }
    }

    private static final List<Fx> active = new ArrayList<>();
    private static final Map<Integer, Tracked> tracked = new HashMap<>();

    // ---------- registration and kill detection ----------
    static void register() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (player == mc.player && entity instanceof LivingEntity le && le != mc.player) {
                remember(le);
            }
            return ActionResult.PASS;
        });
        ClientTickEvents.END_CLIENT_TICK.register(KillEffect::tick);
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "kill_effect"),
                (ctx, tick) -> render(ctx, tick.getTickProgress(false)));
    }

    private static void remember(LivingEntity le) {
        Tracked t = tracked.computeIfAbsent(le.getId(), id -> new Tracked(le));
        t.hitAt = Util.getMeasuringTimeMs();
    }

    private static void tick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) { tracked.clear(); active.clear(); return; }
        long now = Util.getMeasuringTimeMs();

        // ranged kills (bow, crossbow, trident, ...): the target you are looking at has just been hurt
        if (mc.targetedEntity instanceof LivingEntity le && le != mc.player && !le.isRemoved() && le.hurtTime > 0) remember(le);

        Iterator<Tracked> it = tracked.values().iterator();
        while (it.hasNext()) {
            Tracked t = it.next();
            LivingEntity e = t.e;
            if (now - t.hitAt > REMEMBER_MS) { it.remove(); continue; }
            boolean killed = e.isDead() || (e.isRemoved() && e.getRemovalReason() == Entity.RemovalReason.KILLED);
            if (killed) {
                it.remove();
                if (ShrineCfg.bool(KEY, true)) spawn(e.getX(), e.getY(), e.getZ(), e.getWidth(), e.getHeight(), e.getYaw());
            } else if (e.isRemoved()) {
                it.remove();
                // servers often just delete a dying player: low health + a fresh hit means it was a kill
                boolean fresh = now - t.hitAt < 1500L;
                boolean low = t.hp <= Math.max(4f, t.maxHp * 0.3f);
                if (fresh && low && ShrineCfg.bool(KEY, true)) spawn(t.x, t.y, t.z, t.w, t.h, t.yaw);
            } else {
                t.snap();
            }
        }
    }

    private static void spawn(double x, double y, double z, double w, double h, float yaw) {
        active.add(new Fx(x, y, z, w, h, yaw));
        while (active.size() > MAX_ACTIVE) active.remove(0);
    }

    /** Settings > "Проверить эффект": plays the effect a few blocks in front of the player. */
    static void test() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        double yr = Math.toRadians(mc.player.getYaw());
        spawn(mc.player.getX() - Math.sin(yr) * 3.5, mc.player.getY(), mc.player.getZ() + Math.cos(yr) * 3.5,
                0.6, 1.8, mc.player.getYaw() + 180f);
    }

    // ---------- frame ----------
    private static void render(DrawContext ctx, float td) {
        if (active.isEmpty()) return;
        long now = Util.getMeasuringTimeMs();
        active.removeIf(f -> (now - f.t0) / 1000f > DURATION[f.mode]);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.options.hudHidden) return;
        if (!mc.options.getPerspective().isFirstPerson()) return;
        Cam cam = new Cam(mc, ctx, td);
        for (Fx f : active) new Painter(ctx, cam, f, (now - f.t0) / 1000f).run();
    }

    // ---------- small helpers ----------
    private static float sat(float x) { return Math.max(0f, Math.min(1f, x)); }
    private static float smooth(float x) { x = sat(x); return x * x * (3f - 2f * x); }

    private static int mix(int c1, int c2, float k) {
        k = sat(k);
        int r = Math.round(((c1 >> 16) & 255) * (1 - k) + ((c2 >> 16) & 255) * k);
        int g = Math.round(((c1 >> 8) & 255) * (1 - k) + ((c2 >> 8) & 255) * k);
        int b = Math.round((c1 & 255) * (1 - k) + (c2 & 255) * k);
        return (r << 16) | (g << 8) | b;
    }

    private static int scaleRgb(int c, float k) {
        int r = Math.min(255, Math.round(((c >> 16) & 255) * k));
        int g = Math.min(255, Math.round(((c >> 8) & 255) * k));
        int b = Math.min(255, Math.round((c & 255) * k));
        return (r << 16) | (g << 8) | b;
    }

    /** Deterministic random number in [0, 1) for particle i, channel k of one effect. */
    private static float rnd(long seed, int i, int k) {
        long h = seed + i * 0x9E3779B97F4A7C15L + k * 0xC2B2AE3D27D4EB4FL;
        h ^= h >>> 33; h *= 0xFF51AFD7ED558CCDL; h ^= h >>> 33; h *= 0xC4CEB9FE1A85EC53L; h ^= h >>> 33;
        return (h >>> 40) / (float) (1L << 24);
    }

    /** Local -> world rotation: roll around Z, then pitch around X, then yaw around Y. */
    private static double[] rot(double x, double y, double z, double yaw, double pitch, double roll) {
        double cr = Math.cos(roll), sr = Math.sin(roll);
        double x1 = x * cr - y * sr, y1 = x * sr + y * cr;
        double cp = Math.cos(pitch), sp = Math.sin(pitch);
        double y2 = y1 * cp - z * sp, z2 = y1 * sp + z * cp;
        double cy = Math.cos(yaw), sy = Math.sin(yaw);
        return new double[]{x1 * cy + z2 * sy, y2, -x1 * sy + z2 * cy};
    }

    /** Fills a convex screen polygon row by row. */
    private static void fill(DrawContext ctx, float[] xs, float[] ys, int col) {
        float minY = Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
        for (float v : ys) { minY = Math.min(minY, v); maxY = Math.max(maxY, v); }
        int n = xs.length;
        for (int py = Math.round(minY); py <= Math.round(maxY); py++) {
            float sy = py + 0.5f, lo = Float.MAX_VALUE, hi = -Float.MAX_VALUE;
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                float ay = ys[i], by = ys[j];
                if ((ay <= sy && by > sy) || (by <= sy && ay > sy)) {
                    float xi = xs[i] + (sy - ay) * (xs[j] - xs[i]) / (by - ay);
                    lo = Math.min(lo, xi);
                    hi = Math.max(hi, xi);
                }
            }
            if (lo <= hi) ctx.fill(Math.round(lo), py, Math.round(hi) + 1, py + 1, col);
        }
    }

    // ---------- the humanoid "model": boxes in units of the entity height, relative to the feet ----------
    // {centre x, y, z, half x, y, z}
    private static final double[][] PARTS = {
            {0.00, 0.875, 0, 0.125, 0.125, 0.125},     // head
            {0.00, 0.5625, 0, 0.140, 0.1875, 0.070},   // torso
            {-0.21, 0.5625, 0, 0.070, 0.1875, 0.070},  // left arm
            {0.21, 0.5625, 0, 0.070, 0.1875, 0.070},   // right arm
            {-0.07, 0.1875, 0, 0.070, 0.1875, 0.070},  // left leg
            {0.07, 0.1875, 0, 0.070, 0.1875, 0.070}    // right leg
    };
    private static final int[] PART_COL = {0xC8956B, 0x3A63C8, 0x3A63C8, 0x3A63C8, 0x2F3A96, 0x2F3A96};
    private static final int HURT = 0xE03030, SKIN = 0xC8956B;

    private static final int[][] FACE = {{1, 3, 7, 5}, {0, 4, 6, 2}, {2, 6, 7, 3}, {0, 1, 5, 4}, {4, 5, 7, 6}, {0, 2, 3, 1}};
    private static final double[][] NORM = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
    private static final double LX = -0.356, LY = 0.814, LZ = 0.458;     // light direction

    private static final class Face {
        final float[] xs = new float[4], ys = new float[4];
        int col, edge;
        float depth;
    }

    // ---------- the painter: draws one effect at time t ----------
    private static final class Painter {
        final DrawContext ctx;
        final Cam cam;
        final Fx f;
        final float t;
        final double gy;
        final int rgb, pale;
        final float[] o = new float[3];
        final List<Face> faces = new ArrayList<>();

        Painter(DrawContext ctx, Cam cam, Fx f, float t) {
            this.ctx = ctx; this.cam = cam; this.f = f; this.t = t;
            this.gy = f.y + 0.03;
            this.rgb = f.rgb;
            this.pale = mix(f.rgb, 0xFFFFFF, 0.6f);
        }

        void run() {
            shockwave();
            switch (f.mode) {
                case 0 -> soul();
                case 1 -> abyss();
                case 2 -> stars();
                case 3 -> vortex();
                default -> cards();
            }
            flush();
        }

        boolean pt(double x, double y, double z) { return cam.p(x, y, z, o); }

        // ----- primitives -----
        /** Circle or arc lying on the ground plane (drawn as projected segments). */
        void ringXZ(double cx, double gyy, double cz, double r, double a0, double a1, float thBlocks, int col, float al, double step) {
            if (al < 0.01f) return;
            int n = Math.max(3, (int) Math.ceil(Math.abs(a1 - a0) / step));
            float px = 0f, py = 0f;
            boolean has = false;
            for (int i = 0; i <= n; i++) {
                double an = a0 + (a1 - a0) * i / n;
                if (!pt(cx + Math.cos(an) * r, gyy, cz + Math.sin(an) * r)) { has = false; continue; }
                if (has) Predictions.line(ctx, px, py, o[0], o[1], Math.max(0.8f, thBlocks * o[2]), argb(al, col));
                px = o[0]; py = o[1]; has = true;
            }
        }

        /** Soft glowing dot. */
        void dot(double x, double y, double z, double size, int col, float a) {
            if (a < 0.02f || !pt(x, y, z)) return;
            float s = Math.max(2f, (float) size * o[2]);
            centered(ctx, GLOW, o[0], o[1], s * 4f, s * 4f, argb(0.45f * a, col));
            centered(ctx, DISC, o[0], o[1], s, s, argb(a, mix(col, 0xFFFFFF, 0.65f)));
        }

        /** Four-point sparkle. */
        void sparkle(double x, double y, double z, double size, int col, float a, double rotation) {
            if (a < 0.02f || !pt(x, y, z)) return;
            float s = Math.max(3f, (float) size * o[2]), sx = o[0], sy = o[1];
            centered(ctx, GLOW, sx, sy, s * 3.5f, s * 3.5f, argb(0.35f * a, col));
            for (int k = 0; k < 2; k++) {
                double an = rotation + k * Math.PI / 2.0;
                float dx = (float) Math.cos(an) * s * 1.7f, dy = (float) Math.sin(an) * s * 1.7f;
                Predictions.line(ctx, sx - dx, sy - dy, sx + dx, sy + dy, 1.1f, argb(a, mix(col, 0xFFFFFF, 0.7f)));
            }
            centered(ctx, DISC, sx, sy, s * 0.7f, s * 0.7f, argb(a, 0xFFFFFF));
        }

        /** Hollow ring particle facing the camera. */
        void ringDot(double x, double y, double z, double size, int col, float a) {
            if (a < 0.02f || !pt(x, y, z)) return;
            float s = Math.max(4f, (float) size * o[2]);
            centered(ctx, GLOW, o[0], o[1], s * 2.4f, s * 2.4f, argb(0.30f * a, col));
            centered(ctx, RING, o[0], o[1], s, s, argb(a, mix(col, 0xFFFFFF, 0.5f)));
        }

        /** A lit, rotated box; its visible faces are queued and drawn far to near by {@link #flush()}. */
        void box(double cx, double cy, double cz, double hx, double hy, double hz,
                 double yaw, double pitch, double roll, int base, float alpha, float edgeAlpha) {
            if (alpha < 0.02f) return;
            double[][] cr = new double[8][];
            for (int i = 0; i < 8; i++) {
                cr[i] = rot((i & 1) == 0 ? -hx : hx, (i & 2) == 0 ? -hy : hy, (i & 4) == 0 ? -hz : hz, yaw, pitch, roll);
            }
            for (int fi = 0; fi < 6; fi++) {
                int[] ix = FACE[fi];
                double[] n = rot(NORM[fi][0], NORM[fi][1], NORM[fi][2], yaw, pitch, roll);
                double mx = 0, my = 0, mz = 0;
                for (int k = 0; k < 4; k++) { mx += cr[ix[k]][0]; my += cr[ix[k]][1]; mz += cr[ix[k]][2]; }
                mx = cx + mx / 4.0; my = cy + my / 4.0; mz = cz + mz / 4.0;
                double vx = cam.pos.x - mx, vy = cam.pos.y - my, vz = cam.pos.z - mz;
                if (n[0] * vx + n[1] * vy + n[2] * vz <= 0) continue;               // facing away
                Face fc = new Face();
                boolean ok = true;
                for (int k = 0; k < 4; k++) {
                    if (!pt(cx + cr[ix[k]][0], cy + cr[ix[k]][1], cz + cr[ix[k]][2])) { ok = false; break; }
                    fc.xs[k] = o[0]; fc.ys[k] = o[1];
                }
                if (!ok) continue;
                float shade = (float) (0.55 + 0.45 * Math.max(0.0, n[0] * LX + n[1] * LY + n[2] * LZ));
                fc.col = argb(alpha, scaleRgb(base, shade));
                fc.edge = edgeAlpha > 0.01f ? argb(edgeAlpha * alpha, 0xFFFFFF) : 0;
                fc.depth = (float) ((mx - cam.pos.x) * cam.fx + (my - cam.pos.y) * cam.fy + (mz - cam.pos.z) * cam.fz);
                faces.add(fc);
            }
        }

        void flush() {
            faces.sort((a, b) -> Float.compare(b.depth, a.depth));
            for (Face fc : faces) {
                fill(ctx, fc.xs, fc.ys, fc.col);
                if (fc.edge != 0) {
                    for (int k = 0; k < 4; k++) {
                        int j = (k + 1) % 4;
                        Predictions.line(ctx, fc.xs[k], fc.ys[k], fc.xs[j], fc.ys[j], 0.8f, fc.edge);
                    }
                }
            }
            faces.clear();
        }

        /** One body part of the humanoid; (dx, dy, dz) moves it, the angles turn it around its own centre. */
        void part(int k, double dx, double dy, double dz, double eyaw, double pitch, double roll, float alpha, float hurt) {
            double[] pr = PARTS[k];
            double H = f.h, yr = Math.toRadians(-f.yaw);
            double lx = pr[0] * H, lz = pr[2] * H;
            double wx = lx * Math.cos(yr) + lz * Math.sin(yr), wz = -lx * Math.sin(yr) + lz * Math.cos(yr);
            box(f.x + wx + dx, f.y + pr[1] * H + dy, f.z + wz + dz, pr[3] * H, pr[4] * H, pr[5] * H,
                    yr + eyaw, pitch, roll, mix(PART_COL[k], HURT, hurt), alpha, 0.30f);
        }

        // ----- common: a ring that runs over the ground -----
        void shockwave() {
            float q = sat(t / 0.8f);
            if (q >= 1f) return;
            double r = 0.3 + 3.0 * f.size * (1f - (1f - q) * (1f - q));
            float al = (float) Math.pow(1f - q, 1.3);
            ringXZ(f.x, gy, f.z, r, 0, TAU, 0.10f, rgb, 0.45f * al, 0.1);
            ringXZ(f.x, gy, f.z, r, 0, TAU, 0.045f, pale, 0.95f * al, 0.1);
            ringXZ(f.x, gy, f.z, r * 0.82, 0, TAU, 0.06f, rgb, 0.25f * al, 0.12);
        }

        // ----- mode 0: soul ascension -----
        void soul() {
            double H = f.h;
            float hurt = 0.6f * (1f - sat((t - 0.2f) / 1.4f));
            double rise = (0.1 + 2.6 * f.size) * smooth(t / 2.5f);
            for (int k = 0; k < PARTS.length; k++) {
                // the body dissolves from the feet upwards
                float al = 0.92f * (1f - smooth((t - 0.35f - (float) PARTS[k][1] * 0.6f) / 1.7f));
                part(k, 0, rise, 0, t * 1.3, 0, 0, al, hurt);
            }
            flush();

            int n = Math.round(11 * f.detail);
            for (int i = 0; i < n; i++) {                                    // soul rings drifting up
                float age = t - i * 0.09f;
                float life = 1.6f + 0.9f * rnd(f.seed, i, 0);
                if (age < 0f || age > life) continue;
                float q = age / life;
                double an = rnd(f.seed, i, 1) * TAU + age * (2.2 + rnd(f.seed, i, 4));
                double r = (f.w * 0.5 + 0.2 + 0.35 * rnd(f.seed, i, 2)) * f.size;
                double y = f.y + H * (0.15 + 0.8 * rnd(f.seed, i, 3)) + 1.2 * f.size * q;
                float al = (float) Math.pow(Math.sin(Math.PI * q), 0.7) * 0.9f;
                ringDot(f.x + Math.cos(an) * r, y, f.z + Math.sin(an) * r, (0.16 + 0.12 * rnd(f.seed, i, 5)) * f.size, rgb, al);
            }
            int m = Math.round(9 * f.detail);
            for (int i = 0; i < m; i++) {                                    // purple crosses
                float age = t - 0.15f - i * 0.11f;
                float life = 1.5f + 0.8f * rnd(f.seed, i, 6);
                if (age < 0f || age > life) continue;
                float q = age / life;
                double an = rnd(f.seed, i, 7) * TAU + age * 1.4;
                double r = (0.4 + 0.7 * rnd(f.seed, i, 8)) * f.size;
                sparkle(f.x + Math.cos(an) * r, f.y + H * (0.3 + 0.6 * rnd(f.seed, i, 9)) + 1.5 * f.size * q,
                        f.z + Math.sin(an) * r, 0.07 * f.size, 0xB890FF, (float) Math.sin(Math.PI * q) * 0.95f, age * 3.0);
            }
        }

        // ----- mode 1: abyss grip -----
        void portal(double rad, float k) {
            if (rad < 0.05) return;
            for (double r = 0.12; r < rad; r += 0.14) ringXZ(f.x, gy, f.z, r, 0, TAU, 0.14f, rgb, 0.05f * k, 0.3);
            ringXZ(f.x, gy, f.z, rad, 0, TAU, 0.07f, rgb, 0.35f * k, 0.12);
            ringXZ(f.x, gy, f.z, rad, 0, TAU, 0.04f, pale, 0.95f * k, 0.1);
            for (int i = 0; i < 3; i++) {
                double s0 = t * 1.8 + i * TAU / 3.0;
                ringXZ(f.x, gy, f.z, rad * 0.72, s0, s0 + 0.9, 0.06f, pale, 0.9f * k, 0.12);
            }
            if (pt(f.x, gy, f.z)) {
                float w = (float) rad * 2.8f * o[2];
                centered(ctx, GLOW, o[0], o[1], w, w * 0.5f, argb(0.35f * k, rgb));
            }
        }

        void tentacle(int idx, int n, double R, float reach) {
            if (reach < 0.02f) return;
            double H = f.h, a0 = idx * TAU / n + 0.5;
            float[] prev = null;
            double hx = 0, hy = 0, hz = 0, hAng = 0;
            boolean tip = false;
            final int seg = 16;
            for (int s = 0; s <= seg; s++) {
                double u = s / (double) seg;
                double rr = R * 0.9 * (1.0 - 0.8 * u);
                double an = a0 + u * 1.7 + t * 0.9;
                double yy = gy + reach * H * 1.05 * Math.pow(u, 0.85) * (1.0 - 0.2 * u) + 0.07 * Math.sin(t * 6 + u * 8 + idx);
                double px = f.x + Math.cos(an) * rr, pz = f.z + Math.sin(an) * rr;
                if (!pt(px, yy, pz)) { prev = null; continue; }
                float[] cur = {o[0], o[1]};
                if (prev != null) {
                    float th = Math.max(1.5f, (float) (0.16 * (1.0 - 0.6 * u)) * o[2]);
                    Predictions.line(ctx, prev[0], prev[1], cur[0], cur[1], th * 2.4f, argb(0.22f * reach, rgb));
                    Predictions.line(ctx, prev[0], prev[1], cur[0], cur[1], th, argb(0.95f * Math.min(1f, reach * 1.5f), mix(rgb, 0xFFFFFF, 0.45f)));
                }
                prev = cur;
                if (s == seg) { hx = px; hy = yy; hz = pz; hAng = an; tip = true; }
            }
            if (tip) {                                                       // a hand at the end of the arm
                float al = Math.min(1f, reach * 1.6f);
                box(hx, hy, hz, 0.09, 0.12, 0.07, -hAng, 0.4, 0.2, mix(SKIN, HURT, 0.55f), al, 0.3f);
            }
        }

        void abyss() {
            double H = f.h, R = Math.max(0.9, f.w * 0.5 + 0.6) * f.size;
            float open = smooth(t / 0.45f), close = 1f - smooth((t - 2.55f) / 0.6f), k = open * close;
            portal(R * k, k);

            float pull = smooth((t - 1.25f) / 1.0f);                         // the model is dragged down and torn apart
            for (int i = 0; i < PARTS.length; i++) {
                float al = 0.95f * (1f - sat((pull - 0.5f) / 0.5f));
                double sp = rnd(f.seed, i, 5) * 2.0 - 1.0;
                part(i, sp * pull * 0.45, -pull * (PARTS[i][1] * H + 0.35), (rnd(f.seed, i, 6) - 0.5) * pull * 0.5,
                        sp * pull * 0.8, sp * pull * 0.6, sp * pull * 1.2, al, 0.6f);
            }
            flush();

            float reach = smooth((t - 0.45f) / 0.7f) * (1f - 0.92f * pull) * close;
            int n = Math.max(3, Math.round(5 * f.detail));
            for (int a = 0; a < n; a++) tentacle(a, n, R, reach);
            flush();                                                         // the hands
        }

        // ----- mode 2: star burst -----
        void stars() {
            double cx = f.x, cy = f.y + f.h * 0.55, cz = f.z;
            float fl = 1f - sat(t / 0.4f);
            if (fl > 0.02f && pt(cx, cy, cz)) {
                float sz = (float) (f.size * (1.0 + 2.6 * (1f - fl))) * o[2];
                centered(ctx, GLOW, o[0], o[1], sz * 2.2f, sz * 2.2f, argb(0.8f * fl, rgb));
                centered(ctx, DISC, o[0], o[1], sz * 0.5f * fl + 4f, sz * 0.5f * fl + 4f, argb(fl, 0xFFFFFF));
            }
            int n = Math.round(46 * f.detail);
            final double kd = 1.5;
            for (int i = 0; i < n; i++) {
                float age = t - 0.03f * (i % 5);
                float life = 1.4f + 0.9f * rnd(f.seed, i, 0);
                if (age < 0f || age > life) continue;
                float q = age / life;
                double th = rnd(f.seed, i, 1) * TAU, cph = rnd(f.seed, i, 2) * 2.0 - 1.0, sph = Math.sqrt(1.0 - cph * cph);
                double dx = Math.cos(th) * sph, dy = cph, dz = Math.sin(th) * sph;
                double v = (2.4 + 3.0 * rnd(f.seed, i, 3)) * f.size;
                double d0 = v * (1.0 - Math.exp(-kd * age)) / kd, d1 = v * (1.0 - Math.exp(-kd * Math.max(0f, age - 0.06f))) / kd;
                double x1 = cx + dx * d1, y1 = cy + dy * d1 + 0.3 * Math.max(0f, age - 0.06f), z1 = cz + dz * d1;
                double x0 = cx + dx * d0, y0 = cy + dy * d0 + 0.3 * age, z0 = cz + dz * d0;
                float al = (float) Math.pow(1f - q, 0.6) * (0.7f + 0.3f * (float) Math.sin(t * 18 + i * 1.7));
                double sz = (0.045 + 0.06 * rnd(f.seed, i, 4)) * f.size * (1.0 - 0.4 * q);
                int col = mix(rgb, 0xFFFFFF, 0.25f * rnd(f.seed, i, 6));
                if (pt(x1, y1, z1)) {
                    float px = o[0], py = o[1];
                    if (pt(x0, y0, z0)) Predictions.line(ctx, px, py, o[0], o[1], 1.2f, argb(0.35f * al, col));
                }
                if (rnd(f.seed, i, 5) > 0.6f) sparkle(x0, y0, z0, sz * 1.3, col, al, age * 4.0 + i);
                else dot(x0, y0, z0, sz, col, al);
            }
        }

        // ----- mode 3: fire vortex -----
        void vortex() {
            int n = Math.round(80 * f.detail);
            int hot = mix(0xFF9A3C, rgb, 0.2f), ember = mix(0xC8401C, rgb, 0.2f);
            float base = 1f - sat((t - 0.3f) / 1.5f);
            if (base > 0.02f && pt(f.x, gy, f.z)) {
                float w = 2.2f * f.size * o[2];
                centered(ctx, GLOW, o[0], o[1], w, w * 0.5f, argb(0.40f * base, hot));
            }
            for (int i = 0; i < n; i++) {
                float age = t - rnd(f.seed, i, 0) * 1.0f;
                float life = 1.1f + 0.8f * rnd(f.seed, i, 1);
                if (age < 0f || age > life) continue;
                float q = age / life;
                double a0 = rnd(f.seed, i, 2) * TAU;
                double hgt = Math.pow(q, 1.15) * 3.2 * f.size * (0.7 + 0.6 * rnd(f.seed, i, 3));
                double rad = (0.9 - 0.65 * q) * f.size * (0.6 + 0.7 * rnd(f.seed, i, 4));
                double an = a0 + age * (7.0 + 5.0 * q), an1 = a0 + (age - 0.04f) * (7.0 + 5.0 * q);
                double x = f.x + Math.cos(an) * rad, y = f.y + 0.1 + hgt, z = f.z + Math.sin(an) * rad;
                double x1 = f.x + Math.cos(an1) * rad, z1 = f.z + Math.sin(an1) * rad;
                int col = q < 0.35f ? mix(0xFFFFFF, hot, q / 0.35f) : mix(hot, ember, (q - 0.35f) / 0.65f);
                float al = 1f - q * q;
                if (pt(x, y, z)) {
                    float px = o[0], py = o[1];
                    if (pt(x1, y - 0.03, z1)) Predictions.line(ctx, px, py, o[0], o[1], 1.2f, argb(0.45f * al, col));
                }
                dot(x, y, z, 0.07 * f.size * (1.0 - 0.5 * q), col, al);
            }
        }

        // ----- mode 4: cards -----
        void cards() {
            double H = f.h;
            final float slice = 0.95f;
            float fade = 1f - sat((t - 2.3f) / 0.9f);
            if (t < slice) {
                for (int k = 0; k < PARTS.length; k++) part(k, 0, 0, 0, 0, 0, 0, 0.95f, 0.6f);
            } else {
                float s = t - slice;
                for (int k = 0; k < PARTS.length; k++) {                     // the cut pieces fly apart and fall
                    double[] pr = PARTS[k];
                    double vx = (rnd(f.seed, k, 10) - 0.5) * 3.0, vz = (rnd(f.seed, k, 11) - 0.5) * 3.0;
                    double vy = 1.4 + 2.0 * rnd(f.seed, k, 12) + (k == 0 ? 1.0 : 0.0);
                    double ds = Math.min(s, 1.6f);
                    double rest = (gy + Math.min(pr[3], Math.min(pr[4], pr[5])) * H) - (f.y + pr[1] * H);
                    double dy = Math.max(vy * ds - 5.0 * ds * ds, rest);
                    double dh = Math.min(s, 0.8f) * 0.8;
                    double spin = Math.min(s, 0.9f) * (rnd(f.seed, k, 13) - 0.5) * 9.0;
                    part(k, vx * dh, dy, vz * dh, 0, spin, spin * 0.6, 0.95f * fade, 0.6f);
                }
            }
            flush();

            int n = Math.round(8 * f.detail);
            float ca = t < slice ? 1f : 1f - sat((t - slice - 0.2f) / 0.6f);
            if (ca > 0.02f) {
                for (int i = 0; i < n; i++) {                                // cards circle in, cut through, scatter
                    double rad = (t < slice ? 1.9 - 1.5 * smooth(t / slice) : 0.4 + 2.2 * smooth((t - slice) / 0.7f)) * f.size;
                    double an = i * TAU / n + t * 5.5;
                    double cy = f.y + H * (0.2 + 0.65 * rnd(f.seed, i, 20)) + 0.15 * Math.sin(t * 4 + i);
                    double cx = f.x + Math.cos(an) * rad, cz = f.z + Math.sin(an) * rad;
                    double yaw = -an + Math.PI / 2.0, pitch = t * 4.0 + i, roll = 0.4 * Math.sin(t * 3.0 + i);
                    double c = 0.9 + 0.3 * f.size;
                    box(cx, cy, cz, 0.12 * c, 0.17 * c, 0.012 * c, yaw, pitch, roll, 0xF4F4F4, ca, 0.5f);
                    box(cx, cy, cz, 0.04 * c, 0.055 * c, 0.016 * c, yaw, pitch, roll, (i % 2 == 0) ? 0xD83A3A : 0x222222, ca, 0f);
                }
                flush();
            }
            float fs = sat(1f - Math.abs(t - 0.98f) / 0.14f);                // white slashes at the moment of the cut
            if (fs > 0.02f && pt(f.x, f.y + H * 0.55, f.z)) {
                float cx = o[0], cy = o[1], len = (float) H * o[2] * 0.6f;
                centered(ctx, GLOW, cx, cy, len * 1.6f, len * 1.6f, argb(0.5f * fs, rgb));
                for (int k = 0; k < 3; k++) {
                    double ang = rnd(f.seed, k, 30) * Math.PI;
                    float dx = (float) Math.cos(ang) * len, dy = (float) Math.sin(ang) * len;
                    Predictions.line(ctx, cx - dx, cy - dy, cx + dx, cy + dy, 5f, argb(0.25f * fs, rgb));
                    Predictions.line(ctx, cx - dx, cy - dy, cx + dx, cy + dy, 1.8f, argb(0.95f * fs, 0xFFFFFF));
                }
            }
        }
    }
}

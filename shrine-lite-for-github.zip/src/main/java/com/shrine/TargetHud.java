package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import static com.shrine.Gfx.*;

/**
 * HUD > "Здоровье цели": a glass panel under the crosshair with name, health and a segmented bar of the living entity
 * (player, mob, animal) you are looking at. It only shows what the server already sends to the client.
 */
final class TargetHud {
    private TargetHud() {}

    static final String KEY = "hud.health", KEY_ARMOR = "hud.armor";

    private static LivingEntity last;
    private static long seen;
    private static float shown = -1f;

    static void register() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "target_hud"),
                (ctx, tick) -> render(ctx));
    }

    private static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.currentScreen != null || mc.options.hudHidden) return;
        if (!ShrineCfg.bool(KEY, true)) { last = null; return; }

        Entity looked = mc.targetedEntity;
        LivingEntity target = looked instanceof LivingEntity le && !(looked instanceof ArmorStandEntity) ? le : null;
        long now = Util.getMeasuringTimeMs();
        if (target != null) {
            if (last != target) { last = target; shown = target.getHealth(); }
            seen = now;
        }
        if (last == null) return;
        float a = target != null ? 1f : 1f - (now - seen) / 320f;
        if (a <= 0f || last.isRemoved()) { last = null; return; }
        a = 1f - (1f - a) * (1f - a);

        float hp = Math.max(0f, last.getHealth()), max = Math.max(1f, last.getMaxHealth());
        shown += (hp - shown) * 0.18f;

        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        float k = h / Scene.REF_H, vw = w / k;
        var tr = mc.textRenderer;
        boolean gearOn = ShrineCfg.bool(KEY_ARMOR, true);
        final float W = 268f, H = gearOn ? 124f : 92f;
        float x = (vw - W) / 2f, y = 300f + (1f - a) * 8f;

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);

        box(ctx, RR, x - 1, y - 1, W + 2, H + 2, 19, argb(0.55f * a, ACCENT));
        box(ctx, RR, x, y, W, H, 18, argb(0.88f * a, 0x150A0F));

        // head: real skin for players, a letter disc for everything else
        String name = last.getName().getString();
        float hx = x + 14, hy = y + 14, hs = 44f;
        box(ctx, RR, hx - 2, hy - 2, hs + 4, hs + 4, 12, argb(0.5f * a, 0x000000));
        if (last instanceof AbstractClientPlayerEntity pl) {
            PlayerSkinDrawer.draw(ctx, pl.getSkin(), Math.round(hx), Math.round(hy), Math.round(hs), argb(a, 0xFFFFFF));
        } else {
            box(ctx, RR, hx, hy, hs, hs, 10, argb(0.9f * a, 0x5A2A33));
            textC(ctx, tr, Fnt.TITLE_B, name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(), hx + hs / 2f, hy + hs / 2f, argb(a, 0xFFFFFF));
        }

        text(ctx, tr, Fnt.UI_B, name.length() > 14 ? name.substring(0, 13) + "…" : name, x + 70, y + 26, argb(a, 0xFFFFFF));
        float dist = mc.player.distanceTo(last);
        text(ctx, tr, Fnt.SMALL, "Дист: " + String.format(java.util.Locale.ROOT, "%.1f", dist) + " м", x + 70, y + 46, argb(0.5f * a, 0xFFFFFF));

        float abs = last.getAbsorptionAmount();
        String hpText = (int) Math.ceil(hp) + " / " + (int) Math.ceil(max) + (abs > 0f ? " +" + (int) Math.ceil(abs) : "");
        text(ctx, tr, Fnt.UI_B, hpText, x + W - 16 - width(tr, Fnt.UI_B, hpText), y + 26, argb(a, abs > 0f ? 0xFFD24D : 0xFFFFFF));

        // segmented pill bar across the whole panel
        float ratio = Math.max(0f, Math.min(1f, hp / max));
        int c = mix(0xFF4D5D, 0x5DE08A, ratio);
        final int SEG = 13;
        float bx = x + 14, bw = W - 28, gap = 4f, sw = (bw - gap * (SEG - 1)) / SEG, by = y + 68;
        for (int i = 0; i < SEG; i++) {
            float sx = bx + i * (sw + gap);
            box(ctx, RR, sx, by, sw, 12, 6, argb(0.12f * a, 0xFFFFFF));
            float fill = Math.max(0f, Math.min(1f, shown / max * SEG - i));
            if (fill > 0.02f) {
                centered(ctx, GLOW, sx + sw * fill / 2f, by + 6, sw * fill + 14, 26, argb(0.30f * a, c));
                box(ctx, RR, sx, by, Math.max(8f, sw * fill), 12, 6, argb(a, c));
            }
        }

        // equipment: main hand, off hand, helmet, chestplate, leggings, boots
        if (gearOn) {
            EquipmentSlot[] slots = {EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND, EquipmentSlot.HEAD,
                    EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            float sz = 30f, g = (bw - sz * slots.length) / (slots.length - 1), sy = y + 90;
            for (int i = 0; i < slots.length; i++) {
                float sx = bx + i * (sz + g);
                box(ctx, RR, sx, sy, sz, sz, 9, argb(0.40f * a, 0x000000));
                box(ctx, RR_RING, sx, sy, sz, sz, 9, argb(0.10f * a, 0xFFFFFF));
                ItemStack st = last.getEquippedStack(slots[i]);
                if (st.isEmpty() || a < 0.5f) continue;
                float is = 1.4f;                                   // the item icon is 16 units, scale it up inside the slot
                ctx.getMatrices().pushMatrix();
                ctx.getMatrices().translate(sx + (sz - 16f * is) / 2f, sy + (sz - 16f * is) / 2f);
                ctx.getMatrices().scale(is, is);
                ctx.drawItem(st, 0, 0);
                ctx.getMatrices().popMatrix();
            }
        }

        ctx.getMatrices().popMatrix();
    }

    private static int mix(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }
}

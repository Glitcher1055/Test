package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import static com.shrine.Gfx.*;

/**
 * HUD > "Здоровье цели": a glass panel under the crosshair with name, health and a segmented bar of the living entity
 * (player, mob, animal) you are looking at. It only shows what the server already sends to the client.
 */
final class TargetHud {
    private TargetHud() {}

    static final String KEY = "hud.health", KEY_ARMOR = "hud.armor";

    private static LivingEntity last;
    private static long seen;
    private static float shown = -1f;

    static void register() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "target_hud"),
                (ctx, tick) -> render(ctx));
    }

    private static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.currentScreen != null || mc.options.hudHidden) return;
        if (!ShrineCfg.bool(KEY, true)) { last = null; return; }

        Entity looked = mc.targetedEntity;
        LivingEntity target = looked instanceof LivingEntity le && !(looked instanceof ArmorStandEntity) ? le : null;
        long now = Util.getMeasuringTimeMs();
        if (target != null) {
            if (last != target) { last = target; shown = target.getHealth(); }
            seen = now;
        }
        if (last == null) return;
        float a = target != null ? 1f : 1f - (now - seen) / 320f;
        if (a <= 0f || last.isRemoved()) { last = null; return; }
        a = 1f - (1f - a) * (1f - a);

        float hp = Math.max(0f, last.getHealth()), max = Math.max(1f, last.getMaxHealth());
        shown += (hp - shown) * 0.18f;

        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        float k = h / Scene.REF_H, vw = w / k;
        var tr = mc.textRenderer;
        boolean armorOn = ShrineCfg.bool(KEY_ARMOR, true) && last.getArmor() > 0;

        final float W = 250f, H = armorOn ? 84f : 66f;
        float x = (vw - W) / 2f, y = 306f + (1f - a) * 8f;

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);

        box(ctx, RR, x - 1, y - 1, W + 2, H + 2, 17, argb(0.16f * a, 0xFFFFFF));
        box(ctx, RR, x, y, W, H, 16, argb(0.86f * a, 0x150A0F));

        // avatar: first letter of the name
        String name = last.getName().getString();
        centered(ctx, DISC, x + 34, y + 33, 40, 40, argb(0.9f * a, 0x5A2A33));
        textC(ctx, tr, Fnt.UI_B, name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(), x + 34, y + 33, argb(a, 0xFFFFFF));

        text(ctx, tr, Fnt.UI_B, name.length() > 16 ? name.substring(0, 15) + "…" : name, x + 66, y + 20, argb(a, 0xFFFFFF));

        float abs = last.getAbsorptionAmount();
        String hpText = (int) Math.ceil(hp) + " / " + (int) Math.ceil(max) + (abs > 0f ? " +" + (int) Math.ceil(abs) : "");
        text(ctx, tr, Fnt.SMALL, hpText, x + W - 16 - width(tr, Fnt.SMALL, hpText), y + 20, argb(0.85f * a, abs > 0f ? 0xFFD24D : 0xFFFFFF));

        // segmented bar
        float ratio = Math.max(0f, Math.min(1f, hp / max));
        int c = mix(0xFF4D5D, 0x5DE08A, ratio);
        final int SEG = 10;
        float bx = x + 66, bw = W - 66 - 16, gap = 4f, sw = (bw - gap * (SEG - 1)) / SEG, by = y + 38;
        for (int i = 0; i < SEG; i++) {
            float sx = bx + i * (sw + gap);
            box(ctx, RR, sx, by, sw, 10, 5, argb(0.14f * a, 0xFFFFFF));
            float fill = Math.max(0f, Math.min(1f, shown / max * SEG - i));
            if (fill > 0.02f) box(ctx, RR, sx, by, Math.max(6f, sw * fill), 10, 5, argb(a, c));
        }

        if (armorOn) text(ctx, tr, Fnt.SMALL, "Броня: " + last.getArmor(), x + 66, y + 68, argb(0.55f * a, 0xFFFFFF));

        ctx.getMatrices().popMatrix();
    }

    private static int mix(int a, int b, float t) {
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }
}

package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import static com.shrine.Gfx.*;

/**
 * HUD > "Музыка", synced lyrics (see {@link Lyrics}):
 *  - a capsule at the top of the screen: cover, the current line with the sung word highlighted (long lines scroll
 *    with the song) and an equalizer;
 *  - "World Lyrics": every new line appears at a random spot around you in the world, glows, drifts up and fades out.
 *
 * The world part is a 2D overlay with a hand-made camera projection (same idea as {@link TargetEsp}), so it needs no
 * world-render API. It works in first person only.
 */
final class LyricsFx {
    private LyricsFx() {}

    static final String K_WORLD = "lyrics.world", K_PILL = "lyrics.pill", K_NET = "lyrics.net", K_DIST = "lyrics.dist",
            K_SIZE = "lyrics.size", K_SCATTER = "lyrics.scatter", K_SYNC = "lyrics.sync", K_SIDE = "lyrics.side",
            K_GLOW = "lyrics.glow", K_GLOWK = "lyrics.glowk", K_SHADOW = "lyrics.shadow", K_SYNC_TXT = "lyrics.synctxt";

    static void register() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "lyrics_fx"),
                (ctx, tick) -> render(ctx, tick.getTickProgress(false)));
    }

    private static float clamp01(float v) { return Math.max(0f, Math.min(1f, v)); }
    private static float ease(float v) { v = clamp01(v); return v * v * (3f - 2f * v); }

    private static void render(DrawContext ctx, float td) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        boolean chat = mc.currentScreen instanceof ChatScreen;
        if (mc.currentScreen != null && !chat) return;
        if (!MusicPlayer.active()) { spawns.clear(); worldLy = null; pillAnim = 0f; return; }

        Lyrics ly = MusicPlayer.lyrics();
        float t = MusicPlayer.time() + ShrineCfg.num(K_SYNC, 0f) / 1000f;
        if (ly != null && ly.plain) t += ShrineCfg.num(K_SYNC_TXT, 0f);      // simple mode: coarse shift in seconds
        int idx = ly != null ? ly.index(t) : -1;
        if (ShrineCfg.bool(K_PILL, true)) pill(ctx, mc, ly, idx, t);
        if (ShrineCfg.bool(K_WORLD, true) && ly != null && mc.currentScreen == null
                && mc.options.getPerspective().isFirstPerson()) world(ctx, mc, td, ly, idx, t);
    }

    // ================= equalizer (also used by the player card) =================
    static void eq(DrawContext ctx, float x, float cy, float a, boolean live, float t) {
        for (int i = 0; i < 4; i++) {
            float h = live ? 4f + 9f * (0.5f + 0.5f * (float) Math.sin(t * (6f + i * 1.9f) + i * 1.3f)) : 4f;
            int bx = Math.round(x + i * 5f);
            ctx.fill(bx, Math.round(cy - h / 2f), bx + 3, Math.round(cy + h / 2f), argb(0.9f * a, 0xFFFFFF));
        }
    }

    // ================= capsule at the top =================
    private static float pillAnim, pillW = 240f, scrollX;
    private static int pillIdx = -2;
    private static Lyrics pillLy;

    private static String fit(TextRenderer tr, String s, float maxW) {
        if (width(tr, Fnt.SMALL, s) <= maxW) return s;
        while (s.length() > 1 && width(tr, Fnt.SMALL, s + "…") > maxW) s = s.substring(0, s.length() - 1);
        return s + "…";
    }

    private static void pill(DrawContext ctx, MinecraftClient mc, Lyrics ly, int idx, float t) {
        TextRenderer tr = mc.textRenderer;
        pillAnim += (1f - pillAnim) * 0.12f;
        float a = pillAnim;
        float k = mc.getWindow().getScaledHeight() / Scene.REF_H;
        float vw = mc.getWindow().getScaledWidth() / k;

        Lyrics.Line line = null;
        if (ly != null && idx >= 0) {
            Lyrics.Line l = ly.lines.get(idx);
            if (!l.blank() && t < l.end + 2f) line = l;
        }
        MusicPlayer.Track tr0 = MusicPlayer.currentTrack();
        String plain = tr0 == null ? "" : tr0.title + (tr0.artist.isEmpty() ? "" : " · " + tr0.artist);

        float sp = Math.max(3f, width(tr, Fnt.SMALL, "a a") - width(tr, Fnt.SMALL, "aa"));
        float[] wx = null, ww = null;
        float total = 0f, targetW;
        if (line != null) {
            int n = line.words.length;
            wx = new float[n]; ww = new float[n];
            float cx = 0f;
            for (int i = 0; i < n; i++) { ww[i] = width(tr, Fnt.SMALL, line.words[i]); wx[i] = cx; cx += ww[i] + sp; }
            total = cx - sp;
            targetW = Math.max(220f, Math.min(400f, total + 84f));
        } else {
            targetW = Math.max(200f, Math.min(400f, width(tr, Fnt.SMALL, plain) + 84f));
        }
        pillW += (targetW - pillW) * 0.15f;

        final float W = pillW, H = 32f, x = (vw - W) / 2f, y = 12f - (1f - a) * 14f;
        final float tx = x + 38f, tw = W - 38f - 42f;

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        box(ctx, RR, x - 1, y - 1, W + 2, H + 2, 17, argb(0.35f * a, ACCENT));
        box(ctx, RR, x, y, W, H, 16, argb(0.88f * a, 0x0E070C));
        box(ctx, RR, x + 6, y + 5, 22, 22, 11, argb(0.9f * a, 0x2A0F15));
        centered(ctx, RING, x + 17, y + 16, 12, 12, argb(0.8f * a, 0xFFFFFF));
        centered(ctx, DISC, x + 17, y + 16, 4, 4, argb(0.9f * a, 0xFFFFFF));
        eq(ctx, x + W - 28, y + H / 2f, a, !MusicPlayer.paused, t);

        if (line == null) {
            text(ctx, tr, Fnt.SMALL, fit(tr, plain, tw), tx, y + H / 2f, argb(0.9f * a, 0xFFFFFF));
        } else {
            int aw = Lyrics.wordAt(line, t);
            float focus = aw >= 0 ? wx[aw] + ww[aw] / 2f : 0f;
            float target = total <= tw ? (tw - total) / 2f : Math.max(tw - total, Math.min(0f, tw / 2f - focus));
            if (pillIdx != idx || pillLy != ly) {          // a new line: short ones centered at once, long ones start at the left
                pillIdx = idx; pillLy = ly;
                scrollX = total <= tw ? target : 0f;
            }
            scrollX += (target - scrollX) * 0.18f;
            for (int i = 0; i < line.words.length; i++) {
                float px = tx + scrollX + wx[i], c = px + ww[i] / 2f;
                float fade = Math.min(1f, Math.min((c - tx) / 16f, (tx + tw - c) / 16f));
                if (fade <= 0.02f) continue;
                boolean cur = i == aw, past = i < aw;
                if (cur) box(ctx, RR, px - 4, y + H / 2f - 9, ww[i] + 8, 18, 9, argb(0.30f * a * fade, 0xFFB3BC));
                text(ctx, tr, Fnt.SMALL, line.words[i], px, y + H / 2f, argb((cur ? 1f : past ? 0.85f : 0.42f) * a * fade, 0xFFFFFF));
            }
        }
        ctx.getMatrices().popMatrix();
    }

    // ================= World Lyrics =================
    private static final class Spawn {
        final Lyrics.Line line; final double x, y, z; final float roll;
        Spawn(Lyrics.Line line, double x, double y, double z, float roll) { this.line = line; this.x = x; this.y = y; this.z = z; this.roll = roll; }
    }

    private static final List<Spawn> spawns = new ArrayList<>();
    private static int worldIdx = -2;
    private static Lyrics worldLy;

    /** Hand-made first-person camera: position, basis and FOV, so 3D points can be put on the screen. */
    private static final class Cam {
        final Vec3d pos; final double fx, fy, fz, rx, rz, ux, uy, uz, W, H, tanHalf;
        Cam(MinecraftClient mc, DrawContext ctx, float td) {
            pos = mc.player.getCameraPosVec(td);
            double yr = Math.toRadians(mc.player.getYaw(td)), pr = Math.toRadians(mc.player.getPitch(td));
            fx = -Math.sin(yr) * Math.cos(pr); fy = -Math.sin(pr); fz = Math.cos(yr) * Math.cos(pr);
            rx = -Math.cos(yr); rz = -Math.sin(yr);
            ux = -rz * fy; uy = rz * fx - rx * fz; uz = rx * fy;
            W = ctx.getScaledWindowWidth(); H = ctx.getScaledWindowHeight();
            tanHalf = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        }
        /** out = {x, y, pixels per block}. */
        boolean p(double x, double y, double z, float[] out) {
            x -= pos.x; y -= pos.y; z -= pos.z;
            double zc = x * fx + y * fy + z * fz;
            if (zc < 0.5) return false;
            double xc = x * rx + z * rz, yc = x * ux + y * uy + z * uz, k = (H / 2.0) / (zc * tanHalf);
            out[0] = (float) (W / 2.0 + xc * k);
            out[1] = (float) (H / 2.0 - yc * k);
            out[2] = (float) k;
            return true;
        }
    }

    private static void spawn(MinecraftClient mc, float td, Lyrics.Line line, int idx) {
        Random r = new Random(idx * 7919L + 13L);
        float scatter = ShrineCfg.num(K_SCATTER, 0.7f);
        float spread = 20f + scatter * 90f;
        float ang = (r.nextFloat() * 2f - 1f) * spread;
        if (ShrineCfg.bool(K_SIDE, false)) {                // "roadside": keep the middle of the screen free
            float side = r.nextBoolean() ? 1f : -1f;
            ang = side * (24f + r.nextFloat() * Math.max(8f, spread - 24f));
        }
        float pitch = mc.player.getPitch(td) + (r.nextFloat() * 2f - 1f) * (6f + scatter * 24f);
        pitch = Math.max(-60f, Math.min(60f, pitch));
        double yr = Math.toRadians(mc.player.getYaw(td) + ang), pr = Math.toRadians(pitch);
        double dist = Math.max(3f, ShrineCfg.num(K_DIST, 9f));
        Vec3d eye = mc.player.getCameraPosVec(td);
        spawns.add(new Spawn(line,
                eye.x + -Math.sin(yr) * Math.cos(pr) * dist,
                eye.y + -Math.sin(pr) * dist,
                eye.z + Math.cos(yr) * Math.cos(pr) * dist,
                (r.nextFloat() * 2f - 1f) * 0.09f));
        while (spawns.size() > 4) spawns.remove(0);
    }

    private static void world(DrawContext ctx, MinecraftClient mc, float td, Lyrics ly, int idx, float t) {
        if (worldLy != ly) { spawns.clear(); worldIdx = -2; worldLy = ly; }
        if (idx != worldIdx) {
            worldIdx = idx;
            if (idx >= 0 && !ly.lines.get(idx).blank()) spawn(mc, td, ly.lines.get(idx), idx);
        }
        if (spawns.isEmpty()) return;
        Cam cam = new Cam(mc, ctx, td);
        float size = ShrineCfg.num(K_SIZE, 1f);
        float[] o = new float[3];
        for (Iterator<Spawn> it = spawns.iterator(); it.hasNext(); ) {
            Spawn s = it.next();
            float age = t - s.line.start, life = (s.line.end - s.line.start) + 1.1f;
            if (age < -0.3f || age > life) { it.remove(); continue; }      // also drops lines after a skip back
            float in = clamp01(age / 0.3f);
            float al = ease(in) * ease((life - age) / 0.6f);
            if (al <= 0.01f) continue;
            double y = s.y + Math.max(0f, age) * 0.07 + (1f - in) * (1f - in) * 0.5;
            if (!cam.p(s.x, y, s.z, o)) continue;
            float sc = Math.min(8f, 0.07f * size * o[2] * (0.85f + 0.15f * in));
            if (sc < 0.2f) continue;
            drawLine(ctx, mc.textRenderer, s, o[0], o[1], sc, al, t);
        }
    }

    private static final float[][] DIRS = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {0.7f, 0.7f}, {-0.7f, -0.7f}};

    private static void drawLine(DrawContext ctx, TextRenderer tr, Spawn s, float x, float y, float sc, float al, float t) {
        Lyrics.Line L = s.line;
        int n = L.words.length;
        float[] wx = new float[n];
        float sp = Math.max(3f, width(tr, Fnt.TITLE_B, "a a") - width(tr, Fnt.TITLE_B, "aa")), cx = 0f;
        for (int i = 0; i < n; i++) { wx[i] = cx; cx += width(tr, Fnt.TITLE_B, L.words[i]) + sp; }
        float total = cx - sp;
        boolean glow = ShrineCfg.bool(K_GLOW, true), shadow = ShrineCfg.bool(K_SHADOW, true);
        float gk = ShrineCfg.num(K_GLOWK, 0.9f);
        int aw = Lyrics.wordAt(L, t);

        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(x, y);
        m.rotate(s.roll);
        m.scale(sc, sc);
        for (int i = 0; i < n; i++) {
            boolean cur = i == aw, past = i < aw;
            float wa = al * (cur ? 1f : past ? 0.95f : 0.62f);
            float px = -total / 2f + wx[i];
            String w = L.words[i];
            if (shadow) text(ctx, tr, Fnt.TITLE_B, w, px + 1.2f, 1.2f, argb(0.55f * wa, 0x000000));
            if (glow && gk > 0.01f) {
                int gc = cur ? 0xFF8A9A : 0xAFC8FF;
                for (float[] d : DIRS) text(ctx, tr, Fnt.TITLE_B, w, px + d[0] * 2.2f, d[1] * 2.2f, argb(0.16f * gk * wa, gc));
            }
            text(ctx, tr, Fnt.TITLE_B, w, px, 0f, argb(wa, cur ? 0xFFFFFF : past ? 0xFFE9EC : 0xF1F3FF));
        }
        m.popMatrix();
    }
}

package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.util.Identifier;

import static com.shrine.Gfx.*;

/** HUD > "Музыка": a small player card (title, artist, prev / pause / next, progress line). */
final class MusicHud {
    private MusicHud() {}

    static final String KEY = "hud.music", K_X = "music.x", K_Y = "music.y", K_SCALE = "music.scale";
    static final float W = 250f, H = 96f;

    static void register() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "music_hud"), (ctx, tick) -> render(ctx));
    }

    static float[] size() { return new float[]{W, H}; }
    static float anchorX(float vw) { return vw - W / 2f - 20f; }
    static float anchorTop() { return Scene.REF_H - H - 76f; }
    static float posX() { return ShrineCfg.num(K_X, 0f); }
    static float posY() { return ShrineCfg.num(K_Y, 0f); }
    static float scale() { return Math.max(0.5f, Math.min(2.5f, ShrineCfg.num(K_SCALE, 1f))); }

    /** What the card shows: the real player state or demo values. */
    static final class State {
        String title = "Название песни", artist = "Исполнитель";
        float progress = 0.4f;
        boolean paused;
    }

    static State live() {
        State s = new State();
        int c = MusicPlayer.current;
        if (c >= 0 && c < MusicPlayer.tracks.size()) {
            MusicPlayer.Track t = MusicPlayer.tracks.get(c);
            s.title = t.title; s.artist = t.artist;
        } else { s.title = "Ничего не играет"; s.artist = ""; }
        String err = MusicPlayer.error;
        if (err != null) { s.artist = "Ошибка: " + err; }
        float d = MusicPlayer.duration;
        s.progress = d > 0f ? Math.max(0f, Math.min(1f, MusicPlayer.elapsed / d)) : 0f;
        s.paused = MusicPlayer.paused;
        return s;
    }

    private static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        boolean chat = mc.currentScreen instanceof ChatScreen;
        if (mc.player == null || (mc.currentScreen != null && !chat) || mc.options.hudHidden) return;
        if (!ShrineCfg.bool(KEY, false) || (!MusicPlayer.active() && !chat)) return;
        int w = mc.getWindow().getScaledWidth();
        float k = mc.getWindow().getScaledHeight() / Scene.REF_H;
        drawAt(ctx, mc.textRenderer, w / k, live(), 1f);
    }

    /**
     * Clicks on the card while the chat is open (the mouse is free there).
     * @return true when a button was hit, so the chat must not handle the click
     */
    static boolean chatClick(Click click) {
        if (click.button() != 0 || !ShrineCfg.bool(KEY, false)) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        float k = mc.getWindow().getScaledHeight() / Scene.REF_H;
        float vw = mc.getWindow().getScaledWidth() / k;
        float s = scale();
        float lx = ((float) click.x() / k - (anchorX(vw) + posX() - W * s / 2f)) / s;
        float ly = ((float) click.y() / k - (anchorTop() + posY())) / s;
        for (int i = 0; i < 3; i++) {
            float[] r = ctrl(i);
            if (inside(lx, ly, r[0], r[1], r[2], r[3])) {
                if (i == 0) MusicPlayer.prev(); else if (i == 1) MusicPlayer.toggle(); else MusicPlayer.next();
                return true;
            }
        }
        return false;
    }

    /** Draws the card at its configured position and size. */
    static void drawAt(DrawContext ctx, TextRenderer tr, float vw, State st, float a) {
        float k = MinecraftClient.getInstance().getWindow().getScaledHeight() / Scene.REF_H;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        ctx.getMatrices().translate(anchorX(vw) + posX(), anchorTop() + posY());
        ctx.getMatrices().scale(scale(), scale());
        ctx.getMatrices().translate(-W / 2f, 0f);
        panel(ctx, tr, st, a, -1f, -1f);
        ctx.getMatrices().popMatrix();
    }

    /** Control button rectangles in panel coordinates: 0 = previous, 1 = pause / play, 2 = next. */
    static float[] ctrl(int i) {
        float cx = 84f + (W - 12f - 84f) / 2f;
        float[] xs = {cx - 44f, cx, cx + 44f};
        return new float[]{xs[i] - 18f, 54f, 36f, 26f};
    }

    /** @param mx,my mouse in panel coordinates for hover effects (negative = none). */
    static void panel(DrawContext ctx, TextRenderer tr, State st, float a, float mx, float my) {
        box(ctx, RR, -1, -1, W + 2, H + 2, 17, argb(0.50f * a, ACCENT));
        box(ctx, RR, 0, 0, W, H, 16, argb(0.88f * a, 0x150A0F));

        // cover placeholder
        box(ctx, RR, 12, 12, 60, 60, 12, argb(0.9f * a, 0x2A0F15));
        centered(ctx, GLOW, 42, 42, 80, 80, argb(0.35f * a, ACCENT));
        centered(ctx, RING, 42, 42, 28, 28, argb(0.8f * a, 0xFFFFFF));
        centered(ctx, DISC, 42, 42, 8, 8, argb(0.9f * a, 0xFFFFFF));

        String title = st.title.length() > 17 ? st.title.substring(0, 16) + "…" : st.title;
        String artist = st.artist.length() > 24 ? st.artist.substring(0, 23) + "…" : st.artist;
        text(ctx, tr, Fnt.UI_B, title, 84, 24, argb(a, 0xFFFFFF));
        text(ctx, tr, Fnt.SMALL, artist, 84, 44, argb(0.6f * a, 0xFFFFFF));

        int white = argb(a, 0xFFFFFF);
        for (int i = 0; i < 3; i++) {
            float[] r = ctrl(i);
            boolean hov = mx >= 0 && inside(mx, my, r[0], r[1], r[2], r[3]);
            if (hov) box(ctx, RR, r[0], r[1], r[2], r[3], 13, argb(0.14f * a, 0xFFFFFF));
            float cx = r[0] + r[2] / 2f, cy = r[1] + r[3] / 2f;
            if (i == 0) { tri(ctx, cx - 9, cy, 9, false, white); tri(ctx, cx - 1, cy, 9, false, white); }
            else if (i == 2) { tri(ctx, cx - 7, cy, 9, true, white); tri(ctx, cx + 1, cy, 9, true, white); }
            else if (st.paused) tri(ctx, cx - 5, cy, 12, true, white);
            else {
                ctx.fill(Math.round(cx - 5), Math.round(cy - 6), Math.round(cx - 2), Math.round(cy + 6), white);
                ctx.fill(Math.round(cx + 2), Math.round(cy - 6), Math.round(cx + 5), Math.round(cy + 6), white);
            }
        }

        float bx = 12, bw = W - 24, by = H - 12;
        box(ctx, RR, bx, by, bw, 3, 1.5f, argb(0.18f * a, 0xFFFFFF));
        box(ctx, RR, bx, by, Math.max(3f, bw * st.progress), 3, 1.5f, argb(a, 0xFF4D5D));
    }

    private static void tri(DrawContext ctx, float x, float cy, float s, boolean right, int col) {
        int w = Math.round(s * 0.85f);
        for (int i = 0; i < w; i++) {
            float half = (s / 2f) * (1f - (float) i / w);
            int xx = Math.round(right ? x + i : x + (w - 1 - i));
            ctx.fill(xx, Math.round(cy - half), xx + 1, Math.round(cy + half), col);
        }
    }
}

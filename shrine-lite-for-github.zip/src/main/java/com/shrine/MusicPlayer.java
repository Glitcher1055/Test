package com.shrine;

import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.SampleBuffer;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.sound.SoundCategory;
import org.lwjgl.BufferUtils;
import org.lwjgl.openal.AL10;
import org.lwjgl.openal.AL11;
import org.lwjgl.openal.ALC10;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ShortBuffer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Stream;

/**
 * mp3 player for the HUD widget. mp3 files are taken from the game folder "музыка св" (or "shrine_music"),
 * decoded with JLayer (pure Java, so it works on Android launchers too) and played through the same OpenAL
 * that Minecraft uses for its own sounds, streamed in small buffers.
 */
final class MusicPlayer {
    private MusicPlayer() {}

    static final String[] DIRS = {"музыка св", "shrine_music"};

    static final class Track {
        final Path path; final String file; String title, artist = "";
        volatile Lyrics lyrics; volatile int lyricsState;   // 0 not tried, 1 loading, 2 ready, 3 none found
        volatile boolean netTried;
        Track(Path p) {
            path = p;
            String f = p.getFileName().toString();
            file = f;
            title = f.toLowerCase(Locale.ROOT).endsWith(".mp3") ? f.substring(0, f.length() - 4) : f;
        }
    }

    static final List<Track> tracks = new ArrayList<>();
    static volatile int current = -1;
    static volatile boolean paused;
    static volatile float elapsed, duration;
    static volatile String error;
    static volatile long stamp;       // System.nanoTime() when elapsed was last updated

    private static volatile int gen;

    // ---------- folder / list ----------
    static Path dir(int i) { return FabricLoader.getInstance().getGameDir().resolve(DIRS[i]); }

    /** Creates the folders (first launch) and reads the list of mp3 files. */
    static synchronized void rescan() {
        for (int i = 0; i < DIRS.length; i++) { try { Files.createDirectories(dir(i)); } catch (Throwable ignored) { } }
        String playing = current >= 0 && current < tracks.size() ? tracks.get(current).path.toString() : null;
        List<Track> found = new ArrayList<>();
        for (int i = 0; i < DIRS.length; i++) {
            try (Stream<Path> s = Files.list(dir(i))) {
                s.filter(p -> p.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(".mp3") && Files.isRegularFile(p))
                 .sorted().forEach(p -> found.add(new Track(p)));
            } catch (Throwable ignored) { }
        }
        for (Track t : found) readTags(t);
        tracks.clear();
        tracks.addAll(found);
        if (playing != null) {
            current = -1;
            for (int i = 0; i < tracks.size(); i++) if (tracks.get(i).path.toString().equals(playing)) current = i;
        }
    }

    // ---------- controls ----------
    static boolean active() { return current >= 0; }

    static Track currentTrack() { int c = current; return c >= 0 && c < tracks.size() ? tracks.get(c) : null; }

    /** Song position in seconds, smoothed between the playback thread's updates (it runs every ~20-40 ms). */
    static float time() {
        float e = elapsed;
        if (paused || current < 0) return e;
        float d = (System.nanoTime() - stamp) / 1e9f;
        return e + Math.max(0f, Math.min(0.1f, d));
    }

    // ---------- lyrics ----------
    /** Lyrics of the current song, or null (none / still loading). Starts loading on first use. */
    static Lyrics lyrics() {
        Track t = currentTrack();
        if (t == null) return null;
        ensureLyrics(t);
        return t.lyricsState == 2 ? t.lyrics : null;
    }

    static String lyricsStatus() {
        Track t = currentTrack();
        if (t == null) return "Включи песню, чтобы увидеть статус текста";
        return switch (t.lyricsState) {
            case 1 -> "Текст: загружается…";
            case 2 -> t.lyrics.plain
                    ? "Текст: из .txt, строк - " + t.lyrics.lines.size() + " (приблизительно)"
                    : "Текст: найден, строк - " + t.lyrics.lines.size();
            case 3 -> "Текст: не найден (нужен " + Lyrics.fileFor(t).getFileName() + " или " + Lyrics.txtFor(t).getFileName() + ")";
            default -> "Текст: ещё не искали";
        };
    }

    static void ensureLyrics(Track t) {
        boolean net = ShrineCfg.bool("lyrics.net", false);
        int st = t.lyricsState;
        if (st == 1 || st == 2) return;
        if (st == 3 && (!net || t.netTried)) return;
        // the internet lookup and the simple .txt mode want the song length: wait until the playback thread knows it
        boolean needLen = net || Files.isRegularFile(Lyrics.txtFor(t));
        if (needLen && duration <= 0f && error == null && !Files.isRegularFile(Lyrics.fileFor(t))) return;
        t.lyricsState = 1;
        Thread th = new Thread(() -> loadLyrics(t, net), "shrine-lyrics");
        th.setDaemon(true);
        th.start();
    }

    private static void loadLyrics(Track t, boolean net) {
        try {
            Path f = Lyrics.fileFor(t);
            if (Files.isRegularFile(f)) {
                Lyrics ly = Lyrics.load(f);
                if (ly != null) { t.lyrics = ly; t.lyricsState = 2; return; }
            }
            Path txt = Lyrics.txtFor(t);                    // simple mode: plain words, spread evenly over the song
            if (Files.isRegularFile(txt)) {
                Lyrics ly = Lyrics.loadPlain(txt, duration);
                if (ly != null) { t.lyrics = ly; t.lyricsState = 2; return; }
            }
            if (net) {
                t.netTried = true;
                String title = t.title, artist = t.artist;
                if (artist.isEmpty() && title.contains(" - ")) {
                    int i = title.indexOf(" - ");
                    artist = title.substring(0, i).trim();
                    title = title.substring(i + 3).trim();
                }
                String lrc = Lyrics.fetch(title, artist, duration);
                if (lrc != null) {
                    Lyrics ly = Lyrics.parse(lrc);
                    if (!ly.lines.isEmpty()) {
                        try { Files.writeString(f, lrc, StandardCharsets.UTF_8); } catch (Throwable ignored) { }   // cache next to the mp3
                        t.lyrics = ly; t.lyricsState = 2;
                        return;
                    }
                }
            }
        } catch (Throwable e) {
            if (net) t.netTried = true;
        }
        t.lyricsState = 3;
    }

    static void play(int i) {
        if (i < 0 || i >= tracks.size()) return;
        error = null; current = i; paused = false; elapsed = 0f; duration = 0f; stamp = System.nanoTime();
        int g = ++gen;
        Track t = tracks.get(i);
        Thread th = new Thread(() -> run(t, g), "shrine-music");
        th.setDaemon(true);
        th.start();
    }

    static void toggle() {
        if (current < 0) { if (!tracks.isEmpty()) play(0); }
        else paused = !paused;
    }

    static void next() { if (!tracks.isEmpty()) play(current < 0 ? 0 : (current + 1) % tracks.size()); }

    static void prev() {
        if (tracks.isEmpty()) return;
        if (current >= 0 && elapsed > 3f) play(current);
        else play(current <= 0 ? tracks.size() - 1 : current - 1);
    }

    static float volume() { return Math.max(0f, Math.min(1f, ShrineCfg.num("music.volume", 0.8f))); }

    private static float gain() {
        MinecraftClient mc = MinecraftClient.getInstance();
        float master = mc != null && mc.options != null ? mc.options.getSoundVolume(SoundCategory.MASTER) : 1f;
        return master * volume();
    }

    // ---------- playback thread ----------
    private static final int BUFS = 8, CHUNK = 2304 * 8;

    private static void run(Track t, int g) {
        int source = 0;
        Map<Integer, Integer> sizes = new HashMap<>();
        ArrayDeque<Integer> free = new ArrayDeque<>();
        boolean ended = false;
        try {
            if (ALC10.alcGetCurrentContext() == 0L) throw new IOException("звук Minecraft ещё не готов");
            long fileSize = Files.size(t.path);
            try (InputStream in = new BufferedInputStream(Files.newInputStream(t.path), 1 << 16)) {
                Bitstream bs = new Bitstream(in);
                Decoder dec = new Decoder();
                Header h = bs.readFrame();
                if (h == null) throw new IOException("в файле нет звука");
                duration = h.bitrate() > 0 ? fileSize * 8f / h.bitrate() : 0f;

                source = AL10.alGenSources();
                for (int i = 0; i < BUFS; i++) free.add(AL10.alGenBuffers());
                ShortBuffer sb = BufferUtils.createShortBuffer(CHUNK);
                long playedFrames = 0;
                int freq = 44100;
                boolean eof = false, started = false, appliedPause = false;

                while (g == gen) {
                    AL10.alSourcef(source, AL10.AL_GAIN, gain());
                    if (paused != appliedPause) {
                        if (paused) AL10.alSourcePause(source); else if (started) AL10.alSourcePlay(source);
                        appliedPause = paused;
                    }
                    int processed = AL10.alGetSourcei(source, AL10.AL_BUFFERS_PROCESSED);
                    while (processed-- > 0) {
                        int b = AL10.alSourceUnqueueBuffers(source);
                        free.add(b);
                        playedFrames += sizes.getOrDefault(b, 0);
                    }
                    if (paused) { Thread.sleep(40); continue; }
                    elapsed = playedFrames / (float) freq + AL10.alGetSourcef(source, AL11.AL_SEC_OFFSET);
                    stamp = System.nanoTime();

                    if (!eof && !free.isEmpty()) {
                        sb.clear();
                        int ch = 2;
                        while (sb.remaining() >= 2304 && !eof) {
                            SampleBuffer out = (SampleBuffer) dec.decodeFrame(h, bs);
                            ch = out.getChannelCount();
                            freq = out.getSampleFrequency();
                            sb.put(out.getBuffer(), 0, out.getBufferLength());
                            bs.closeFrame();
                            h = bs.readFrame();
                            if (h == null) eof = true;
                        }
                        if (sb.position() > 0) {
                            sb.flip();
                            int b = free.poll();
                            sizes.put(b, sb.remaining() / ch);
                            AL10.alBufferData(b, ch == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16, sb, freq);
                            AL10.alSourceQueueBuffers(source, b);
                        }
                    } else {
                        Thread.sleep(20);
                    }
                    int queued = AL10.alGetSourcei(source, AL10.AL_BUFFERS_QUEUED);
                    int st = AL10.alGetSourcei(source, AL10.AL_SOURCE_STATE);
                    if (!paused && queued > 0 && st != AL10.AL_PLAYING) { AL10.alSourcePlay(source); started = true; }
                    if (eof && queued == 0) { ended = true; break; }
                }
            }
        } catch (Throwable e) {
            if (g == gen) {
                String m = e.getMessage();
                error = m != null && !m.isEmpty() ? m : e.getClass().getSimpleName();
                paused = true;
            }
        } finally {
            try {
                if (source != 0) {
                    AL10.alSourceStop(source);
                    int q = AL10.alGetSourcei(source, AL10.AL_BUFFERS_QUEUED);
                    while (q-- > 0) free.add(AL10.alSourceUnqueueBuffers(source));
                    AL10.alDeleteSources(source);
                    for (int b : free) AL10.alDeleteBuffers(b);
                }
            } catch (Throwable ignored) { }
        }
        if (ended && g == gen) next();       // the song finished: play the next one
    }

    // ---------- ID3 tags (title / artist) ----------
    private static int syncsafe(byte[] b, int o) { return (b[o] & 0x7F) << 21 | (b[o + 1] & 0x7F) << 14 | (b[o + 2] & 0x7F) << 7 | (b[o + 3] & 0x7F); }
    private static int be32(byte[] b, int o) { return (b[o] & 0xFF) << 24 | (b[o + 1] & 0xFF) << 16 | (b[o + 2] & 0xFF) << 8 | (b[o + 3] & 0xFF); }

    private static String text(byte[] b, int o, int len) {
        if (len < 2) return "";
        int enc = b[o];
        Charset cs = switch (enc) {
            case 1 -> StandardCharsets.UTF_16;
            case 2 -> StandardCharsets.UTF_16BE;
            case 3 -> StandardCharsets.UTF_8;
            default -> Charset.forName("windows-1251");   // most Russian tags are cp1251
        };
        String s = new String(b, o + 1, len - 1, cs);
        return s.replace("\0", "").trim();
    }

    private static void readTags(Track t) {
        try (InputStream in = Files.newInputStream(t.path)) {
            byte[] hdr = in.readNBytes(10);
            if (hdr.length < 10 || hdr[0] != 'I' || hdr[1] != 'D' || hdr[2] != '3') return;
            int ver = hdr[3];
            int size = syncsafe(hdr, 6);
            byte[] tag = in.readNBytes(Math.min(size, 1 << 20));
            int idLen = ver == 2 ? 3 : 4, hLen = ver == 2 ? 6 : 10, p = 0;
            while (p + hLen <= tag.length) {
                if (tag[p] == 0) break;
                String id = new String(tag, p, idLen, StandardCharsets.ISO_8859_1);
                int fs = ver == 2 ? (tag[p + 3] & 0xFF) << 16 | (tag[p + 4] & 0xFF) << 8 | (tag[p + 5] & 0xFF)
                        : ver == 4 ? syncsafe(tag, p + 4) : be32(tag, p + 4);
                if (fs <= 0 || p + hLen + fs > tag.length) break;
                if (id.equals("TIT2") || id.equals("TT2")) { String s = text(tag, p + hLen, fs); if (!s.isEmpty()) t.title = s; }
                else if (id.equals("TPE1") || id.equals("TP1")) t.artist = text(tag, p + hLen, fs);
                p += hLen + fs;
            }
        } catch (Throwable ignored) { }
    }
}

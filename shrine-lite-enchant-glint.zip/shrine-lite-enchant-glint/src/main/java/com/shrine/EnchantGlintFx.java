package com.shrine;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

/**
 * Visual > "Зачарование": the enchantment shimmer on armor and items, like the EnchantGlint video.
 *
 * Vanilla draws the glint with separate textures: enchanted_glint_item.png (items in hand / inventory) and
 * enchanted_glint_armor.png (armor being worn); ..._entity.png is replaced too for older layouts.
 * While the feature is on, this class generates the glint pattern itself (style, colors, density, speed)
 * every 100 ms and registers it under those identifiers, so the game draws our shimmer instead.
 * Turning it off reloads resources, which brings the vanilla textures back.
 */
final class EnchantGlintFx {
    private EnchantGlintFx() {}

    static final String KEY = "visual.glint", K_STYLE = "visual.glint.style", K_COLOR = "visual.glint.color",
            K_COLOR2 = "visual.glint.color2", K_SPEED = "visual.glint.speed", K_DENSITY = "visual.glint.density";

    static final String[] STYLES = {"Фиолетовое", "Свой цвет", "Два цвета", "Радуга", "Галактика", "Голограмма",
            "Лава", "Лёд", "Искры", "Полосы", "Пульс"};
    private static final int[] DENSITY = {3, 2, 1};          // "Частая", "Средняя", "Редкая" -> tiles per texture

    static final Identifier PREVIEW = Identifier.of("shrine", "glint/preview");
    private static final Identifier VANILLA_ITEM = Identifier.of("minecraft", "textures/misc/enchanted_glint_item.png");
    private static final Identifier VANILLA_ARMOR = Identifier.of("minecraft", "textures/misc/enchanted_glint_armor.png");   // worn armor
    private static final Identifier VANILLA_ENTITY = Identifier.of("minecraft", "textures/misc/enchanted_glint_entity.png"); // older layout, harmless if unused
    private static final int N = 64;
    private static final long INTERVAL_MS = 100;
    private static final long START = Util.getMeasuringTimeMs();

    private static long nextAt;
    private static boolean wasOn;
    private static volatile boolean ready;

    static boolean enabled() { return ShrineCfg.bool(KEY, false); }
    static boolean ready() { return ready; }
    static int style() { return clamp(ShrineCfg.integer(K_STYLE, 0), 0, STYLES.length - 1); }
    static int color1() { return ShrineGui.PALETTE[clamp(ShrineCfg.integer(K_COLOR, 5), 0, ShrineGui.PALETTE.length - 1)]; }
    static int color2() { return ShrineGui.PALETTE[clamp(ShrineCfg.integer(K_COLOR2, 4), 0, ShrineGui.PALETTE.length - 1)]; }
    static int tiles() { return DENSITY[clamp(ShrineCfg.integer(K_DENSITY, 1), 0, DENSITY.length - 1)]; }
    static float speed() { return Math.max(0.2f, Math.min(3f, ShrineCfg.num(K_SPEED, 1f))); }

    // ---------- tick: runs every client tick, updates the texture ~10 times a second ----------
    static void tick() {
        MinecraftClient mc = MinecraftClient.getInstance();
        boolean on = enabled();
        if (!on && wasOn) {
            wasOn = false;
            ready = false;
            mc.reloadResources();                            // gives the vanilla glint textures back
            return;
        }
        // the preview in the settings window must update even while the feature is off
        if (!on && !(mc.currentScreen instanceof ShrineGui)) return;
        long now = Util.getMeasuringTimeMs();
        if (now < nextAt) return;
        nextAt = now + INTERVAL_MS;
        double t = ((now - START) * speed() / 4000.0) % 1.0;  // one loop of the pattern every 4 s at speed 1
        try {
            BufferedImage img = frame((float) t);
            put(mc, PREVIEW, img);
            ready = true;
            if (on) {
                put(mc, VANILLA_ITEM, img);      // held items, inventory
                put(mc, VANILLA_ARMOR, img);     // armor worn by you and by other players
                put(mc, VANILLA_ENTITY, img);
                wasOn = true;
            }
        } catch (IOException | RuntimeException ignored) {
            // a failed frame is skipped; the next tick tries again
        }
    }

    private static void put(MinecraftClient mc, Identifier id, BufferedImage img) throws IOException {
        ByteArrayOutputStream png = new ByteArrayOutputStream();
        ImageIO.write(img, "png", png);
        NativeImage native_ = NativeImage.read(new ByteArrayInputStream(png.toByteArray()));
        try { mc.getTextureManager().destroyTexture(id); } catch (RuntimeException ignored) { }
        mc.getTextureManager().registerTexture(id, new NativeImageBackedTexture(() -> "shrine glint", native_));
    }

    private static BufferedImage frame(float t) {
        BufferedImage img = new BufferedImage(N, N, BufferedImage.TYPE_INT_ARGB);
        int style = style(), c1 = color1(), c2 = color2(), d = tiles();
        for (int y = 0; y < N; y++)
            for (int x = 0; x < N; x++) img.setRGB(x, y, texel(style, x, y, t, d, c1, c2));
        return img;
    }

    // ---------- the 11 patterns. Every term is an integer multiple of the tile size, so the texture repeats seamlessly ----------
    private static int texel(int style, int x, int y, float t, int d, int c1, int c2) {
        float u = (x + 0.5f) / N * d, v = (y + 0.5f) / N * d;
        switch (style) {
            case 0: { float w = wave(u + v + t); return argb(mix(0xB07CFF, 0xFF4DFF, w), 0.35f + 0.35f * w); }
            case 1: { float w = wave(u + t);     return argb(c1, 0.20f + 0.50f * w); }
            case 2: { float w = wave(u + t);     return argb(mix(c1, c2, w), 0.30f + 0.40f * w); }
            case 3: { return argb(hue(u + t), 0.55f); }
            case 4: {
                float n = wave(u * 3 + v * 2 + t) * wave(u * 2 - v * 3 - t);
                return argb(mix(0x8A4DFF, 0x4DB8FF, wave(u + t)), 0.10f + 0.60f * n * n);
            }
            case 5: { float w = wave(u + v + t); return argb(mix(0x4DFFF0, 0xFF5DD6, w), 0.40f + 0.30f * w); }
            case 6: { float w = wave(u + v * 2 + t); return argb(mix(0xFF8A2A, 0xFF2A2A, w), 0.45f + 0.35f * w); }
            case 7: { float w = wave(u * 2 - v + t); return argb(mix(0x9FE8FF, 0xFFFFFF, w), 0.25f + 0.45f * w); }
            case 8: {
                int seed = (int) Math.floor(t * 8);          // sparkles jump 8 times per loop
                int h = (x * 73856093) ^ (y * 19349663) ^ (seed * 83492791);
                h ^= h >>> 13; h *= 0x5bd1e995; h ^= h >>> 15;
                return (h & 0x3F) == 0 ? argb(0xFFFFFF, 0.95f) : 0;
            }
            case 9: {
                float f = fract(u + t);
                return argb(c1, f < 0.5f ? 0.55f : 0.08f);
            }
            default: {
                float dx = (x + 0.5f) / N * 2 - 1, dy = (y + 0.5f) / N * 2 - 1;
                float r = (float) Math.sqrt(dx * dx + dy * dy) * d;
                float w = wave(r * 2 - t);
                return argb(mix(c1, c2, w), 0.25f + 0.40f * w);
            }
        }
    }

    // ---------- color helpers ----------
    private static float wave(float p) { return 0.5f + 0.5f * (float) Math.sin(2 * Math.PI * p); }
    private static float fract(float p) { return p - (float) Math.floor(p); }
    private static int hue(float h) { return java.awt.Color.HSBtoRGB(fract(h), 0.6f, 1f) & 0xFFFFFF; }
    private static int argb(int rgb, float a) { return (Math.round(Math.max(0f, Math.min(1f, a)) * 255f) << 24) | (rgb & 0xFFFFFF); }
    private static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }
    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
}

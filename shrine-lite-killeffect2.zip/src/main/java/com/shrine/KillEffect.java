package com.shrine;

import com.shrine.Predictions.Cam;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import static com.shrine.Gfx.*;

/**
 * Target > "Kill Effect": an animation that plays where an enemy you hit has just died.
 *
 * Detection: every entity you attack is remembered for a few seconds; when its health reaches zero the effect starts
 * at its position. Modes: soul ascension, abyss grip, star burst, fire vortex, cards, particle flash, black hole.
 *
 * Drawing: a 2D overlay like {@link TargetEsp}. World points are projected to the screen by hand; the "models" (a
 * humanoid made of boxes, hands, cards) are lit, rotated boxes whose faces are sorted by depth and filled as polygons.
 */
final class KillEffect {
    private KillEffect() {}

    static final String KEY = "target.kill", K_MODE = "target.kill.mode", K_COLOR = "target.kill.color",
            K_SIZE = "target.kill.size", K_DETAIL = "target.kill.detail";
    static final String[] MODES = {"Восхождение души", "Хватка бездны", "Звёздный взрыв", "Огненный смерч", "Карты",
            "Вспышка частиц", "Чёрная дыра"};
    static final String[] DETAIL = {"Низкая", "Средняя", "Высокая"};
    private static final float[] DETAIL_MUL = {0.5f, 1f, 1.7f};
    private static final float[] DURATION = {2.8f, 3.2f, 2.4f, 2.8f, 3.2f, 3.0f, 3.6f};
    private static final double TAU = Math.PI * 2.0;
    private static final long REMEMBER_MS = 8000L;
    private static final int MAX_ACTIVE = 6;

    /** One running effect. */
    private static final class Fx {
        final double x, y, z, w, h;
        final float yaw, size, detail;
        final int mode, rgb;
        final long seed, t0;
        final double[][] P;      // body boxes (humanoid or four-legged, by the entity's proportions)
        final int[] PC;

        Fx(double x, double y, double z, double w, double h, float yaw) {
            this.x = x; this.y = y; this.z = z; this.w = w; this.h = Math.max(0.4, h); this.yaw = yaw;
            this.mode = Math.max(0, Math.min(MODES.length - 1, ShrineCfg.integer(K_MODE, 0)));
            int ci = Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, ShrineCfg.integer(K_COLOR, 4)));
            this.rgb = ShrineGui.PALETTE[ci];
            this.size = Math.max(0.5f, Math.min(2.0f, ShrineCfg.num(K_SIZE, 1f)));
            this.detail = DETAIL_MUL[Math.max(0, Math.min(DETAIL_MUL.length - 1, ShrineCfg.integer(K_DETAIL, 1)))];
            boolean human = this.h >= this.w * 2.2;
            this.P = human ? HUMAN : beast(this.w, this.h);
            this.PC = human ? HUMAN_COL : beastCol();
            this.seed = System.nanoTime();
            this.t0 = Util.getMeasuringTimeMs();
        }
    }

    private static final class Tracked {
        final LivingEntity e;
        long hitAt;
        // last state seen while the target was still alive (used when a server just removes a dying player)
        double x, y, z, w = 0.6, h = 1.8;
        float yaw, hp = 20f, maxHp = 20f;
        Tracked(LivingEntity e) { this.e = e; snap(); }
        void snap() {
            x = e.getX(); y = e.getY(); z = e.getZ(); w = e.getWidth(); h = e.getHeight(); yaw = e.getYaw();
            hp = e.getHealth(); maxHp = Math.max(1f, e.getMaxHealth());
        }
    }

    private static final List<Fx> active = new ArrayList<>();
    private static final Map<Integer, Tracked> tracked = new HashMap<>();

    // ---------- registration and kill detection ----------
    static void register() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (player == mc.player && entity instanceof LivingEntity le && le != mc.player) {
                remember(le);
            }
            return ActionResult.PASS;
        });
        ClientTickEvents.END_CLIENT_TICK.register(KillEffect::tick);
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "kill_effect"),
                (ctx, tick) -> render(ctx, tick.getTickProgress(false)));
    }

    private static void remember(LivingEntity le) {
        Tracked t = tracked.computeIfAbsent(le.getId(), id -> new Tracked(le));
        t.hitAt = Util.getMeasuringTimeMs();
    }

    private static void tick(MinecraftClient mc) {
        if (mc.world == null || mc.player == null) { tracked.clear(); active.clear(); return; }
        long now = Util.getMeasuringTimeMs();

        // ranged kills (bow, crossbow, trident, ...): the target you are looking at has just been hurt
        if (mc.targetedEntity instanceof LivingEntity le && le != mc.player && !le.isRemoved() && le.hurtTime > 0) remember(le);

        Iterator<Tracked> it = tracked.values().iterator();
        while (it.hasNext()) {
            Tracked t = it.next();
            LivingEntity e = t.e;
            if (now - t.hitAt > REMEMBER_MS) { it.remove(); continue; }
            boolean killed = e.isDead() || (e.isRemoved() && e.getRemovalReason() == Entity.RemovalReason.KILLED);
            if (killed) {
                it.remove();
                if (ShrineCfg.bool(KEY, true)) spawn(e.getX(), e.getY(), e.getZ(), e.getWidth(), e.getHeight(), e.getYaw());
            } else if (e.isRemoved()) {
                it.remove();
                // servers often just delete a dying player: low health + a fresh hit means it was a kill
                boolean fresh = now - t.hitAt < 1500L;
                boolean low = t.hp <= Math.max(4f, t.maxHp * 0.3f);
                if (fresh && low && ShrineCfg.bool(KEY, true)) spawn(t.x, t.y, t.z, t.w, t.h, t.yaw);
            } else {
                t.snap();
            }
        }
    }

    private static void spawn(double x, double y, double z, double w, double h, float yaw) {
        active.add(new Fx(x, y, z, w, h, yaw));
        while (active.size() > MAX_ACTIVE) active.remove(0);
    }

    /** Settings > "Проверить эффект": plays the effect a few blocks in front of the player. */
    static void test() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        double yr = Math.toRadians(mc.player.getYaw());
        spawn(mc.player.getX() - Math.sin(yr) * 3.5, mc.player.getY(), mc.player.getZ() + Math.cos(yr) * 3.5,
                0.6, 1.8, mc.player.getYaw() + 180f);
    }

    // ---------- frame ----------
    private static void render(DrawContext ctx, float td) {
        if (active.isEmpty()) return;
        long now = Util.getMeasuringTimeMs();
        active.removeIf(f -> (now - f.t0) / 1000f > DURATION[f.mode]);
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.options.hudHidden) return;
        if (!mc.options.getPerspective().isFirstPerson()) return;
        Cam cam = new Cam(mc, ctx, td);
        for (Fx f : active) new Painter(ctx, cam, f, (now - f.t0) / 1000f).run();
    }

    // ---------- small helpers ----------
    private static float sat(float x) { return Math.max(0f, Math.min(1f, x)); }
    private static float smooth(float x) { x = sat(x); return x * x * (3f - 2f * x); }

    private static int mix(int c1, int c2, float k) {
        k = sat(k);
        int r = Math.round(((c1 >> 16) & 255) * (1 - k) + ((c2 >> 16) & 255) * k);
        int g = Math.round(((c1 >> 8) & 255) * (1 - k) + ((c2 >> 8) & 255) * k);
        int b = Math.round((c1 & 255) * (1 - k) + (c2 & 255) * k);
        return (r << 16) | (g << 8) | b;
    }

    private static int scaleRgb(int c, float k) {
        int r = Math.min(255, Math.round(((c >> 16) & 255) * k));
        int g = Math.min(255, Math.round(((c >> 8) & 255) * k));
        int b = Math.min(255, Math.round((c & 255) * k));
        return (r << 16) | (g << 8) | b;
    }

    /** Deterministic random number in [0, 1) for particle i, channel k of one effect. */
    private static float rnd(long seed, int i, int k) {
        long h = seed + i * 0x9E3779B97F4A7C15L + k * 0xC2B2AE3D27D4EB4FL;
        h ^= h >>> 33; h *= 0xFF51AFD7ED558CCDL; h ^= h >>> 33; h *= 0xC4CEB9FE1A85EC53L; h ^= h >>> 33;
        return (h >>> 40) / (float) (1L << 24);
    }

    /** Local -> world rotation: roll around Z, then pitch around X, then yaw around Y. */
    private static double[] rot(double x, double y, double z, double yaw, double pitch, double roll) {
        double cr = Math.cos(roll), sr = Math.sin(roll);
        double x1 = x * cr - y * sr, y1 = x * sr + y * cr;
        double cp = Math.cos(pitch), sp = Math.sin(pitch);
        double y2 = y1 * cp - z * sp, z2 = y1 * sp + z * cp;
        double cy = Math.cos(yaw), sy = Math.sin(yaw);
        return new double[]{x1 * cy + z2 * sy, y2, -x1 * sy + z2 * cy};
    }

    /** Fills a convex screen polygon row by row. */
    private static void fill(DrawContext ctx, float[] xs, float[] ys, int col) {
        float minY = Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
        for (float v : ys) { minY = Math.min(minY, v); maxY = Math.max(maxY, v); }
        int n = xs.length;
        for (int py = Math.round(minY); py <= Math.round(maxY); py++) {
            float sy = py + 0.5f, lo = Float.MAX_VALUE, hi = -Float.MAX_VALUE;
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                float ay = ys[i], by = ys[j];
                if ((ay <= sy && by > sy) || (by <= sy && ay > sy)) {
                    float xi = xs[i] + (sy - ay) * (xs[j] - xs[i]) / (by - ay);
                    lo = Math.min(lo, xi);
                    hi = Math.max(hi, xi);
                }
            }
            if (lo <= hi) ctx.fill(Math.round(lo), py, Math.round(hi) + 1, py + 1, col);
        }
    }

    // ---------- the "models": boxes in units of the entity height, relative to the feet ----------
    // {centre x, y, z, half x, y, z}; the proportions of the vanilla player model (32 px tall)
    private static final double[][] HUMAN = {
            {0.00, 0.875, 0, 0.125, 0.125, 0.125},        // head
            {0.00, 0.5625, 0, 0.125, 0.1875, 0.0625},     // torso
            {-0.1875, 0.5625, 0, 0.0625, 0.1875, 0.0625}, // left arm
            {0.1875, 0.5625, 0, 0.0625, 0.1875, 0.0625},  // right arm
            {-0.0625, 0.1875, 0, 0.0625, 0.1875, 0.0625}, // left leg
            {0.0625, 0.1875, 0, 0.0625, 0.1875, 0.0625}   // right leg
    };
    // the dying body is tinted red like the vanilla hurt flash
    private static final int[] HUMAN_COL = {0xD83A3A, 0xC41818, 0xCC2222, 0xCC2222, 0xA81010, 0xA81010};

    /** Four-legged body for wide mobs (pig, cow, wolf, spider, ...): body, head, four legs. */
    private static double[][] beast(double w, double h) {
        double wr = w / h, lg = Math.max(0.05, 0.07 * wr), hd = Math.max(0.1, 0.17 * wr);
        return new double[][]{
                {0, 0.58, 0, 0.32 * wr, 0.21, 0.50 * wr},
                {0, 0.80, 0.50 * wr + 0.02, hd, 0.15, hd},
                {-0.22 * wr, 0.19, 0.32 * wr, lg, 0.19, lg},
                {0.22 * wr, 0.19, 0.32 * wr, lg, 0.19, lg},
                {-0.22 * wr, 0.19, -0.32 * wr, lg, 0.19, lg},
                {0.22 * wr, 0.19, -0.32 * wr, lg, 0.19, lg}
        };
    }
    private static int[] beastCol() { return new int[]{0xC41818, 0xD83A3A, 0xA81010, 0xA81010, 0xA81010, 0xA81010}; }
    private static final int HURT = 0xE03030, SKIN = 0xC8956B;

    private static final int[][] FACE = {{1, 3, 7, 5}, {0, 4, 6, 2}, {2, 6, 7, 3}, {0, 1, 5, 4}, {4, 5, 7, 6}, {0, 2, 3, 1}};
    private static final double[][] NORM = {{1, 0, 0}, {-1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}, {0, 0, -1}};
    private static final double LX = -0.356, LY = 0.814, LZ = 0.458;     // light direction

    private static final class Face {
        final float[] xs = new float[4], ys = new float[4];
        int col, edge;
        float depth;
    }

    // ---------- the painter: draws one effect at time t ----------
    private static final class Painter {
        final DrawContext ctx;
        final Cam cam;
        final Fx f;
        final float t;
        final double gy;
        final int rgb, pale;
        final float[] o = new float[3];
        final List<Face> faces = new ArrayList<>();
        final double[][] P;
        final int[] PC;
        boolean flat;            // faces drawn without shading
        float edgeA = 0.30f;     // outline strength of body parts

        Painter(DrawContext ctx, Cam cam, Fx f, float t) {
            this.ctx = ctx; this.cam = cam; this.f = f; this.t = t; this.P = f.P; this.PC = f.PC;
            this.gy = f.y + 0.03;
            this.rgb = f.rgb;
            this.pale = mix(f.rgb, 0xFFFFFF, 0.6f);
        }

        void run() {
            switch (f.mode) {
                case 0 -> soul();
                case 1 -> abyss();
                case 2 -> stars();
                case 3 -> vortex();
                case 4 -> cards();
                case 5 -> flash();
                default -> hole();
            }
            flush();
        }

        boolean pt(double x, double y, double z) { return cam.p(x, y, z, o); }

        // ----- primitives -----
        /** Circle or arc lying on the ground plane (drawn as projected segments). */
        void ringXZ(double cx, double gyy, double cz, double r, double a0, double a1, float thBlocks, int col, float al, double step) {
            if (al < 0.01f) return;
            int n = Math.max(3, (int) Math.ceil(Math.abs(a1 - a0) / step));
            float px = 0f, py = 0f;
            boolean has = false;
            for (int i = 0; i <= n; i++) {
                double an = a0 + (a1 - a0) * i / n;
                if (!pt(cx + Math.cos(an) * r, gyy, cz + Math.sin(an) * r)) { has = false; continue; }
                if (has) Predictions.line(ctx, px, py, o[0], o[1], Math.max(0.8f, thBlocks * o[2]), argb(al, col));
                px = o[0]; py = o[1]; has = true;
            }
        }

        /** Soft glowing dot. */
        void dot(double x, double y, double z, double size, int col, float a) {
            if (a < 0.02f || !pt(x, y, z)) return;
            float s = Math.max(2f, (float) size * o[2]);
            centered(ctx, GLOW, o[0], o[1], s * 4f, s * 4f, argb(0.45f * a, col));
            centered(ctx, DISC, o[0], o[1], s, s, argb(a, mix(col, 0xFFFFFF, 0.65f)));
        }

        /** Four-point sparkle. */
        void sparkle(double x, double y, double z, double size, int col, float a, double rotation) {
            if (a < 0.02f || !pt(x, y, z)) return;
            float s = Math.max(3f, (float) size * o[2]), sx = o[0], sy = o[1];
            centered(ctx, GLOW, sx, sy, s * 3.5f, s * 3.5f, argb(0.35f * a, col));
            for (int k = 0; k < 2; k++) {
                double an = rotation + k * Math.PI / 2.0;
                float dx = (float) Math.cos(an) * s * 1.7f, dy = (float) Math.sin(an) * s * 1.7f;
                Predictions.line(ctx, sx - dx, sy - dy, sx + dx, sy + dy, 1.1f, argb(a, mix(col, 0xFFFFFF, 0.7f)));
            }
            centered(ctx, DISC, sx, sy, s * 0.7f, s * 0.7f, argb(a, 0xFFFFFF));
        }

        /** Hollow ring particle facing the camera. */
        void ringDot(double x, double y, double z, double size, int col, float a) {
            if (a < 0.02f || !pt(x, y, z)) return;
            float s = Math.max(4f, (float) size * o[2]);
            centered(ctx, GLOW, o[0], o[1], s * 2.4f, s * 2.4f, argb(0.30f * a, col));
            centered(ctx, RING, o[0], o[1], s, s, argb(a, mix(col, 0xFFFFFF, 0.5f)));
        }

        /** A lit, rotated box; its visible faces are queued and drawn far to near by {@link #flush()}. */
        void box(double cx, double cy, double cz, double hx, double hy, double hz,
                 double yaw, double pitch, double roll, int base, float alpha, float edgeAlpha) {
            if (alpha < 0.02f) return;
            double[][] cr = new double[8][];
            for (int i = 0; i < 8; i++) {
                cr[i] = rot((i & 1) == 0 ? -hx : hx, (i & 2) == 0 ? -hy : hy, (i & 4) == 0 ? -hz : hz, yaw, pitch, roll);
            }
            for (int fi = 0; fi < 6; fi++) {
                int[] ix = FACE[fi];
                double[] n = rot(NORM[fi][0], NORM[fi][1], NORM[fi][2], yaw, pitch, roll);
                double mx = 0, my = 0, mz = 0;
                for (int k = 0; k < 4; k++) { mx += cr[ix[k]][0]; my += cr[ix[k]][1]; mz += cr[ix[k]][2]; }
                mx = cx + mx / 4.0; my = cy + my / 4.0; mz = cz + mz / 4.0;
                double vx = cam.pos.x - mx, vy = cam.pos.y - my, vz = cam.pos.z - mz;
                if (n[0] * vx + n[1] * vy + n[2] * vz <= 0) continue;               // facing away
                Face fc = new Face();
                boolean ok = true;
                for (int k = 0; k < 4; k++) {
                    if (!pt(cx + cr[ix[k]][0], cy + cr[ix[k]][1], cz + cr[ix[k]][2])) { ok = false; break; }
                    fc.xs[k] = o[0]; fc.ys[k] = o[1];
                }
                if (!ok) continue;
                float shade = flat ? 1f : (float) (0.55 + 0.45 * Math.max(0.0, n[0] * LX + n[1] * LY + n[2] * LZ));
                fc.col = argb(alpha, scaleRgb(base, shade));
                fc.edge = edgeAlpha > 0.01f ? argb(edgeAlpha * alpha, 0xFFFFFF) : 0;
                fc.depth = (float) ((mx - cam.pos.x) * cam.fx + (my - cam.pos.y) * cam.fy + (mz - cam.pos.z) * cam.fz);
                faces.add(fc);
            }
        }

        void flush() {
            faces.sort((a, b) -> Float.compare(b.depth, a.depth));
            for (Face fc : faces) {
                fill(ctx, fc.xs, fc.ys, fc.col);
                if (fc.edge != 0) {
                    for (int k = 0; k < 4; k++) {
                        int j = (k + 1) % 4;
                        Predictions.line(ctx, fc.xs[k], fc.ys[k], fc.xs[j], fc.ys[j], 0.8f, fc.edge);
                    }
                }
            }
            faces.clear();
        }

        /** One body part of the humanoid; (dx, dy, dz) moves it, the angles turn it around its own centre. */
        void part(int k, double dx, double dy, double dz, double eyaw, double pitch, double roll, float alpha, float hurt) {
            partC(k, dx, dy, dz, eyaw, pitch, roll, alpha, mix(PC[k], HURT, hurt));
        }

        void partC(int k, double dx, double dy, double dz, double eyaw, double pitch, double roll, float alpha, int col) {
            double[] pr = P[k];
            double H = f.h, yr = Math.toRadians(-f.yaw);
            double lx = pr[0] * H, lz = pr[2] * H;
            double wx = lx * Math.cos(yr) + lz * Math.sin(yr), wz = -lx * Math.sin(yr) + lz * Math.cos(yr);
            box(f.x + wx + dx, f.y + pr[1] * H + dy, f.z + wz + dz, pr[3] * H, pr[4] * H, pr[5] * H,
                    yr + eyaw, pitch, roll, col, alpha, edgeA);
        }

        // ----- mode 0: soul ascension -----
        void soul() {
            double H = f.h;
            float hurt = 0.6f * (1f - sat((t - 0.2f) / 1.4f));
            double rise = (0.1 + 2.6 * f.size) * smooth(t / 2.5f);
            for (int k = 0; k < P.length; k++) {
                // the body dissolves from the feet upwards
                float al = 0.92f * (1f - smooth((t - 0.35f - (float) P[k][1] * 0.6f) / 1.7f));
                part(k, 0, rise, 0, t * 1.3, 0, 0, al, hurt);
            }
            flush();

            int n = Math.round(11 * f.detail);
            for (int i = 0; i < n; i++) {                                    // soul rings drifting up
                float age = t - i * 0.09f;
                float life = 1.6f + 0.9f * rnd(f.seed, i, 0);
                if (age < 0f || age > life) continue;
                float q = age / life;
                double an = rnd(f.seed, i, 1) * TAU + age * (2.2 + rnd(f.seed, i, 4));
                double r = (f.w * 0.5 + 0.2 + 0.35 * rnd(f.seed, i, 2)) * f.size;
                double y = f.y + H * (0.15 + 0.8 * rnd(f.seed, i, 3)) + 1.2 * f.size * q;
                float al = (float) Math.pow(Math.sin(Math.PI * q), 0.7) * 0.9f;
                ringDot(f.x + Math.cos(an) * r, y, f.z + Math.sin(an) * r, (0.16 + 0.12 * rnd(f.seed, i, 5)) * f.size, rgb, al);
            }
            int m = Math.round(9 * f.detail);
            for (int i = 0; i < m; i++) {                                    // purple crosses
                float age = t - 0.15f - i * 0.11f;
                float life = 1.5f + 0.8f * rnd(f.seed, i, 6);
                if (age < 0f || age > life) continue;
                float q = age / life;
                double an = rnd(f.seed, i, 7) * TAU + age * 1.4;
                double r = (0.4 + 0.7 * rnd(f.seed, i, 8)) * f.size;
                sparkle(f.x + Math.cos(an) * r, f.y + H * (0.3 + 0.6 * rnd(f.seed, i, 9)) + 1.5 * f.size * q,
                        f.z + Math.sin(an) * r, 0.07 * f.size, 0xB890FF, (float) Math.sin(Math.PI * q) * 0.95f, age * 3.0);
            }
        }

        // ----- mode 1: abyss grip -----
        void portal(double rad, float k) {
            if (rad < 0.05) return;
            if (pt(f.x, gy, f.z)) {
                float w = (float) rad * 2.8f * o[2];
                centered(ctx, GLOW, o[0], o[1], w, w * 0.5f, argb(0.35f * k, rgb));
            }
        }

        void tentacle(int idx, int n, double R, float reach) {
            if (reach < 0.02f) return;
            double H = f.h, a0 = idx * TAU / n + 0.5;
            float[] prev = null;
            double hx = 0, hy = 0, hz = 0, hAng = 0;
            boolean tip = false;
            final int seg = 16;
            for (int s = 0; s <= seg; s++) {
                double u = s / (double) seg;
                double rr = R * 0.9 * (1.0 - 0.8 * u);
                double an = a0 + u * 1.7 + t * 0.9;
                double yy = gy + reach * H * 1.05 * Math.pow(u, 0.85) * (1.0 - 0.2 * u) + 0.07 * Math.sin(t * 6 + u * 8 + idx);
                double px = f.x + Math.cos(an) * rr, pz = f.z + Math.sin(an) * rr;
                if (!pt(px, yy, pz)) { prev = null; continue; }
                float[] cur = {o[0], o[1]};
                if (prev != null) {
                    float th = Math.max(1.5f, (float) (0.16 * (1.0 - 0.6 * u)) * o[2]);
                    Predictions.line(ctx, prev[0], prev[1], cur[0], cur[1], th * 2.4f, argb(0.22f * reach, rgb));
                    Predictions.line(ctx, prev[0], prev[1], cur[0], cur[1], th, argb(0.95f * Math.min(1f, reach * 1.5f), mix(rgb, 0xFFFFFF, 0.45f)));
                }
                prev = cur;
                if (s == seg) { hx = px; hy = yy; hz = pz; hAng = an; tip = true; }
            }
            if (tip) {                                                       // a hand at the end of the arm
                float al = Math.min(1f, reach * 1.6f);
                box(hx, hy, hz, 0.09, 0.12, 0.07, -hAng, 0.4, 0.2, mix(SKIN, HURT, 0.55f), al, 0.3f);
            }
        }

        void abyss() {
            double H = f.h, R = Math.max(0.9, f.w * 0.5 + 0.6) * f.size;
            float open = smooth(t / 0.45f), close = 1f - smooth((t - 2.55f) / 0.6f), k = open * close;
            portal(R * k, k);

            float pull = smooth((t - 1.25f) / 1.0f);                         // the model is dragged down and torn apart
            for (int i = 0; i < P.length; i++) {
                float al = 0.95f * (1f - sat((pull - 0.5f) / 0.5f));
                double sp = rnd(f.seed, i, 5) * 2.0 - 1.0;
                part(i, sp * pull * 0.45, -pull * (P[i][1] * H + 0.35), (rnd(f.seed, i, 6) - 0.5) * pull * 0.5,
                        sp * pull * 0.8, sp * pull * 0.6, sp * pull * 1.2, al, 0.6f);
            }
            flush();

            float reach = smooth((t - 0.45f) / 0.7f) * (1f - 0.92f * pull) * close;
            int n = Math.max(3, Math.round(5 * f.detail));
            for (int a = 0; a < n; a++) tentacle(a, n, R, reach);
            flush();                                                         // the hands
        }

        // ----- mode 2: star burst -----
        void stars() {
            double cx = f.x, cy = f.y + f.h * 0.55, cz = f.z;
            float fl = 1f - sat(t / 0.4f);
            if (fl > 0.02f && pt(cx, cy, cz)) {
                float sz = (float) (f.size * (1.0 + 2.6 * (1f - fl))) * o[2];
                centered(ctx, GLOW, o[0], o[1], sz * 2.2f, sz * 2.2f, argb(0.8f * fl, rgb));
                centered(ctx, DISC, o[0], o[1], sz * 0.5f * fl + 4f, sz * 0.5f * fl + 4f, argb(fl, 0xFFFFFF));
            }
            int n = Math.round(46 * f.detail);
            final double kd = 1.5;
            for (int i = 0; i < n; i++) {
                float age = t - 0.03f * (i % 5);
                float life = 1.4f + 0.9f * rnd(f.seed, i, 0);
                if (age < 0f || age > life) continue;
                float q = age / life;
                double th = rnd(f.seed, i, 1) * TAU, cph = rnd(f.seed, i, 2) * 2.0 - 1.0, sph = Math.sqrt(1.0 - cph * cph);
                double dx = Math.cos(th) * sph, dy = cph, dz = Math.sin(th) * sph;
                double v = (2.4 + 3.0 * rnd(f.seed, i, 3)) * f.size;
                double d0 = v * (1.0 - Math.exp(-kd * age)) / kd, d1 = v * (1.0 - Math.exp(-kd * Math.max(0f, age - 0.06f))) / kd;
                double x1 = cx + dx * d1, y1 = cy + dy * d1 + 0.3 * Math.max(0f, age - 0.06f), z1 = cz + dz * d1;
                double x0 = cx + dx * d0, y0 = cy + dy * d0 + 0.3 * age, z0 = cz + dz * d0;
                float al = (float) Math.pow(1f - q, 0.6) * (0.7f + 0.3f * (float) Math.sin(t * 18 + i * 1.7));
                double sz = (0.045 + 0.06 * rnd(f.seed, i, 4)) * f.size * (1.0 - 0.4 * q);
                int col = mix(rgb, 0xFFFFFF, 0.25f * rnd(f.seed, i, 6));
                if (pt(x1, y1, z1)) {
                    float px = o[0], py = o[1];
                    if (pt(x0, y0, z0)) Predictions.line(ctx, px, py, o[0], o[1], 1.2f, argb(0.35f * al, col));
                }
                if (rnd(f.seed, i, 5) > 0.6f) sparkle(x0, y0, z0, sz * 1.3, col, al, age * 4.0 + i);
                else dot(x0, y0, z0, sz, col, al);
            }
        }

        // ----- mode 3: fire vortex -----
        void vortex() {
            int n = Math.round(80 * f.detail);
            int hot = mix(0xFF9A3C, rgb, 0.2f), ember = mix(0xC8401C, rgb, 0.2f);
            float base = 1f - sat((t - 0.3f) / 1.5f);
            if (base > 0.02f && pt(f.x, gy, f.z)) {
                float w = 2.2f * f.size * o[2];
                centered(ctx, GLOW, o[0], o[1], w, w * 0.5f, argb(0.40f * base, hot));
            }
            for (int i = 0; i < n; i++) {
                float age = t - rnd(f.seed, i, 0) * 1.0f;
                float life = 1.1f + 0.8f * rnd(f.seed, i, 1);
                if (age < 0f || age > life) continue;
                float q = age / life;
                double a0 = rnd(f.seed, i, 2) * TAU;
                double hgt = Math.pow(q, 1.15) * 3.2 * f.size * (0.7 + 0.6 * rnd(f.seed, i, 3));
                double rad = (0.9 - 0.65 * q) * f.size * (0.6 + 0.7 * rnd(f.seed, i, 4));
                double an = a0 + age * (7.0 + 5.0 * q), an1 = a0 + (age - 0.04f) * (7.0 + 5.0 * q);
                double x = f.x + Math.cos(an) * rad, y = f.y + 0.1 + hgt, z = f.z + Math.sin(an) * rad;
                double x1 = f.x + Math.cos(an1) * rad, z1 = f.z + Math.sin(an1) * rad;
                int col = q < 0.35f ? mix(0xFFFFFF, hot, q / 0.35f) : mix(hot, ember, (q - 0.35f) / 0.65f);
                float al = 1f - q * q;
                if (pt(x, y, z)) {
                    float px = o[0], py = o[1];
                    if (pt(x1, y - 0.03, z1)) Predictions.line(ctx, px, py, o[0], o[1], 1.2f, argb(0.45f * al, col));
                }
                dot(x, y, z, 0.07 * f.size * (1.0 - 0.5 * q), col, al);
            }
        }

        // ----- mode 4: cards -----
        void cards() {
            double H = f.h;
            final float slice = 0.95f;
            float fade = 1f - sat((t - 2.3f) / 0.9f);
            if (t < slice) {
                for (int k = 0; k < P.length; k++) part(k, 0, 0, 0, 0, 0, 0, 0.95f, 0.6f);
            } else {
                float s = t - slice;
                for (int k = 0; k < P.length; k++) {                     // the cut pieces fly apart and fall
                    double[] pr = P[k];
                    double vx = (rnd(f.seed, k, 10) - 0.5) * 3.0, vz = (rnd(f.seed, k, 11) - 0.5) * 3.0;
                    double vy = 1.4 + 2.0 * rnd(f.seed, k, 12) + (k == 0 ? 1.0 : 0.0);
                    double ds = Math.min(s, 1.6f);
                    double rest = (gy + Math.min(pr[3], Math.min(pr[4], pr[5])) * H) - (f.y + pr[1] * H);
                    double dy = Math.max(vy * ds - 5.0 * ds * ds, rest);
                    double dh = Math.min(s, 0.8f) * 0.8;
                    double spin = Math.min(s, 0.9f) * (rnd(f.seed, k, 13) - 0.5) * 9.0;
                    part(k, vx * dh, dy, vz * dh, 0, spin, spin * 0.6, 0.95f * fade, 0.6f);
                }
            }
            flush();

            int n = Math.round(8 * f.detail);
            float ca = t < slice ? 1f : 1f - sat((t - slice - 0.2f) / 0.6f);
            if (ca > 0.02f) {
                for (int i = 0; i < n; i++) {                                // cards circle in, cut through, scatter
                    double rad = (t < slice ? 1.9 - 1.5 * smooth(t / slice) : 0.4 + 2.2 * smooth((t - slice) / 0.7f)) * f.size;
                    double an = i * TAU / n + t * 5.5;
                    double cy = f.y + H * (0.2 + 0.65 * rnd(f.seed, i, 20)) + 0.15 * Math.sin(t * 4 + i);
                    double cx = f.x + Math.cos(an) * rad, cz = f.z + Math.sin(an) * rad;
                    double yaw = -an + Math.PI / 2.0, pitch = t * 4.0 + i, roll = 0.4 * Math.sin(t * 3.0 + i);
                    double c = 0.9 + 0.3 * f.size;
                    box(cx, cy, cz, 0.12 * c, 0.17 * c, 0.012 * c, yaw, pitch, roll, 0xF4F4F4, ca, 0.5f);
                    box(cx, cy, cz, 0.04 * c, 0.055 * c, 0.016 * c, yaw, pitch, roll, (i % 2 == 0) ? 0xD83A3A : 0x222222, ca, 0f);
                }
                flush();
            }
            float fs = sat(1f - Math.abs(t - 0.98f) / 0.14f);                // white slashes at the moment of the cut
            if (fs > 0.02f && pt(f.x, f.y + H * 0.55, f.z)) {
                float cx = o[0], cy = o[1], len = (float) H * o[2] * 0.6f;
                centered(ctx, GLOW, cx, cy, len * 1.6f, len * 1.6f, argb(0.5f * fs, rgb));
                for (int k = 0; k < 3; k++) {
                    double ang = rnd(f.seed, k, 30) * Math.PI;
                    float dx = (float) Math.cos(ang) * len, dy = (float) Math.sin(ang) * len;
                    Predictions.line(ctx, cx - dx, cy - dy, cx + dx, cy + dy, 5f, argb(0.25f * fs, rgb));
                    Predictions.line(ctx, cx - dx, cy - dy, cx + dx, cy + dy, 1.8f, argb(0.95f * fs, 0xFFFFFF));
                }
            }
        }

        // ----- shared helpers for the two newest modes -----
        /** World position of a point inside body box k (u, v, w in 0..1), turned with the entity. */
        double[] bodyPoint(int k, double u, double v, double w) {
            double[] pr = P[k];
            double H = f.h, yr = Math.toRadians(-f.yaw);
            double lx = (pr[0] + (2 * u - 1) * pr[3]) * H, ly = (pr[1] + (2 * v - 1) * pr[4]) * H, lz = (pr[2] + (2 * w - 1) * pr[5]) * H;
            return new double[]{f.x + lx * Math.cos(yr) + lz * Math.sin(yr), f.y + ly, f.z - lx * Math.sin(yr) + lz * Math.cos(yr)};
        }

        /** Thin pointed glass shard (a filled triangle turned on the screen). */
        void shard(double x, double y, double z, double len, double wid, double rot, int col, float a) {
            if (a < 0.02f || !pt(x, y, z)) return;
            float L = Math.max(3f, (float) len * o[2]), W = Math.max(1.5f, (float) wid * o[2]), cx = o[0], cy = o[1];
            float c = (float) Math.cos(rot), sn = (float) Math.sin(rot);
            float[] xs = {cx + c * L, cx - c * L * 0.45f + sn * W, cx - c * L * 0.45f - sn * W};
            float[] ys = {cy + sn * L, cy - sn * L * 0.45f - c * W, cy - sn * L * 0.45f + c * W};
            fill(ctx, xs, ys, argb(a, col));
        }

        private final class Vox { float sx, sy, size, depth, a; int col; }

        /**
         * The body as a frosted ghost made of small square "pixels". dissolve (0..1) removes pixels at random,
         * pull (0..1) sucks them in a spiral into the middle of the ground under the body.
         */
        void voxelBody(int base, float alpha, float dissolve, float pull, double spin) {
            double H = f.h, vs = Math.max(0.07, H * 0.055);
            List<Vox> list = new ArrayList<>();
            int id = 0;
            for (int k = 0; k < P.length; k++) {
                double[] pr = P[k];
                int nx = Math.max(1, (int) Math.round(2 * pr[3] * H / vs)), ny = Math.max(1, (int) Math.round(2 * pr[4] * H / vs)),
                        nz = Math.max(1, (int) Math.round(2 * pr[5] * H / vs));
                for (int ix = 0; ix < nx; ix++) for (int iy = 0; iy < ny; iy++) for (int iz = 0; iz < nz; iz++) {
                    id++;
                    if (ix > 0 && ix < nx - 1 && iy > 0 && iy < ny - 1 && iz > 0 && iz < nz - 1) continue;   // inside: never seen
                    if (rnd(f.seed, id, 40) < dissolve) continue;
                    double[] w = bodyPoint(k, (ix + 0.5) / nx, (iy + 0.5) / ny, (iz + 0.5) / nz);
                    double px = w[0], py = w[1], pz = w[2];
                    float q = 0f;
                    if (pull > 0f) {
                        q = sat(pull * 1.35f - rnd(f.seed, id, 41) * 0.35f);
                        double e = q * q, ang = spin * q + 4.0 * q * q;
                        double dx = px - f.x, dz = pz - f.z, ca = Math.cos(ang), sa = Math.sin(ang);
                        double sc = 1.0 - e;
                        px = f.x + (dx * ca - dz * sa) * sc;
                        pz = f.z + (dx * sa + dz * ca) * sc;
                        py = py + (gy + 0.05 - py) * e;
                    }
                    float a = alpha * (1f - sat((q - 0.7f) / 0.3f));
                    if (a < 0.02f || !pt(px, py, pz)) continue;
                    Vox v = new Vox();
                    v.sx = o[0]; v.sy = o[1];
                    v.size = Math.max(2f, (float) (vs * (1.0 - 0.6 * q)) * o[2] * 1.25f);
                    v.col = scaleRgb(base, 0.8f + 0.35f * rnd(f.seed, id, 42));
                    v.a = a;
                    v.depth = (float) ((px - cam.pos.x) * cam.fx + (py - cam.pos.y) * cam.fy + (pz - cam.pos.z) * cam.fz);
                    list.add(v);
                }
            }
            list.sort((a, b) -> Float.compare(b.depth, a.depth));
            for (Vox v : list) {
                int x0 = Math.round(v.sx - v.size / 2f), y0 = Math.round(v.sy - v.size / 2f), sz = Math.max(2, Math.round(v.size));
                ctx.fill(x0, y0, x0 + sz, y0 + sz, argb(v.a, v.col));
            }
        }

        // ----- mode 5: particle flash -----
        void flash() {
            double H = f.h;
            if (t < 0.58f) {                                                 // red body, white flash, gone
                boolean white = t >= 0.38f;
                flat = true;
                edgeA = white ? 0f : 0.18f;
                float al = white ? 1f - sat((t - 0.50f) / 0.08f) : 1f;
                double j = white ? 0.0 : 0.012 * Math.sin(t * 80.0);
                for (int k = 0; k < P.length; k++) partC(k, j, 0, 0, 0, 0, 0, al, white ? 0xFFFFFF : mix(PC[k], 0xE01010, 0.7f));
                flush();
                flat = false;
                edgeA = 0.30f;
                if (white && pt(f.x, f.y + H * 0.55, f.z)) {
                    float g = (float) H * o[2] * 2.4f;
                    centered(ctx, GLOW, o[0], o[1], g, g, argb(0.6f * al, 0xFFFFFF));
                }
            }
            float ts = t - 0.5f;
            if (ts <= 0f) return;
            float dq = sat((t - 0.5f) / 1.5f);                              // what is left dissolves pixel by pixel
            if (dq < 1f) voxelBody(mix(pale, 0xC8C0FF, 0.35f), 0.9f * (1f - 0.3f * dq), dq, 0f, 0.0);

            int n = Math.round(90 * f.detail);                              // glass shards fly out and land
            for (int i = 0; i < n; i++) {
                float age = ts - 0.04f * rnd(f.seed, i, 50);
                float life = 1.3f + 1.0f * rnd(f.seed, i, 51);
                if (age < 0f || age > life) continue;
                int pk = Math.min(P.length - 1, (int) (rnd(f.seed, i, 52) * P.length));
                double[] w0 = bodyPoint(pk, rnd(f.seed, i, 53), rnd(f.seed, i, 54), rnd(f.seed, i, 55));
                double dx = w0[0] - f.x, dz = w0[2] - f.z, dl = Math.max(0.05, Math.hypot(dx, dz));
                double th = rnd(f.seed, i, 56) * TAU, sp = (1.2 + 3.6 * rnd(f.seed, i, 57)) * f.size;
                double vx = (dx / dl * 0.6 + Math.cos(th) * 0.8) * sp, vz = (dz / dl * 0.6 + Math.sin(th) * 0.8) * sp;
                double vy = (0.8 + 3.2 * rnd(f.seed, i, 58)) * (0.7 + 0.3 * f.size);
                double ya = Math.max(0.0, w0[1] - (gy + 0.02));
                double tl = (vy + Math.sqrt(vy * vy + 14.0 * ya)) / 7.0;     // time of landing (gravity 7)
                double ah = Math.min(age, tl) + Math.max(0.0, age - tl) * 0.06;
                double x = w0[0] + vx * ah, z = w0[2] + vz * ah;
                double y = age < tl ? w0[1] + vy * age - 3.5 * age * age : gy + 0.02;
                float al = (float) Math.pow(1f - age / life, 0.8);
                double len = (0.10 + 0.20 * rnd(f.seed, i, 59)) * f.size;
                double rot = rnd(f.seed, i, 60) * TAU + age * (3.0 + 7.0 * rnd(f.seed, i, 61)) * (age < tl ? 1.0 : 0.1);
                int col = mix(0xFFFFFF, rgb, 0.15f + 0.55f * rnd(f.seed, i, 62));
                shard(x, y, z, len, len * 0.32, rot, col, al * 0.92f);
            }
        }

        // ----- mode 6: black hole -----
        /** Dark disc on the ground with a violet glow around it (filled, no outline rings). */
        void disc(double rad, float k) {
            if (rad < 0.05 || k < 0.02f) return;
            if (pt(f.x, gy, f.z)) {
                float w = (float) rad * 4.4f * o[2];
                centered(ctx, GLOW, o[0], o[1], w, w * 0.55f, argb(0.55f * k, 0x7A56FF));
            }
            double[] rs = {1.0, 0.82, 0.55};
            int[] cs = {0x2A1458, 0x130A30, 0x040208};
            float[] as = {0.65f, 0.85f, 0.97f};
            final int n = 36;
            for (int l = 0; l < 3; l++) {
                float[] xs = new float[n], ys = new float[n];
                boolean ok = true;
                for (int i = 0; i < n && ok; i++) {
                    double an = i * TAU / n;
                    if (!pt(f.x + Math.cos(an) * rad * rs[l], gy, f.z + Math.sin(an) * rad * rs[l])) ok = false;
                    else { xs[i] = o[0]; ys[i] = o[1]; }
                }
                if (ok) fill(ctx, xs, ys, argb(as[l] * k, cs[l]));
            }
        }

        /** A thick black band that rises from the edge of the disc and bends over the body like a cage. */
        void holeArm(int idx, int n, double R, float reach) {
            if (reach < 0.02f) return;
            double H = f.h, a0 = idx * TAU / n + 0.4;
            float[] prev = null;
            final int seg = 18;
            for (int s = 0; s <= seg; s++) {
                double u = s / (double) seg;
                double an = a0 + u * 0.8 + t * 0.35;
                double rr = R * (1.0 - 0.88 * Math.pow(u, 1.5));
                double yy = gy + reach * H * 1.3 * Math.sin(u * Math.PI * 0.52);
                if (!pt(f.x + Math.cos(an) * rr, yy, f.z + Math.sin(an) * rr)) { prev = null; continue; }
                float[] cur = {o[0], o[1]};
                if (prev != null) {
                    float th = Math.max(1.8f, (float) (0.13 * (1.0 - 0.45 * u)) * o[2]), a = Math.min(1f, reach * 1.6f);
                    Predictions.line(ctx, prev[0], prev[1], cur[0], cur[1], th * 1.9f, argb(0.30f * a, 0x8A66FF));
                    Predictions.line(ctx, prev[0], prev[1], cur[0], cur[1], th, argb(0.97f * a, 0x0A0614));
                }
                prev = cur;
            }
        }

        /** Thin dashed white strands that spiral up around the body. */
        void strands(float k) {
            if (k < 0.02f) return;
            double H = f.h;
            for (int j = 0; j < 3; j++) {
                float[] prev = null;
                for (int s = 0; s <= 30; s++) {
                    double u = s / 30.0;
                    double an = j * TAU / 3.0 + u * 8.0 + t * 3.0;
                    double rr = (f.w * 0.5 + 0.35) * f.size * (1.0 - 0.55 * u);
                    double yy = gy + 0.05 + u * H * 1.15 * k;
                    if (!pt(f.x + Math.cos(an) * rr, yy, f.z + Math.sin(an) * rr)) { prev = null; continue; }
                    float[] cur = {o[0], o[1]};
                    if (prev != null && s % 3 != 2) {
                        Predictions.line(ctx, prev[0], prev[1], cur[0], cur[1], 3f, argb(0.22f * k, 0xB8A0FF));
                        Predictions.line(ctx, prev[0], prev[1], cur[0], cur[1], 1.3f, argb(0.9f * k, 0xFFFFFF));
                    }
                    prev = cur;
                }
            }
        }

        void hole() {
            double R = Math.max(1.1, f.w * 0.5 + 0.8) * f.size;
            float open = smooth(t / 0.4f), close = 1f - smooth((t - 3.0f) / 0.55f), k = open * close;
            disc(R * k, k);

            float appear = smooth(t / 0.3f), pull = smooth((t - 1.0f) / 1.8f);
            voxelBody(mix(pale, 0xC8C0FF, 0.5f), 0.9f * appear, 0f, pull, 3.5);   // the whole body, then sucked in

            float reach = smooth((t - 0.2f) / 0.7f) * (1f - smooth((t - 2.75f) / 0.6f));
            int n = Math.max(4, Math.round(6 * f.detail));
            for (int a = 0; a < n; a++) holeArm(a, n, R, reach);
            strands(reach);

            int m = Math.round(26 * f.detail);                                // violet specks spiral into the hole
            for (int i = 0; i < m; i++) {
                float age = (t + rnd(f.seed, i, 70) * 2.0f) % 1.8f, q = age / 1.8f;
                double an = rnd(f.seed, i, 71) * TAU + q * 5.0;
                double rr = R * (1.0 - q) * (0.5 + 0.5 * rnd(f.seed, i, 72));
                dot(f.x + Math.cos(an) * rr, gy + 0.05 + (1f - q) * 0.9 * rnd(f.seed, i, 73), f.z + Math.sin(an) * rr,
                        0.05 * f.size, 0xB8A0FF, (float) Math.sin(Math.PI * q) * 0.9f * k);
            }
        }
    }
}

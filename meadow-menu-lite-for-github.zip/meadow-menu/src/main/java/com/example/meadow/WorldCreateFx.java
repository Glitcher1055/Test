package com.example.meadow;

import com.example.meadow.Gfx.Fnt;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.option.GameOptionsScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.widget.CheckboxWidget;
import net.minecraft.client.gui.widget.PressableWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextWidget;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.util.Util;

/**
 * PS5 look for the world creation flow ("Создание мира", game rules, experiments, data packs, world editing):
 * while {@link #active} is true, those screens get the Shrine backdrop and their buttons / fields / tabs
 * are drawn as glass pills. The mixins only call into this class.
 */
public final class WorldCreateFx {
    private WorldCreateFx() {}

    /** True while a world creation / editing screen (or a sub-screen of it) is open. */
    public static boolean active;

    /** True on the Settings screens (Настройки and its sub-screens): list-row look instead of pills. */
    public static boolean settings() {
        Screen s = MinecraftClient.getInstance().currentScreen;
        return s instanceof GameOptionsScreen || s instanceof OptionsScreen;
    }

    /** True whenever the PS5 skin should be applied (world creation flow or settings). */
    public static boolean skin() { return active || settings(); }

    /** The vanilla centered title sits in the first ~28 GUI px: on settings screens we draw our own at the left. */
    public static boolean isHeaderTitle(ClickableWidget w) { return settings() && w.getY() < 28; }

    // ---------- main "Настройки" page: vertical list with icons, like the PS5 settings ----------
    private static final Map<ClickableWidget, Identifier> ICONS = new IdentityHashMap<>();
    private static final String[] KEYS = {"options.online", "options.skinCustomisation", "options.sounds", "options.video",
            "options.controls", "options.language", "options.chat", "options.resourcepack", "options.accessibility",
            "options.telemetry", "options.credits_and_attribution"};
    private static final Identifier[] KEY_ICONS = {Gfx.ICO_ONLINE, Gfx.ICO_SKIN, Gfx.ICO_SOUND, Gfx.ICO_VIDEO,
            Gfx.ICO_CONTROLS, Gfx.ICO_LANGUAGE, Gfx.I_CHAT, Gfx.ICO_PACK, Gfx.ICO_ACCESS, Gfx.ICO_DATA, Gfx.ICO_INFO};

    /**
     * Re-lays out the vanilla Settings buttons as one vertical list (the buttons stay the real vanilla ones,
     * so every click still opens the right screen). Called after the screen has been initialised.
     */
    public static void layoutSettings(Screen screen) {
        ICONS.clear();
        float k = screen.height / Scene.REF_H;
        if (k <= 0f) return;
        float vw = screen.width / k;
        List<ClickableWidget> rows = new ArrayList<>();
        ClickableWidget done = null;
        String doneText = ScreenTexts.DONE.getString();
        for (ClickableWidget w : Screens.getButtons(screen)) {
            if (w instanceof TextWidget) {                    // vanilla centered title: we draw our own at the left
                if (w.getY() < 28) w.visible = false;
                continue;
            }
            if (w instanceof SliderWidget) { w.visible = false; continue; }   // FOV is also in the video settings
            if (!(w instanceof PressableWidget)) continue;
            String m = w.getMessage().getString();
            if (m.isEmpty()) { w.visible = false; continue; }                  // difficulty lock icon
            if (m.equals(doneText)) done = w; else rows.add(w);
        }
        rows.sort((a, b) -> a.getY() != b.getY() ? Integer.compare(a.getY(), b.getY()) : Integer.compare(a.getX(), b.getX()));

        float listW = Math.min(vw * 0.68f, 760f), x0 = (vw - listW) / 2f + 20f;
        float top = 96f, bottom = 462f;
        float rowH = Math.min(46f, (bottom - top) / Math.max(1, rows.size()));
        for (int i = 0; i < rows.size(); i++) {
            ClickableWidget w = rows.get(i);
            w.setX(Math.round(x0 * k));
            w.setY(Math.round((top + i * rowH) * k));
            w.setWidth(Math.max(40, Math.round(listW * k)));
            w.setHeight(Math.max(12, Math.round(rowH * k)));
            Identifier icon = Gfx.I_GEAR;
            String m = w.getMessage().getString();
            for (int j = 0; j < KEYS.length; j++) {
                if (m.equals(Text.translatable(KEYS[j]).getString())) { icon = KEY_ICONS[j]; break; }
            }
            ICONS.put(w, icon);
        }
        if (done != null) {
            float dw = 300f, dh = 38f;
            done.setX(Math.round((vw - dw) / 2f * k));
            done.setY(Math.round(486f * k));
            done.setWidth(Math.round(dw * k));
            done.setHeight(Math.round(dh * k));
        }
    }

    private static final Scene SCENE = new Scene();
    private static int sw, sh;
    static { SCENE.instantBackdrop = true; }   // continues the backdrop of the previous Shrine screen

    public static void backdrop(DrawContext ctx, Screen s, float delta) {
        if (s.width != sw || s.height != sh) {
            sw = s.width; sh = s.height;
            SCENE.init(sw, sh);
        }
        SCENE.begin(ctx, 0, 0, delta);
        SCENE.stars(ctx, delta);
        if (s instanceof GameOptionsScreen || s instanceof OptionsScreen) {
            Gfx.text(ctx, MinecraftClient.getInstance().textRenderer, Fnt.TITLE, s.getTitle().getString(), 54f, 45f, Gfx.argb(1f, 0xFFFFFF));
        }
        SCENE.end(ctx);
    }

    // ---------- widget skins (all drawn on the virtual canvas, so they match the other Shrine screens) ----------
    public static void button(DrawContext ctx, ClickableWidget w) {
        float k = SCENE.k;
        if (k <= 0f) return;
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        if (settings()) { row(ctx, tr, w, k); return; }
        float x = w.getX() / k, y = w.getY() / k, ww = w.getWidth() / k, hh = w.getHeight() / k;
        boolean on = w.active, hov = on && w.isHovered();
        float a = on ? 1f : 0.45f;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        Gfx.box(ctx, Gfx.RR, x, y, ww, hh, hh / 2f, Gfx.argb((hov ? 0.30f : 0.15f) * a, 0xFFFFFF));
        Gfx.box(ctx, Gfx.RR_RING, x, y, ww, hh, hh / 2f, Gfx.argb((hov ? 0.75f : 0.20f) * a, 0xFFFFFF));
        label(ctx, tr, w.getMessage().getString(), x, y, ww, hh, Gfx.argb((hov ? 1f : 0.92f) * a, 0xFFFFFF));
        ctx.getMatrices().popMatrix();
    }

    public static void tab(DrawContext ctx, ClickableWidget w, boolean selected) {
        float k = SCENE.k;
        if (k <= 0f) return;
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        float x = w.getX() / k, y = w.getY() / k, ww = w.getWidth() / k, hh = w.getHeight() / k;
        boolean hov = w.isHovered();
        float ph = Math.min(hh, 36f), py = y + (hh - ph) / 2f;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        if (selected) Gfx.box(ctx, Gfx.RR, x + 6f, py, ww - 12f, ph, ph / 2f, Gfx.argb(0.96f, 0xFFFFFF));
        label(ctx, tr, w.getMessage().getString(), x, y, ww, hh,
                selected ? Gfx.argb(1f, 0x14101A) : Gfx.argb(hov ? 1f : 0.80f, 0xFFFFFF));
        ctx.getMatrices().popMatrix();
    }

    public static void field(DrawContext ctx, TextFieldWidget f) {
        float k = SCENE.k;
        if (k <= 0f) return;
        TextRenderer tr = MinecraftClient.getInstance().textRenderer;
        float x = f.getX() / k, y = f.getY() / k, ww = f.getWidth() / k, hh = f.getHeight() / k;
        boolean focused = f.isFocused();
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        Gfx.box(ctx, Gfx.RR, x, y, ww, hh, hh / 2.6f, Gfx.argb(0.09f, 0xFFFFFF));
        Gfx.box(ctx, Gfx.RR_RING, x, y, ww, hh, hh / 2.6f, Gfx.argb(focused ? 0.70f : 0.16f, 0xFFFFFF));

        String t = f.getText();
        float cy = y + hh / 2f, tx = x + 14f, avail = ww - 28f;
        boolean blink = ((int) (Util.getMeasuringTimeMs() / 450L)) % 2 == 0;
        int start = 0;
        while (start < t.length() - 1 && Gfx.width(tr, Fnt.LABEL, t.substring(start)) > avail) start++;
        if (!t.isEmpty()) Gfx.text(ctx, tr, Fnt.LABEL, t.substring(start), tx, cy, Gfx.argb(1f, 0xFFFFFF));
        if (focused && blink) {
            int cur = Math.max(start, Math.min(t.length(), f.getCursor()));
            float cx = tx + (t.isEmpty() ? 0 : Gfx.width(tr, Fnt.LABEL, t.substring(start, cur)));
            ctx.fill(Math.round(cx), Math.round(cy - 9), Math.round(cx) + 2, Math.round(cy + 9), Gfx.argb(0.95f, 0xFFFFFF));
        }
        ctx.getMatrices().popMatrix();
    }

    /** Centered label that shrinks to a smaller font if it does not fit. */
    private static void label(DrawContext ctx, TextRenderer tr, String s, float x, float y, float w, float h, int color) {
        Fnt font = Gfx.width(tr, Fnt.UI, s) <= w - 16f ? Fnt.UI
                : (Gfx.width(tr, Fnt.LABEL, s) <= w - 12f ? Fnt.LABEL : Fnt.SMALL);
        Gfx.textC(ctx, tr, font, s, x + w / 2f, y + h / 2f, color);
    }

    /** PS5 settings row: no fill, thin separator, outlined when hovered, label left, value right. */
    private static void row(DrawContext ctx, TextRenderer tr, ClickableWidget w, float k) {
        float x = w.getX() / k, y = w.getY() / k, ww = w.getWidth() / k, hh = w.getHeight() / k;
        String msg = w.getMessage().getString();
        boolean on = w.active, hov = on && (w.isHovered() || w.isFocused());
        float a = on ? 1f : 0.40f;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        if (ScreenTexts.DONE.getString().equals(msg)) {
            Gfx.box(ctx, Gfx.RR, x, y, ww, hh, hh / 2f, Gfx.argb((hov ? 1f : 0.96f) * a, 0xFFFFFF));
            label(ctx, tr, msg, x, y, ww, hh, Gfx.argb(a, 0x14101A));
        } else if (ScreenTexts.CANCEL.getString().equals(msg) || ScreenTexts.BACK.getString().equals(msg)) {
            Gfx.box(ctx, Gfx.RR, x, y, ww, hh, hh / 2f, Gfx.argb((hov ? 0.30f : 0.15f) * a, 0xFFFFFF));
            Gfx.box(ctx, Gfx.RR_RING, x, y, ww, hh, hh / 2f, Gfx.argb((hov ? 0.75f : 0.20f) * a, 0xFFFFFF));
            label(ctx, tr, msg, x, y, ww, hh, Gfx.argb(a, 0xFFFFFF));
        } else {
            float r = Math.min(hh / 2.4f, 10f);
            if (hov) {
                Gfx.box(ctx, Gfx.RR, x, y, ww, hh, r, Gfx.argb(0.07f * a, 0xFFFFFF));
                Gfx.box(ctx, Gfx.RR_RING, x, y, ww, hh, r, Gfx.argb(0.80f * a, 0xFFFFFF));
            } else {
                ctx.fill(Math.round(x + 6f), Math.round(y + hh) - 1, Math.round(x + ww - 6f), Math.round(y + hh), Gfx.argb(0.12f * a, 0xFFFFFF));
            }
            Identifier icon = ICONS.get(w);
            if (icon != null) {
                String lab = msg.replaceAll("(…|\\.\\.\\.)$", "");
                Gfx.centered(ctx, icon, x + 34f, y + hh / 2f, Math.min(28f, hh * 0.72f), Math.min(28f, hh * 0.72f),
                        Gfx.argb((hov ? 1f : 0.92f) * a, 0xFFFFFF));
                Gfx.text(ctx, tr, Fnt.UI, lab, x + 70f, y + hh / 2f, Gfx.argb((hov ? 1f : 0.92f) * a, 0xFFFFFF));
                ctx.getMatrices().popMatrix();
                return;
            }
            String label = msg, value = null;
            int c = msg.indexOf(": ");
            if (c > 0 && c < msg.length() - 2) { label = msg.substring(0, c); value = msg.substring(c + 2); }
            Fnt font = Gfx.width(tr, Fnt.UI, msg) + 40f <= ww ? Fnt.UI : Fnt.LABEL;
            int col = Gfx.argb((hov ? 1f : 0.92f) * a, 0xFFFFFF);
            Gfx.text(ctx, tr, font, label, x + 16f, y + hh / 2f, col);
            if (value != null) {
                Gfx.text(ctx, tr, font, value, x + ww - 16f - Gfx.width(tr, font, value), y + hh / 2f, Gfx.argb(0.62f * a, 0xFFFFFF));
            } else if (w instanceof CheckboxWidget cb) {
                float cx = x + ww - 28f, cy = y + hh / 2f;
                Gfx.centered(ctx, Gfx.DISC, cx, cy, 20f, 20f, Gfx.argb(0.18f * a, 0xFFFFFF));
                if (cb.isChecked()) Gfx.centered(ctx, Gfx.DISC, cx, cy, 12f, 12f, Gfx.argb(a, 0xFFFFFF));
            }
        }
        ctx.getMatrices().popMatrix();
    }
}

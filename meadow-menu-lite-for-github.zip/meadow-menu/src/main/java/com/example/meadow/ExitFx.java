package com.example.meadow;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.util.ScreenshotRecorder;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

/**
 * "Leaving a world" animation: the last game frame shrinks into a card, then the server / world
 * screen fades in with the world we just left selected.
 */
final class ExitFx {
    private ExitFx() {}

    static boolean active;                 // the animation is playing on the current screen

    private static final Identifier TEX_ID = Identifier.of("meadow", "exit/shot");
    private static String kind, key;       // what we joined last: "server" + address, or "world" + folder name
    private static long capturedAt, startedAt;
    private static boolean fresh;
    private static volatile NativeImage pending;
    private static boolean registered;

    /** Called when the player presses "Играть". */
    static void remember(String k, String id) { kind = k; key = id; }

    /** Called when the connection closes: the framebuffer still holds the last game frame. */
    static void capture(MinecraftClient mc) {
        if (kind == null) return;
        release(mc);
        capturedAt = Util.getMeasuringTimeMs();
        fresh = true;
        try {
            ScreenshotRecorder.takeScreenshot(mc.getFramebuffer(), 2, img -> pending = img);
        } catch (Throwable t) {
            pending = null;
        }
    }

    /** @return the remembered key if we have just left a world of this kind (and starts the animation). */
    static String take(String k) {
        if (!fresh || !k.equals(kind) || Util.getMeasuringTimeMs() - capturedAt > 15000L) return null;
        fresh = false;
        active = true;
        startedAt = 0;
        return key;
    }

    private static float ease(float x) {
        x = Math.max(0f, Math.min(1f, x));
        return x < 0.5f ? 4f * x * x * x : 1f - (float) Math.pow(-2f * x + 2f, 3) / 2f;
    }

    private static Identifier texture(MinecraftClient mc) {
        NativeImage img = pending;
        if (img != null) {
            pending = null;
            try {
                mc.getTextureManager().registerTexture(TEX_ID, new NativeImageBackedTexture(() -> "meadow exit", img));
                registered = true;
            } catch (Throwable t) {
                registered = false;
            }
        }
        return registered ? TEX_ID : null;
    }

    private static void release(MinecraftClient mc) {
        pending = null;
        if (registered) {
            try { mc.getTextureManager().destroyTexture(TEX_ID); } catch (Throwable ignored) { }
            registered = false;
        }
        active = false;
        startedAt = 0;
    }

    /** Draws on the virtual canvas, over the screen. tx..th = the selected tile the card shrinks into. */
    static void draw(DrawContext ctx, MinecraftClient mc, float vw, float tx, float ty, float tw, float th) {
        if (!active) return;
        long now = Util.getMeasuringTimeMs();
        if (startedAt == 0) startedAt = now;
        float t = (now - startedAt) / 1000f;
        Identifier id = texture(mc);
        if (t > 0.85f || (id == null && t > 0.5f)) { release(mc); return; }
        if (id == null) return;

        float p = ease(t / 0.50f);
        float a = 1f - ease((t - 0.48f) / 0.32f);
        float cw = 230f, ch = cw * Scene.REF_H / vw;
        float cx = vw / 2f + (tx + tw / 2f - vw / 2f) * p, cy = Scene.REF_H / 2f + (ty + th / 2f - Scene.REF_H / 2f) * p;
        float W = vw + (cw - vw) * p, H = Scene.REF_H + (ch - Scene.REF_H) * p;

        Gfx.centered(ctx, Gfx.GLOW, cx, cy, W * 1.3f, H * 1.5f, Gfx.argb(0.30f * p * a, Gfx.ACCENT));
        Gfx.blit(ctx, id, Math.round(cx - W / 2f), Math.round(cy - H / 2f), Math.round(W), Math.round(H), Gfx.argb(a, 0xFFFFFF));
        Gfx.box(ctx, Gfx.RR_RING, cx - W / 2f - 2f, cy - H / 2f - 2f, W + 4f, H + 4f, 30f * p + 2f, Gfx.argb(0.55f * p * a, 0xFFFFFF));
    }
}

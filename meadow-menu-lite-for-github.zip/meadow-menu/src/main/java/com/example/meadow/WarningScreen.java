package com.example.meadow;

import com.example.meadow.Gfx.Fnt;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static com.example.meadow.Gfx.*;

/** Startup sequence like the video: logo + loading bar, photosensitivity warning, bokeh transition, then the menu. */
public final class WarningScreen extends Screen {
    private static final float SPLASH_END = 1.5f, WARN_IN = 1.9f, WARN_OUT = 5.6f, WARN_END = 6.3f, BOKEH_END = 7.4f;
    private static final String HEAD = "ФОТОЧУВСТВИТЕЛЬНАЯ ЭПИЛЕПСИЯ:";
    private static final String BODY = "Если у вас когда-либо были эпилепсия или судороги, перед использованием "
            + "проконсультируйтесь с врачом. Некоторые эффекты могут спровоцировать судороги даже у людей, "
            + "у которых раньше их не было.";

    private final Screen next;
    private long start;
    private final float[][] blobs = new float[11][4]; // x(0..1), y(0..1), radius, phase

    public WarningScreen(Screen next) {
        super(Text.literal("Shrine"));
        this.next = next;
        Random r = new Random(11L);
        for (float[] b : blobs) { b[0] = r.nextFloat(); b[1] = r.nextFloat(); b[2] = 70f + r.nextFloat() * 120f; b[3] = r.nextFloat() * 6.28f; }
    }

    @Override
    protected void init() {
        if (start == 0) start = Util.getMeasuringTimeMs();
    }

    private static float ease(float x) { x = Math.max(0f, Math.min(1f, x)); return 1f - (1f - x) * (1f - x); }

    @Override
    public void render(DrawContext ctx, int mxReal, int myReal, float delta) {
        float t = (Util.getMeasuringTimeMs() - start) / 1000f;
        if (t > BOKEH_END) { client.setScreen(next); return; }

        float k = height / Scene.REF_H, vw = width / k;
        ctx.fillGradient(0, 0, width, height, 0xFF08030B, 0xFF1D0509);
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);

        float cx = vw / 2f;
        centered(ctx, GLOW, cx, 300f, vw * 0.8f, 380f, argb(0.12f * ease((t - 0.5f) / 1.2f), ACCENT));

        // 1) logo + loading bar
        float sa = ease(t / 0.4f) * (1f - ease((t - (SPLASH_END - 0.35f)) / 0.35f));
        if (sa > 0.01f) {
            centered(ctx, LOGO, cx, 250f, 64f, 64f, argb(sa, ACCENT));
            float bw = 150f, bx = cx - bw / 2f, by = 320f, p = ease(t / (SPLASH_END - 0.3f));
            box(ctx, RR, bx, by, bw, 3, 1.5f, argb(0.16f * sa, 0xFFFFFF));
            box(ctx, RR, bx, by, Math.max(3f, bw * p), 3, 1.5f, argb(0.95f * sa, 0xFFFFFF));
        }

        // 2) photosensitivity warning
        float wa = ease((t - WARN_IN) / 0.7f) * (1f - ease((t - WARN_OUT) / 0.7f));
        if (wa > 0.01f) {
            float maxW = Math.min(vw * 0.62f, 560f);
            List<String> lines = new ArrayList<>();
            lines.add(HEAD);
            wrap(BODY, maxW, lines);
            float y = 360f - lines.size() * 13f;
            for (int i = 0; i < lines.size(); i++) {
                String s = lines.get(i);
                textC(ctx, textRenderer, Fnt.LABEL, s, cx, y + i * 26f, argb((i == 0 ? 1f : 0.88f) * wa, 0xFFFFFF));
            }
        }

        // 3) bokeh transition
        float u = (t - WARN_END) / (BOKEH_END - WARN_END);
        if (u > 0f) {
            float env = (float) Math.sin(Math.PI * Math.min(1f, u));
            for (float[] b : blobs) {
                float bx = b[0] * vw + (float) Math.sin(t * 0.6f + b[3]) * 16f;
                float by = b[1] * Scene.REF_H + (float) Math.cos(t * 0.5f + b[3]) * 12f;
                centered(ctx, GLOW, bx, by, b[2] * 3.2f, b[2] * 3.2f, argb(0.34f * env, ACCENT));
                centered(ctx, DISC, bx, by, b[2] * 1.6f, b[2] * 1.6f, argb(0.20f * env, 0xFF5A5A));
            }
        }
        ctx.getMatrices().popMatrix();

        // continue the loading animation and fade it out over the first moments of this screen
        if (BootFx.shown()) {
            float ba = 1f - t / 0.9f;
            if (ba > 0.01f) BootFx.draw(ctx, ba * ba);
        }
    }

    private void wrap(String s, float maxW, List<String> out) {
        StringBuilder line = new StringBuilder();
        for (String word : s.split(" ")) {
            String cand = line.isEmpty() ? word : line + " " + word;
            if (width(textRenderer, Fnt.LABEL, cand) > maxW && !line.isEmpty()) {
                out.add(line.toString());
                line = new StringBuilder(word);
            } else {
                line = new StringBuilder(cand);
            }
        }
        if (!line.isEmpty()) out.add(line.toString());
    }

    /** Tap / click skips straight to the transition. */
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        float t = (Util.getMeasuringTimeMs() - start) / 1000f;
        if (t < WARN_END) start = Util.getMeasuringTimeMs() - (long) (WARN_END * 1000f);
        return true;
    }

    @Override public boolean shouldCloseOnEsc() { return false; }
    @Override public boolean shouldPause() { return false; }
}

package com.example.meadow.mixin;

import com.example.meadow.BootFx;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.SplashOverlay;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * The red Mojang loading overlay is drawn first (its logic keeps running: it is what finishes the resource reload),
 * then our startup animation is painted over the whole screen.
 */
@Mixin(SplashOverlay.class)
public class SplashOverlayMixin {
    @Inject(method = "render", at = @At("RETURN"))
    private void shrine$boot(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
        BootFx.draw(ctx, 1f);
    }
}

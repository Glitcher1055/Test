package com.example.meadow;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.util.Random;
import java.util.zip.CRC32;
import java.util.zip.Deflater;
import java.util.zip.DeflaterOutputStream;

/**
 * Startup animation that replaces the red Mojang loading overlay: a blue glowing core in the dark, particle ribbons
 * orbit and spread into a band, a warm flash, then a soft spotlight with drifting dust.
 *
 * Everything is drawn procedurally. The only texture is a soft round gradient that is generated in memory
 * (our resource pack is not loaded yet while the game is still loading, so we cannot rely on png files).
 */
public final class BootFx {
    private BootFx() {}

    private static final Identifier SOFT = Identifier.of("meadow", "boot/soft");
    private static boolean tried, ready;
    private static long start, last;
    private static boolean everShown;

    private static final int N = 180, DUST = 46;
    private static final float[][] P = new float[N][8];     // a0, speed, rad0, spread, tilt, size, u, v
    private static final float[][] D = new float[DUST][5];  // x(0..1), y(0..1), size, speed, phase
    static {
        Random r = new Random(21L);
        for (float[] p : P) {
            p[0] = r.nextFloat() * 6.2832f; p[1] = 0.35f + r.nextFloat() * 0.9f; p[2] = 14f + r.nextFloat() * 50f;
            p[3] = 60f + r.nextFloat() * 300f; p[4] = 0.25f + r.nextFloat() * 0.75f; p[5] = 3f + r.nextFloat() * 7f;
            p[6] = r.nextFloat(); p[7] = r.nextFloat();
        }
        for (float[] d : D) {
            d[0] = r.nextFloat(); d[1] = r.nextFloat(); d[2] = 6f + r.nextFloat() * 22f;
            d[3] = 0.004f + r.nextFloat() * 0.012f; d[4] = r.nextFloat() * 6.28f;
        }
    }

    /** True once the animation has been drawn (the first screen after loading fades it out). */
    public static boolean shown() { return everShown; }

    // ---------- generated soft-disc texture ----------
    private static boolean ensure(MinecraftClient mc) {
        if (ready) return true;
        if (tried) return false;
        tried = true;
        try {
            NativeImage img = NativeImage.read(new ByteArrayInputStream(softPng(256)));
            mc.getTextureManager().registerTexture(SOFT, new NativeImageBackedTexture(() -> "meadow boot", img));
            ready = true;
        } catch (Throwable t) {
            ready = false;
        }
        return ready;
    }

    /** Minimal PNG writer (no java.awt: the game may run where AWT is missing). White RGBA, alpha = soft falloff. */
    private static byte[] softPng(int n) throws Exception {
        byte[] raw = new byte[(n * 4 + 1) * n];
        int o = 0;
        for (int y = 0; y < n; y++) {
            raw[o++] = 0;
            for (int x = 0; x < n; x++) {
                float dx = (x + 0.5f) / n * 2f - 1f, dy = (y + 0.5f) / n * 2f - 1f;
                float d = (float) Math.sqrt(dx * dx + dy * dy);
                float a = d >= 1f ? 0f : (float) Math.pow(1f - d, 2.2);
                raw[o++] = (byte) 255; raw[o++] = (byte) 255; raw[o++] = (byte) 255;
                raw[o++] = (byte) Math.round(a * 255f);
            }
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write(new byte[]{(byte) 0x89, 'P', 'N', 'G', 0x0D, 0x0A, 0x1A, 0x0A});
        ByteArrayOutputStream ihdr = new ByteArrayOutputStream();
        DataOutputStream d = new DataOutputStream(ihdr);
        d.writeInt(n); d.writeInt(n); d.writeByte(8); d.writeByte(6); d.writeByte(0); d.writeByte(0); d.writeByte(0);
        chunk(out, "IHDR", ihdr.toByteArray());
        ByteArrayOutputStream z = new ByteArrayOutputStream();
        try (DeflaterOutputStream dz = new DeflaterOutputStream(z, new Deflater(6))) { dz.write(raw); }
        chunk(out, "IDAT", z.toByteArray());
        chunk(out, "IEND", new byte[0]);
        return out.toByteArray();
    }

    private static void chunk(ByteArrayOutputStream out, String type, byte[] data) throws Exception {
        DataOutputStream d = new DataOutputStream(out);
        d.writeInt(data.length);
        byte[] t = type.getBytes("US-ASCII");
        d.write(t); d.write(data);
        CRC32 crc = new CRC32();
        crc.update(t); crc.update(data);
        d.writeInt((int) crc.getValue());
    }

    // ---------- drawing ----------
    private static float sm(float x) { x = Math.max(0f, Math.min(1f, x)); return x * x * (3f - 2f * x); }

    private static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = Math.round(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = Math.round(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = Math.round((a & 255) * (1 - t) + (b & 255) * t);
        return (r << 16) | (g << 8) | bl;
    }

    private static void soft(DrawContext ctx, float x, float y, float w, float h, float alpha, int rgb) {
        if (alpha <= 0.004f) return;
        Gfx.centered(ctx, SOFT, x, y, w, h, Gfx.argb(alpha, rgb));
    }

    /** @param ga global opacity (1 while the overlay is up, fades to 0 on the next screen). */
    public static void draw(DrawContext ctx, float ga) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!ensure(mc)) return;
        long now = Util.getMeasuringTimeMs();
        if (start == 0 || now - last > 1500L) start = now;   // a new session: first launch, or a later resource reload
        last = now;
        everShown = true;
        float t = (now - start) / 1000f;

        int w = mc.getWindow().getScaledWidth(), h = mc.getWindow().getScaledHeight();
        float k = h / Scene.REF_H, vw = w / k, cx = vw / 2f, cy = 262f;

        float warm = sm((t - 5.0f) / 2.6f);                 // 0 = night blue, 1 = warm light
        float orb = sm(t / 1.3f);
        float swirl = sm((t - 1.0f) / 1.2f), band = sm((t - 2.4f) / 1.8f);
        int bg1 = lerp(0x060103, 0x240709, warm), bg2 = lerp(0x0C0205, 0x3F0D12, warm);
        ctx.fillGradient(0, 0, w, h, Gfx.argb(ga, bg1), Gfx.argb(ga, bg2));

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);

        // --- warm spotlight from the top left, appears after the flash ---
        if (warm > 0.01f) {
            float sx = vw * 0.14f;
            soft(ctx, sx, -20f, 980f, 760f, 0.50f * warm * ga, 0xFF6B66);
            soft(ctx, sx, -10f, 330f, 300f, 0.80f * warm * ga, 0xFFD2CC);
            for (int i = 0; i < 9; i++) {
                float f = 1f - i / 9f;
                soft(ctx, sx + i * 70f, i * 58f, 300f + i * 34f, 190f + i * 22f, 0.10f * f * warm * ga, 0xFF8F88);
            }
            soft(ctx, cx, 575f, vw * 1.1f, 190f, 0.30f * warm * ga, 0xB83A44);   // floor haze
        }

        // --- the glowing core ---
        int blue = lerp(lerp(0xFF2E3A, 0xFF6B4A, sm((t - 3f) / 2f)), 0xFFB39A, warm);
        float core = 46f + 150f * sm((t - 0.5f) / 2.2f) + 7f * (float) Math.sin(t * 3.1f);
        float coreFade = (1f - 0.55f * warm) * orb * ga;
        soft(ctx, cx, cy, core * 4.4f, core * 3.4f, 0.42f * coreFade, blue);
        soft(ctx, cx, cy, core * 2.1f, core * 1.7f, 0.70f * coreFade, lerp(blue, 0xFFFFFF, 0.25f));
        soft(ctx, cx, cy, core * 0.75f, core * 0.75f, 0.95f * coreFade, 0xFFFFFF);

        // --- orbiting ribbons and the drifting band of particles ---
        for (int i = 0; i < N; i++) {
            float[] p = P[i];
            boolean isBand = (i & 3) == 0;
            float x, y, a;
            if (isBand) {
                float u = p[6];
                float spreadX = (u - 0.5f) * vw * 1.15f * band;
                x = cx + spreadX + (float) Math.sin(t * 0.7f + p[0]) * 8f;
                y = cy + 12f * (float) Math.sin(u * 9f + t * 0.9f) + (p[7] - 0.5f) * 26f * (0.4f + band);
                a = band * (0.35f + 0.5f * Math.abs((float) Math.sin(t * 1.7f + p[0])));
            } else {
                float ang = p[0] + t * p[1];
                float rad = p[2] + p[3] * sm((t - 1.1f) / 2.6f) * (0.5f + 0.5f * (float) Math.sin(t * 0.5f + p[0]) * 0.5f + 0.5f);
                x = cx + (float) Math.cos(ang) * rad;
                y = cy + (float) Math.sin(ang) * rad * p[4];
                a = swirl * (0.30f + 0.65f * Math.abs((float) Math.sin(t * 2.3f + p[0] * 3f)));
            }
            a *= orb * (1f - 0.80f * warm) * ga;
            int col = lerp(lerp(0xFF6A66, 0xFFB0A4, p[7]), 0xFFD0C4, warm);
            float s = p[5] * (isBand ? 0.9f : 1f);
            soft(ctx, x, y, s * 2.6f, s * 2.6f, 0.55f * a, col);
            soft(ctx, x, y, s * 0.8f, s * 0.8f, 0.95f * a, 0xFFFFFF);
        }

        // --- dust motes in the warm light ---
        if (warm > 0.02f) {
            for (float[] d : D) {
                float yy = ((d[1] - t * d[3]) % 1f + 1f) % 1f;
                float x = d[0] * vw + (float) Math.sin(t * 0.4f + d[4]) * 18f, y = yy * Scene.REF_H;
                float tw = 0.4f + 0.6f * Math.abs((float) Math.sin(t * 0.9f + d[4]));
                soft(ctx, x, y, d[2] * 2.4f, d[2] * 2.4f, 0.32f * tw * warm * ga, 0xFF8A7A);
                soft(ctx, x, y, d[2] * 0.7f, d[2] * 0.7f, 0.55f * tw * warm * ga, 0xFFD6CE);
            }
        }
        ctx.getMatrices().popMatrix();

        // --- the flash between the blue and the warm part ---
        float fl = Math.max(0f, 1f - Math.abs(t - 5.2f) / 0.40f);
        if (fl > 0.01f) ctx.fill(0, 0, w, h, Gfx.argb(0.80f * fl * fl * ga, 0xFFC4BA));
    }
}

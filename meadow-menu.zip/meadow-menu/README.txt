Meadow Menu - Fabric 1.20.1

Build:   gradle wrapper (once, if no gradlew)  ->  ./gradlew build
Output:  build/libs/meadow-menu-1.0.0.jar  -> drop into .minecraft/mods (with Fabric API)
Dev run: ./gradlew runClient

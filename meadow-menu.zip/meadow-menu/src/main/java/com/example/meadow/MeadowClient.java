package com.example.meadow;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.gui.screen.TitleScreen;

public class MeadowClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Every time the vanilla title screen opens, swap it for ours.
        // "Back" buttons return to the TitleScreen, which gets swapped again -> always lands on our menu.
        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            if (screen instanceof TitleScreen title) {
                client.execute(() -> {
                    if (client.currentScreen == title) {
                        client.setScreen(new MeadowMenuScreen(title));
                    }
                });
            }
        });
    }
}

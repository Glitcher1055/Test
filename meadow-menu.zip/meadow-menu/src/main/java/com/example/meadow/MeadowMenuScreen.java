package com.example.meadow;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public final class MeadowMenuScreen extends Screen {

    // ---------- palette / tuning ----------
    private static final String BRAND = "meadow";
    private static final int ACCENT_RGB = 0xB98CFF;
    private static final int ACCENT = 0xFF000000 | ACCENT_RGB;
    private static final int BG_TOP = 0xFF05030E;
    private static final int BG_BOTTOM = 0xFF0B0620;
    private static final int STAR_COUNT = 180;
    private static final float BTN_R = 38f;
    private static final float BTN_GAP = 118f;
    private static final DateTimeFormatter CLOCK_FMT =
            DateTimeFormatter.ofPattern("HH:mm, EEEE", Locale.forLanguageTag("ru-RU"));

    private final Screen parent;
    private final Random rnd = new Random(7L);
    private final List<Star> stars = new ArrayList<>();
    private final List<MenuButton> buttons = new ArrayList<>();
    private long openedAt;
    private float time;

    public MeadowMenuScreen(Screen parent) {
        super(Text.literal(BRAND));
        this.parent = parent;
    }

    @Override
    protected void init() {
        openedAt = Util.getMeasuringTimeMs();

        stars.clear();
        for (int i = 0; i < STAR_COUNT; i++) {
            float depth = 0.2f + rnd.nextFloat() * 0.8f; // 0..1, closer = bigger + faster + more parallax
            stars.add(new Star(rnd.nextFloat() * width, rnd.nextFloat() * height,
                    depth, rnd.nextFloat() * 6.28f));
        }

        buttons.clear();
        buttons.add(new MenuButton("Настройки", Icon.GEAR,
                () -> client.setScreen(new OptionsScreen(this, client.options))));
        buttons.add(new MenuButton("Одиночная игра", Icon.PERSON,
                () -> client.setScreen(new SelectWorldScreen(this))));
        buttons.add(new MenuButton("Сетевая игра", Icon.GROUP,
                () -> client.setScreen(new MultiplayerScreen(this))));

        float startX = width / 2f - (buttons.size() - 1) * BTN_GAP / 2f;
        float y = height / 2f + 22f;
        for (int i = 0; i < buttons.size(); i++) buttons.get(i).setCenter(startX + i * BTN_GAP, y);
    }

    // ---------- render ----------
    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        time += delta / 20f;
        float fade = Math.min(1f, (Util.getMeasuringTimeMs() - openedAt) / 700f);
        fade = 1f - (1f - fade) * (1f - fade); // ease-out
        float pulse = 0.85f + 0.15f * (float) Math.sin(time * 1.3f);

        ctx.fillGradient(0, 0, width, height, BG_TOP, BG_BOTTOM);
        drawBeam(ctx, pulse, fade);
        drawStars(ctx, mx, my, delta, fade);

        drawTitle(ctx, fade);

        for (MenuButton b : buttons) {
            boolean hov = b.contains(mx, my);
            b.hover += ((hov ? 1f : 0f) - b.hover) * Math.min(1f, delta * 0.3f);

            float rise = (1f - fade) * 14f;
            float cy = b.cy + rise;
            float r = BTN_R * (1f + 0.09f * b.hover);

            fillCircle(ctx, b.cx, cy, r + 7f, argb((0.06f + 0.14f * b.hover) * fade, ACCENT_RGB)); // glow
            fillCircle(ctx, b.cx, cy, r, argb((0.20f + 0.14f * b.hover) * fade, 0xFFFFFF));          // glass
            fillCircle(ctx, b.cx, cy, r - 1.5f, argb((0.30f + 0.10f * b.hover) * fade, 0x120A2A));  // inner tint
            drawIcon(ctx, b.icon, b.cx, cy, r * 0.5f, argb((0.55f + 0.45f * b.hover) * fade, 0xFFFFFF));

            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(b.label),
                    (int) b.cx, (int) (cy + BTN_R + 13f),
                    argb((0.35f + 0.65f * b.hover) * fade, 0xFFFFFF));
        }

        drawClock(ctx, fade);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(BRAND + " client • " + LocalDateTime.now().getYear()),
                width / 2, height - 14, argb(0.3f * fade, 0xFFFFFF));
    }

    private void drawBeam(DrawContext ctx, float pulse, float fade) {
        for (int y = 0; y < height; y += 2) {
            float t = y / (float) height;
            float cx = y * 0.45f + 40f;
            float half = 26f + y * 0.13f;
            float a = (1f - t) * (1f - t) * 0.30f * pulse * fade;
            ctx.fill((int) (cx - half), y, (int) (cx + half), y + 2, argb(a, ACCENT_RGB));
            // brighter core
            ctx.fill((int) (cx - half * 0.35f), y, (int) (cx + half * 0.35f), y + 2, argb(a * 0.5f, 0xFFFFFF));
        }
    }

    private void drawStars(DrawContext ctx, int mx, int my, float delta, float fade) {
        float px = (mx - width / 2f) / width;
        float py = (my - height / 2f) / height;
        for (Star s : stars) {
            s.y += s.depth * 0.45f * delta;
            if (s.y > height + 2) { s.y = -2; s.x = rnd.nextFloat() * width; }
            float tw = 0.35f + 0.65f * Math.abs((float) Math.sin(time * 2f + s.phase));
            int x = (int) (s.x - px * 14f * s.depth);
            int y = (int) (s.y - py * 8f * s.depth);
            int size = s.depth > 0.8f ? 2 : 1;
            int rgb = s.depth > 0.85f ? ACCENT_RGB : 0xFFFFFF;
            ctx.fill(x, y, x + size, y + size, argb(tw * 0.9f * fade, rgb));
        }
    }

    private void drawTitle(DrawContext ctx, float fade) {
        String prefix = "Добро пожаловать в ";
        int pw = textRenderer.getWidth(prefix);
        int bw = textRenderer.getWidth(BRAND);
        int total = pw + 12 + bw;
        int x = width / 2 - total / 2;
        int y = height / 2 - 52 - (int) ((1f - fade) * 10f);

        ctx.drawTextWithShadow(textRenderer, Text.literal(prefix), x, y, argb(0.85f * fade, 0xFFFFFF));

        // small diamond logo
        int dx = x + pw + 3, dy = y + 4;
        int c = argb(fade, ACCENT_RGB);
        ctx.fill(dx + 3, dy - 3, dx + 5, dy - 1, c);
        ctx.fill(dx + 2, dy - 1, dx + 6, dy + 1, c);
        ctx.fill(dx + 1, dy + 1, dx + 7, dy + 3, c);
        ctx.fill(dx + 2, dy + 3, dx + 6, dy + 5, c);
        ctx.fill(dx + 3, dy + 5, dx + 5, dy + 7, c);

        ctx.drawTextWithShadow(textRenderer, Text.literal(BRAND), x + pw + 12, y, c);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Во что сегодня играем?"),
                width / 2, y + 14, argb(0.4f * fade, 0xFFFFFF));
    }

    private void drawClock(DrawContext ctx, float fade) {
        String raw = LocalDateTime.now().format(CLOCK_FMT);
        int sp = raw.indexOf(' ');
        String s = (sp >= 0 && sp + 1 < raw.length())
                ? raw.substring(0, sp + 1) + Character.toUpperCase(raw.charAt(sp + 1)) + raw.substring(sp + 2)
                : raw;
        ctx.drawTextWithShadow(textRenderer, Text.literal(s),
                width - textRenderer.getWidth(s) - 10, 8, argb(0.85f * fade, 0xFFFFFF));
    }

    // ---------- icons ----------
    private static void drawIcon(DrawContext ctx, Icon icon, float cx, float cy, float s, int color) {
        switch (icon) {
            case GEAR -> {
                fillCircle(ctx, cx, cy, s, color);
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4;
                    fillCircle(ctx, cx + (float) Math.cos(a) * s * 1.0f,
                            cy + (float) Math.sin(a) * s * 1.0f, s * 0.30f, color);
                }
                fillCircle(ctx, cx, cy, s * 0.42f, 0xFF1A1030);
            }
            case PERSON -> person(ctx, cx, cy, s, color);
            case GROUP -> {
                person(ctx, cx - s * 0.75f, cy + s * 0.15f, s * 0.6f, color);
                person(ctx, cx + s * 0.75f, cy + s * 0.15f, s * 0.6f, color);
                person(ctx, cx, cy, s * 0.82f, color);
            }
        }
    }

    private static void person(DrawContext ctx, float cx, float cy, float s, int color) {
        fillCircle(ctx, cx, cy - s * 0.35f, s * 0.38f, color);
        fillCircle(ctx, cx, cy + s * 0.80f, s * 0.68f, color);
    }

    // ---------- helpers ----------
    private static void fillCircle(DrawContext ctx, float cx, float cy, float r, int color) {
        int top = (int) Math.floor(cy - r), bot = (int) Math.ceil(cy + r);
        for (int y = top; y < bot; y++) {
            float dy = y + 0.5f - cy;
            float half = (float) Math.sqrt(Math.max(0f, r * r - dy * dy));
            if (half < 0.5f) continue;
            ctx.fill((int) (cx - half), y, (int) (cx + half), y + 1, color);
        }
    }

    private static int argb(float a, int rgb) {
        int al = Math.round(Math.max(0f, Math.min(1f, a)) * 255f);
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    // ---------- input ----------
    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (button == 0) {
            for (MenuButton b : buttons) {
                if (b.contains(mx, my)) { b.action.run(); return true; }
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override public boolean shouldPause() { return false; }
    @Override public boolean shouldCloseOnEsc() { return false; }

    // ---------- data ----------
    private enum Icon { GEAR, PERSON, GROUP }

    private static final class MenuButton {
        final String label; final Icon icon; final Runnable action;
        float cx, cy, hover;
        MenuButton(String label, Icon icon, Runnable action) { this.label = label; this.icon = icon; this.action = action; }
        void setCenter(float x, float y) { cx = x; cy = y; }
        boolean contains(double mx, double my) {
            double dx = mx - cx, dy = my - cy, r = BTN_R * (1.0 + 0.09 * hover);
            return dx * dx + dy * dy <= r * r;
        }
    }

    private static final class Star {
        float x, y, depth, phase;
        Star(float x, float y, float depth, float phase) { this.x = x; this.y = y; this.depth = depth; this.phase = phase; }
    }
}

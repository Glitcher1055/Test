package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import static com.shrine.Gfx.*;

/**
 * Visual > "Предсказания": while you hold an ender pearl / snowball / potion / bow / loaded crossbow a dashed
 * trajectory is drawn and a glowing ring marks the spot where the projectile will land. Projectiles already flying
 * (yours and other players') get the same line plus a "до падения" timer card.
 *
 * Everything is a 2D overlay: world points are projected to the screen by hand.
 * The flight is simulated tick by tick with the vanilla physics (gravity, drag, block + entity collision).
 */
final class Predictions {
    private Predictions() {}

    static final String KEY = "visual.pred", K_PEARL = "visual.pred.pearl", K_SNOW = "visual.pred.snow",
            K_POTION = "visual.pred.potion", K_ARROW = "visual.pred.arrow", K_OTHERS = "visual.pred.others",
            K_LINE = "visual.pred.line", K_TIME = "visual.pred.time", K_COLOR = "visual.pred.color";

    private static final int HIT = 0xFF8A4D;          // marker color when the projectile would hit an entity
    private static final int MAX_STEPS = 160;         // 8 seconds of flight

    static int color() {
        int i = Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, ShrineCfg.integer(K_COLOR, 0)));
        return ShrineGui.PALETTE[i];
    }

    // ---------- projection (hand-made, for absolute world points) ----------
    static final class Cam {
        final Vec3d pos;
        final double fx, fy, fz, rx, rz, ux, uy, uz, W, H, tanHalf;

        Cam(MinecraftClient mc, DrawContext ctx, float td) {
            pos = mc.player.getCameraPosVec(td);
            double yr = Math.toRadians(mc.player.getYaw(td)), pr = Math.toRadians(mc.player.getPitch(td));
            fx = -Math.sin(yr) * Math.cos(pr);
            fy = -Math.sin(pr);
            fz = Math.cos(yr) * Math.cos(pr);
            rx = -Math.cos(yr);
            rz = -Math.sin(yr);
            ux = -rz * fy;
            uy = rz * fx - rx * fz;
            uz = rx * fy;
            W = ctx.getScaledWindowWidth();
            H = ctx.getScaledWindowHeight();
            tanHalf = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        }

        /** out = {x, y, pixelsPerBlock}; false when the point is behind the camera. */
        boolean p(double wx, double wy, double wz, float[] out) {
            double x = wx - pos.x, y = wy - pos.y, z = wz - pos.z;
            double zc = x * fx + y * fy + z * fz;
            if (zc < 0.1) return false;
            double xc = x * rx + z * rz, yc = x * ux + y * uy + z * uz;
            double k = (H / 2.0) / (zc * tanHalf);
            out[0] = (float) (W / 2.0 + xc * k);
            out[1] = (float) (H / 2.0 - yc * k);
            out[2] = (float) k;
            return true;
        }
    }

    /** A flat surface the marker lies on: (du, dv) in blocks from the landing point -> screen. */
    interface Surf { boolean at(double du, double dv, float[] out); }

    // ---------- physics ----------
    private static final class Path {
        final List<Vec3d> pts = new ArrayList<>();
        Vec3d end, normal = new Vec3d(0, 1, 0);
        BlockPos block;
        LivingEntity entity;
        boolean landed;
        float time;
    }

    private record Launch(double speed, double gravity, double waterDrag, float roll, float yawOff) {}

    private static boolean on(String k) { return ShrineCfg.bool(k, true); }

    /** What the player is about to throw / shoot (empty when nothing or the group is switched off). */
    private static List<Launch> held(PlayerEntity p) {
        List<Launch> out = new ArrayList<>();
        for (ItemStack s : new ItemStack[]{p.getMainHandStack(), p.getOffHandStack()}) {
            if (s.isEmpty()) continue;
            if (s.isOf(Items.ENDER_PEARL)) {
                if (on(K_PEARL)) out.add(new Launch(1.5, 0.03, 0.8, 0f, 0f));
                return out;
            }
            if (s.isOf(Items.SNOWBALL) || s.isOf(Items.EGG)) {
                if (on(K_SNOW)) out.add(new Launch(1.5, 0.03, 0.8, 0f, 0f));
                return out;
            }
            if (s.isOf(Items.SPLASH_POTION) || s.isOf(Items.LINGERING_POTION)) {
                if (on(K_POTION)) out.add(new Launch(0.5, 0.05, 0.8, -20f, 0f));
                return out;
            }
            if (s.isOf(Items.EXPERIENCE_BOTTLE)) {
                if (on(K_POTION)) out.add(new Launch(0.7, 0.07, 0.8, -20f, 0f));
                return out;
            }
            if (s.isOf(Items.BOW)) {
                if (!on(K_ARROW) || !p.isUsingItem() || !p.getActiveItem().isOf(Items.BOW)) return out;
                float pull = BowItem.getPullProgress(p.getItemUseTime());
                if (pull >= 0.1f) out.add(new Launch(pull * 3.0, 0.05, 0.6, 0f, 0f));
                return out;
            }
            if (s.isOf(Items.CROSSBOW)) {
                ChargedProjectilesComponent c = s.get(DataComponentTypes.CHARGED_PROJECTILES);
                if (c == null || c.isEmpty()) continue;
                List<ItemStack> li = c.getProjectiles();
                if (!on(K_ARROW) || li.isEmpty() || li.get(0).isOf(Items.FIREWORK_ROCKET)) return out;
                int n = li.size();
                for (int i = 0; i < n; i++)
                    out.add(new Launch(3.15, 0.05, 0.6, 0f, n == 1 ? 0f : (i - (n - 1) / 2f) * 10f));
                return out;
            }
            if (s.isOf(Items.TRIDENT)) {
                if (on(K_ARROW) && p.isUsingItem() && p.getActiveItem().isOf(Items.TRIDENT) && p.getItemUseTime() >= 10)
                    out.add(new Launch(2.5, 0.05, 0.99, 0f, 0f));
                return out;
            }
        }
        return out;
    }

    private static Vec3d launchVel(PlayerEntity p, float td, Launch l) {
        double yaw = Math.toRadians(p.getYaw(td) + l.yawOff()), pitch = Math.toRadians(p.getPitch(td)), roll = Math.toRadians(l.roll());
        Vec3d d = new Vec3d(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch + roll), Math.cos(yaw) * Math.cos(pitch))
                .normalize().multiply(l.speed());
        Vec3d m = p.getVelocity();
        return d.add(m.x, p.isOnGround() ? 0.0 : m.y, m.z);
    }

    /** 0 = not a projectile we track, 1 pearl, 2 snowball/egg, 3 potion/bottle, 4 arrow/trident. */
    private static int group(EntityType<?> t) {
        if (t == EntityType.ENDER_PEARL) return 1;
        if (t == EntityType.SNOWBALL || t == EntityType.EGG) return 2;
        if (t == EntityType.SPLASH_POTION || t == EntityType.LINGERING_POTION || t == EntityType.EXPERIENCE_BOTTLE) return 3;
        if (t == EntityType.ARROW || t == EntityType.SPECTRAL_ARROW || t == EntityType.TRIDENT) return 4;
        return 0;
    }

    private static double gravityOf(EntityType<?> t) {
        if (t == EntityType.EXPERIENCE_BOTTLE) return 0.07;
        if (t == EntityType.SPLASH_POTION || t == EntityType.LINGERING_POTION) return 0.05;
        if (group(t) == 4) return 0.05;
        return 0.03;
    }

    private static Path simulate(MinecraftClient mc, Vec3d pos, Vec3d vel, double g, double wdrag, List<LivingEntity> targets) {
        Path p = new Path();
        p.pts.add(pos);
        for (int i = 0; i < MAX_STEPS; i++) {
            Vec3d next = pos.add(vel);
            double len = Math.max(1e-6, vel.length());

            LivingEntity he = null;
            Vec3d hp = null;
            double hd = Double.MAX_VALUE;
            for (LivingEntity e : targets) {
                Optional<Vec3d> r = e.getBoundingBox().expand(0.3).raycast(pos, next);
                if (r.isPresent()) {
                    double d = r.get().squaredDistanceTo(pos);
                    if (d < hd) { hd = d; he = e; hp = r.get(); }
                }
            }
            BlockHitResult bh = mc.world.raycast(new RaycastContext(pos, next,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
            boolean blk = bh.getType() != HitResult.Type.MISS;
            double bd = blk ? bh.getPos().squaredDistanceTo(pos) : Double.MAX_VALUE;

            if (he != null && hd <= bd) {
                p.pts.add(hp);
                p.end = hp;
                p.entity = he;
                p.landed = true;
                p.time = (float) ((i + Math.sqrt(hd) / len) * 0.05);
                return p;
            }
            if (blk) {
                Vec3d hit = bh.getPos();
                p.pts.add(hit);
                p.end = hit;
                p.block = bh.getBlockPos();
                p.normal = new Vec3d(bh.getSide().getOffsetX(), bh.getSide().getOffsetY(), bh.getSide().getOffsetZ());
                p.landed = true;
                p.time = (float) ((i + Math.sqrt(bd) / len) * 0.05);
                return p;
            }
            pos = next;
            p.pts.add(pos);
            boolean water = !mc.world.getFluidState(BlockPos.ofFloored(pos)).isEmpty();
            vel = vel.multiply(water ? wdrag : 0.99).add(0, -g, 0);
            if (pos.y < mc.world.getBottomY() - 8) break;
        }
        p.end = pos;
        p.time = (p.pts.size() - 1) * 0.05f;
        return p;
    }

    // ---------- in-game element ----------
    static void register() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "predictions"),
                (ctx, tick) -> render(ctx, tick.getTickProgress(false)));
    }

    private static void render(DrawContext ctx, float td) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.options.hudHidden) return;
        if (!ShrineCfg.bool(KEY, true)) return;
        if (!mc.options.getPerspective().isFirstPerson()) return;

        Cam cam = new Cam(mc, ctx, td);
        float t = Util.getMeasuringTimeMs() / 1000f;
        int rgb = color();
        boolean line = ShrineCfg.bool(K_LINE, true), time = ShrineCfg.bool(K_TIME, true), others = ShrineCfg.bool(K_OTHERS, true);

        List<LivingEntity> targets = new ArrayList<>();
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof LivingEntity le && le != mc.player && le.isAlive() && !le.isSpectator()
                    && le.squaredDistanceTo(mc.player) < 120.0 * 120.0) targets.add(le);
        }

        // 1) what you are about to throw
        for (Launch l : held(mc.player)) {
            Vec3d start = cam.pos.add(0, -0.1, 0);
            Path p = simulate(mc, start, launchVel(mc.player, td, l), l.gravity(), l.waterDrag(), targets);
            draw(ctx, mc.textRenderer, cam, p, rgb, line, time, t);
        }

        // 2) projectiles already flying
        int shown = 0;
        for (Entity e : mc.world.getEntities()) {
            if (shown >= 24) break;
            int g = group(e.getType());
            if (g == 0) continue;
            boolean mine = e instanceof ProjectileEntity pe && pe.getOwner() == mc.player;
            if (!mine && !others) continue;
            if (!on(g == 1 ? K_PEARL : g == 2 ? K_SNOW : g == 3 ? K_POTION : K_ARROW)) continue;
            Vec3d v = e.getVelocity();
            if (v.lengthSquared() < 0.01) continue;                 // arrow stuck in a block
            Vec3d pos = e.getLerpedPos(td);
            if (pos.squaredDistanceTo(cam.pos) > 150.0 * 150.0) continue;
            double wd = g == 4 ? (e.getType() == EntityType.TRIDENT ? 0.99 : 0.6) : 0.8;
            Path p = simulate(mc, pos, v, gravityOf(e.getType()), wd, targets);
            draw(ctx, mc.textRenderer, cam, p, rgb, line, time, t);
            shown++;
        }
    }

    private static void draw(DrawContext ctx, TextRenderer tr, Cam cam, Path p, int rgb, boolean line, boolean time, float t) {
        int col = p.entity != null ? HIT : rgb;
        float[] o = new float[3];

        if (line) {
            float[][] sp = new float[p.pts.size()][];
            for (int i = 0; i < sp.length; i++) {
                Vec3d v = p.pts.get(i);
                sp[i] = cam.p(v.x, v.y, v.z, o) ? new float[]{o[0], o[1]} : null;
            }
            polyline(ctx, sp, col, 1f, t);
        }
        if (!p.landed || p.end == null) return;
        Vec3d e = p.end;

        if (p.entity != null) {
            // would hit a creature: a ring around it
            LivingEntity le = p.entity;
            if (cam.p(le.getX(), le.getY() + le.getHeight() * 0.5, le.getZ(), o)) {
                float r = Math.max(8f, Math.max(le.getHeight(), le.getWidth()) * 0.55f * o[2]);
                screenRing(ctx, o[0], o[1], r, 1.6f, col, t);
                if (time) card(ctx, tr, o[0], o[1] - r - 22f, p.time, col, 1f);
            }
            return;
        }
        // flat marker on the surface that is hit
        Vec3d n = p.normal;
        double ux, uy, uz, vx, vy, vz;
        if (Math.abs(n.y) > 0.5) { ux = 1; uy = 0; uz = 0; vx = 0; vy = 0; vz = 1; }
        else { ux = -n.z; uy = 0; uz = n.x; vx = 0; vy = 1; vz = 0; }
        final double cx = e.x + n.x * 0.03, cy = e.y + n.y * 0.03, cz = e.z + n.z * 0.03;
        final double fux = ux, fuy = uy, fuz = uz, fvx = vx, fvy = vy, fvz = vz;
        Surf s = (du, dv, out) -> cam.p(cx + fux * du + fvx * dv, cy + fuy * du + fvy * dv, cz + fuz * du + fvz * dv, out);

        double bu = 0, bv = 0;
        if (p.block != null) {
            Vec3d bc = Vec3d.ofCenter(p.block).add(n.x * 0.5, n.y * 0.5, n.z * 0.5);
            bu = (bc.x - e.x) * ux + (bc.y - e.y) * uy + (bc.z - e.z) * uz;
            bv = (bc.x - e.x) * vx + (bc.y - e.y) * vy + (bc.z - e.z) * vz;
        }
        marker(ctx, s, col, 1f, t, bu, bv);
        if (time && cam.p(e.x, e.y, e.z, o)) card(ctx, tr, o[0], o[1] - 46f, p.time, col, 1f);
    }

    // ---------- drawing ----------
    private static int mix(int c1, int c2, float k) {
        int r = Math.round(((c1 >> 16) & 255) * (1 - k) + ((c2 >> 16) & 255) * k);
        int g = Math.round(((c1 >> 8) & 255) * (1 - k) + ((c2 >> 8) & 255) * k);
        int b = Math.round((c1 & 255) * (1 - k) + (c2 & 255) * k);
        return (r << 16) | (g << 8) | b;
    }

    /** Thin line of any angle and thickness (the matrix is scaled down 4x so the int fill gets 0.25 precision). */
    static void line(DrawContext ctx, float x1, float y1, float x2, float y2, float th, int color) {
        float dx = x2 - x1, dy = y2 - y1;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 0.01f) return;
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.translate(x1, y1);
        m.rotate((float) Math.atan2(dy, dx));
        m.scale(0.25f, 0.25f);
        int t = Math.max(1, Math.round(th * 2f));
        ctx.fill(0, -t, Math.round(len * 4f) + 1, t, color);
        m.popMatrix();
    }

    /** Dashed glowing line through screen points (null = point behind the camera). Dashes slowly run forward. */
    static void polyline(DrawContext ctx, float[][] sp, int rgb, float a, float t) {
        int core = mix(rgb, 0xFFFFFF, 0.65f);
        int shift = (int) (t * 6f);
        int n = sp.length;
        for (int i = 1; i < n; i++) {
            float[] p0 = sp[i - 1], p1 = sp[i];
            if (p0 == null || p1 == null) continue;
            if (((i + shift) % 3 + 3) % 3 == 2) continue;      // gap in the dashes
            float k = 0.35f + 0.65f * i / (float) n;
            line(ctx, p0[0], p0[1], p1[0], p1[1], 3.2f, argb(0.16f * a * k, rgb));
            line(ctx, p0[0], p0[1], p1[0], p1[1], 1.2f, argb(a * k, core));
        }
    }

    /** Circle in screen space, rotating arcs (used around a creature that would be hit). */
    private static void screenRing(DrawContext ctx, float cx, float cy, float r, float th, int rgb, float t) {
        int core = mix(rgb, 0xFFFFFF, 0.5f);
        final int N = 36;
        for (int i = 0; i < N; i++) {
            double a0 = Math.PI * 2 * i / N + t * 1.2, a1 = Math.PI * 2 * (i + 1) / N + t * 1.2;
            if (i % 9 >= 6) continue;                          // 3 gaps
            float x0 = cx + (float) Math.cos(a0) * r, y0 = cy + (float) Math.sin(a0) * r;
            float x1 = cx + (float) Math.cos(a1) * r, y1 = cy + (float) Math.sin(a1) * r;
            line(ctx, x0, y0, x1, y1, th * 2.4f, argb(0.18f, rgb));
            line(ctx, x0, y0, x1, y1, th, argb(0.95f, core));
        }
    }

    private static void arc(DrawContext ctx, Surf s, float[] o, double r, double a0, double a1, float thM, int rgb, float al, double du0, double dv0) {
        int n = Math.max(4, (int) (Math.abs(a1 - a0) / 0.14));
        float px = 0, py = 0;
        boolean has = false;
        for (int i = 0; i <= n; i++) {
            double an = a0 + (a1 - a0) * i / n;
            if (!s.at(du0 + Math.cos(an) * r, dv0 + Math.sin(an) * r, o)) { has = false; continue; }
            if (has) line(ctx, px, py, o[0], o[1], Math.max(0.8f, thM * o[2]), argb(al, rgb));
            px = o[0]; py = o[1]; has = true;
        }
    }

    /**
     * The landing marker: segmented rotating outer ring, glassy disc, thin white inner ring, filled diamond in the
     * middle and a thin outline of the block face it lands on (bu / bv = where that face is, in blocks).
     */
    static void marker(DrawContext ctx, Surf s, int rgb, float a, float t, double bu, double bv) {
        float[] o = new float[3];
        int pale = mix(rgb, 0xFFFFFF, 0.35f);
        double R = 0.72 * (1.0 + 0.025 * Math.sin(t * 3.0));

        // block face outline
        double[][] sq = {{-0.5, -0.5}, {0.5, -0.5}, {0.5, 0.5}, {-0.5, 0.5}};
        float[][] sc = new float[4][];
        for (int i = 0; i < 4; i++) sc[i] = s.at(bu + sq[i][0], bv + sq[i][1], o) ? new float[]{o[0], o[1]} : null;
        for (int i = 0; i < 4; i++) {
            float[] p0 = sc[i], p1 = sc[(i + 1) % 4];
            if (p0 != null && p1 != null) line(ctx, p0[0], p0[1], p1[0], p1[1], 0.8f, argb(0.30f * a, 0xFFFFFF));
        }

        // glass disc: a few wide, faint concentric strokes
        for (double r = 0.12; r < R - 0.05; r += 0.11)
            arc(ctx, s, o, r, 0, Math.PI * 2, 0.13f, 0xFFFFFF, 0.045f * a, 0, 0);
        arc(ctx, s, o, R - 0.04, 0, Math.PI * 2, 0.02f, 0xFFFFFF, 0.35f * a, 0, 0);

        // outer ring: 6 arcs, slowly turning
        double base = t * 0.7;
        for (int i = 0; i < 6; i++) {
            double a0 = base + i * Math.PI / 3, a1 = a0 + Math.PI / 3 * 0.66;
            arc(ctx, s, o, R, a0, a1, 0.13f, rgb, 0.20f * a, 0, 0);
            arc(ctx, s, o, R, a0, a1, 0.075f, pale, a, 0, 0);
        }

        // inner ring
        arc(ctx, s, o, 0.22, 0, Math.PI * 2, 0.06f, 0xFFFFFF, 0.30f * a, 0, 0);
        arc(ctx, s, o, 0.22, 0, Math.PI * 2, 0.035f, 0xFFFFFF, 0.95f * a, 0, 0);

        // center diamond (filled with horizontal strokes)
        final int N = 7;
        double d = 0.11;
        for (int k = -N; k <= N; k++) {
            double dv = d * k / N, hw = d - Math.abs(dv);
            float[] l = new float[3], rr = new float[3];
            if (!s.at(-hw, dv, l) || !s.at(hw, dv, rr)) continue;
            float th = Math.max(1.3f, (float) (d / N * 1.5) * l[2]);
            line(ctx, l[0], l[1], rr[0], rr[1], th, argb(a, pale));
        }
    }

    /** "до падения 0.4s" card. */
    static void card(DrawContext ctx, TextRenderer tr, float cx, float cy, float seconds, int rgb, float a) {
        String v = String.format(Locale.ROOT, "%.1fs", seconds);
        float w = 104f, h = 24f, x = cx - w / 2f, y = cy - h / 2f;
        box(ctx, RR, x, y, w, h, 12, argb(0.82f * a, 0x150A0F));
        box(ctx, RR_RING, x, y, w, h, 12, argb(0.35f * a, rgb));
        text(ctx, tr, Fnt.TINY_B, "до падения", x + 11, cy, argb(0.55f * a, 0xFFFFFF));
        text(ctx, tr, Fnt.SMALL, v, x + w - 11 - width(tr, Fnt.SMALL, v), cy, argb(a, 0xFFFFFF));
    }
}

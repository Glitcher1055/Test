package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.util.Arrays;

import static com.shrine.Gfx.*;

/**
 * HUD > "Инвентарь": a 9x3 grid with the main inventory of the player (the hotbar is already on screen), with stack
 * counts and durability bars. It fades away when the inventory is empty and is hidden while any screen is open.
 *
 * Settings: size, panel background, slot backgrounds. Position and size are saved in the config and edited in
 * {@link HudEditScreen}. The panel is anchored to the top-left corner of the screen.
 */
final class InventoryHud {
    private InventoryHud() {}

    static final String KEY = "hud.inventory", K_BG = "hud.inventory.bg", K_SLOTS = "hud.inventory.slots",
            K_SCALE = "hud.inventory.scale", K_X = "hud.inventory.x", K_Y = "hud.inventory.y";

    static final int COLS = 9, ROWS = 3;
    static final float SLOT = 22f, GAP = 2f, PAD = 7f, MARGIN = 14f;
    static final float W = PAD * 2f + COLS * SLOT + (COLS - 1) * GAP;
    static final float H = PAD * 2f + ROWS * SLOT + (ROWS - 1) * GAP;
    private static final int FIRST_SLOT = 9;                 // 0..8 is the hotbar

    /** What a panel shows: the real inventory or demo items. */
    static final class Data {
        final ItemStack[] slots = new ItemStack[COLS * ROWS];
        { Arrays.fill(slots, ItemStack.EMPTY); }
    }

    private static final Data live = new Data();
    private static float vis;
    private static long lastMs;

    static void register() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "inventory_hud"),
                (ctx, tick) -> render(ctx));
    }

    // ---------- settings ----------
    static float posX() { return ShrineCfg.num(K_X, 0f); }
    static float posY() { return ShrineCfg.num(K_Y, 0f); }
    static float scale() { return Math.max(0.5f, Math.min(2.0f, ShrineCfg.num(K_SCALE, 1f))); }

    /** Top-left corner of the panel in virtual units, kept on screen whatever the window shape is. */
    static float[] origin(float vw) {
        float s = scale();
        float x = Math.max(0f, Math.min(vw - W * s, MARGIN + posX()));
        float y = Math.max(0f, Math.min(Scene.REF_H - H * s, MARGIN + posY()));
        return new float[]{x, y};
    }

    /** Fake items for the position editor. */
    static Data demo() {
        Data d = new Data();
        ItemStack[] pool = {
                new ItemStack(Items.DIAMOND_SWORD), new ItemStack(Items.GOLDEN_APPLE, 12), new ItemStack(Items.ENDER_PEARL, 16),
                new ItemStack(Items.DIAMOND_PICKAXE), new ItemStack(Items.COOKED_BEEF, 64), new ItemStack(Items.TOTEM_OF_UNDYING),
                new ItemStack(Items.OAK_LOG, 48), new ItemStack(Items.SHIELD), new ItemStack(Items.ARROW, 32),
                new ItemStack(Items.IRON_INGOT, 27), new ItemStack(Items.BOW), new ItemStack(Items.EXPERIENCE_BOTTLE, 8)};
        int[] at = {0, 2, 3, 5, 6, 9, 10, 12, 13, 15, 18, 20, 21, 23, 24};
        for (int i = 0; i < at.length; i++) d.slots[at[i]] = pool[i % pool.length];
        return d;
    }

    // ---------- the in-game element ----------
    private static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.currentScreen != null || mc.options.hudHidden) return;
        if (!ShrineCfg.bool(KEY, true)) { vis = 0f; return; }

        long now = Util.getMeasuringTimeMs();
        float dt = lastMs == 0L ? 0f : Math.min(0.1f, (now - lastMs) / 1000f);
        lastMs = now;

        PlayerInventory inv = mc.player.getInventory();
        boolean empty = true;
        for (int i = 0; i < live.slots.length; i++) {
            ItemStack st = inv.getStack(FIRST_SLOT + i);
            live.slots[i] = st;
            if (!st.isEmpty()) empty = false;
        }

        vis += ((empty ? 0f : 1f) - vis) * Math.min(1f, dt * 12f);
        if (vis < 0.01f) return;
        float a = 1f - (1f - vis) * (1f - vis);
        drawAt(ctx, mc.textRenderer, live, a, -10f * (1f - a));
    }

    /** Draws the panel at its configured position and size. */
    static void drawAt(DrawContext ctx, TextRenderer tr, Data d, float a, float slideX) {
        MinecraftClient mc = MinecraftClient.getInstance();
        float k = mc.getWindow().getScaledHeight() / Scene.REF_H;
        float vw = mc.getWindow().getScaledWidth() / k;
        float[] o = origin(vw);
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        ctx.getMatrices().translate(o[0] + slideX, o[1]);
        ctx.getMatrices().scale(scale(), scale());
        panel(ctx, tr, d, a);
        ctx.getMatrices().popMatrix();
    }

    // ---------- the panel (origin = top-left corner, virtual units) ----------
    static void panel(DrawContext ctx, TextRenderer tr, Data d, float a) {
        boolean bg = ShrineCfg.bool(K_BG, true), slotBg = ShrineCfg.bool(K_SLOTS, true);
        if (bg) {
            box(ctx, RR, -1, -1, W + 2, H + 2, 15, argb(0.50f * a, ACCENT));
            box(ctx, RR, 0, 0, W, H, 14, argb(0.88f * a, 0x150A0F));
        }
        for (int i = 0; i < COLS * ROWS; i++) {
            float sx = PAD + (i % COLS) * (SLOT + GAP), sy = PAD + (i / COLS) * (SLOT + GAP);
            if (slotBg) {
                box(ctx, RR, sx, sy, SLOT, SLOT, 7, argb(0.40f * a, 0x000000));
                box(ctx, RR_RING, sx, sy, SLOT, SLOT, 7, argb(0.10f * a, 0xFFFFFF));
            }
            ItemStack st = d.slots[i];
            if (st == null || st.isEmpty() || a < 0.5f) continue;     // items cannot be faded, so they appear halfway
            item(ctx, st, sx + (SLOT - 16f) / 2f, sy + (SLOT - 16f) / 2f);
            overlay(ctx, tr, st, sx, sy, a);
        }
    }

    private static void item(DrawContext ctx, ItemStack st, float x, float y) {
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(x, y);
        ctx.drawItem(st, 0, 0);
        ctx.getMatrices().popMatrix();
    }

    /** Stack count in the corner and the durability bar of damaged tools. */
    private static void overlay(DrawContext ctx, TextRenderer tr, ItemStack st, float sx, float sy, float a) {
        if (st.getCount() > 1) {
            String n = String.valueOf(st.getCount());
            text(ctx, tr, Fnt.TINY_B, n, sx + SLOT - 2f - width(tr, Fnt.TINY_B, n), sy + SLOT - 5f, argb(a, 0xFFFFFF));
        }
        if (st.isItemBarVisible()) {
            float bw = 14f, bx = sx + (SLOT - bw) / 2f, by = sy + SLOT - 4.5f;
            box(ctx, RR, bx, by, bw, 2f, 1f, argb(0.85f * a, 0x000000));
            box(ctx, RR, bx, by, Math.max(1.5f, bw * st.getItemBarStep() / 13f), 2f, 1f, argb(a, st.getItemBarColor()));
        }
    }
}

package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

import static com.shrine.Gfx.*;

/**
 * HUD > "Плашка": a rounded bar that always sits at the top center of the screen:
 * [logo]  name | server | FPS | ping.
 * Every part can be switched off; size and the distance from the top edge are settings.
 */
final class Watermark {
    private Watermark() {}

    static final String KEY = "hud.watermark", K_NAME = "hud.watermark.name", K_SERVER = "hud.watermark.server",
            K_FPS = "hud.watermark.fps", K_PING = "hud.watermark.ping", K_SCALE = "hud.watermark.scale",
            K_TOP = "hud.watermark.top";

    private static final float H = 32f, PAD = 12f, ICON = 20f, SEP = 12f;
    private static final int PINK = 0xFFC4C4;

    private static int shownFps, shownPing;
    private static long statAt;

    static void register() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "watermark"),
                (ctx, tick) -> render(ctx));
    }

    private static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        if (!ShrineCfg.bool(KEY, true)) return;
        TextRenderer tr = mc.textRenderer;

        // FPS / ping are refreshed 4 times per second, so the numbers can be read
        long now = System.currentTimeMillis();
        if (now - statAt > 250L) {
            statAt = now;
            shownFps = mc.getCurrentFps();
            shownPing = 0;
            if (mc.getNetworkHandler() != null) {
                PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
                if (e != null) shownPing = e.getLatency();
            }
        }

        List<String> parts = new ArrayList<>();
        if (ShrineCfg.bool(K_NAME, true)) parts.add("Shrine");
        if (ShrineCfg.bool(K_SERVER, false)) {
            ServerInfo si = mc.getCurrentServerEntry();
            parts.add(si == null ? "Одиночная игра" : si.address);
        }
        if (ShrineCfg.bool(K_FPS, true)) parts.add(shownFps + " FPS");
        if (ShrineCfg.bool(K_PING, true)) parts.add(shownPing + "ms");

        // width of the bar in virtual units: pad, logo, gap, texts separated by 24-unit gaps with a divider, pad
        float w = PAD + ICON + 8f + PAD;
        for (int i = 0; i < parts.size(); i++) w += width(tr, Fnt.LABEL, parts.get(i)) + (i > 0 ? SEP * 2f : 0f);
        if (parts.isEmpty()) w = PAD * 2f + ICON;

        float k = mc.getWindow().getScaledHeight() / Scene.REF_H;
        float vw = mc.getWindow().getScaledWidth() / k;
        float sc = Math.max(0.6f, Math.min(1.6f, ShrineCfg.num(K_SCALE, 1f)));
        float top = Math.max(0f, Math.min(60f, ShrineCfg.num(K_TOP, 10f)));

        var m = ctx.getMatrices();
        m.pushMatrix();
        m.scale(k, k);
        m.translate(vw / 2f, top);
        m.scale(sc, sc);
        draw(ctx, tr, parts, w);
        m.popMatrix();
    }

    /** Origin = top center of the bar. */
    private static void draw(DrawContext ctx, TextRenderer tr, List<String> parts, float w) {
        float x = -w / 2f, cy = H / 2f;
        box(ctx, RR, x - 5, -4, w + 10, H + 8, 20, argb(0.10f, ACCENT));       // soft glow
        box(ctx, RR, x - 1, -1, w + 2, H + 2, 17, argb(0.55f, ACCENT));        // red rim
        box(ctx, RR, x, 0, w, H, 16, argb(0.90f, 0x1A0508));                   // body
        box(ctx, RR_RING, x, 0, w, H, 16, argb(0.35f, ACCENT));

        centered(ctx, LOGO, x + PAD + ICON / 2f, cy, ICON, ICON, argb(1f, ACCENT));
        float px = x + PAD + ICON + 8f;
        for (int i = 0; i < parts.size(); i++) {
            if (i > 0) {
                px += SEP;
                ctx.fill(Math.round(px), Math.round(cy - 8f), Math.round(px) + 1, Math.round(cy + 8f), argb(0.28f, 0xFFFFFF));
                px += SEP;
            }
            String s = parts.get(i);
            text(ctx, tr, Fnt.LABEL, s, px, cy, argb(1f, i == 0 && "Shrine".equals(s) ? PINK : 0xF4E4E4));
            px += width(tr, Fnt.LABEL, s);
        }
    }
}

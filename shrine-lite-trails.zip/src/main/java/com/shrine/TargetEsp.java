package com.shrine;

import com.shrine.Predictions.Cam;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;

import static com.shrine.Gfx.*;

/**
 * Target > "Target ESP": the creature you aim at gets a glowing effect around it.
 *
 * The effect exists only while the crosshair is on the target: move the aim away and it disappears at once.
 * Styles are picked from a list (Target > Target ESP > Стиль): crystals, glass ring, comets, ground circles,
 * soft orbs, lock-on brackets, flat shards, spinning cubes, a chain ring, light flares and dashed rings.
 *
 * Same technique as {@link Predictions}: a 2D overlay, world points are projected to the screen by hand.
 * Everything is animated from one clock ({@link #anim}) that runs at the "Скорость" setting.
 */
final class TargetEsp {
    private TargetEsp() {}

    static final String KEY = "target.esp", K_STYLE = "target.esp.style", K_COLOR = "target.esp.color",
            K_SPEED = "target.esp.speed";
    static final String[] STYLES = {
            "Кристаллы", "Кольцо", "Кометы", "Круги", "Шары", "Скобки",
            "Осколки", "Кубики", "Цепь", "Вспышки", "Пунктир"
    };

    private static final double TAU = Math.PI * 2.0;
    private static final long FADE_IN_MS = 300L;

    private static LivingEntity target;
    private static long shownAt, lastMs;
    private static float anim;

    static int color() {
        int i = Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, ShrineCfg.integer(K_COLOR, 5)));
        return ShrineGui.PALETTE[i];
    }

    static void register() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "target_esp"),
                (ctx, tick) -> render(ctx, tick.getTickProgress(false)));
    }

    // ---------- helpers ----------
    private static int mix(int c1, int c2, float k) {
        int r = Math.round(((c1 >> 16) & 255) * (1 - k) + ((c2 >> 16) & 255) * k);
        int g = Math.round(((c1 >> 8) & 255) * (1 - k) + ((c2 >> 8) & 255) * k);
        int b = Math.round((c1 & 255) * (1 - k) + (c2 & 255) * k);
        return (r << 16) | (g << 8) | b;
    }

    private static float dist(float[] a, float[] b) {
        float dx = a[0] - b[0], dy = a[1] - b[1];
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    /** Fills a convex screen polygon (xs[i], ys[i]) row by row. */
    private static void fill(DrawContext ctx, float[] xs, float[] ys, int col) {
        float minY = Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
        for (float v : ys) { minY = Math.min(minY, v); maxY = Math.max(maxY, v); }
        int n = xs.length;
        for (int py = Math.round(minY); py <= Math.round(maxY); py++) {
            float sy = py + 0.5f, lo = Float.MAX_VALUE, hi = -Float.MAX_VALUE;
            for (int i = 0; i < n; i++) {
                int j = (i + 1) % n;
                float ay = ys[i], by = ys[j];
                if ((ay <= sy && by > sy) || (by <= sy && ay > sy)) {
                    float xi = xs[i] + (sy - ay) * (xs[j] - xs[i]) / (by - ay);
                    lo = Math.min(lo, xi);
                    hi = Math.max(hi, xi);
                }
            }
            if (lo <= hi) ctx.fill(Math.round(lo), py, Math.round(hi) + 1, py + 1, col);
        }
    }

    // ---------- frame ----------
    private static void render(DrawContext ctx, float td) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.options.hudHidden) return;
        if (!ShrineCfg.bool(KEY, true)) { target = null; return; }
        if (!mc.options.getPerspective().isFirstPerson()) return;

        long now = Util.getMeasuringTimeMs();
        float dt = lastMs == 0L ? 0f : Math.min(0.1f, (now - lastMs) / 1000f);
        lastMs = now;

        // the target exists only while the crosshair is on it: aim away and it is gone at once
        LivingEntity tg = null;
        if (mc.crosshairTarget instanceof EntityHitResult hr && hr.getEntity() instanceof LivingEntity hit
                && hit != mc.player && hit.isAlive() && !hit.isSpectator()) {
            tg = hit;
        }
        if (tg == null) { target = null; return; }
        if (tg != target) { target = tg; shownAt = now; }

        float speed = ShrineCfg.num(K_SPEED, 1f);
        anim += dt * speed;

        float in = Math.min(1f, (now - shownAt) / (float) FADE_IN_MS);
        float a = 1f - (1f - in) * (1f - in);

        Vec3d p = tg.getLerpedPos(td);
        Fx fx = new Fx(ctx, new Cam(mc, ctx, td), p, tg.getWidth(), tg.getHeight(), color(), a, anim);
        int style = Math.max(0, Math.min(STYLES.length - 1, ShrineCfg.integer(K_STYLE, 0)));

        switch (style) {                               // behind the body
            case 1 -> fx.glassRing();
            case 3 -> fx.groundRipples();
            case 10 -> fx.dashed();
            default -> { }
        }
        switch (style) {                               // in front of it
            case 0 -> fx.crystals();
            case 2 -> fx.comets();
            case 4 -> fx.orbs();
            case 5 -> fx.brackets();
            case 6 -> fx.shards();
            case 7 -> fx.cubes();
            case 8 -> fx.chain();
            case 9 -> fx.flares();
            default -> { }
        }
    }

    // ---------- the effects ----------
    private static final class Fx {
        final DrawContext ctx;
        final Cam cam;
        final double x, y, z, w, h;     // feet center, hitbox width and height
        final int rgb;
        final float a, t;
        final float[] o = new float[3]; // last projected point: x, y, pixels per block

        Fx(DrawContext ctx, Cam cam, Vec3d p, double w, double h, int rgb, float a, float t) {
            this.ctx = ctx; this.cam = cam; this.x = p.x; this.y = p.y; this.z = p.z;
            this.w = w; this.h = h; this.rgb = rgb; this.a = a; this.t = t;
        }

        boolean pt(double wx, double wy, double wz) { return cam.p(wx, wy, wz, o); }

        /** Circle / arc lying on a horizontal plane at height gy around the target (drawn as projected segments). */
        void ringXZ(double gy, double r, double a0, double a1, float thBlocks, int col, float al, double step) {
            int n = Math.max(3, (int) Math.ceil(Math.abs(a1 - a0) / step));
            float px = 0f, py = 0f;
            boolean has = false;
            for (int i = 0; i <= n; i++) {
                double an = a0 + (a1 - a0) * i / n;
                if (!pt(x + Math.cos(an) * r, gy, z + Math.sin(an) * r)) { has = false; continue; }
                if (has) Predictions.line(ctx, px, py, o[0], o[1], Math.max(0.8f, thBlocks * o[2]), argb(al, col));
                px = o[0]; py = o[1]; has = true;
            }
        }

        // ---------- style 0: crystals ----------
        /** Faceted gem: a diamond filled with horizontal strokes, lighter in the middle, over a soft glow. */
        void gem(float sx, float sy, float hw, float hh, int col) {
            centered(ctx, GLOW, sx, sy, hh * 5f, hh * 5f, argb(0.45f * a, col));
            int n = Math.max(4, Math.min(10, Math.round(hh)));
            for (int k = -n; k <= n; k++) {
                float f = 1f - Math.abs(k) / (float) n, dy = hh * k / n, half = hw * f;
                Predictions.line(ctx, sx - half, sy + dy, sx + half, sy + dy, Math.max(1f, hh / n * 1.3f),
                        argb(0.92f * a, mix(col, 0xFFFFFF, 0.15f + 0.45f * f)));
            }
            Predictions.line(ctx, sx, sy - hh, sx, sy + hh, 0.8f, argb(0.5f * a, 0xFFFFFF));
        }

        void crystals() {
            final int n = 7;
            int col = mix(rgb, 0xFF4FD8, 0.55f);
            for (int i = 0; i < n; i++) {
                double an = t * 1.1 + i * TAU / n;
                double r = w * 0.5 + 0.55 + 0.1 * Math.sin(t * 1.7 + i * 1.3);
                double yy = y + h * (0.12 + 0.78 * (0.5 + 0.5 * Math.sin(t * 1.2 + i * 1.9)));
                if (!pt(x + Math.cos(an) * r, yy, z + Math.sin(an) * r)) continue;
                float hh = Math.max(3f, 0.2f * o[2]);
                float spin = (float) Math.abs(Math.cos(t * 2.4 + i));          // the gem turns around its axis
                gem(o[0], o[1], hh * (0.38f + 0.35f * spin), hh, col);
            }
        }

        // ---------- style 1: glass ring ----------
        /** Translucent band that slides up and down the body, flaring at the top, with bright rims. */
        void glassRing() {
            final int n = 40;
            double ph = 0.5 + 0.5 * Math.sin(t * 0.9);
            double bh = 0.30 + 0.22 * (0.5 + 0.5 * Math.sin(t * 1.7 + 1.0));
            double y0 = y - 0.05 + (h + 0.1 - bh) * ph, y1 = y0 + bh;
            double rb = w * 0.5 + 0.28 + 0.05 * Math.sin(t * 2.3);
            double rt = rb * (1.0 + 0.22 * (0.5 + 0.5 * Math.sin(t * 0.9 + 0.8)));
            float[][] bot = new float[n + 1][], top = new float[n + 1][];
            for (int i = 0; i <= n; i++) {
                double an = TAU * i / n + t * 0.5, c = Math.cos(an), s = Math.sin(an);
                bot[i] = pt(x + c * rb, y0, z + s * rb) ? new float[]{o[0], o[1]} : null;
                top[i] = pt(x + c * rt, y1, z + s * rt) ? new float[]{o[0], o[1]} : null;
            }
            for (int i = 0; i < n; i++) {
                float[] b0 = bot[i], b1 = bot[i + 1], t0 = top[i], t1 = top[i + 1];
                if (b0 == null || b1 == null || t0 == null || t1 == null) continue;
                double mid = TAU * (i + 0.5) / n + t * 0.5, nx = Math.cos(mid), nz = Math.sin(mid);
                double vx = cam.pos.x - (x + nx * rb), vz = cam.pos.z - (z + nz * rb);
                double face = Math.abs((nx * vx + nz * vz) / Math.max(1e-6, Math.sqrt(vx * vx + vz * vz)));  // 1 = facing us
                float th = Math.max(dist(b0, b1), dist(t0, t1)) + 0.8f;
                float al = (0.07f + 0.20f * (1f - (float) face)) * a;                                      // glass: stronger at the rim
                Predictions.line(ctx, (b0[0] + b1[0]) / 2f, (b0[1] + b1[1]) / 2f, (t0[0] + t1[0]) / 2f, (t0[1] + t1[1]) / 2f,
                        th, argb(al, rgb));
            }
            int rim = mix(rgb, 0xFFFFFF, 0.55f);
            for (int i = 0; i < n; i++) {
                float[][] pair = {bot[i], bot[i + 1], top[i], top[i + 1]};
                for (int k = 0; k < 2; k++) {
                    float[] p0 = pair[k * 2], p1 = pair[k * 2 + 1];
                    if (p0 == null || p1 == null) continue;
                    Predictions.line(ctx, p0[0], p0[1], p1[0], p1[1], 3.0f, argb(0.14f * a, rgb));
                    Predictions.line(ctx, p0[0], p0[1], p1[0], p1[1], 0.9f, argb(0.75f * a, rim));
                }
            }
        }

        // ---------- style 2: comets ----------
        void comets() {
            final int tail = 24;
            double cy = y + h * 0.5;
            int core = mix(rgb, 0xFFFFFF, 0.75f);
            for (int i = 0; i < 3; i++) {
                double tilt = 0.45 + 0.5 * i, yaw = i * 2.1, rad = w * 0.5 + 0.75 + 0.1 * i;
                double a0 = t * (2.1 + 0.4 * i) + i * 2.094;
                float[] prev = null;
                float headSize = 0f;
                for (int k = 0; k <= tail; k++) {
                    double an = a0 - k * 0.06;
                    double ox = Math.cos(an) * rad, oz = Math.sin(an) * rad;
                    double ty = -oz * Math.sin(tilt), tz = oz * Math.cos(tilt);              // tilt the orbit around X
                    double wx = ox * Math.cos(yaw) + tz * Math.sin(yaw), wz = -ox * Math.sin(yaw) + tz * Math.cos(yaw);
                    double wy = cy + ty + 0.25 * Math.sin(t * 1.3 + i + k * 0.02);
                    if (!pt(x + wx, wy, z + wz)) { prev = null; continue; }
                    float fr = 1f - k / (float) tail;
                    float[] cur = {o[0], o[1]};
                    if (k == 0) headSize = Math.max(4f, 0.16f * o[2]);
                    if (prev != null) {
                        float th = Math.max(0.8f, 0.16f * o[2] * (float) Math.pow(fr, 0.8));
                        float al = 0.85f * (float) Math.pow(fr, 1.3) * a;
                        Predictions.line(ctx, prev[0], prev[1], cur[0], cur[1], th * 2.6f, argb(0.25f * al, rgb));
                        Predictions.line(ctx, prev[0], prev[1], cur[0], cur[1], th, argb(al, core));
                    }
                    prev = cur;
                    if (k == 0) {
                        centered(ctx, GLOW, cur[0], cur[1], headSize * 5f, headSize * 5f, argb(0.55f * a, rgb));
                        centered(ctx, DISC, cur[0], cur[1], headSize, headSize, argb(a, 0xFFFFFF));
                    }
                }
            }
        }

        // ---------- style 3: ground circles ----------
        void groundRipples() {
            double gy = y + 0.02, inner = w * 0.5 + 0.22, outer = w * 0.5 + 0.95;
            int pale = mix(rgb, 0xFFFFFF, 0.55f);
            for (double r = 0.12; r < outer; r += 0.13) ringXZ(gy, r, 0, TAU, 0.15f, rgb, 0.05f * a, 0.28);   // glass disc
            for (double r = 0.1; r < inner; r += 0.1) ringXZ(gy, r, 0, TAU, 0.12f, 0xFFFFFF, 0.05f * a, 0.3);  // lighter core
            ringXZ(gy, outer, 0, TAU, 0.035f, pale, 0.45f * a, 0.12);
            for (int i = 0; i < 6; i++) {                                                                       // turning inner arcs
                double s0 = t * 0.9 + i * TAU / 6, s1 = s0 + TAU / 6 * 0.62;
                ringXZ(gy, inner, s0, s1, 0.11f, rgb, 0.22f * a, 0.14);
                ringXZ(gy, inner, s0, s1, 0.06f, pale, a, 0.14);
            }
            for (int j = 0; j < 2; j++) {                                                                       // ripples running outwards
                double ph = (t * 0.45 + j * 0.5) % 1.0;
                ringXZ(gy, inner + (outer + 0.45 - inner) * ph, 0, TAU, 0.05f, pale, (1f - (float) ph) * 0.7f * a, 0.12);
            }
        }

        // ---------- style 4: soft orbs ----------
        void orbs() {
            int col = mix(rgb, 0x8FA8FF, 0.5f);
            for (int i = 0; i < 9; i++) {
                double r = w * 0.5 + 0.35 + 0.45 * (0.5 + 0.5 * Math.sin(t * (0.5 + 0.17 * i) + i * 2.1));
                double an = t * (0.7 + 0.13 * i) * 0.6 + i * 0.7;
                double yy = y + h * (0.5 + 0.5 * Math.sin(t * (0.9 + 0.11 * i) * 0.5 + i * 1.3));
                if (!pt(x + Math.cos(an) * r, yy, z + Math.sin(an) * r)) continue;
                float sz = Math.max(6f, (0.45f + 0.25f * (float) Math.sin(t * 1.6 + i)) * o[2]);
                centered(ctx, GLOW, o[0], o[1], sz * 2.4f, sz * 2.4f, argb(0.30f * a, col));
                centered(ctx, DISC, o[0], o[1], sz, sz, argb(0.22f * a, col));
                centered(ctx, DISC, o[0], o[1], sz * 0.35f, sz * 0.35f, argb(0.5f * a, 0xFFFFFF));
            }
        }

        // ---------- style 5: lock-on brackets ----------
        private float[] rot(float cx, float cy, float dx, float dy, float ca, float sa) {
            return new float[]{cx + dx * ca - dy * sa, cy + dx * sa + dy * ca};
        }

        void brackets() {
            float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
            boolean any = false;
            double hw = w / 2.0;
            for (int i = 0; i < 8; i++) {
                if (!pt(x + ((i & 1) == 0 ? -hw : hw), y + ((i & 2) == 0 ? 0.0 : h), z + ((i & 4) == 0 ? -hw : hw))) continue;
                any = true;
                minX = Math.min(minX, o[0]); maxX = Math.max(maxX, o[0]);
                minY = Math.min(minY, o[1]); maxY = Math.max(maxY, o[1]);
            }
            if (!any) return;
            float cx = (minX + maxX) / 2f, cy = (minY + maxY) / 2f;
            float half = Math.max(maxX - minX, maxY - minY) / 2f * 1.1f + 8f + 2f * (float) Math.sin(t * 3.0);
            half = Math.min(half, ctx.getScaledWindowHeight() * 0.45f);
            float arm = half * 0.42f;
            float ca = (float) Math.cos(t * 1.3), sa = (float) Math.sin(t * 1.3);
            int core = mix(rgb, 0xFFFFFF, 0.55f);
            for (int k = 0; k < 4; k++) {
                float sx = (k & 1) == 0 ? -1f : 1f, sy = (k & 2) == 0 ? -1f : 1f;
                float[] c = rot(cx, cy, sx * half, sy * half, ca, sa);
                float[] hz = rot(cx, cy, sx * (half - arm), sy * half, ca, sa);
                float[] vt = rot(cx, cy, sx * half, sy * (half - arm), ca, sa);
                Predictions.line(ctx, c[0], c[1], hz[0], hz[1], 5f, argb(0.20f * a, rgb));
                Predictions.line(ctx, c[0], c[1], vt[0], vt[1], 5f, argb(0.20f * a, rgb));
                Predictions.line(ctx, c[0], c[1], hz[0], hz[1], 1.8f, argb(0.95f * a, core));
                Predictions.line(ctx, c[0], c[1], vt[0], vt[1], 1.8f, argb(0.95f * a, core));
                centered(ctx, GLOW, c[0], c[1], 14f, 14f, argb(0.40f * a, rgb));
            }
        }

        // ---------- style 6: shards (flat white diamonds tumbling around the body) ----------
        void shards() {
            final int n = 9;
            int core = mix(rgb, 0xFFFFFF, 0.7f);
            for (int i = 0; i < n; i++) {
                double an = t * 0.6 + i * TAU / n;
                double r = w * 0.5 + 0.45 + 0.3 * Math.sin(t * 1.3 + i * 2.1);
                double cy = y + h * (0.2 + 0.65 * (0.5 + 0.5 * Math.sin(t * 0.8 + i * 1.7)));
                double cx = x + Math.cos(an) * r, cz = z + Math.sin(an) * r;
                if (!pt(cx, cy, cz)) continue;
                float sx0 = o[0], sy0 = o[1], ppb = o[2];
                double s = 0.16 + 0.07 * ((i * 3) % 4) / 3.0;                  // half size in blocks
                double sp = t * 2.0 + i * 1.3;
                // two axes of the diamond: one horizontal, one that rolls up and down as it spins
                double ux = Math.cos(sp) * s, uz = Math.sin(sp) * s;
                double vx = -Math.sin(sp) * 0.45 * s, vz = Math.cos(sp) * 0.45 * s, vy = 0.9 * s * Math.cos(sp * 0.7 + i);
                float[] X = new float[4], Y = new float[4];
                boolean ok = true;
                for (int k = 0; k < 4 && ok; k++) {
                    double dx = k == 0 ? ux : k == 2 ? -ux : k == 1 ? vx : -vx;
                    double dy = k == 1 ? vy : k == 3 ? -vy : 0.0;
                    double dz = k == 0 ? uz : k == 2 ? -uz : k == 1 ? vz : -vz;
                    if (!pt(cx + dx, cy + dy, cz + dz)) { ok = false; break; }
                    X[k] = o[0]; Y[k] = o[1];
                }
                if (!ok) continue;
                float size = Math.max(3f, (float) s * ppb);
                float glow = 0.5f + 0.5f * (float) Math.sin(t * 2.5 + i);
                centered(ctx, GLOW, sx0, sy0, size * 3.2f, size * 3.2f, argb(0.30f * a * glow, rgb));
                fill(ctx, X, Y, argb(0.88f * a, core));
            }
        }

        // ---------- style 7: cubes (small glowing squares rotating in a cloud) ----------
        void cubes() {
            final int n = 12;
            float[][] corner = {{-1, -1}, {1, -1}, {1, 1}, {-1, 1}};
            for (int i = 0; i < n; i++) {
                double an = t * (0.5 + 0.07 * (i % 4)) + i * 2.4;
                double r = w * 0.5 + 0.3 + 0.5 * (0.5 + 0.5 * Math.sin(t * 0.7 + i * 1.9));
                double cy = y + h * (0.15 + 0.7 * (0.5 + 0.5 * Math.sin(t * 0.6 + i * 2.3)));
                if (!pt(x + Math.cos(an) * r, cy, z + Math.sin(an) * r)) continue;
                float px = o[0], py = o[1], ppb = o[2];
                float sz = Math.max(3f, 0.085f * ppb);
                float rot = (float) (t * 1.6 + i * 0.9);
                float c = (float) Math.cos(rot), s = (float) Math.sin(rot);
                float blink = 0.6f + 0.4f * (float) Math.sin(t * 3.0 + i);
                float[] X = new float[4], Y = new float[4];
                for (int k = 0; k < 4; k++) {
                    float dx = corner[k][0] * sz, dy = corner[k][1] * sz;
                    X[k] = px + dx * c - dy * s;
                    Y[k] = py + dx * s + dy * c;
                }
                centered(ctx, GLOW, px, py, sz * 3.5f, sz * 3.5f, argb(0.28f * a * blink, rgb));
                fill(ctx, X, Y, argb(0.85f * a * blink, mix(rgb, 0xFFFFFF, 0.6f)));
            }
        }

        // ---------- style 8: chain (a ring of links that rises and falls around the body) ----------
        void chain() {
            final int n = 10, seg = 12;
            double cy = y + h * (0.45 + 0.1 * Math.sin(t * 0.7));
            double R = w * 0.5 + 0.55;
            int col = mix(rgb, 0xFFFFFF, 0.65f);
            for (int i = 0; i < n; i++) {
                double an = t * 0.8 + i * TAU / n;
                double px = x + Math.cos(an) * R, pz = z + Math.sin(an) * R;
                // every other link is turned by 90 degrees, so the links hook into each other like a real chain
                double ax = (i % 2 == 0) ? -Math.sin(an) : Math.cos(an);
                double az = (i % 2 == 0) ? Math.cos(an) : Math.sin(an);
                double lw = 0.16, lh = 0.11;
                float[] prev = null;
                for (int k = 0; k <= seg; k++) {
                    double ph = TAU * k / seg;
                    double dx = Math.cos(ph) * lw, dy = Math.sin(ph) * lh;
                    if (!pt(px + ax * dx, cy + dy, pz + az * dx)) { prev = null; continue; }
                    float[] cur = {o[0], o[1]};
                    float th = Math.max(1f, 0.035f * o[2]);
                    if (prev != null) {
                        Predictions.line(ctx, prev[0], prev[1], cur[0], cur[1], th * 2.6f, argb(0.2f * a, rgb));
                        Predictions.line(ctx, prev[0], prev[1], cur[0], cur[1], th, argb(0.95f * a, col));
                    }
                    prev = cur;
                }
            }
        }

        // ---------- style 9: flares (white horizontal light flashes on both sides) ----------
        void flares() {
            for (int i = 0; i < 2; i++) {
                double side = i == 0 ? -1.0 : 1.0;
                double fy = y + h * (0.5 + 0.12 * Math.sin(t * 0.9 + i * Math.PI));
                if (!pt(x + side * (w * 0.5 + 0.35), fy, z)) continue;
                float px = o[0], py = o[1], ppb = o[2];
                float pulse = 0.55f + 0.45f * (float) Math.sin(t * 2.2 + i * Math.PI);
                float sz = Math.max(6f, 0.3f * ppb);
                centered(ctx, GLOW, px, py, sz * 3.2f, Math.max(4f, sz * 1.5f), argb(0.45f * a * pulse, rgb));
                centered(ctx, DISC, px, py, sz * 2.0f, Math.max(1.5f, sz * 0.45f * pulse), argb(0.9f * a * pulse, 0xFFFFFF));
                centered(ctx, DISC, px, py, sz * 0.6f, sz * 0.6f, argb(a * pulse, 0xFFFFFF));
            }
        }

        // ---------- style 10: dashed rings (one on the ground, one rising around the body) ----------
        void dashed() {
            double gy = y + 0.02, R = w * 0.5 + 0.55, ry = y + h * (0.5 + 0.28 * Math.sin(t * 0.6));
            int pale = mix(rgb, 0xFFFFFF, 0.6f);
            ringXZ(gy, R, 0, TAU, 0.2f, rgb, 0.10f * a, 0.12);                              // soft glow under the feet
            for (int i = 0; i < 12; i++) {                                                  // ground dashes turning one way
                double s0 = t * 1.1 + i * TAU / 12, s1 = s0 + TAU / 12 * 0.55;
                ringXZ(gy, R, s0, s1, 0.05f, pale, 0.95f * a, 0.1);
            }
            for (int i = 0; i < 10; i++) {                                                  // rising dashes turning the other way
                double s0 = -t * 1.5 + i * TAU / 10, s1 = s0 + TAU / 10 * 0.5;
                ringXZ(ry, R * 0.95, s0, s1, 0.045f, pale, 0.85f * a, 0.1);
            }
        }
    }
}

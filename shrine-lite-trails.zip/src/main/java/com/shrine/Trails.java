package com.shrine;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

import static com.shrine.Gfx.*;

/**
 * Player > "Trails": a line that follows the player and / or particles falling off the feet (ported from the Pulse
 * client "Trails" module, all of its modes).
 *
 * Walk mode:   only trail / only particles / trail + particles.
 * Trail type:  solid ribbon, dashed (outline only), fading ribbon.
 * Particles:   heart, spark, snowflake, glow, star, dollar; physics: realistic, no collisions, none, attraction.
 *
 * Same technique as {@link Predictions}: a 2D overlay, world points are projected to the screen by hand.
 * Unlike the other overlays it uses the REAL camera (so it also works from the third person view).
 */
final class Trails {
    private Trails() {}

    static final String KEY = "player.trails", K_MODE = "player.trails.mode", K_FIRST = "player.trails.first",
            K_TYPE = "player.trails.type", K_LEN = "player.trails.len", K_WIDTH = "player.trails.width",
            K_COLOR = "player.trails.color", K_SPAWN = "player.trails.spawn", K_PTYPE = "player.trails.ptype",
            K_PHYS = "player.trails.phys", K_AMOUNT = "player.trails.amount", K_PSIZE = "player.trails.psize",
            K_LIFE = "player.trails.life", K_SPREAD = "player.trails.spread", K_PCOLOR = "player.trails.pcolor";

    static final String[] MODES = {"Только след", "Только частицы", "След + частицы"};
    static final String[] TYPES = {"Сплошной", "Пунктир", "Затухающий"};
    static final String[] SPAWNS = {"Под ногами", "По телу"};
    static final String[] PARTICLES = {"Сердце", "Искра", "Снежинка", "Сияние", "Звезда", "Доллар"};
    static final String[] PHYSICS = {"Реалистичная", "Без коллизий", "Без физики", "Притяжение"};
    private static final String[] TEX = {"heart", "sparkle", "snowflake", "glow", "star", "dollar"};

    private static final double MIN_STEP = 0.08;     // a trail point every 8 cm of walking
    private static final double SPAWN_STEP = 0.12;   // a burst of particles every 12 cm of walking
    private static final int MAX_POINTS = 2500, MAX_PARTICLES = 700;
    private static final double GRAVITY = 0.02;

    private record Pt(Vec3d pos, long time) {}

    private static final class Particle {
        Vec3d last, pos, vel;
        int age, life, phys;
        float rot, scale;
        Identifier tex;
        int rgb;
    }

    private static final List<Pt> points = new ArrayList<>();
    private static final List<Particle> particles = new ArrayList<>();
    private static Vec3d lastPoint, lastSpawn;
    private static long lastTickMs;

    private static int pick(String key, int def, int max) {
        return Math.max(0, Math.min(max, ShrineCfg.integer(key, def)));
    }

    private static int color(String key, int def) {
        return ShrineGui.PALETTE[pick(key, def, ShrineGui.PALETTE.length - 1)];
    }

    static void register() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "trails"),
                (ctx, tick) -> render(ctx, tick.getTickProgress(false)));
    }

    private static void clear() {
        points.clear();
        particles.clear();
        lastPoint = null;
        lastSpawn = null;
        lastTickMs = 0L;
    }

    // ---------- camera (the real one, so the third person view projects correctly) ----------
    private static java.lang.reflect.Method posMethod;

    /** Camera position. Looked up by return type, so it does not depend on the mapping name of the getter. */
    private static Vec3d cameraPos(Camera c) {
        try {
            if (posMethod == null) {
                for (java.lang.reflect.Method m : Camera.class.getMethods()) {
                    if (m.getParameterCount() == 0 && m.getReturnType() == Vec3d.class) { posMethod = m; break; }
                }
            }
            return posMethod == null ? null : (Vec3d) posMethod.invoke(c);
        } catch (Throwable t) {
            return null;
        }
    }

    /** World point -> screen (x, y, pixels per block); same maths as {@link Predictions.Cam}, but from an explicit camera. */
    private static final class View {
        final Vec3d pos;
        final double fx, fy, fz, rx, rz, ux, uy, uz, W, H, tanHalf;

        View(MinecraftClient mc, DrawContext ctx, Vec3d pos, double yawDeg, double pitchDeg) {
            this.pos = pos;
            double yr = Math.toRadians(yawDeg), pr = Math.toRadians(pitchDeg);
            fx = -Math.sin(yr) * Math.cos(pr);
            fy = -Math.sin(pr);
            fz = Math.cos(yr) * Math.cos(pr);
            rx = -Math.cos(yr);
            rz = -Math.sin(yr);
            ux = -rz * fy;
            uy = rz * fx - rx * fz;
            uz = rx * fy;
            W = ctx.getScaledWindowWidth();
            H = ctx.getScaledWindowHeight();
            tanHalf = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
        }

        boolean p(double wx, double wy, double wz, float[] out) {
            double x = wx - pos.x, y = wy - pos.y, z = wz - pos.z;
            double zc = x * fx + y * fy + z * fz;
            if (zc < 0.1) return false;
            double xc = x * rx + z * rz, yc = x * ux + y * uy + z * uz;
            double k = (H / 2.0) / (zc * tanHalf);
            out[0] = (float) (W / 2.0 + xc * k);
            out[1] = (float) (H / 2.0 - yc * k);
            out[2] = (float) k;
            return true;
        }
    }

    // ---------- frame ----------
    private static void render(DrawContext ctx, float td) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) { clear(); return; }
        if (!ShrineCfg.bool(KEY, false)) { clear(); return; }
        if (mc.currentScreen != null || mc.options.hudHidden) return;

        long now = Util.getMeasuringTimeMs();
        int mode = pick(K_MODE, 0, MODES.length - 1);
        boolean doTrail = mode != 1, doParticles = mode != 0;
        if (!doTrail) points.clear();
        if (!doParticles) particles.clear();

        Vec3d p = mc.player.getLerpedPos(td);

        // teleport / respawn: do not draw a ribbon across the whole map
        if (lastPoint != null && lastPoint.distanceTo(p) > 8.0) { points.clear(); lastPoint = null; lastSpawn = null; }

        if (doTrail && (lastPoint == null || lastPoint.distanceTo(p) > MIN_STEP)) {
            points.add(new Pt(p.add(0.0, 0.05, 0.0), now));
            lastPoint = p;
            if (points.size() > MAX_POINTS) points.remove(0);
        }
        if (doParticles && (lastSpawn == null || lastSpawn.distanceTo(p) > SPAWN_STEP)) {
            spawn(mc, p);
            lastSpawn = p;
        }

        float maxAge = Math.max(0.5f, ShrineCfg.num(K_LEN, 3f)) * 1000f;
        points.removeIf(pt -> now - pt.time() > maxAge);

        // particles run at 20 ticks per second, like in the original
        if (lastTickMs == 0L) lastTickMs = now;
        int steps = 0;
        while (now - lastTickMs >= 50L && steps < 5) { tickParticles(mc); lastTickMs += 50L; steps++; }
        if (now - lastTickMs >= 50L) lastTickMs = now;
        float part = Math.max(0f, Math.min(1f, (now - lastTickMs) / 50f));

        boolean firstPerson = mc.options.getPerspective().isFirstPerson();
        if (firstPerson && !ShrineCfg.bool(K_FIRST, false)) return;

        // the real camera
        Camera cam = mc.gameRenderer.getCamera();
        if (cam == null) return;
        Vec3d cp = cameraPos(cam);
        if (cp == null) cp = mc.player.getCameraPosVec(td);
        View v = new View(mc, ctx, cp, cam.getYaw(), cam.getPitch());

        if (doTrail && points.size() >= 2) drawTrail(ctx, v, now, maxAge);
        if (doParticles && !particles.isEmpty()) drawParticles(ctx, v, part);
    }

    // ---------- trail ----------
    private static void drawTrail(DrawContext ctx, View v, long now, float maxAge) {
        int type = pick(K_TYPE, 0, TYPES.length - 1);
        float height = Math.max(0.05f, ShrineCfg.num(K_WIDTH, 0.3f));
        int rgb = color(K_COLOR, 4);

        int n = points.size();
        float[][] bot = new float[n][], top = new float[n][];
        float[] age = new float[n];
        float[] o = new float[3];
        for (int i = 0; i < n; i++) {
            Pt pt = points.get(i);
            age[i] = Math.max(0f, Math.min(1f, (now - pt.time()) / maxAge));
            Vec3d q = pt.pos();
            if (v.p(q.x, q.y, q.z, o)) bot[i] = new float[]{o[0], o[1]};
            if (v.p(q.x, q.y + height, q.z, o)) top[i] = new float[]{o[0], o[1]};
        }

        if (type == 1) {
            // dashed: only the two edges, every other segment
            for (int i = 0; i + 1 < n; i += 2) {
                float al = 1f - age[i];
                edge(ctx, bot[i], bot[i + 1], al, rgb);
                edge(ctx, top[i], top[i + 1], al, rgb);
            }
            return;
        }

        boolean faded = type == 2;
        float[] xs = new float[4], ys = new float[4];
        for (int i = 0; i + 1 < n; i++) {
            float[] b1 = bot[i], b2 = bot[i + 1], t1 = top[i], t2 = top[i + 1];
            if (b1 == null || b2 == null || t1 == null || t2 == null) continue;
            float a1 = (1f - age[i]) * (faded ? 1f - age[i] : 1f) * 0.7f;
            float a2 = (1f - age[i + 1]) * (faded ? 1f - age[i + 1] : 1f) * 0.7f;
            xs[0] = b1[0]; ys[0] = b1[1];
            xs[1] = b2[0]; ys[1] = b2[1];
            xs[2] = t2[0]; ys[2] = t2[1];
            xs[3] = t1[0]; ys[3] = t1[1];
            fillQuad(ctx, xs, ys, argb((a1 + a2) * 0.5f, rgb));
            float al = 1f - (age[i] + age[i + 1]) * 0.5f;
            edge(ctx, b1, b2, al, rgb);
            edge(ctx, t1, t2, al, rgb);
        }
    }

    private static void edge(DrawContext ctx, float[] a, float[] b, float alpha, int rgb) {
        if (a == null || b == null || alpha <= 0.02f) return;
        Predictions.line(ctx, a[0], a[1], b[0], b[1], 1.0f, argb(alpha, rgb));
    }

    /**
     * Fills a convex screen quad. It is scanned along the shorter side (a ribbon seen from the side is a thin
     * parallelogram, so this is a handful of 1px strips instead of dozens), and only inside the screen.
     */
    private static void fillQuad(DrawContext ctx, float[] xs, float[] ys, int col) {
        float minX = Float.MAX_VALUE, maxX = -Float.MAX_VALUE, minY = Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
        for (int i = 0; i < 4; i++) {
            minX = Math.min(minX, xs[i]); maxX = Math.max(maxX, xs[i]);
            minY = Math.min(minY, ys[i]); maxY = Math.max(maxY, ys[i]);
        }
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        if (maxX < 0 || maxY < 0 || minX > sw || minY > sh) return;
        boolean cols = (maxX - minX) < (maxY - minY);
        int from = Math.max(0, Math.round(cols ? minX : minY));
        int to = Math.min(cols ? sw : sh, Math.round(cols ? maxX : maxY));
        for (int s = from; s < to; s++) {
            float c = s + 0.5f, lo = Float.MAX_VALUE, hi = -Float.MAX_VALUE;
            for (int i = 0; i < 4; i++) {
                int j = (i + 1) & 3;
                float a0 = cols ? xs[i] : ys[i], a1 = cols ? xs[j] : ys[j];
                float b0 = cols ? ys[i] : xs[i], b1 = cols ? ys[j] : xs[j];
                if ((a0 <= c && a1 > c) || (a1 <= c && a0 > c)) {
                    float r = b0 + (c - a0) * (b1 - b0) / (a1 - a0);
                    lo = Math.min(lo, r);
                    hi = Math.max(hi, r);
                }
            }
            if (lo >= hi) continue;
            int l = Math.round(lo), h = Math.round(hi);
            if (l >= h) continue;
            if (cols) ctx.fill(s, l, s + 1, h, col);
            else ctx.fill(l, s, h, s + 1, col);
        }
    }

    // ---------- particles ----------
    private static void spawn(MinecraftClient mc, Vec3d base) {
        if (particles.size() >= MAX_PARTICLES) return;
        ThreadLocalRandom r = ThreadLocalRandom.current();
        int count = Math.max(1, Math.round(ShrineCfg.num(K_AMOUNT, 4f)));
        int life = Math.max(5, Math.round(ShrineCfg.num(K_LIFE, 20f)));
        float size = ShrineCfg.num(K_PSIZE, 0.3f);
        double spread = 0.3 * ShrineCfg.num(K_SPREAD, 1f);
        int rgb = color(K_PCOLOR, 6);
        Identifier tex = Identifier.of("shrine", "textures/particle/" + TEX[pick(K_PTYPE, 0, TEX.length - 1)] + ".png");
        int phys = pick(K_PHYS, 0, PHYSICS.length - 1);
        boolean body = pick(K_SPAWN, 0, SPAWNS.length - 1) == 1;
        for (int i = 0; i < count; i++) {
            double yOff = body ? r.nextDouble(0.0, Math.max(0.1, mc.player.getHeight())) : r.nextDouble(0.0, 0.2);
            Particle p = new Particle();
            p.pos = base.add(r.nextDouble(-0.2, 0.2), yOff, r.nextDouble(-0.2, 0.2));
            p.last = p.pos;
            p.vel = new Vec3d(r.nextDouble(-spread, spread), r.nextDouble(0.05, Math.max(0.06, spread)), r.nextDouble(-spread, spread));
            p.life = life;
            p.scale = size;
            p.tex = tex;
            p.rgb = rgb;
            p.phys = phys;
            p.rot = r.nextFloat() * 360f;
            particles.add(p);
        }
    }

    private static boolean solid(MinecraftClient mc, double x, double y, double z) {
        BlockPos bp = BlockPos.ofFloored(x, y, z);
        return !mc.world.getBlockState(bp).getCollisionShape(mc.world, bp).isEmpty();
    }

    private static void tickParticles(MinecraftClient mc) {
        for (int i = particles.size() - 1; i >= 0; i--) {
            Particle p = particles.get(i);
            if (++p.age >= p.life) { particles.remove(i); continue; }
            p.last = p.pos;
            switch (p.phys) {
                case 0, 1 -> {   // realistic (with block collisions) / no collisions: drag + gravity
                    Vec3d v = p.vel.multiply(0.98).add(0.0, -GRAVITY, 0.0);
                    double x = p.pos.x, y = p.pos.y, z = p.pos.z;
                    if (p.phys == 1) {
                        x += v.x; y += v.y; z += v.z;
                    } else {
                        double vx = v.x, vy = v.y, vz = v.z;
                        if (solid(mc, x + vx, y, z)) vx *= -0.3; else x += vx;
                        if (solid(mc, x, y + vy, z)) { vy *= -0.3; vx *= 0.8; vz *= 0.8; } else y += vy;
                        if (solid(mc, x, y, z + vz)) vz *= -0.3; else z += vz;
                        v = new Vec3d(vx, vy, vz);
                    }
                    p.vel = v;
                    p.pos = new Vec3d(x, y, z);
                }
                case 3 -> {      // attraction: pulled towards the player
                    Vec3d dir = new Vec3d(mc.player.getX(), mc.player.getY() + 1.0, mc.player.getZ()).subtract(p.pos);
                    if (dir.lengthSquared() > 0.01) p.vel = p.vel.add(dir.normalize().multiply(0.03));
                    p.pos = p.pos.add(p.vel);
                }
                default -> p.pos = p.pos.add(p.vel);   // no physics
            }
        }
    }

    private static void drawParticles(DrawContext ctx, View v, float part) {
        float[] o = new float[3];
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        var m = ctx.getMatrices();
        for (Particle p : particles) {
            float prog = Math.min(1f, (p.age + part) / p.life);
            float alpha = 1f - prog;
            if (alpha <= 0.02f) continue;
            double x = p.last.x + (p.pos.x - p.last.x) * part;
            double y = p.last.y + (p.pos.y - p.last.y) * part;
            double z = p.last.z + (p.pos.z - p.last.z) * part;
            if (!v.p(x, y, z, o)) continue;
            float size = p.scale * (1f - prog * 0.3f) * o[2];
            if (size < 1.5f || o[0] < -size || o[1] < -size || o[0] > sw + size || o[1] > sh + size) continue;
            m.pushMatrix();
            m.translate(o[0], o[1]);
            m.rotate((float) Math.toRadians(p.rot));
            m.scale(size / 64f, size / 64f);
            blit(ctx, p.tex, -32, -32, 64, 64, argb(alpha, p.rgb));
            m.popMatrix();
        }
    }
}

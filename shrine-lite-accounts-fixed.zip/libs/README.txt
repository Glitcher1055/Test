Сюда (необязательно) можно положить ViaFabricPlus-4.4.15.jar - иначе GitHub Actions скачает его сам.

IAS-*.jar (необязательно): In-Game Account Switcher для 1.21.11. Если файла нет, GitHub Actions скачает его с Modrinth сам.

package com.shrine;

import com.shrine.Gfx.Fnt;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CompletableFuture;

import static com.shrine.Gfx.*;

/**
 * PS5 "who is using this controller" screen for switching the account. Opens from the round avatar in the top bar.
 * The account list and the sign-in itself come from In-Game Account Switcher (see {@link Ias}).
 */
public final class PsAccountScreen extends Screen {

    private static final float TILE = 124f, STEP = 176f, ROW_Y = 292f, RIGHT_PAD = 55f;
    private static final int[] TINTS = {0xF1F1F4, 0xC9D3E8, 0xFFD0D0, 0xD7F0D2, 0xFFE9B8, 0xE3D2F5};
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm", Locale.ROOT);

    private enum St { IDLE, WORKING, PASSWORD, ERROR, DONE }

    private static final class Tile {
        final Ias.Acc acc;          // null for the "+" tile and for the launcher account that IAS does not know
        final String name;
        final boolean add, current;
        float cx, cy, anim;
        Tile(Ias.Acc acc, String name, boolean add, boolean current) { this.acc = acc; this.name = name; this.add = add; this.current = current; }
        boolean stored() { return acc != null; }
        boolean contains(double mx, double my) {
            if (add) { double dx = mx - cx, dy = my - cy, r = (TILE + 6f) / 2f; return dx * dx + dy * dy <= r * r; }
            return Gfx.inside(mx, my, cx - TILE / 2f, cy - TILE / 2f, TILE, TILE);
        }
    }

    private final Screen parent;
    private final Scene scene = new Scene();
    private final List<Tile> tiles = new ArrayList<>();
    private float scroll, scrollTarget;
    private long opened;

    private St st = St.IDLE;
    private String loginName = "", status = "", error = "";
    private volatile boolean cancelled;
    private long doneAt;
    private CompletableFuture<String> pwFuture;

    private boolean addOpen;
    private String addError = "";
    private TextFieldWidget nickField, pwField;
    private ServerDialog delDialog;
    private Tile delTarget;
    private long dialogAt;

    // clickable regions of the current frame (virtual coordinates)
    private float[] rClose = new float[4], rDelX = new float[4], rCancel = new float[4], rAddNick = new float[4],
            rAddMs = new float[4], rAddX = new float[4], rNickBox = new float[4], rPwBox = new float[4], rPwOk = new float[4];
    private Tile delXTile;

    public PsAccountScreen(Screen parent) {
        super(Text.literal("accounts"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        scene.init(width, height);
        opened = Util.getMeasuringTimeMs();
        nickField = newField(16);
        pwField = newField(64);
        rebuild();
        attachFields();
    }

    private TextFieldWidget newField(int max) {
        TextFieldWidget f = new TextFieldWidget(textRenderer, 0, 0, 200, 20, Text.empty());
        f.setMaxLength(max);
        return f;
    }

    private void attachFields() {
        clearChildren();
        if (addOpen) addDrawableChild(nickField);
        if (st == St.PASSWORD) addDrawableChild(pwField);
    }

    /** The active account first, then the rest in IAS order. */
    private void rebuild() {
        tiles.clear();
        tiles.add(new Tile(null, "", true, false));
        String cur = client.getSession().getUsername();
        List<Ias.Acc> list = Ias.accounts();
        Ias.Acc match = null;
        for (Ias.Acc a : list) if (a.name().equalsIgnoreCase(cur)) { match = a; break; }
        if (match != null) tiles.add(new Tile(match, match.name(), false, true));
        else if (cur != null && !cur.isBlank()) tiles.add(new Tile(null, cur, false, true));
        for (Ias.Acc a : list) if (a != match) tiles.add(new Tile(a, a.name(), false, false));
    }

    // ---------- render ----------
    @Override
    public void render(DrawContext ctx, int mxReal, int myReal, float delta) {
        scene.begin(ctx, mxReal, myReal, delta);
        scene.stars(ctx, delta);
        float mx = scene.mx, my = scene.my, f = scene.fade(), vw = scene.vw;
        long now = Util.getMeasuringTimeMs();
        boolean modal = st != St.IDLE || addOpen || delDialog != null;

        if (st == St.DONE && now - doneAt > 950L) {
            Gfx.cover(ctx, width, height);
            scene.end(ctx);
            client.setScreen(parent);
            return;
        }

        String clock = LocalDateTime.now().format(CLOCK);
        int cw = width(textRenderer, Fnt.UI, clock);
        text(ctx, textRenderer, Fnt.UI, clock, vw - RIGHT_PAD - cw, 45f, argb(0.92f * f, 0xFFFFFF));

        textC(ctx, textRenderer, Fnt.TITLE, "С возвращением в Shrine", vw / 2f, 150f, argb(0.95f * f, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.LABEL, "Кто сейчас играет?", vw / 2f, 190f, argb(0.45f * f, 0xFFFFFF));
        if (!Ias.available())
            textC(ctx, textRenderer, Fnt.SMALL, "Смена аккаунта недоступна: " + Ias.unavailableReason(), vw / 2f, 222f, argb(0.85f * f, 0xFF8A8A));

        // row of tiles, centered; scrolls sideways when there are many
        int n = tiles.size();
        float total = n * STEP, avail = vw - 120f;
        scroll += (scrollTarget - scroll) * Math.min(1f, delta * 0.3f);
        float start = total <= avail ? vw / 2f - total / 2f + STEP / 2f : 60f + STEP / 2f - scroll;
        rDelX = new float[4]; delXTile = null;
        int hov = -1;
        for (int i = 0; i < n; i++) {
            Tile t = tiles.get(i);
            t.cx = start + i * STEP;
            t.cy = ROW_Y;
            if (!modal && t.contains(mx, my)) hov = i;
        }
        for (int i = 0; i < n; i++) {
            Tile t = tiles.get(i);
            t.anim += ((i == hov ? 1f : 0f) - t.anim) * Math.min(1f, delta * 0.35f);
            float p = ease((now - opened - 70L * i) / 420f);
            drawTile(ctx, t, f * p, mx, my, modal, 22f * (1f - p));
        }
        if (total > avail && !modal) {   // edge hint that there is more to scroll to
            textC(ctx, textRenderer, Fnt.SMALL, "прокрутите, чтобы увидеть остальные", vw / 2f, 392f, argb(0.30f * f, 0xFFFFFF));
        }

        drawFooter(ctx, mx, my, f, modal);

        if (delDialog != null) {
            float da = delDialog.alpha();
            ctx.fill(0, 0, Math.round(vw) + 2, Math.round(Scene.REF_H) + 2, argb(0.66f * da, 0x050105));
            delDialog.draw(ctx, textRenderer, vw, mx, my, da, scene.time);
        } else if (addOpen) {
            drawAddDialog(ctx, mx, my, vw);
        } else if (st != St.IDLE) {
            drawLogin(ctx, mx, my, vw, now);
        }
        scene.end(ctx);
    }

    private void drawTile(DrawContext ctx, Tile t, float a, float mx, float my, boolean modal, float dy) {
        float h = t.anim, cx = t.cx, cy = t.cy + dy;
        if (t.add) {
            float d = (TILE + 6f) * (1f + 0.10f * h);
            if (h > 0.02f) centered(ctx, GLOW, cx, cy, d * 1.9f, d * 1.9f, argb(0.30f * h * a, ACCENT));
            centered(ctx, DISC, cx, cy, d, d, argb((0.14f + 0.10f * h) * a, 0xFFFFFF));
            centered(ctx, RING, cx, cy, d, d, argb((0.55f + 0.40f * h) * a, 0xFFFFFF));
            int arm = Math.round(d * 0.14f), th = Math.max(2, Math.round(d * 0.035f));
            int x = Math.round(cx), y = Math.round(cy), col = argb((0.80f + 0.20f * h) * a, 0xFFFFFF);
            ctx.fill(x - arm, y - th, x + arm, y + th, col);
            ctx.fill(x - th, y - arm, x + th, y + arm, col);
            textC(ctx, textRenderer, Fnt.LABEL, "Добавить аккаунт", cx, cy + TILE / 2f + 30f, argb((0.62f + 0.38f * h) * a, 0xFFFFFF));
            return;
        }

        float s = TILE * (1f + 0.10f * h), x = cx - s / 2f, y = cy - s / 2f, r = s * 0.28f;
        if (h > 0.02f || t.current) centered(ctx, GLOW, cx, cy, s * 1.9f, s * 1.9f, argb((t.current ? 0.20f + 0.16f * h : 0.34f * h) * a, ACCENT));
        int tint = TINTS[Math.floorMod(t.name.toLowerCase(Locale.ROOT).hashCode(), TINTS.length)];
        box(ctx, RR, x, y, s, s, r, argb(0.96f * a, tint));
        face(ctx, cx, cy, s, a);
        if (h > 0.02f) box(ctx, RR_RING, x - 5, y - 5, s + 10, s + 10, r + 5, argb(0.95f * h * a, 0xFFFFFF));
        else if (t.current) box(ctx, RR_RING, x - 5, y - 5, s + 10, s + 10, r + 5, argb(0.80f * a, ACCENT));

        float ly = cy + TILE / 2f + 30f;
        textC(ctx, textRenderer, Fnt.LABEL, t.name, cx, ly, argb((0.70f + 0.30f * h) * a, 0xFFFFFF));
        String sub = t.current ? "Сейчас в игре" : (t.acc == null ? "" : (t.acc.offline() ? "Без лицензии" : "Microsoft"));
        if (!sub.isEmpty()) textC(ctx, textRenderer, Fnt.SMALL, sub, cx, ly + 20f, argb((t.current ? 0.95f : 0.42f) * a, t.current ? ACCENT : 0xFFFFFF));

        if (t.stored() && h > 0.3f && !modal) {      // small cross in the corner: remove this account
            float bx = x + s - 6f, by = y + 6f;
            boolean hx = Gfx.inside(mx, my, bx - 15, by - 15, 30, 30);
            centered(ctx, DISC, bx, by, 26, 26, argb((hx ? 1f : 0.88f) * a, hx ? 0xFF6B6B : 0x14101A));
            textC(ctx, textRenderer, Fnt.TINY_B, "×", bx, by - 0.5f, argb(a, 0xFFFFFF));
            rDelX = new float[]{bx - 15, by - 15, 30, 30};
            delXTile = t;
        }
    }

    /** The PS5 default avatar: two dot eyes and a smile. */
    private void face(DrawContext ctx, float cx, float cy, float s, float a) {
        int ink = argb(0.92f * a, 0x1B1620);
        float ex = s * 0.17f, ey = cy - s * 0.10f, ed = s * 0.12f;
        centered(ctx, DISC, cx - ex, ey, ed, ed * 1.1f, ink);
        centered(ctx, DISC, cx + ex, ey, ed, ed * 1.1f, ink);
        final int dots = 13;
        for (int i = 0; i < dots; i++) {
            float u = i / (float) (dots - 1) * 2f - 1f;
            centered(ctx, DISC, cx + u * s * 0.26f, cy + s * 0.12f + (1f - u * u) * s * 0.09f, s * 0.075f, s * 0.075f, ink);
        }
    }

    private void drawFooter(DrawContext ctx, float mx, float my, float f, boolean modal) {
        float cx = scene.vw / 2f, cy = 474f;
        boolean h = !modal && Gfx.inside(mx, my, cx - 26, cy - 26, 52, 52);
        if (h) centered(ctx, GLOW, cx, cy, 110, 110, argb(0.30f * f, ACCENT));
        centered(ctx, DISC, cx, cy, 46, 46, argb((h ? 0.30f : 0.16f) * f, 0xFFFFFF));
        centered(ctx, RING, cx, cy, 46, 46, argb((h ? 0.90f : 0.45f) * f, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.UI_B, "×", cx, cy - 0.5f, argb(f, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.SMALL, "Закрыть", cx, cy + 40f, argb(0.45f * f, 0xFFFFFF));
        rClose = new float[]{cx - 26, cy - 26, 52, 52};

        float hx = scene.vw - RIGHT_PAD - 70f, hy = 504f;     // hint, bottom right
        centered(ctx, DISC, hx, hy, 24, 24, argb(0.20f * f, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.TINY_B, "×", hx, hy - 0.5f, argb(0.85f * f, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.SMALL, "Выбрать", hx + 20f, hy, argb(0.75f * f, 0xFFFFFF));
    }

    // ---------- login progress ----------
    private void drawLogin(DrawContext ctx, float mx, float my, float vw, long now) {
        float a = Math.min(1f, (now - dialogAt) / 200f);
        ctx.fill(0, 0, Math.round(vw) + 2, Math.round(Scene.REF_H) + 2, argb(0.72f * a, 0x050105));
        float cx = vw / 2f;
        rCancel = new float[4];
        rPwOk = new float[4];
        rPwBox = new float[4];

        if (st == St.PASSWORD) {
            float w = 400f, h = 214f, x = cx - w / 2f, y = (Scene.REF_H - h) / 2f;
            box(ctx, RR, x - 1, y - 1, w + 2, h + 2, 27, argb(0.10f * a, 0xFFFFFF));
            box(ctx, RR, x, y, w, h, 26, argb(0.97f * a, 0x1A1116));
            text(ctx, textRenderer, Fnt.UI_B, "Пароль шифрования", x + 24, y + 33, argb(a, 0xFFFFFF));
            text(ctx, textRenderer, Fnt.SMALL, "Нужен, чтобы расшифровать аккаунт " + loginName, x + 24, y + 62, argb(0.50f * a, 0xFFFFFF));
            rPwBox = new float[]{x + 20, y + 84, w - 40, 42};
            drawField(ctx, pwField, "Пароль", rPwBox, a, true);
            rPwOk = new float[]{x + 20, y + 144, w - 40, 42};
            pill(ctx, rPwOk, "Войти", true, !pwField.getText().isEmpty(), a, mx, my);
            return;
        }

        textC(ctx, textRenderer, Fnt.UI_B, st == St.DONE ? "Добро пожаловать, " + loginName + "!" : loginName, cx, 190f, argb(a, 0xFFFFFF));
        if (st == St.WORKING) {
            spinner(ctx, cx, 262f, a);
            textC(ctx, textRenderer, Fnt.LABEL, status.isEmpty() ? "Подключение..." : status, cx, 322f, argb(0.62f * a, 0xFFFFFF));
            rCancel = new float[]{cx - 80, 352, 160, 40};
            pill(ctx, rCancel, "Отмена", false, true, a, mx, my);
        } else if (st == St.ERROR) {
            textC(ctx, textRenderer, Fnt.LABEL, error, cx, 262f, argb(a, 0xFF8A8A));
            rCancel = new float[]{cx - 80, 312, 160, 40};
            pill(ctx, rCancel, "Закрыть", false, true, a, mx, my);
        }
    }

    private void spinner(DrawContext ctx, float cx, float cy, float a) {
        final int n = 12;
        for (int i = 0; i < n; i++) {
            double an = i * Math.PI * 2.0 / n;
            float lead = ((scene.time * 1.6f) * n - i) % n;
            if (lead < 0f) lead += n;
            float al = 0.15f + 0.85f * (1f - lead / n);
            centered(ctx, DOT, cx + (float) Math.cos(an) * 26f, cy + (float) Math.sin(an) * 26f, 9, 9, argb(al * a, 0xFFFFFF));
        }
    }

    // ---------- "add account" dialog ----------
    private void drawAddDialog(DrawContext ctx, float mx, float my, float vw) {
        float a = Math.min(1f, (Util.getMeasuringTimeMs() - dialogAt) / 200f);
        ctx.fill(0, 0, Math.round(vw) + 2, Math.round(Scene.REF_H) + 2, argb(0.66f * a, 0x050105));
        float w = 420f, h = 300f, x = (vw - w) / 2f, y = (Scene.REF_H - h) / 2f - 6f + (1f - a) * 14f;
        box(ctx, RR, x - 1, y - 1, w + 2, h + 2, 27, argb(0.10f * a, 0xFFFFFF));
        box(ctx, RR, x, y, w, h, 26, argb(0.97f * a, 0x1A1116));
        text(ctx, textRenderer, Fnt.UI_B, "Добавить аккаунт", x + 24, y + 33, argb(a, 0xFFFFFF));

        float cx = x + w - 30, cy = y + 33;
        boolean hc = Gfx.inside(mx, my, cx - 14, cy - 14, 28, 28);
        centered(ctx, DISC, cx, cy, 22, 22, argb((hc ? 1f : 0.88f) * a, 0xFF6B6B));
        textC(ctx, textRenderer, Fnt.TINY_B, "×", cx, cy - 0.5f, argb(a, 0x2A0A0A));
        rAddX = new float[]{cx - 14, cy - 14, 28, 28};

        rNickBox = new float[]{x + 20, y + 62, w - 40, 42};
        drawField(ctx, nickField, "Ник (без лицензии)", rNickBox, a, false);
        if (!addError.isEmpty()) text(ctx, textRenderer, Fnt.SMALL, addError, x + 24, y + 120, argb(a, 0xFF8A8A));

        rAddNick = new float[]{x + 20, y + 138, w - 40, 42};
        pill(ctx, rAddNick, "Добавить по нику", true, !nickField.getText().isBlank(), a, mx, my);

        textC(ctx, textRenderer, Fnt.SMALL, "или", x + w / 2f, y + 202, argb(0.40f * a, 0xFFFFFF));
        rAddMs = new float[]{x + 20, y + 224, w - 40, 42};
        pill(ctx, rAddMs, "Войти через Microsoft", false, Ias.canAddMicrosoft(), a, mx, my);
    }

    private void drawField(DrawContext ctx, TextFieldWidget f, String placeholder, float[] r, float a, boolean mask) {
        boolean focused = f.isFocused();
        box(ctx, RR, r[0], r[1], r[2], r[3], 14, argb(0.09f * a, 0xFFFFFF));
        box(ctx, RR_RING, r[0], r[1], r[2], r[3], 14, argb((focused ? 0.70f : 0.16f) * a, 0xFFFFFF));
        String raw = f.getText(), t = mask ? "*".repeat(raw.length()) : raw;
        float cy = r[1] + r[3] / 2f, tx = r[0] + 16f, avail = r[2] - 32f;
        boolean blink = ((int) (scene.time * 2.2f)) % 2 == 0;
        if (t.isEmpty()) {
            if (!focused) text(ctx, textRenderer, Fnt.LABEL, placeholder, tx, cy, argb(0.38f * a, 0xFFFFFF));
            else if (blink) ctx.fill(Math.round(tx), Math.round(cy - 9), Math.round(tx) + 2, Math.round(cy + 9), argb(0.9f * a, 0xFFFFFF));
            return;
        }
        int start = 0;
        while (start < t.length() - 1 && width(textRenderer, Fnt.LABEL, t.substring(start)) > avail) start++;
        text(ctx, textRenderer, Fnt.LABEL, t.substring(start), tx, cy, argb(a, 0xFFFFFF));
        if (focused && blink) {
            int cur = Math.max(start, Math.min(t.length(), f.getCursor()));
            float cx = tx + width(textRenderer, Fnt.LABEL, t.substring(start, cur));
            ctx.fill(Math.round(cx), Math.round(cy - 9), Math.round(cx) + 2, Math.round(cy + 9), argb(0.95f * a, 0xFFFFFF));
        }
    }

    private void pill(DrawContext ctx, float[] r, String label, boolean primary, boolean enabled, float a, float mx, float my) {
        boolean ho = enabled && Gfx.inside(mx, my, r[0], r[1], r[2], r[3]);
        if (primary) {
            if (ho) box(ctx, RR_RING, r[0] - 4, r[1] - 4, r[2] + 8, r[3] + 8, 25, argb(0.55f * a, 0xFFFFFF));
            box(ctx, RR, r[0], r[1], r[2], r[3], 21, argb((enabled ? 0.97f : 0.18f) * a, 0xFFFFFF));
            textC(ctx, textRenderer, Fnt.UI_B, label, r[0] + r[2] / 2f, r[1] + r[3] / 2f,
                    argb(enabled ? a : 0.45f * a, enabled ? 0x14101A : 0xFFFFFF));
        } else {
            box(ctx, RR, r[0], r[1], r[2], r[3], 21, argb(((ho ? 0.30f : 0.20f) * (enabled ? 1f : 0.5f)) * a, 0xFFFFFF));
            box(ctx, RR_RING, r[0], r[1], r[2], r[3], 21, argb((ho ? 0.60f : 0.22f) * a, 0xFFFFFF));
            textC(ctx, textRenderer, Fnt.UI_B, label, r[0] + r[2] / 2f, r[1] + r[3] / 2f, argb((enabled ? 0.95f : 0.40f) * a, 0xFFFFFF));
        }
    }

    // ---------- actions ----------
    private final Ias.Listener listener = new Ias.Listener() {
        @Override public boolean cancelled() { return cancelled; }
        @Override public void stage(String text) { if (st == St.WORKING) status = text; }
        @Override public CompletableFuture<String> password() {
            CompletableFuture<String> f = new CompletableFuture<>();
            client.execute(() -> openPassword(f));
            return f;
        }
        @Override public void success() {
            if (cancelled) return;
            st = St.DONE;
            doneAt = Util.getMeasuringTimeMs();
            clearChildren();
        }
        @Override public void error(String message) {
            if (cancelled) return;
            st = St.ERROR;
            error = message;
            dialogAt = Util.getMeasuringTimeMs();
            clearChildren();
        }
    };

    private void startLogin(Tile t) {
        if (t.acc == null || t.current || st != St.IDLE) return;
        loginName = t.name;
        status = "";
        cancelled = false;
        st = St.WORKING;
        dialogAt = Util.getMeasuringTimeMs();
        Ias.login(t.acc, listener);
    }

    private void openPassword(CompletableFuture<String> f) {
        if (cancelled) { f.complete(""); return; }
        pwFuture = f;
        pwField.setText("");
        st = St.PASSWORD;
        dialogAt = Util.getMeasuringTimeMs();
        attachFields();
        pwField.setFocused(true);
        setFocused(pwField);
    }

    private void submitPassword() {
        if (pwFuture == null || pwField.getText().isEmpty()) return;
        CompletableFuture<String> f = pwFuture;
        pwFuture = null;
        st = St.WORKING;
        attachFields();
        f.complete(pwField.getText());
    }

    private void cancelLogin() {
        cancelled = true;
        if (pwFuture != null) { pwFuture.complete(""); pwFuture = null; }
        st = St.IDLE;
        attachFields();
    }

    private void openAdd() {
        addOpen = true;
        addError = "";
        nickField.setText("");
        dialogAt = Util.getMeasuringTimeMs();
        attachFields();
        nickField.setFocused(true);
        setFocused(nickField);
    }

    private void closeAdd() {
        addOpen = false;
        attachFields();
        setFocused(null);
    }

    private void confirmNick() {
        String err = Ias.addOffline(nickField.getText());
        if (err != null) { addError = err; return; }
        closeAdd();
        rebuild();
    }

    private void askDelete(Tile t) {
        delTarget = t;
        delDialog = new ServerDialog(ServerDialog.Mode.DELETE, null, null, 0, t.name + " пропадёт из списка аккаунтов", null);
        delDialog.titleOverride = "Удаление аккаунта";
    }

    private void confirmDelete() {
        if (delTarget != null && delTarget.acc != null) Ias.remove(delTarget.acc);
        delDialog = null;
        delTarget = null;
        rebuild();
    }

    // ---------- input ----------
    private static boolean hit(float[] r, double mx, double my) {
        return r[2] > 0 && Gfx.inside(mx, my, r[0], r[1], r[2], r[3]);
    }

    private static float ease(float x) {
        x = Math.max(0f, Math.min(1f, x));
        return 1f - (1f - x) * (1f - x);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        double mx = click.x() / scene.k, my = click.y() / scene.k;

        if (delDialog != null) {
            int r = delDialog.click(mx, my, this);
            if (r == 1) { delDialog = null; delTarget = null; }
            else if (r == 2) confirmDelete();
            return true;
        }
        switch (st) {
            case WORKING -> { if (hit(rCancel, mx, my)) cancelLogin(); return true; }
            case ERROR -> { if (hit(rCancel, mx, my)) st = St.IDLE; return true; }
            case DONE -> { return true; }
            case PASSWORD -> {
                if (hit(rPwBox, mx, my)) { pwField.setFocused(true); setFocused(pwField); }
                else if (hit(rPwOk, mx, my)) submitPassword();
                return true;
            }
            default -> { }
        }
        if (addOpen) {
            if (hit(rAddX, mx, my)) closeAdd();
            else if (hit(rNickBox, mx, my)) { nickField.setFocused(true); setFocused(nickField); }
            else if (hit(rAddNick, mx, my)) confirmNick();
            else if (hit(rAddMs, mx, my) && Ias.canAddMicrosoft()) { addOpen = false; attachFields(); Ias.addMicrosoft(this); }
            return true;
        }

        if (hit(rClose, mx, my)) { close(); return true; }
        if (!Ias.available()) return true;   // IAS missing: nothing to pick, the notice explains why
        if (delXTile != null && hit(rDelX, mx, my)) { askDelete(delXTile); return true; }
        for (Tile t : tiles) {
            if (!t.contains(mx, my)) continue;
            if (t.add) openAdd();
            else startLogin(t);
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (addOpen || delDialog != null || st != St.IDLE) return true;
        float total = tiles.size() * STEP, avail = scene.vw - 120f;
        float max = Math.max(0f, total - avail);
        scrollTarget = Math.max(0f, Math.min(max, scrollTarget - (float) (verticalAmount + horizontalAmount) * 70f));
        return true;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int kc = input.key();
        if (kc == org.lwjgl.glfw.GLFW.GLFW_KEY_ENTER || kc == org.lwjgl.glfw.GLFW.GLFW_KEY_KP_ENTER) {
            if (st == St.PASSWORD) { submitPassword(); return true; }
            if (addOpen && st == St.IDLE) { confirmNick(); return true; }
        }
        return super.keyPressed(input);
    }

    @Override public boolean shouldPause() { return false; }

    @Override
    public void close() {
        if (delDialog != null) { delDialog = null; delTarget = null; return; }
        if (st == St.WORKING || st == St.PASSWORD) { cancelLogin(); return; }
        if (st == St.ERROR) { st = St.IDLE; return; }
        if (st == St.DONE) return;
        if (addOpen) { closeAdd(); return; }
        client.setScreen(parent);
    }
}

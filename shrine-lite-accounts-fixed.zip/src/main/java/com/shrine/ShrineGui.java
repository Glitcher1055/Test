package com.shrine;

import com.shrine.Gfx.Fnt;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.util.ArrayList;
import java.util.List;

import static com.shrine.Gfx.*;
import java.util.HashMap;
import java.util.Map;

/**
 * Settings window of the mod (opened with Right Shift): a glass panel with a tab list on the left and scrolling
 * settings on the right. To add a tab or a setting, edit {@link #TABS} below - the layout is automatic.
 * Values live in {@link ShrineCfg} (config/shrine.properties); read them anywhere with ShrineCfg.bool("visual.particles", true).
 */
public final class ShrineGui extends Screen {

    // ================= content: add new tabs / settings here =================
    static final int[] PALETTE = {0xFF4D5D, 0xFF8A4D, 0xFFD24D, 0x5DE08A, 0x4DB8FF, 0xB07CFF, 0xFFFFFF, 0xFF7AC8};
    /** Window accent: the red of the menus. */
    private static final int ACC = Gfx.ACCENT, LAV = 0xFFC4C4;

    private static final List<Tab> TABS = List.of(
        tab("Visual", "Визуал",
            mod("Предсказания", "Метка падения и линия полёта пёрла, снежка, зелья, стрелы и трезубца", "nav", Predictions.KEY, true, true,
                toggle(Predictions.K_PEARL, "Эндер-пёрл", true),
                toggle(Predictions.K_SNOW, "Снежок и яйцо", true),
                toggle(Predictions.K_POTION, "Зелья и пузырьки опыта", true),
                toggle(Predictions.K_ARROW, "Лук, арбалет, трезубец", true),
                toggle(Predictions.K_OTHERS, "Чужие снаряды", true),
                toggle(Predictions.K_LINE, "Линия траектории", true),
                toggle(Predictions.K_TIME, "Время до падения", true),
                color(Predictions.K_COLOR, "Цвет", 0))),
        tab("Hud", "HUD",
            mod("Инвентарь", "Сетка 9×3 с твоим инвентарём: количество предметов и прочность", "pack", InventoryHud.KEY, true, true,
                slider(InventoryHud.K_SCALE, "Масштаб", 0.5f, 2.0f, 1f, "x"),
                toggle(InventoryHud.K_BG, "Общий фон", true),
                toggle(InventoryHud.K_SLOTS, "Фон слотов", true),
                button("hud.inventory.pos", "Расположение", "Перетащить панель, размер колёсиком"))),
        tab("Player", "Игрок"),
        tab("Target", "Цель",
            mod("Target ESP", "Свечение вокруг цели, пока прицел на ней: 11 стилей на выбор", "cube", TargetEsp.KEY, true, true,
                choice(TargetEsp.K_STYLE, "Стиль", 0, TargetEsp.STYLES),
                color(TargetEsp.K_COLOR, "Цвет", 5),
                slider(TargetEsp.K_SPEED, "Скорость анимации", 0.4f, 2.5f, 1f, "x")),
            mod("Здоровье цели", "Панель с именем, здоровьем и бронёй того, на кого смотришь", "info", TargetHud.KEY, true, true,
                choice(TargetHud.K_DESIGN, "Дизайн", 0, TargetHud.DESIGNS),
                toggle(TargetHud.KEY_ARMOR, "Показывать броню и предметы", true),
                slider(TargetHud.K_SCALE, "Размер", 0.5f, 2.5f, 1f, "x"),
                button("hud.target.pos", "Расположение", "Перетащить панель, размер колёсиком")),
            mod("Kill Effect", "Анимация после убийства противника: 10 режимов", "skin", KillEffect.KEY, true, true,
                choice(KillEffect.K_MODE, "Режим", 0, KillEffect.MODES),
                color(KillEffect.K_COLOR, "Цвет", 4),
                slider(KillEffect.K_SIZE, "Размер", 0.5f, 2.0f, 1f, "x"),
                choice(KillEffect.K_DETAIL, "Детализация", 1, KillEffect.DETAIL),
                button("kill.test", "Проверить эффект", "Показать эффект перед собой")))
    );

    /** A module that is on the roadmap but not written yet: only a card with its name. */
    private static Sec soon(String name) { return sec(name + " · скоро"); }
    // =========================================================================

    private enum T { TOGGLE, CHOICE, SLIDER, COLOR, BUTTON }
    private record Opt(T t, String key, String label, float min, float max, float def, String unit, String[] items, String sub) {}
    private record Sec(String title, List<Opt> opts, String desc, String icon, String master, boolean masterDef, boolean open, boolean pinned) {}
    private record Tab(String name, String sub, List<Sec> secs) {}

    private static Tab tab(String n, String s, Sec... secs) { return new Tab(n, s, List.of(secs)); }
    private static Sec sec(String t, Opt... o) { return new Sec(t, List.of(o), "", "sliders", null, false, false, false); }
    /** A function card: icon tile, title, description, arrow (opens its settings right inside the card) and an on/off switch ("master"). */
    private static Sec mod(String t, String desc, String icon, String master, boolean masterDef, boolean open, Opt... o) {
        return new Sec(t, List.of(o), desc, icon, master, masterDef, open, false);
    }
    private static Opt toggle(String k, String l, boolean d) { return new Opt(T.TOGGLE, k, l, 0, 1, d ? 1 : 0, "", null, null); }
    /** A toggle that also has its own settings page: right-click it. */
    private static Opt func(String k, String l, boolean d, String sub) { return new Opt(T.TOGGLE, k, l, 0, 1, d ? 1 : 0, "", null, sub); }
    private static Opt choice(String k, String l, int d, String... items) { return new Opt(T.CHOICE, k, l, 0, items.length - 1, d, "", items, null); }
    private static Opt slider(String k, String l, float min, float max, float d, String u) { return new Opt(T.SLIDER, k, l, min, max, d, u, null, null); }
    /** A row that runs an action when clicked (see {@link #action}); the hint is shown under the label. */
    private static Opt button(String id, String l, String hint) { return new Opt(T.BUTTON, id, l, 0, 1, 0, hint, null, null); }
    private static Opt color(String k, String l, int d) { return new Opt(T.COLOR, k, l, 0, PALETTE.length - 1, d, "", null, null); }

    // ================= window geometry (virtual 540-high canvas) =================
    private static final float W = 760f, H = 420f, SIDE = 64f, PAD = 18f, ROW_GAP = 2f;
    private static final float HEADH = 58f, SUBH = 30f;   // card: title row, arrow + switch row
    private static final float HEAD = 66f;      // top bar height above the scrolling area

    private float k = 1f, vw = 960f;
    private final long openedAt = Util.getMeasuringTimeMs();
    private int tab;
    private float scroll, scrollTarget, contentH;
    private float[] tabHover = new float[TABS.size()];
    private float tabAnim;                      // 0..1 content fade after switching a tab
    private float x, y;

    // hit areas rebuilt every frame
    private record Hit(float x, float y, float w, float h, Opt opt, int idx) {}
    private final List<Hit> hits = new ArrayList<>();
    /** Opened / closed state of the cards (kept while the game runs) and their opening animation. */
    private static final Map<String, Boolean> OPEN = new HashMap<>();
    private final Map<String, Float> anim = new HashMap<>();
    private List<Sec> curSecs = List.of();
    private Opt dragging;
    private float dragX, dragW;
    private float[] rClose = new float[4], rView = new float[4], rSearch = new float[4];
    /** Dropdown of a choice setting: the option whose list is open, and the rows drawn this frame. */
    private static final float DROP_ROW = 24f, DROP_PAD = 5f;
    private Opt dropOpt;
    private final Map<String, float[]> choiceRect = new HashMap<>();
    private float vtF, vbF;
    private String query = "";
    private boolean searchFocus;

    public ShrineGui() { super(Text.literal("Shrine")); }

    @Override
    protected void init() {
        k = height / Scene.REF_H;
        vw = width / k;
    }

    @Override public boolean shouldPause() { return false; }

    private float open() {
        float t = Math.min(1f, (Util.getMeasuringTimeMs() - openedAt) / 260f);
        return 1f - (1f - t) * (1f - t);
    }

    private static float ease(float cur, float to, float d) { return cur + (to - cur) * Math.min(1f, d); }

    // ---------- render ----------
    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        // our own backdrop is drawn in render(); the vanilla blur is not wanted
    }

    @Override
    public void render(DrawContext ctx, int mxReal, int myReal, float delta) {
        float a = open();
        // the game stays visible behind the window, only darkened with a red tint
        ctx.fillGradient(0, 0, width, height, argb(0.62f * a, 0x0C0205), argb(0.78f * a, 0x2A0509));
        float mx = mxReal / k, my = myReal / k;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);

        x = (vw - W) / 2f;
        y = (Scene.REF_H - H) / 2f + (1f - a) * 16f;
        hits.clear();
        tabAnim = ease(tabAnim, 1f, delta * 0.22f);
        scroll = ease(scroll, scrollTarget, delta * 0.4f);

        // window
        box(ctx, RR, x - 1, y - 1, W + 2, H + 2, 27, argb(0.14f * a, 0xFFFFFF));
        box(ctx, RR, x, y, W, H, 26, argb(0.93f * a, 0x150A0F));
        box(ctx, RR, x, y, SIDE, H, 26, argb(0.55f * a, 0x000000));
        ctx.fill(Math.round(x + SIDE), Math.round(y + 22), Math.round(x + SIDE) + 1, Math.round(y + H - 22), argb(0.07f * a, 0xFFFFFF));

        drawContent(ctx, mx, my, a, delta);
        drawSidebar(ctx, mx, my, delta, a);

        ctx.getMatrices().popMatrix();
    }

    private void drawSidebar(DrawContext ctx, float mx, float my, float delta, float a) {
        // logo
        box(ctx, RR, x + 14, y + 14, 36, 36, 12, argb(a, ACC));
        textC(ctx, textRenderer, Fnt.TITLE_B, "S", x + 32, y + 32, argb(a, 0xFFFFFF));
        ctx.fill(Math.round(x + 18), Math.round(y + 62), Math.round(x + SIDE - 18), Math.round(y + 62) + 1, argb(0.10f * a, 0xFFFFFF));

        float ty = y + 74;
        int over = -1;
        float overY = 0f;
        for (int i = 0; i < TABS.size(); i++) {
            float bx = x + 10, bw = SIDE - 20, bh = 44;
            boolean hov = inside(mx, my, bx, ty, bw, bh);
            if (hov) { over = i; overY = ty; }
            tabHover[i] = ease(tabHover[i], hov ? 1f : 0f, delta * 0.3f);
            boolean sel = i == tab;
            if (sel) {
                box(ctx, RR, bx, ty, bw, bh, 13, argb(0.30f * a, ACC));
                box(ctx, RR_RING, bx, ty, bw, bh, 13, argb(0.55f * a, ACC));
            } else if (tabHover[i] > 0.01f) {
                box(ctx, RR, bx, ty, bw, bh, 13, argb(0.08f * tabHover[i] * a, 0xFFFFFF));
            }
            tabIcon(ctx, TABS.get(i).name(), bx + bw / 2f, ty + bh / 2f,
                    argb((sel ? 1f : 0.42f + 0.40f * tabHover[i]) * a, sel ? 0xFFFFFF : 0xE6C4C4));
            hits.add(new Hit(bx, ty, bw, bh, null, i));
            ty += bh + 8;
        }

        // user
        float uy = y + H - 50;
        centered(ctx, DISC, x + SIDE / 2f, uy + 18, 30, 30, argb(0.9f * a, 0x5A2A33));
        String nick = net.minecraft.client.MinecraftClient.getInstance().getSession().getUsername();
        textC(ctx, textRenderer, Fnt.TINY_B, nick.isEmpty() ? "?" : nick.substring(0, 1).toUpperCase(java.util.Locale.ROOT), x + SIDE / 2f, uy + 18, argb(a, 0xFFFFFF));

        // name of the hovered tab
        if (over >= 0) {
            String n = TABS.get(over).name();
            float w = width(textRenderer, Fnt.SMALL, n) + 24;
            box(ctx, RR, x + SIDE + 6, overY + 7, w, 30, 10, argb(0.96f * a, 0x1A0B11));
            box(ctx, RR_RING, x + SIDE + 6, overY + 7, w, 30, 10, argb(0.35f * a, ACC));
            text(ctx, textRenderer, Fnt.SMALL, n, x + SIDE + 18, overY + 22, argb(a, 0xFFFFFF));
        }
    }

    private void tabIcon(DrawContext ctx, String n, float cx, float cy, int col) {
        switch (n) {
            case "Target" -> {
                centered(ctx, RING, cx, cy, 22, 22, col);
                ctx.fill(Math.round(cx) - 1, Math.round(cy) - 11, Math.round(cx) + 1, Math.round(cy) - 5, col);
                ctx.fill(Math.round(cx) - 1, Math.round(cy) + 5, Math.round(cx) + 1, Math.round(cy) + 11, col);
                ctx.fill(Math.round(cx) - 11, Math.round(cy) - 1, Math.round(cx) - 5, Math.round(cy) + 1, col);
                ctx.fill(Math.round(cx) + 5, Math.round(cy) - 1, Math.round(cx) + 11, Math.round(cy) + 1, col);
            }
            case "Visual" -> { centered(ctx, RING, cx, cy, 22, 22, col); centered(ctx, DISC, cx, cy, 8, 8, col); }
            case "Hud" -> {
                for (int i = 0; i < 4; i++) centered(ctx, DISC, cx - 5 + (i % 2) * 10, cy - 5 + (i / 2) * 10, 7, 7, col);
            }
            case "Builders" -> { box(ctx, RR_RING, cx - 9, cy - 9, 18, 18, 4, col); box(ctx, RR, cx - 4, cy - 4, 8, 8, 2, col); }
            case "Themes" -> { centered(ctx, DISC, cx - 3, cy, 16, 16, col); centered(ctx, RING, cx + 4, cy, 14, 14, col); }
            case "Cosmetics" -> {
                centered(ctx, DISC, cx, cy - 6, 8, 8, col);
                centered(ctx, DISC, cx - 6, cy + 5, 8, 8, col);
                centered(ctx, DISC, cx + 6, cy + 5, 8, 8, col);
            }
            default -> centered(ctx, DISC, cx, cy, 10, 10, col);
        }
    }

    /** {enabled functions, all functions}: a function is a card with an on/off switch. */
    private int[] counts() {
        int on = 0, all = 0;
        for (Tab tb : TABS) for (Sec s : tb.secs())
            if (s.master() != null) { all++; if (ShrineCfg.bool(s.master(), s.masterDef())) on++; }
        return new int[]{on, all};
    }

    private List<Sec> searchSecs() {
        String q = query.trim().toLowerCase(java.util.Locale.ROOT);
        List<Opt> found = new ArrayList<>();
        for (Tab tb : TABS) for (Sec s : tb.secs()) for (Opt o : s.opts())
            if (o.label().toLowerCase(java.util.Locale.ROOT).contains(q)) found.add(o);
        return List.of(new Sec("Результаты: " + found.size(), found, "Найдено по запросу", "sliders", null, false, true, true));
    }

    private String tailFit(String s, float maxW) {
        while (s.length() > 1 && width(textRenderer, Fnt.SMALL, s) > maxW) s = s.substring(1);
        return s;
    }

    private void drawContent(DrawContext ctx, float mx, float my, float a, float delta) {
        Tab t = TABS.get(tab);
        float cx = x + SIDE + PAD, cw = W - SIDE - PAD * 2;
        float ta = a * tabAnim;

        // ---- scrolling area (drawn first: the top bar stays above it) ----
        float vt = y + HEAD, vb = y + H - 24, vh = vb - vt;
        rView = new float[]{cx - 8, vt, cw + 16, vh};
        vtF = vt; vbF = vb;
        choiceRect.clear();
        float cur = 0f;
        float oy = vt - scroll + (1f - tabAnim) * 10f;

        {
            List<Sec> secs = query.isBlank() ? t.secs() : searchSecs();
            curSecs = secs;
            if (secs.isEmpty()) {
                textC(ctx, textRenderer, Fnt.LABEL, "Пока здесь пусто", cx + cw / 2f, vt + vh / 2f - 10, argb(0.5f * ta, 0xFFFFFF));
                textC(ctx, textRenderer, Fnt.SMALL, "Функции появятся позже", cx + cw / 2f, vt + vh / 2f + 14, argb(0.3f * ta, 0xFFFFFF));
            }
            float gap = 12f, colW = (cw - gap) / 2f;
            float[] colH = {0f, 0f};
            for (int i = 0; i < secs.size(); i++) {
                Sec s = secs.get(i);
                int c = i % 2;                       // fixed column: cards never jump while they open / close
                float fr = stepAnim(s, delta);
                float h = cardH(s, colW, fr);
                drawCard(ctx, s, i, cx + c * (colW + gap), oy + colH[c], colW, h, fr, mx, my, ta, vt, vb);
                colH[c] += h + 10f;
            }
            cur = Math.max(colH[0], colH[1]);
        }
        if (dropOpt != null && !choiceRect.containsKey(dropOpt.key())) dropOpt = null;   // its row scrolled away
        contentH = cur;
        float max = Math.max(0f, contentH - vh);
        scrollTarget = Math.max(0f, Math.min(max, scrollTarget));
        if (max > 0f) {
            float th = Math.max(26f, vh * vh / contentH), ty = vt + (vh - th) * (scroll / max);
            box(ctx, RR, x + W - 12, ty, 3, th, 1.5f, argb(0.45f * a, ACC));
        }

        // ---- top bar ----
        float by0 = y + 14, bh0 = 34f;
        String cat = t.name();
        float pw = width(textRenderer, Fnt.UI_B, cat) + 44;
        box(ctx, RR, cx, by0, pw, bh0, 12, argb(0.20f * a, ACC));
        box(ctx, RR_RING, cx, by0, pw, bh0, 12, argb(0.50f * a, ACC));
        centered(ctx, DISC, cx + 17, by0 + bh0 / 2f, 8, 8, argb(a, ACC));
        text(ctx, textRenderer, Fnt.UI_B, cat, cx + 30, by0 + bh0 / 2f, argb(a, 0xFFFFFF));
        float nx = cx + pw + 8;
        {
            int[] cnt = counts();
            String cs = cnt[0] + " / " + cnt[1];
            float cwd = width(textRenderer, Fnt.SMALL, cs) + 36;
            box(ctx, RR, nx, by0, cwd, bh0, 12, argb(0.07f * a, 0xFFFFFF));
            centered(ctx, DISC, nx + 15, by0 + bh0 / 2f, 7, 7, argb(a, 0x5DE08A));
            text(ctx, textRenderer, Fnt.SMALL, cs, nx + 26, by0 + bh0 / 2f, argb(0.85f * a, 0xFFFFFF));
            float sw = 190f, sx = x + W - 56 - sw;
            rSearch = new float[]{sx, by0, sw, bh0};
            box(ctx, RR, sx, by0, sw, bh0, 12, argb((searchFocus ? 0.14f : 0.07f) * a, 0xFFFFFF));
            if (searchFocus) box(ctx, RR_RING, sx, by0, sw, bh0, 12, argb(0.55f * a, ACC));
            boolean caret = searchFocus && (Util.getMeasuringTimeMs() / 500L) % 2L == 0L;
            String qs = query.isEmpty() ? "Поиск" : tailFit(query, sw - 30) + (caret ? "|" : "");
            text(ctx, textRenderer, Fnt.SMALL, qs, sx + 14, by0 + bh0 / 2f, argb((query.isEmpty() ? 0.35f : 1f) * a, 0xFFFFFF));
        }
        float bx = x + W - 30, byc = by0 + bh0 / 2f;
        boolean hc = inside(mx, my, bx - 15, byc - 15, 30, 30);
        centered(ctx, DISC, bx, byc, 28, 28, argb((hc ? 0.28f : 0.14f) * a, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.UI_B, "×", bx, byc - 1, argb(a, 0xFFFFFF));
        rClose = new float[]{bx - 15, byc - 15, 30, 30};

        // ---- footer ----
        text(ctx, textRenderer, Fnt.TINY_B, "Shrine 1.0 · 1.21.11", cx, y + H - 12, argb(0.28f * a, 0xFFFFFF));
        String hint = "Стрелка на карточке - настройки   ·   Right Shift - закрыть";
        text(ctx, textRenderer, Fnt.TINY_B, hint, x + W - PAD - width(textRenderer, Fnt.TINY_B, hint), y + H - 12, argb(0.28f * a, 0xFFFFFF));

        drawDrop(ctx, mx, my, a);
    }


    private static float edgeFade(float center, float top, float bottom) {
        float e = Math.min(center - top, bottom - center);
        return Math.max(0f, Math.min(1f, e / 24f));
    }

    private float rowHeight(Opt o, float cw) {
        return o.t() == T.SLIDER ? 42f : o.t() == T.BUTTON && !o.unit().isEmpty() ? 40f : 32f;
    }

    private boolean isOpen(Sec s) { return s.pinned() || OPEN.getOrDefault(s.title(), s.open()); }

    /** Eased 0..1 opening state of a card. */
    private float stepAnim(Sec s, float delta) {
        float to = isOpen(s) ? 1f : 0f;
        float cur = anim.getOrDefault(s.title(), to);
        cur = ease(cur, to, delta * 0.35f);
        if (Math.abs(cur - to) < 0.004f) cur = to;
        anim.put(s.title(), cur);
        return cur;
    }

    private static boolean hasSub(Sec s) { return !s.pinned() && (!s.opts().isEmpty() || s.master() != null); }

    private float rowsH(Sec s, float colW) {
        float sum = 0f;
        for (Opt o : s.opts()) sum += rowHeight(o, colW - 28f) + ROW_GAP;
        return sum;
    }

    private float cardH(Sec s, float colW, float fr) {
        float h = HEADH + (hasSub(s) ? SUBH : 0f) + 8f;
        if (!s.opts().isEmpty()) h += fr * (rowsH(s, colW) + 4f);
        return h;
    }

    private String fit(Fnt f, String s, float maxW) {
        if (width(textRenderer, f, s) <= maxW) return s;
        while (s.length() > 1 && width(textRenderer, f, s + "...") > maxW) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    private void pill(DrawContext ctx, float px, float py, boolean on, float f) {
        box(ctx, RR, px, py, 38, 20, 10, argb((on ? 1f : 0.16f) * f, on ? ACC : 0xFFFFFF));
        centered(ctx, DISC, on ? px + 28 : px + 10, py + 10, 14, 14, argb(f, 0xFFFFFF));
    }

    /** One function card: [icon tile] title / description, then [arrow ... switch], then the settings. */
    private void drawCard(DrawContext ctx, Sec s, int idx, float sx, float top, float cw, float h, float fr,
                          float mx, float my, float ta, float vt, float vb) {
        float bt = Math.max(top, vt), bb = Math.min(top + h, vb);
        if (bb - bt > 6f) {
            box(ctx, RR, sx, bt, cw, bb - bt, 16, argb(0.95f * ta, 0x120609));
            box(ctx, RR_RING, sx, bt, cw, bb - bt, 16, argb(0.10f * ta, 0xFFFFFF));
        }
        boolean sub = hasSub(s), hasOpts = !s.opts().isEmpty();
        float fa = edgeFade(top + HEADH / 2f, vt, vb) * ta;
        if (fa > 0.01f) {
            box(ctx, RR, sx + 12, top + 10, 38, 38, 12, argb(fa, 0x2A0F16));
            centered(ctx, tex("ico_" + s.icon()), sx + 31, top + 29, 20, 20, argb(fa, 0xFF9AA2));
            text(ctx, textRenderer, Fnt.UI_B, s.title(), sx + 62, top + 23, argb(fa, 0xFFFFFF));
            if (!s.desc().isEmpty())
                text(ctx, textRenderer, Fnt.TINY_B, fit(Fnt.TINY_B, s.desc(), cw - 76f), sx + 62, top + 43, argb(0.42f * fa, 0xFFFFFF));
        }
        if (sub) {
            float sy = top + HEADH + SUBH / 2f;
            float fb = edgeFade(sy, vt, vb) * ta;
            boolean hov = inside(mx, my, sx, top, cw, HEADH + SUBH) && my > vt && my < vb;
            if (fb > 0.01f) {
                if (hasOpts) centered(ctx, tex(fr > 0.5f ? "ico_chev_up" : "ico_chev_down"), sx + 26, sy, 14, 14, argb((hov ? 1f : 0.7f) * fb, 0xFFFFFF));
                if (s.master() != null) pill(ctx, sx + cw - 14 - 38, sy - 10, ShrineCfg.bool(s.master(), s.masterDef()), fb);
            }
            if (s.master() != null)
                hits.add(new Hit(sx + cw - 14 - 38 - 6, sy - 13, 50, 26,
                        new Opt(T.TOGGLE, s.master(), "", 0, 1, s.masterDef() ? 1 : 0, "", null, null), 0));
            if (hasOpts) hits.add(new Hit(sx, top, cw, HEADH + SUBH, null, 300 + idx));
        }
        if (fr < 0.01f) return;
        float ry = top + HEADH + (sub ? SUBH : 0f) + 2f;
        for (Opt o : s.opts()) {
            float rh = rowHeight(o, cw - 28f);
            if (ry + rh > top + h - 6f) break;                  // not revealed yet while the card is opening
            float f = edgeFade(ry + rh / 2f, vt, vb) * ta * fr;
            if (f > 0.01f) drawOpt(ctx, o, sx + 14, ry, cw - 28f, rh, mx, my, f, vt, vb);
            ry += rh + ROW_GAP;
        }
    }

    private void drawOpt(DrawContext ctx, Opt o, float cx, float ry, float cw, float h, float mx, float my, float f, float vt, float vb) {
        boolean hov = inside(mx, my, cx - 6, ry, cw + 12, h) && my > vt && my < vb;
        if (hov) box(ctx, RR, cx - 6, ry, cw + 12, h, 8, argb(0.05f * f, 0xFFFFFF));
        float cy = ry + h / 2f;
        switch (o.t()) {
            case TOGGLE -> {
                boolean on = ShrineCfg.bool(o.key(), o.def() > 0.5f);
                text(ctx, textRenderer, Fnt.SMALL, o.label(), cx, cy, argb(0.92f * f, 0xFFFFFF));
                pill(ctx, cx + cw - 38, cy - 10, on, f);
                hits.add(new Hit(cx - 6, ry, cw + 12, h, o, 0));
            }
            case SLIDER -> {
                float v = ShrineCfg.num(o.key(), o.def());
                v = Math.max(o.min(), Math.min(o.max(), v));
                String val = String.format(java.util.Locale.ROOT, "%.1f", v) + o.unit();
                text(ctx, textRenderer, Fnt.SMALL, o.label(), cx, cy, argb(0.92f * f, 0xFFFFFF));
                float tx = cx + cw * 0.46f, tw = cw - cw * 0.46f, ty = ry + 28;
                text(ctx, textRenderer, Fnt.TINY_B, val, cx + cw - width(textRenderer, Fnt.TINY_B, val), ry + 11, argb(0.7f * f, LAV));
                float p = (v - o.min()) / (o.max() - o.min());
                box(ctx, RR, tx, ty - 2, tw, 4, 2, argb(0.16f * f, 0xFFFFFF));
                box(ctx, RR, tx, ty - 2, Math.max(4f, tw * p), 4, 2, argb(f, ACC));
                centered(ctx, GLOW, tx + tw * p, ty, 22, 22, argb(0.45f * f, ACC));
                centered(ctx, DISC, tx + tw * p, ty, 9, 9, argb(f, LAV));
                hits.add(new Hit(tx - 6, ry + 16, tw + 12, 24, o, 0));
            }
            case COLOR -> {
                int idx = Math.max(0, Math.min(PALETTE.length - 1, ShrineCfg.integer(o.key(), (int) o.def())));
                centered(ctx, tex("ico_refresh"), cx + 6, cy, 12, 12, argb(0.6f * f, 0xFFFFFF));
                text(ctx, textRenderer, Fnt.SMALL, o.label(), cx + 22, cy, argb(0.92f * f, 0xFFFFFF));
                centered(ctx, GLOW, cx + cw - 10, cy, 30, 30, argb(0.35f * f, PALETTE[idx]));
                centered(ctx, DISC, cx + cw - 10, cy, 12, 12, argb(f, PALETTE[idx]));
                hits.add(new Hit(cx - 6, ry, cw + 12, h, o, 0));
            }
            case BUTTON -> {
                boolean hasHint = !o.unit().isEmpty();
                text(ctx, textRenderer, Fnt.SMALL, o.label(), cx, hasHint ? ry + 13f : cy, argb(0.92f * f, 0xFFFFFF));
                if (hasHint) text(ctx, textRenderer, Fnt.TINY_B, o.unit(), cx, ry + 28f, argb(0.4f * f, 0xFFFFFF));
                textC(ctx, textRenderer, Fnt.UI_B, "›", cx + cw - 8, cy, argb((hov ? 1f : 0.7f) * f, 0xFFFFFF));
                hits.add(new Hit(cx - 6, ry, cw + 12, h, o, 0));
            }
            case CHOICE -> {
                int sel = Math.max(0, Math.min(o.items().length - 1, ShrineCfg.integer(o.key(), (int) o.def())));
                String s = o.items()[sel];
                float pw = width(textRenderer, Fnt.SMALL, s) + 22;
                centered(ctx, tex("ico_refresh"), cx + 6, cy, 12, 12, argb(0.6f * f, 0xFFFFFF));
                text(ctx, textRenderer, Fnt.SMALL, o.label(), cx + 22, cy, argb(0.92f * f, 0xFFFFFF));
                box(ctx, RR, cx + cw - pw, cy - 11, pw, 22, 8, argb(0.08f * f, 0xFFFFFF));
                box(ctx, RR_RING, cx + cw - pw, cy - 11, pw, 22, 8, argb(0.12f * f, 0xFFFFFF));
                textC(ctx, textRenderer, Fnt.SMALL, s, cx + cw - pw / 2f, cy, argb(f, 0xFFFFFF));
                choiceRect.put(o.key(), new float[]{cx - 6, ry, cw + 12, h});
                hits.add(new Hit(cx - 6, ry, cw + 12, h, o, 0));
            }
        }
    }

    /** Where the open list of a choice setting is drawn: under its row, or above it if there is no room. */
    private float[] dropBox() {
        if (dropOpt == null) return null;
        float[] r = choiceRect.get(dropOpt.key());
        if (r == null) return null;
        float maxW = 0f;
        for (String s : dropOpt.items()) maxW = Math.max(maxW, width(textRenderer, Fnt.SMALL, s));
        float dw = maxW + 44f, dh = dropOpt.items().length * DROP_ROW + DROP_PAD * 2f;
        float dx = r[0] + r[2] - dw;
        float dy = r[1] + r[3] + 4f;
        if (dy + dh > vbF) dy = r[1] - dh - 4f;
        dy = Math.max(vtF, Math.min(dy, vbF - dh));
        return new float[]{dx, dy, dw, dh};
    }

    private void drawDrop(DrawContext ctx, float mx, float my, float a) {
        float[] d = dropBox();
        if (d == null) return;
        float dx = d[0], dy = d[1], dw = d[2], dh = d[3];
        box(ctx, RR, dx - 1, dy - 1, dw + 2, dh + 2, 13, argb(0.14f * a, 0xFFFFFF));
        box(ctx, RR, dx, dy, dw, dh, 12, argb(0.97f * a, 0x1A0B11));
        box(ctx, RR_RING, dx, dy, dw, dh, 12, argb(0.25f * a, ACC));
        String[] items = dropOpt.items();
        int sel = Math.max(0, Math.min(items.length - 1, ShrineCfg.integer(dropOpt.key(), (int) dropOpt.def())));
        for (int i = 0; i < items.length; i++) {
            float iy = dy + DROP_PAD + i * DROP_ROW;
            boolean hov = inside(mx, my, dx + 4, iy, dw - 8, DROP_ROW);
            if (i == sel) box(ctx, RR, dx + 4, iy, dw - 8, DROP_ROW, 8, argb(0.28f * a, ACC));
            else if (hov) box(ctx, RR, dx + 4, iy, dw - 8, DROP_ROW, 8, argb(0.08f * a, 0xFFFFFF));
            text(ctx, textRenderer, Fnt.SMALL, items[i], dx + 14, iy + DROP_ROW / 2f,
                    argb((i == sel ? 1f : 0.85f) * a, 0xFFFFFF));
        }
    }

    /** Runs a {@link #button} row. */
    private void action(String id) {
        if (client == null) return;
        if ("hud.target.pos".equals(id)) { ShrineCfg.save(); client.setScreen(new HudEditScreen(this, false)); }
        else if ("hud.inventory.pos".equals(id)) { ShrineCfg.save(); client.setScreen(new HudEditScreen(this, true)); }
        else if ("kill.test".equals(id)) { ShrineCfg.save(); client.setScreen(null); KillEffect.test(); }
    }

    // ---------- input ----------
    private double toV(double v) { return v / k; }

    private void setSlider(Opt o, double mx) {
        float p = (float) Math.max(0, Math.min(1, (mx - dragX) / dragW));
        float v = o.min() + p * (o.max() - o.min());
        float step = Math.abs(o.max() - o.min()) > 20f ? 1f : 0.1f;
        v = Math.round(v / step) * step;
        ShrineCfg.setNum(o.key(), v);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = toV(click.x()), my = toV(click.y());
        if (click.button() == 1) return true;       // no right-click pages any more: everything is inside the cards
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        searchFocus = rSearch[2] > 0f && inside(mx, my, rSearch[0], rSearch[1], rSearch[2], rSearch[3]);
        if (searchFocus) return true;
        if (inside(mx, my, rClose[0], rClose[1], rClose[2], rClose[3])) { close(); return true; }
        if (dropOpt != null) {                      // an open list: a click picks an item or closes the list
            float[] d = dropBox();
            if (d != null && inside(mx, my, d[0], d[1], d[2], d[3])) {
                int i = (int) ((my - d[1] - DROP_PAD) / DROP_ROW);
                if (i >= 0 && i < dropOpt.items().length) { ShrineCfg.setInt(dropOpt.key(), i); ShrineCfg.save(); }
            }
            dropOpt = null;
            return true;
        }
        boolean inView = inside(mx, my, rView[0], rView[1], rView[2], rView[3]);
        for (Hit h : hits) {
            if (!inside(mx, my, h.x, h.y, h.w, h.h)) continue;
            if (h.opt == null) {
                if (h.idx >= 300) {                     // click on a card header: open / close its settings
                    if (!inView) continue;
                    int i = h.idx - 300;
                    if (i < curSecs.size()) { Sec s = curSecs.get(i); OPEN.put(s.title(), !isOpen(s)); }
                    return true;
                }
                if (tab != h.idx || !query.isEmpty()) { tab = h.idx; query = ""; scroll = scrollTarget = 0f; tabAnim = 0f; }
                return true;
            }
            if (!inView) continue;
            Opt o = h.opt;
            switch (o.t()) {
                case TOGGLE -> ShrineCfg.setBool(o.key(), !ShrineCfg.bool(o.key(), o.def() > 0.5f));
                case CHOICE -> dropOpt = (dropOpt != null && dropOpt.key().equals(o.key())) ? null : o;
                case COLOR -> ShrineCfg.setInt(o.key(), (ShrineCfg.integer(o.key(), (int) o.def()) + 1) % PALETTE.length);
                case BUTTON -> action(o.key());
                case SLIDER -> { dragging = o; dragX = h.x + 6; dragW = h.w - 12; setSlider(o, mx); }
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (dragging != null) { setSlider(dragging, toV(click.x())); return true; }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (dragging != null) { dragging = null; ShrineCfg.save(); return true; }
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollTarget -= (float) verticalAmount * 46f;
        float max = Math.max(0f, contentH - (H - HEAD - 24f));
        scrollTarget = Math.max(0f, Math.min(max, scrollTarget));
        return true;
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (searchFocus) {
            int cp = input.codepoint();
            if (cp >= 32 && cp != 127 && query.length() < 40) { query += new String(Character.toChars(cp)); scroll = scrollTarget = 0f; }
            return true;
        }
        return super.charTyped(input);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (searchFocus) {
            int kc = input.key();
            if (kc == org.lwjgl.glfw.GLFW.GLFW_KEY_BACKSPACE) { if (!query.isEmpty()) query = query.substring(0, query.length() - 1); return true; }
            if (kc == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE || kc == org.lwjgl.glfw.GLFW.GLFW_KEY_ENTER) { searchFocus = false; if (kc == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) query = ""; return true; }
        }
        if (input.key() == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(input);
    }

    @Override
    public void close() {
        ShrineCfg.save();
        super.close();
    }
}

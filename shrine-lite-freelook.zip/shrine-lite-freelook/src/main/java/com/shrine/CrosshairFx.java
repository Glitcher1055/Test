package com.shrine;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.Perspective;

import static com.shrine.Gfx.RING;
import static com.shrine.Gfx.centered;

/** Combat > Crosshair: replaces the vanilla crosshair with a style / colour / size of your choice. */
final class CrosshairFx {
    private CrosshairFx() {}

    static final String KEY = "combat.crosshair", K_STYLE = "combat.crosshair.style", K_COLOR = "combat.crosshair.color",
            K_SIZE = "combat.crosshair.size", K_GAP = "combat.crosshair.gap", K_THICK = "combat.crosshair.thick";

    static void register() {
        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original -> (ctx, tick) -> {
            if (ShrineCfg.bool(KEY, false)) draw(ctx); else original.render(ctx, tick);
        });
    }

    private static void draw(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.currentScreen != null || mc.options.hudHidden) return;
        if (mc.options.getPerspective() != Perspective.FIRST_PERSON) return;
        int cx = ctx.getScaledWindowWidth() / 2, cy = ctx.getScaledWindowHeight() / 2;
        int style = Math.max(0, Math.min(3, ShrineCfg.integer(K_STYLE, 0)));
        int idx = Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, ShrineCfg.integer(K_COLOR, 6)));
        int col = 0xFF000000 | ShrineGui.PALETTE[idx];
        int size = Math.max(2, Math.round(ShrineCfg.num(K_SIZE, 6f)));
        int gap = Math.max(0, Math.round(ShrineCfg.num(K_GAP, 2f)));
        int t = Math.max(1, Math.round(ShrineCfg.num(K_THICK, 2f)));
        int lo = -(t / 2), hi = lo + t;

        if (style == 2) {                       // circle
            float d = (size + gap) * 2f + 4f;
            centered(ctx, RING, cx, cy, d, d, col);
            return;
        }
        if (style == 1 || style == 3) {         // dot (alone or in the middle of the cross)
            int r = Math.max(1, t);
            ctx.fill(cx - r / 2, cy - r / 2, cx - r / 2 + r + 1, cy - r / 2 + r + 1, col);
            if (style == 1) return;
        }
        // four arms
        ctx.fill(cx - gap - size, cy + lo, cx - gap, cy + hi, col);
        ctx.fill(cx + gap, cy + lo, cx + gap + size, cy + hi, col);
        ctx.fill(cx + lo, cy - gap - size, cx + hi, cy - gap, col);
        ctx.fill(cx + lo, cy + gap, cx + hi, cy + gap + size, col);
    }
}

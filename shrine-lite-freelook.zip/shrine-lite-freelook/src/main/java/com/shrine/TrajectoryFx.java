package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ChargedProjectilesComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import static com.shrine.Gfx.*;

/**
 * "Траектории полёта" (EvoVisuals, день 11). Shows where an ender pearl / snowball / egg / potion / XP bottle /
 * arrow / trident will land BEFORE you throw it (item in hand, bow being drawn, loaded crossbow), and for projectiles
 * that are already flying (yours and other players').
 *
 * What is drawn (everything is a 2D HUD overlay, 3D points are projected by hand, first person only):
 *  - landing mark lying on the surface: six thick rotating arcs, a translucent white ring, a solid square in the
 *    middle and a faint fill; it glides after the aim and turns red when the projectile would hit a living target;
 *  - a soft vertical column of light over the landing point (multishot crossbow: three marks, three columns);
 *  - a thick glowing pale-pink arc for the flight path;
 *  - a small dark pill with the flight time ("2.1 s") and an icon of the projectile; the pill outline turns green
 *    when the projectile lands in less than half a second, and red when it would hit someone.
 */
final class TrajectoryFx {
    private TrajectoryFx() {}

    static final String K_ON = "fx.traj", K_LEN = "fx.traj.len", K_TIME = "fx.traj.time", K_PRED = "fx.traj.predict",
            K_OTH = "fx.traj.others", K_LINE = "fx.traj.line", K_RED = "fx.traj.red", K_SIZE = "fx.traj.size",
            K_COL = "fx.traj.color", K_MULTI = "fx.traj.multi", K_VIG = "fx.traj.vignette", K_BEAM = "fx.traj.beam";

    private static final Identifier TIMER = tex("ico_timer");
    private static final int RED = 0xFF3A5E, GREEN = 0x2EE6A6, TEAL = 0x4FD8D0;
    private static final Vec3d UP = new Vec3d(0, 1, 0);

    private enum Kind { PEARL, ARROW, POTION, OTHER }

    static void init() {
        HudElementRegistry.attachElementBefore(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "trajectory"),
                TrajectoryFx::render);
    }

    // ================================================================ camera / projection

    private static final class Cam {
        Vec3d pos, fwd, right, up;
        float f, cx, cy;

        /** {screenX, screenY, depth} in GUI units, or null when the point is behind the camera. */
        float[] proj(Vec3d p) {
            Vec3d d = p.subtract(pos);
            double z = d.dotProduct(fwd);
            if (z < 0.05) return null;
            double x = d.dotProduct(right), y = d.dotProduct(up);
            return new float[]{(float) (cx + x / z * f), (float) (cy - y / z * f), (float) z};
        }
    }

    /** Width in PHYSICAL pixels of something `blocks` wide at `depth`, so strokes keep their perspective. */
    private static int pxw(Cam cam, float depth, double blocks, float s, int min, int max) {
        int v = Math.round((float) (cam.f * s * blocks / Math.max(0.3f, depth)));
        return Math.max(min, Math.min(max, v));
    }

    // ================================================================ simulation

    private record Shot(double speed, double gravity, double roll, boolean arrow, Kind kind) {}

    private static final class Result {
        final List<Vec3d> pts = new ArrayList<>();
        Vec3d end, normal = UP;
        LivingEntity target;
        double ticks;
        Kind kind = Kind.OTHER;
    }

    private static String path(net.minecraft.item.Item it) { return Registries.ITEM.getId(it).getPath(); }

    /** What the player would throw / shoot right now, or null. */
    private static Shot held(ClientPlayerEntity p) {
        for (Hand hand : Hand.values()) {
            ItemStack st = p.getStackInHand(hand);
            if (st.isEmpty()) continue;
            boolean using = p.isUsingItem() && p.getActiveItem().getItem() == st.getItem();
            switch (path(st.getItem())) {
                case "ender_pearl" -> { return new Shot(1.5, 0.03, 0, false, Kind.PEARL); }
                case "snowball", "egg" -> { return new Shot(1.5, 0.03, 0, false, Kind.OTHER); }
                case "splash_potion", "lingering_potion" -> { return new Shot(0.5, 0.05, -20, false, Kind.POTION); }
                case "experience_bottle" -> { return new Shot(0.7, 0.07, -20, false, Kind.POTION); }
                case "trident" -> { if (using) return new Shot(2.5, 0.05, 0, true, Kind.ARROW); }
                case "bow" -> {
                    if (using) {
                        float pull = BowItem.getPullProgress(p.getItemUseTime());
                        if (pull >= 0.1f) return new Shot(pull * 3.0, 0.05, 0, true, Kind.ARROW);
                    }
                }
                case "crossbow" -> { if (CrossbowItem.isCharged(st)) return new Shot(3.15, 0.05, 0, true, Kind.ARROW); }
                default -> { }
            }
        }
        return null;
    }

    private static Result sim(ClientWorld w, Entity shooter, Entity skip, Vec3d pos, Vec3d vel, double grav,
                              boolean arrow, Kind kind, int steps, List<LivingEntity> targets) {
        Result r = new Result();
        r.kind = kind;
        r.pts.add(pos);
        for (int i = 0; i < steps; i++) {
            Vec3d next = pos.add(vel);
            BlockHitResult bh = w.raycast(new RaycastContext(pos, next, RaycastContext.ShapeType.COLLIDER,
                    RaycastContext.FluidHandling.NONE, shooter));
            boolean blockHit = bh.getType() != HitResult.Type.MISS;
            double best = blockHit ? bh.getPos().squaredDistanceTo(pos) : Double.MAX_VALUE;
            LivingEntity hitE = null;
            Vec3d hitP = null;
            for (LivingEntity e : targets) {
                if (e == skip) continue;
                Optional<Vec3d> o = e.getBoundingBox().expand(0.3).raycast(pos, next);
                if (o.isPresent()) {
                    double d = o.get().squaredDistanceTo(pos);
                    if (d < best) { best = d; hitE = e; hitP = o.get(); }
                }
            }
            double len = Math.max(1.0e-6, vel.length());
            if (hitE != null) {
                r.end = hitP; r.target = hitE; r.normal = UP;
                r.ticks = i + Math.sqrt(best) / len;
                r.pts.add(hitP);
                return r;
            }
            if (blockHit) {
                r.end = bh.getPos();
                r.normal = new Vec3d(bh.getSide().getOffsetX(), bh.getSide().getOffsetY(), bh.getSide().getOffsetZ());
                r.ticks = i + Math.sqrt(best) / len;
                r.pts.add(r.end);
                return r;
            }
            pos = next;
            r.pts.add(pos);
            boolean water = w.getFluidState(BlockPos.ofFloored(pos)).isIn(FluidTags.WATER);
            double drag = water ? (arrow ? 0.6 : 0.8) : 0.99;
            vel = vel.multiply(drag).subtract(0, grav, 0);
            if (pos.y < w.getBottomY() - 8) break;
        }
        return r;
    }

    // ================================================================ frame

    /** Smooth follow / red fade of the marker of your own shot. */
    private static Vec3d smooth;
    private static long smoothT, redT;
    private static float redA;

    private static void render(DrawContext ctx, RenderTickCounter counter) {
        if (!ShrineCfg.bool(K_ON, true)) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null || mc.options.hudHidden || !mc.options.getPerspective().isFirstPerson()) return;
        float tp = counter.getTickProgress(false);

        Cam cam = new Cam();
        cam.pos = p.getCameraPosVec(tp);
        double yaw = Math.toRadians(p.getYaw(tp)), pit = Math.toRadians(p.getPitch(tp));
        cam.fwd = new Vec3d(-Math.sin(yaw) * Math.cos(pit), -Math.sin(pit), Math.cos(yaw) * Math.cos(pit));
        cam.right = new Vec3d(-Math.cos(yaw), 0, -Math.sin(yaw));
        cam.up = cam.right.crossProduct(cam.fwd);
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        double fov = mc.options.getFov().getValue();
        cam.f = (float) ((sh / 2.0) / Math.tan(Math.toRadians(fov) / 2.0));
        cam.cx = sw / 2f;
        cam.cy = sh / 2f;

        int steps = Math.max(10, Math.round(ShrineCfg.num(K_LEN, 120f)));
        List<LivingEntity> targets = new ArrayList<>();
        for (Entity e : w.getEntities()) {
            if (e instanceof LivingEntity le && le != p && le.isAlive() && !le.isSpectator()
                    && le.squaredDistanceTo(p) < 90 * 90 && targets.size() < 64) targets.add(le);
        }

        // projectiles already in the air (other players' and yours)
        if (ShrineCfg.bool(K_OTH, true)) {
            int shown = 0;
            for (Entity e : w.getEntities()) {
                if (shown >= 10) break;
                if (!(e instanceof ProjectileEntity pe) || e.squaredDistanceTo(p) > 96 * 96) continue;
                double grav; boolean arrow = false; Kind kind;
                switch (Registries.ENTITY_TYPE.getId(e.getType()).getPath()) {
                    case "ender_pearl" -> { grav = 0.03; kind = Kind.PEARL; }
                    case "snowball", "egg" -> { grav = 0.03; kind = Kind.OTHER; }
                    case "splash_potion", "lingering_potion", "potion" -> { grav = 0.05; kind = Kind.POTION; }
                    case "experience_bottle" -> { grav = 0.07; kind = Kind.POTION; }
                    case "arrow", "spectral_arrow", "trident" -> { grav = 0.05; arrow = true; kind = Kind.ARROW; }
                    default -> { continue; }
                }
                Vec3d v = e.getVelocity();
                if (v.lengthSquared() < 0.0025) continue;           // stuck in a block / standing still
                Result r = sim(w, e, pe.getOwner(), e.getLerpedPos(tp), v, grav, arrow, kind, steps, targets);
                draw(ctx, mc, cam, List.of(r), false);
                shown++;
            }
        }

        // what you are about to throw
        if (ShrineCfg.bool(K_PRED, true)) {
            Shot s = held(p);
            if (s != null) {
                double ro = Math.toRadians(s.roll());
                Vec3d dir = new Vec3d(-Math.sin(yaw) * Math.cos(pit), -Math.sin(pit + ro), Math.cos(yaw) * Math.cos(pit))
                        .normalize().multiply(s.speed());
                Vec3d pv = p.getVelocity();
                Vec3d start = p.getCameraPosVec(tp).subtract(0, 0.1, 0);
                List<Result> group = new ArrayList<>();
                // main shot first (it owns the timer and the red state), then multishot side shots
                group.add(sim(w, p, p, start, dir.add(pv.x, p.isOnGround() ? 0 : pv.y, pv.z), s.gravity(), s.arrow(), s.kind(), steps, targets));
                if (s.arrow() && s.speed() > 3.0 && ShrineCfg.bool(K_MULTI, true) && multishot(p)) {
                    for (int sgn = -1; sgn <= 1; sgn += 2) {
                        Vec3d d2 = rotate(dir, cam.up, Math.toRadians(10.0 * sgn));
                        group.add(sim(w, p, p, start, d2.add(pv.x, p.isOnGround() ? 0 : pv.y, pv.z), s.gravity(), s.arrow(), s.kind(), steps, targets));
                    }
                }
                draw(ctx, mc, cam, group, true);
            } else {
                redA = 0f;
            }
        }
    }

    /** A loaded crossbow with Multishot holds three projectiles. */
    private static boolean multishot(ClientPlayerEntity p) {
        for (Hand hand : Hand.values()) {
            ItemStack st = p.getStackInHand(hand);
            if (st.isEmpty() || !path(st.getItem()).equals("crossbow")) continue;
            ChargedProjectilesComponent c = st.get(DataComponentTypes.CHARGED_PROJECTILES);
            if (c != null && c.getProjectiles().size() >= 3) return true;
        }
        return false;
    }

    /** Rodrigues rotation of v around the unit axis by ang. */
    private static Vec3d rotate(Vec3d v, Vec3d axis, double ang) {
        double c = Math.cos(ang), s = Math.sin(ang);
        return v.multiply(c).add(axis.crossProduct(v).multiply(s)).add(axis.multiply(axis.dotProduct(v) * (1 - c)));
    }

    // ================================================================ low level drawing

    /** Per-stamp alpha so that `k` overlapping stamps add up to the wanted TOTAL alpha. */
    private static int ac(float total, int rgb, int k) {
        total = Math.max(0f, Math.min(0.999f, total));
        return argb(1f - (float) Math.pow(1f - total, 1.0 / Math.max(1, k)), rgb);
    }

    private static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = Math.round(((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int g = Math.round(((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int bl = Math.round((a & 255) + ((b & 255) - (a & 255)) * t);
        return (r << 16) | (g << 8) | bl;
    }

    /** Convex polygon (PHYSICAL pixels) filled row by row: every pixel is touched once, so alpha stays exact. */
    private static void poly(DrawContext ctx, float[] xs, float[] ys, int col) {
        int n = xs.length;
        float ymin = Float.MAX_VALUE, ymax = -Float.MAX_VALUE;
        for (int i = 0; i < n; i++) { ymin = Math.min(ymin, ys[i]); ymax = Math.max(ymax, ys[i]); }
        for (int y = (int) Math.floor(ymin); y < (int) Math.ceil(ymax); y++) {
            float yc = y + 0.5f, lo = Float.MAX_VALUE, hi = -Float.MAX_VALUE;
            for (int e = 0; e < n; e++) {
                int f = e + 1 == n ? 0 : e + 1;
                float ya = ys[e], yb = ys[f];
                if ((ya <= yc && yb > yc) || (yb <= yc && ya > yc)) {
                    float x = xs[e] + (xs[f] - xs[e]) * ((yc - ya) / (yb - ya));
                    lo = Math.min(lo, x);
                    hi = Math.max(hi, x);
                }
            }
            int xa = Math.round(lo), xb = Math.round(hi);
            if (hi > lo && xb > xa) ctx.fill(xa, y, xb, y + 1, col);
        }
    }

    /** Rectangle of width th around the segment (x0,y0)-(x1,y1); the ends overshoot a little so polyline joints close. */
    private static void quad(DrawContext ctx, float x0, float y0, float x1, float y1, float th, int col) {
        float dx = x1 - x0, dy = y1 - y0, len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 1.0e-3f) {
            int h = Math.max(1, Math.round(th / 2f)), cx = Math.round(x0), cy = Math.round(y0);
            ctx.fill(cx - h, cy - h, cx + h, cy + h, col);
            return;
        }
        float ux = dx / len, uy = dy / len, ex = ux * th * 0.035f, ey = uy * th * 0.035f;
        x0 -= ex; y0 -= ey; x1 += ex; y1 += ey;
        float nx = -uy * th / 2f, ny = ux * th / 2f;
        poly(ctx, new float[]{x0 + nx, x1 + nx, x1 - nx, x0 - nx}, new float[]{y0 + ny, y1 + ny, y1 - ny, y0 - ny}, col);
    }

    /** Filled convex polygon from 3D points (e.g. the disc under the mark). */
    private static void fillPoly(DrawContext ctx, Cam cam, List<Vec3d> pts, float s, int col) {
        float[] xs = new float[pts.size()], ys = new float[pts.size()];
        for (int i = 0; i < xs.length; i++) {
            float[] q = cam.proj(pts.get(i));
            if (q == null) return;
            xs[i] = q[0] * s;
            ys[i] = q[1] * s;
        }
        poly(ctx, xs, ys, col);
    }

    /**
     * Soft stroke between two points given in GUI units. Call it inside the 1/guiScale matrix: it works in PHYSICAL
     * pixels, `th` is the thickness in them and `a` the total opacity. Thick strokes (3 px and up) are rasterised as
     * exact quads, thin ones as 1-2 px stamps. `first` only matters for thin strokes (joints stay even).
     */
    private static void stroke(DrawContext ctx, float x0, float y0, float x1, float y1, float s, int th, float a,
                               int rgb, boolean first) {
        float dx = (x1 - x0) * s, dy = (y1 - y0) * s;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len > 3000f || a <= 0.002f) return;
        th = Math.max(1, th);
        if (th >= 3) {
            quad(ctx, x0 * s, y0 * s, x1 * s, y1 * s, th, argb(a, rgb));
            return;
        }
        int n = Math.max(1, (int) Math.ceil(len));
        int col = ac(a, rgb, th);
        float px = x0 * s, py = y0 * s;
        int h = th / 2;
        for (int i = first ? 0 : 1; i <= n; i++) {
            int ix = Math.round(px + dx * i / n) - h, iy = Math.round(py + dy * i / n) - h;
            ctx.fill(ix, iy, ix + th, iy + th, col);
        }
    }

    private static Vec3d pt(Vec3d c, Vec3d u, Vec3d v, double r, double a) {
        return c.add(u.multiply(Math.cos(a) * r)).add(v.multiply(Math.sin(a) * r));
    }

    private static Vec3d lerp(Vec3d a, Vec3d b, double t) { return a.add(b.subtract(a).multiply(t)); }

    /** Arc of a circle lying in the plane (u, v) around c. */
    private static void arc(DrawContext ctx, Cam cam, Vec3d c, Vec3d u, Vec3d v, double r, double a0, double a1,
                            float s, int th, float a, int rgb) {
        int seg = Math.max(3, (int) Math.ceil(Math.abs(a1 - a0) / (Math.PI / 24.0)));
        float[] prev = null;
        for (int i = 0; i <= seg; i++) {
            float[] cur = cam.proj(pt(c, u, v, r, a0 + (a1 - a0) * i / seg));
            if (prev != null && cur != null) stroke(ctx, prev[0], prev[1], cur[0], cur[1], s, th, a, rgb, i == 1);
            prev = cur;
        }
    }

    // ================================================================ flight path

    /** Thick glowing pale line: wide soft pass, brighter middle pass and a whitish core, easing in from the start. */
    private static void line(DrawContext ctx, Cam cam, Result r, int col, float s, float alpha) {
        int n = r.pts.size();
        if (n < 2) return;
        int mid = mix(col, 0xFFFFFF, 0.30f), core = mix(col, 0xFFFFFF, 0.70f);
        float[] prev = cam.proj(r.pts.get(0));
        for (int i = 1; i < n; i++) {
            float[] cur = cam.proj(r.pts.get(i));
            if (cur != null && prev != null && Math.abs(cur[0] - prev[0]) + Math.abs(cur[1] - prev[1]) < 900f) {
                float f = alpha * Math.min(1f, i / Math.max(6f, n * 0.15f));
                int th = pxw(cam, (cur[2] + prev[2]) * 0.5f, 0.06, s, 1, 8);
                stroke(ctx, prev[0], prev[1], cur[0], cur[1], s, th * 3, 0.13f * f, col, false);
                stroke(ctx, prev[0], prev[1], cur[0], cur[1], s, th * 2, 0.30f * f, mid, false);
                stroke(ctx, prev[0], prev[1], cur[0], cur[1], s, th, 0.92f * f, core, false);
            }
            prev = cur;
        }
    }

    // ================================================================ landing mark

    /** Soft column of light standing on the landing point: wide faint pass, brighter pass and a thin white core. */
    private static void beam(DrawContext ctx, Cam cam, Vec3d c, double h, double rad, float s, int col, float a) {
        float[] base = cam.proj(c);
        if (base == null) return;
        int w = pxw(cam, base[2], rad * 2.0, s, 3, 90);
        int hi = mix(col, 0xFFFFFF, 0.55f);
        final int N = 14;
        float[] prev = base;
        for (int k = 1; k <= N; k++) {
            float[] cur = cam.proj(c.add(0, h * k / N, 0));
            float f = 1f - (k - 1f) / N;
            f *= f;
            if (prev != null && cur != null) {
                stroke(ctx, prev[0], prev[1], cur[0], cur[1], s, w, 0.09f * a * f, col, false);
                stroke(ctx, prev[0], prev[1], cur[0], cur[1], s, Math.max(1, w * 72 / 100), 0.10f * a * f, hi, false);
                stroke(ctx, prev[0], prev[1], cur[0], cur[1], s, Math.max(1, w * 45 / 100), 0.11f * a * f, hi, false);
                stroke(ctx, prev[0], prev[1], cur[0], cur[1], s, Math.max(1, w / 5), 0.16f * a * f, 0xFFFFFF, false);
            }
            prev = cur;
        }
    }

    /**
     * Landing mark lying on the surface (call inside the 1/guiScale matrix). R is the outer radius in blocks.
     * Returns {screenX, topY} in GUI units for the pill, or null when the mark is behind the camera.
     */
    private static float[] marker(DrawContext ctx, Cam cam, Vec3d c, Vec3d n, double R, boolean beam, boolean full,
                                  float s, int col, float pulse, float time) {
        float[] cp = cam.proj(c);
        if (cp == null) return null;
        float depth = cp[2];
        Vec3d h = Math.abs(n.y) > 0.9 ? new Vec3d(1, 0, 0) : new Vec3d(0, 1, 0);
        Vec3d u = n.crossProduct(h).normalize(), v = n.crossProduct(u).normalize();
        int pink = mix(col, 0xFFFFFF, 0.12f);
        int tw = pxw(cam, depth, R * 0.15, s, 2, 40);     // outer arcs: thick, like in the video
        int tin = pxw(cam, depth, R * 0.085, s, 1, 24);   // inner white ring
        float rot = time * 1.25f;

        // faint translucent fill of the whole mark (one polygon, so there is no banding)
        if (full && depth < 90f) {
            List<Vec3d> ring = new ArrayList<>();
            for (int i = 0; i < 40; i++) ring.add(pt(c, u, v, R * 0.94, i * Math.PI * 2 / 40));
            fillPoly(ctx, cam, ring, s, argb(0.085f, mix(col, 0xFFFFFF, 0.55f)));
        }
        // six thick arcs with gaps, slowly turning
        for (int i = 0; i < 6; i++) {
            double a0 = rot + i * Math.PI / 3.0, a1 = a0 + Math.toRadians(44);
            arc(ctx, cam, c, u, v, R, a0, a1, s, tw + 4, 0.16f * pulse, col);
            arc(ctx, cam, c, u, v, R, a0, a1, s, tw, 0.96f * pulse, pink);
        }
        // translucent white ring that breathes
        float br = 0.70f + 0.15f * (float) Math.sin(time * 3f);
        arc(ctx, cam, c, u, v, R * 0.52, 0, Math.PI * 2, s, tin + 4, 0.10f, 0xFFFFFF);
        arc(ctx, cam, c, u, v, R * 0.52, 0, Math.PI * 2, s, tin, br, 0xFFFFFF);
        // solid square in the middle
        double hs = R * 0.19, ang = 0.35 + Math.PI / 4.0, dr = hs * Math.sqrt(2.0);
        List<Vec3d> sq = new ArrayList<>();
        for (int i = 0; i < 4; i++) sq.add(pt(c, u, v, dr, ang + i * Math.PI / 2));
        fillPoly(ctx, cam, sq, s, argb(0.97f * pulse, pink));
        // column of light
        if (beam) beam(ctx, cam, c, 3.2 * (R / 0.46), 0.15 * (R / 0.46), s, col, 0.95f * pulse);

        float top = Float.MAX_VALUE;
        for (int i = 0; i < 8; i++) {
            float[] q = cam.proj(pt(c, u, v, R, i * Math.PI / 4.0));
            if (q != null) top = Math.min(top, q[1]);
        }
        return new float[]{cp[0], top == Float.MAX_VALUE ? cp[1] : top};
    }

    private static void vignette(DrawContext ctx, float a) {
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight(), n = 22, st = 3;
        for (int i = 0; i < n; i++) {
            float f = 1f - i / (float) n, al = a * 0.30f * f * f;
            if (al <= 0.003f) continue;
            int c = argb(al, RED);
            ctx.fill(0, i * st, w, (i + 1) * st, c);
            ctx.fill(0, h - (i + 1) * st, w, h - i * st, c);
            ctx.fill(i * st, (i + 1) * st, (i + 1) * st, h - (i + 1) * st, c);
            ctx.fill(w - (i + 1) * st, (i + 1) * st, w - i * st, h - (i + 1) * st, c);
        }
    }

    private static Vec3d center(Result r) {
        return r.target != null ? new Vec3d(r.end.x, r.target.getY(), r.end.z).add(UP.multiply(0.02))
                : r.end.add(r.normal.multiply(0.02));
    }

    // ================================================================ pill

    /** Small icon of the projectile, drawn pixel by pixel (cx, cy in GUI units). */
    private static void icon(DrawContext ctx, Kind k, float cx, float cy, float s, int rgb) {
        if (k == Kind.OTHER) { centered(ctx, TIMER, cx, cy, 7, 7, argb(1f, rgb)); return; }
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.scale(1f / s, 1f / s);
        int x = Math.round(cx * s), y = Math.round(cy * s), u = Math.max(1, Math.round(s * 0.85f));
        int col = argb(1f, rgb);
        switch (k) {
            case PEARL -> {   // ring with a dot, like the pearl in the video
                for (int i = 0; i < 14; i++) {
                    double a = i * Math.PI * 2 / 14;
                    int px = x + (int) Math.round(Math.cos(a) * 3.2 * u), py = y + (int) Math.round(Math.sin(a) * 3.2 * u);
                    ctx.fill(px - u / 2, py - u / 2, px - u / 2 + u, py - u / 2 + u, col);
                }
                ctx.fill(x - u, y - u, x + u, y + u, col);
            }
            case ARROW -> {   // diagonal arrow pointing up-right
                for (int i = -3; i <= 3; i++) ctx.fill(x + i * u, y - i * u, x + i * u + u, y - i * u + u, col);
                for (int i = 0; i <= 3; i++) {
                    ctx.fill(x + 3 * u - i * u, y - 3 * u, x + 3 * u - i * u + u, y - 3 * u + u, col);
                    ctx.fill(x + 3 * u, y - 3 * u + i * u, x + 3 * u + u, y - 3 * u + i * u + u, col);
                }
            }
            case POTION -> {  // bottle: neck + round body
                ctx.fill(x - u, y - 4 * u, x + u, y - u, col);
                ctx.fill(x - 3 * u, y - u, x + 3 * u, y + 3 * u, col);
                ctx.fill(x - 2 * u, y + 3 * u, x + 2 * u, y + 4 * u, col);
            }
            default -> { }
        }
        m.popMatrix();
    }

    // ================================================================ one group (main shot + multishot sides)

    /** group.get(0) is the main shot (timer + red state); the rest are multishot side shots. */
    private static void draw(DrawContext ctx, MinecraftClient mc, Cam cam, List<Result> group, boolean own) {
        Result r = group.get(0);
        boolean hit = r.target != null && ShrineCfg.bool(K_RED, true);
        int idx = Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, ShrineCfg.integer(K_COL, 7)));
        int accent = ShrineGui.PALETTE[idx];
        float s = (float) mc.getWindow().getScaleFactor();
        long now = Util.getMeasuringTimeMs();
        float time = now / 1000f;

        float k;
        if (own) {
            float dt = Math.min(0.1f, Math.max(0f, (now - redT) / 1000f));
            redT = now;
            redA += ((hit ? 1f : 0f) - redA) * Math.min(1f, dt * 12f);
            if (redA < 0.01f && !hit) redA = 0f;
            k = redA;
        } else {
            k = hit ? 1f : 0f;
        }
        int main = mix(accent, RED, k);
        float pulse = hit ? 0.8f + 0.2f * (float) Math.sin(time * 10f) : 1f;
        boolean beam = ShrineCfg.bool(K_BEAM, true);

        if (own && k > 0.02f && ShrineCfg.bool(K_VIG, false)) vignette(ctx, k);

        float[] anchor = null;
        var m = ctx.getMatrices();
        m.pushMatrix();
        m.scale(1f / s, 1f / s);

        if (ShrineCfg.bool(K_LINE, true)) {
            for (int i = 0; i < group.size(); i++) line(ctx, cam, group.get(i), main, s, own ? 0.75f : 1f);
        }
        if (r.end != null) {
            double R = 0.46 * Math.max(0.3f, ShrineCfg.num(K_SIZE, 1f));
            Vec3d at = center(r);
            if (own) {   // the mark glides after the aim instead of jumping
                float dt = Math.max(0f, (now - smoothT) / 1000f);
                if (smooth == null || dt > 0.3f || smooth.squaredDistanceTo(at) > 64) smooth = at;
                else smooth = smooth.add(at.subtract(smooth).multiply(1.0 - Math.exp(-dt * 18.0)));
                smoothT = now;
                at = smooth;
            }
            anchor = marker(ctx, cam, at, r.target != null ? UP : r.normal, R, beam, true, s, main, pulse, time);
            for (int i = 1; i < group.size(); i++) {
                Result e = group.get(i);
                if (e.end == null) continue;
                marker(ctx, cam, center(e), e.target != null ? UP : e.normal, R * 0.8, beam, false, s,
                        mix(accent, RED, e.target != null ? 1f : 0f), 1f, time);
            }
        }
        m.popMatrix();
        if (anchor == null || !ShrineCfg.bool(K_TIME, true)) return;

        // flight time pill: dark body, outline (accent -> green when about to land, red when it hits), icon + "2.1 s"
        var tr = mc.textRenderer;
        float sec = (float) (r.ticks / 20.0);
        boolean soon = sec < 0.5f;
        int ic = soon ? GREEN : (hit ? RED : TEAL);
        int ring = soon ? GREEN : (hit ? RED : mix(main, 0xFFFFFF, 0.35f));
        String ts = String.format(Locale.ROOT, "%.1f s", sec);
        float pw = width(tr, Fnt.TINY_B, ts) + 24f, px = anchor[0] - pw / 2f, ly = anchor[1] - 11f;
        box(ctx, RR, px, ly - 7, pw, 14, 7, argb(0.92f, 0x0A0710));
        box(ctx, RR_RING, px - 1.5f, ly - 8.5f, pw + 3f, 17, 8.5f, argb(soon || hit ? 0.95f : 0.80f, ring));
        icon(ctx, r.kind, px + 9, ly, s, ic);
        text(ctx, tr, Fnt.TINY_B, ts, px + 16, ly, argb(0.95f, 0xFFFFFF));
    }
}

package com.shrine;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import static com.shrine.Gfx.*;

/** HUD > Информация: small always-on widgets (stats, effects, armour, keys, low-health warning). Vanilla text, no custom fonts. */
final class InfoHud {
    private InfoHud() {}

    static final String K_STATS = "hud.info.stats", K_POTIONS = "hud.info.potions", K_ARMOR = "hud.info.armor",
            K_KEYS = "hud.info.keys", K_LOWHP = "hud.info.lowhp",
            K_ISLAND = "hud.info.island", K_COMPASS = "hud.info.compass", K_INV = "hud.info.inv", K_HOTBAR = "hud.info.hotbar";

    private static final int BG = 0x99000000, ON = 0xDDE63946 /* pressed key */, WHITE = 0xFFFFFFFF, DIM = 0xB3FFFFFF;

    static void register() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "info_hud"), (ctx, tick) -> render(ctx));
        // own hotbar: when switched on it replaces the vanilla one, otherwise vanilla is drawn as usual
        HudElementRegistry.replaceElement(VanillaHudElements.HOTBAR, original -> (ctx, tick) -> {
            if (ShrineCfg.bool(K_HOTBAR, false)) hotbar(ctx); else original.render(ctx, tick);
        });
    }

    private static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        if (ShrineCfg.bool(K_LOWHP, false)) lowHp(ctx, mc, w, h);
        if (ShrineCfg.bool(K_STATS, false)) stats(ctx, mc, tr);
        if (ShrineCfg.bool(K_POTIONS, false)) potions(ctx, mc, tr, w);
        if (ShrineCfg.bool(K_ARMOR, false)) armor(ctx, mc, tr, w, h);
        if (ShrineCfg.bool(K_KEYS, false)) keys(ctx, mc, tr, h);
        if (ShrineCfg.bool(K_ISLAND, false)) island(ctx, mc, tr, w);
        if (ShrineCfg.bool(K_COMPASS, false)) compass(ctx, mc, tr, w);
        if (ShrineCfg.bool(K_INV, false)) inventory(ctx, mc, h);
    }

    // ---- "dynamic island": a pill at the top centre with the clock and what is going on ----
    private static void island(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int sw) {
        String clock = java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"));
        String info;
        if (MusicPlayer.active() && MusicPlayer.current >= 0 && MusicPlayer.current < MusicPlayer.tracks.size())
            info = MusicPlayer.tracks.get(MusicPlayer.current).title;
        else info = mc.getCurrentFps() + " FPS";
        if (info.length() > 28) info = info.substring(0, 27) + "..";
        int w = tr.getWidth(clock) + tr.getWidth(info) + 40;
        int x = (sw - w) / 2;
        box(ctx, RR, x, 5, w, 20, 10, 0xDD000000);
        box(ctx, RR_RING, x, 5, w, 20, 10, 0x33FFFFFF);
        ctx.drawTextWithShadow(tr, clock, x + 12, 11, WHITE);
        ctx.fill(x + 16 + tr.getWidth(clock), 10, x + 17 + tr.getWidth(clock), 20, 0x55FFFFFF);
        ctx.drawTextWithShadow(tr, info, x + 24 + tr.getWidth(clock), 11, DIM);
    }

    // ---- compass strip under the island ----
    private static void compass(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int sw) {
        float yaw = mc.player.getYaw() % 360f;
        if (yaw < 0) yaw += 360f;
        int cx = sw / 2, y = 30, half = 70;
        ctx.fill(cx - half, y, cx + half, y + 14, 0x77000000);
        String[] names = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};     // yaw 0 = south in Minecraft
        for (int i = 0; i < 8; i++) {
            float d = i * 45f - yaw;
            while (d > 180f) d -= 360f;
            while (d < -180f) d += 360f;
            if (Math.abs(d) > 55f) continue;
            int tx = cx + Math.round(d / 55f * (half - 8));
            boolean main = names[i].length() == 1;
            ctx.drawTextWithShadow(tr, names[i], tx - tr.getWidth(names[i]) / 2, y + 3, main ? WHITE : DIM);
        }
        ctx.fill(cx - 1, y + 11, cx + 1, y + 14, 0xFF000000 | ACCENT);
        String deg = Math.round(yaw) + "";
        ctx.drawTextWithShadow(tr, deg, cx - tr.getWidth(deg) / 2, y + 16, DIM);
    }

    // ---- main inventory shown on the left ----
    private static void inventory(DrawContext ctx, MinecraftClient mc, int sh) {
        int cell = 18, x0 = 6, y0 = sh / 2 - 30;
        panel(ctx, x0 - 3, y0 - 3, 9 * cell + 6, 3 * cell + 6);
        for (int r = 0; r < 3; r++) for (int c = 0; c < 9; c++) {
            ItemStack st = mc.player.getInventory().getStack(9 + r * 9 + c);
            if (!st.isEmpty()) ctx.drawItem(st, x0 + c * cell + 1, y0 + r * cell + 1);
        }
    }

    // ---- own hotbar ----
    private static void hotbar(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        TextRenderer tr = mc.textRenderer;
        int sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        int slot = 24, gap = 3, total = 9 * slot + 8 * gap;
        int x0 = (sw - total) / 2, y = sh - slot - 8;
        box(ctx, RR, x0 - 6, y - 5, total + 12, slot + 10, 12, 0xAA000000);
        int sel = mc.player.getInventory().getSelectedSlot();
        for (int i = 0; i < 9; i++) {
            int sx = x0 + i * (slot + gap);
            boolean on = i == sel;
            box(ctx, RR, sx, y, slot, slot, 8, on ? (0xCC000000 | ACCENT) : 0x44FFFFFF);
            ItemStack st = mc.player.getInventory().getStack(i);
            if (st.isEmpty()) continue;
            ctx.drawItem(st, sx + 4, y + 4);
            if (st.getCount() > 1) {
                String n = String.valueOf(st.getCount());
                ctx.drawTextWithShadow(tr, n, sx + slot - 3 - tr.getWidth(n), y + slot - 10, WHITE);
            }
            if (st.isDamageable() && st.getDamage() > 0) {
                float f = 1f - st.getDamage() / (float) Math.max(1, st.getMaxDamage());
                int col = f > 0.5f ? 0xFF7CFC7C : f > 0.2f ? 0xFFFFD36B : 0xFFFF6B6B;
                ctx.fill(sx + 4, y + slot - 4, sx + 4 + Math.round(16 * f), y + slot - 3, col);
            }
        }
    }

    private static void panel(DrawContext ctx, int x, int y, int w, int h) {
        ctx.fill(x, y, x + w, y + h, BG);
        ctx.fill(x, y, x + 2, y + h, 0xFF000000 | ACCENT);
    }

    // ---- FPS / ping / coordinates ----
    private static void stats(DrawContext ctx, MinecraftClient mc, TextRenderer tr) {
        String ping = "-";
        try {
            PlayerListEntry e = mc.getNetworkHandler() != null ? mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid()) : null;
            if (e != null) ping = e.getLatency() + " ms";
        } catch (Throwable ignored) { }
        String[] lines = {
                "FPS  " + mc.getCurrentFps(),
                "Ping  " + ping,
                "XYZ  " + (int) Math.floor(mc.player.getX()) + " " + (int) Math.floor(mc.player.getY()) + " " + (int) Math.floor(mc.player.getZ())
        };
        int w = 0;
        for (String s : lines) w = Math.max(w, tr.getWidth(s));
        panel(ctx, 6, 6, w + 12, lines.length * 11 + 6);
        for (int i = 0; i < lines.length; i++) ctx.drawTextWithShadow(tr, lines[i], 12, 9 + i * 11, WHITE);
    }

    // ---- active status effects (right side) ----
    private static void potions(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int sw) {
        int y = 6;
        for (StatusEffectInstance e : mc.player.getStatusEffects()) {
            String name = e.getEffectType().value().getName().getString() + " " + (e.getAmplifier() + 1);
            int sec = e.getDuration() / 20;
            String time = e.isInfinite() ? "inf" : String.format("%d:%02d", sec / 60, sec % 60);
            String line = name + "  " + time;
            int w = tr.getWidth(line) + 12;
            ctx.fill(sw - w - 6, y, sw - 6, y + 14, BG);
            ctx.fill(sw - 8, y, sw - 6, y + 14, 0xFF000000 | e.getEffectType().value().getColor());
            ctx.drawTextWithShadow(tr, line, sw - w, y + 3, WHITE);
            y += 16;
        }
    }

    // ---- armour with durability (above the hotbar, right) ----
    private static void armor(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int sw, int sh) {
        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
        int x = sw / 2 + 98, y = sh - 22;
        for (EquipmentSlot s : slots) {
            ItemStack st = mc.player.getEquippedStack(s);
            if (st.isEmpty()) continue;
            ctx.drawItem(st, x, y);
            if (st.isDamageable()) {
                int left = st.getMaxDamage() - st.getDamage();
                int pct = Math.round(100f * left / Math.max(1, st.getMaxDamage()));
                int col = pct > 50 ? 0xFF7CFC7C : pct > 20 ? 0xFFFFD36B : 0xFFFF6B6B;
                ctx.drawTextWithShadow(tr, pct + "%", x + 18, y + 4, col);
            }
            x += 20 + 30;
            if (x > sw - 30) break;
        }
    }

    // ---- WASD / jump / mouse ----
    private static void key(DrawContext ctx, TextRenderer tr, int x, int y, int w, int h, String label, boolean down) {
        ctx.fill(x, y, x + w, y + h, down ? ON : BG);
        ctx.drawTextWithShadow(tr, label, x + (w - tr.getWidth(label)) / 2, y + (h - 8) / 2, down ? WHITE : DIM);
    }

    private static void keys(DrawContext ctx, MinecraftClient mc, TextRenderer tr, int sh) {
        var o = mc.options;
        int x = 8, y = sh - 84, s = 22, g = 2;
        key(ctx, tr, x + s + g, y, s, s, "W", o.forwardKey.isPressed());
        key(ctx, tr, x, y + s + g, s, s, "A", o.leftKey.isPressed());
        key(ctx, tr, x + s + g, y + s + g, s, s, "S", o.backKey.isPressed());
        key(ctx, tr, x + 2 * (s + g), y + s + g, s, s, "D", o.rightKey.isPressed());
        key(ctx, tr, x, y + 2 * (s + g), 3 * s + 2 * g, 14, "SPACE", o.jumpKey.isPressed());
        key(ctx, tr, x, y + 2 * (s + g) + 16, (3 * s + 2 * g - g) / 2, 16, "LMB", o.attackKey.isPressed());
        key(ctx, tr, x + (3 * s + 2 * g - g) / 2 + g, y + 2 * (s + g) + 16, (3 * s + 2 * g - g) / 2, 16, "RMB", o.useKey.isPressed());
    }

    // ---- pulsing red edges when health is low ----
    private static void lowHp(DrawContext ctx, MinecraftClient mc, int w, int h) {
        float hp = mc.player.getHealth();
        if (hp > 6f || mc.player.isCreative() || mc.player.isSpectator()) return;
        float pulse = 0.5f + 0.5f * (float) Math.sin(Util.getMeasuringTimeMs() / 260.0);
        int a = (int) ((0.22f + 0.28f * pulse) * (hp <= 3f ? 1f : 0.6f) * 255f);
        int c = (a << 24) | 0xC0101A, clear = 0x00C0101A;
        int band = Math.max(24, h / 6);
        ctx.fillGradient(0, 0, w, band, c, clear);
        ctx.fillGradient(0, h - band, w, h, clear, c);
    }
}

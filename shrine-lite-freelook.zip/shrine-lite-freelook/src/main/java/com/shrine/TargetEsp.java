package com.shrine;

import com.shrine.Gfx.Fnt;
import com.shrine.Predictions.Cam;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;

import java.util.Locale;
import java.util.Random;

import static com.shrine.Gfx.*;

/**
 * Target > "Target ESP": the creature you aim at / hit gets a glowing effect and an info card.
 *
 * Styles (Target > Target ESP > Стиль): crystals orbiting the target, a glass ring sliding up and down the body,
 * comets with long tails, ripple circles on the ground, soft glowing orbs and rotating lock-on brackets.
 * On top of any style: white hitbox with a center axis, rising sparks, a spark burst when the target is hit
 * and a card with name / HP / equipment.
 *
 * Same technique as {@link Predictions}: a 2D overlay, world points are projected to the screen by hand.
 * Everything is animated from one clock ({@link #anim}) that runs at the "Скорость" setting.
 */
final class TargetEsp {
    private TargetEsp() {}

    static final String KEY = "target.esp", K_STYLE = "target.esp.style", K_COLOR = "target.esp.color",
            K_SPEED = "target.esp.speed", K_BOX = "target.esp.box", K_SPARK = "target.esp.spark", K_CARD = "target.esp.card";
    static final String[] STYLES = {"Кристаллы", "Кольцо", "Кометы", "Круги", "Шары", "Скобки"};

    private static final long HOLD_MS = 3500L;     // the target stays highlighted this long after you stop aiming at it
    private static final long FADE_MS = 450L;
    private static final double TAU = Math.PI * 2.0;
    private static final int HURT = 0xFF8A4D;      // hitbox color while the target is flashing red

    private static LivingEntity target;
    private static long shownAt, seenAt, lastMs, burstAt = -100000L;
    private static float anim, shownHp;
    private static int lastHurt;

    static int color() {
        int i = Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, ShrineCfg.integer(K_COLOR, 5)));
        return ShrineGui.PALETTE[i];
    }

    static void register() {
        HudElementRegistry.attachElementAfter(VanillaHudElements.CROSSHAIR, Identifier.of("shrine", "target_esp"),
                (ctx, tick) -> render(ctx, tick.getTickProgress(false)));
    }

    // ---------- helpers ----------
    private static int mix(int c1, int c2, float k) {
        int r = Math.round(((c1 >> 16) & 255) * (1 - k) + ((c2 >> 16) & 255) * k);
        int g = Math.round(((c1 >> 8) & 255) * (1 - k) + ((c2 >> 8) & 255) * k);
        int b = Math.round((c1 & 255) * (1 - k) + (c2 & 255) * k);
        return (r << 16) | (g << 8) | b;
    }

    private static float dist(float[] a, float[] b) {
        float dx = a[0] - b[0], dy = a[1] - b[1];
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    // ---------- frame ----------
    private static void render(DrawContext ctx, float td) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.currentScreen != null || mc.options.hudHidden) return;
        if (!ShrineCfg.bool(KEY, true)) { target = null; return; }
        if (!mc.options.getPerspective().isFirstPerson()) return;

        long now = Util.getMeasuringTimeMs();
        if (mc.crosshairTarget instanceof EntityHitResult hr && hr.getEntity() instanceof LivingEntity hit
                && hit != mc.player && hit.isAlive() && !hit.isSpectator()) {
            if (hit != target) { target = hit; shownAt = now; shownHp = hit.getHealth(); lastHurt = hit.hurtTime; }
            seenAt = now;
        }
        LivingEntity tg = target;
        if (tg == null) return;
        long idle = now - seenAt;
        if (tg.isRemoved() || !tg.isAlive() || tg.squaredDistanceTo(mc.player) > 48.0 * 48.0 || idle > HOLD_MS + FADE_MS) {
            target = null;
            return;
        }

        float speed = ShrineCfg.num(K_SPEED, 1f);
        float dt = lastMs == 0L ? 0f : Math.min(0.1f, (now - lastMs) / 1000f);
        lastMs = now;
        anim += dt * speed;

        float in = Math.min(1f, (now - shownAt) / 300f);
        float out = idle > HOLD_MS ? 1f - (idle - HOLD_MS) / (float) FADE_MS : 1f;
        float a = (1f - (1f - in) * (1f - in)) * Math.max(0f, out);

        int hurt = tg.hurtTime;
        if (hurt > lastHurt) burstAt = now;           // just got hit
        lastHurt = hurt;
        shownHp += (tg.getHealth() - shownHp) * Math.min(1f, dt * 8f);

        Vec3d p = tg.getLerpedPos(td);
        Fx fx = new Fx(ctx, new Cam(mc, ctx, td), p, tg.getWidth(), tg.getHeight(), color(), a, anim, Math.min(1f, hurt / 10f));
        int style = Math.max(0, Math.min(STYLES.length - 1, ShrineCfg.integer(K_STYLE, 0)));

        switch (style) {                               // behind the hitbox
            case 1 -> fx.glassRing();
            case 3 -> fx.groundRipples();
            default -> { }
        }
        if (ShrineCfg.bool(K_BOX, true)) fx.wireBox();
        switch (style) {                               // in front of it
            case 0 -> fx.crystals();
            case 2 -> fx.comets();
            case 4 -> fx.orbs();
            case 5 -> fx.brackets();
            default -> { }
        }
        if (ShrineCfg.bool(K_SPARK, true)) fx.sparks();
        fx.burst((now - burstAt) / 1000f);
        if (ShrineCfg.bool(K_CARD, true)) card(ctx, mc, tg, a);
    }

    // ---------- the effects ----------
    private static final class Fx {
        final DrawContext ctx;
        final Cam cam;
        final double x, y, z, w, h;     // feet center, hitbox width and height
        final int rgb;
        final float a, t, hurt;
        final float[] o = new float[3]; // last projected point: x, y, pixels per block

        Fx(DrawContext ctx, Cam cam, Vec3d p, double w, double h, int rgb, float a, float t, float hurt) {
            this.ctx = ctx; this.cam = cam; this.x = p.x; this.y = p.y; this.z = p.z;
            this.w = w; this.h = h; this.rgb = rgb; this.a = a; this.t = t; this.hurt = hurt;
        }

        boolean pt(double wx, double wy, double wz) { return cam.p(wx, wy, wz, o); }

        /** Circle / arc lying on the ground plane around the target (drawn as projected segments). */
        void ringXZ(double gy, double r, double a0, double a1, float thBlocks, int col, float al, double step) {
            int n = Math.max(3, (int) Math.ceil(Math.abs(a1 - a0) / step));
            float px = 0f, py = 0f;
            boolean has = false;
            for (int i = 0; i <= n; i++) {
                double an = a0 + (a1 - a0) * i / n;
                if (!pt(x + Math.cos(an) * r, gy, z + Math.sin(an) * r)) { has = false; continue; }
                if (has) Predictions.line(ctx, px, py, o[0], o[1], Math.max(0.8f, thBlocks * o[2]), argb(al, col));
                px = o[0]; py = o[1]; has = true;
            }
        }

        /** White hitbox with a center axis and an arrow under the feet. */
        void wireBox() {
            double hw = w / 2.0;
            float[][] s = new float[8][];
            for (int i = 0; i < 8; i++) {
                s[i] = pt(x + ((i & 1) == 0 ? -hw : hw), y + ((i & 2) == 0 ? 0.0 : h), z + ((i & 4) == 0 ? -hw : hw))
                        ? new float[]{o[0], o[1]} : null;
            }
            int[][] e = {{0, 1}, {2, 3}, {4, 5}, {6, 7}, {0, 2}, {1, 3}, {4, 6}, {5, 7}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
            int col = mix(0xFFFFFF, HURT, hurt);
            for (int[] k : e) {
                float[] p0 = s[k[0]], p1 = s[k[1]];
                if (p0 == null || p1 == null) continue;
                Predictions.line(ctx, p0[0], p0[1], p1[0], p1[1], 3.0f, argb(0.10f * a, hurt > 0.01f ? HURT : rgb));
                Predictions.line(ctx, p0[0], p0[1], p1[0], p1[1], 0.9f, argb(0.95f * a, col));
            }
            // center axis (head -> feet) and the small arrow at the bottom
            if (pt(x, y + h, z)) {
                float tx = o[0], ty = o[1];
                if (pt(x, y, z)) {
                    float bx = o[0], by = o[1];
                    Predictions.line(ctx, tx, ty, bx, by, 0.8f, argb(0.8f * a, mix(rgb, 0xFFFFFF, 0.7f)));
                    Predictions.line(ctx, bx - 4f, by - 5f, bx, by, 0.9f, argb(0.9f * a, 0xFFFFFF));
                    Predictions.line(ctx, bx + 4f, by - 5f, bx, by, 0.9f, argb(0.9f * a, 0xFFFFFF));
                }
            }
        }

        // ---------- style 0: crystals ----------
        /** Faceted gem: a diamond filled with horizontal strokes, lighter in the middle, over a soft glow. */
        void gem(float sx, float sy, float hw, float hh, int col) {
            centered(ctx, GLOW, sx, sy, hh * 5f, hh * 5f, argb(0.45f * a, col));
            int n = Math.max(4, Math.min(10, Math.round(hh)));
            for (int k = -n; k <= n; k++) {
                float f = 1f - Math.abs(k) / (float) n, dy = hh * k / n, half = hw * f;
                Predictions.line(ctx, sx - half, sy + dy, sx + half, sy + dy, Math.max(1f, hh / n * 1.3f),
                        argb(0.92f * a, mix(col, 0xFFFFFF, 0.15f + 0.45f * f)));
            }
            Predictions.line(ctx, sx, sy - hh, sx, sy + hh, 0.8f, argb(0.5f * a, 0xFFFFFF));
        }

        void crystals() {
            final int n = 7;
            int col = mix(rgb, 0xFF4FD8, 0.55f);
            for (int i = 0; i < n; i++) {
                double an = t * 1.1 + i * TAU / n;
                double r = w * 0.5 + 0.55 + 0.1 * Math.sin(t * 1.7 + i * 1.3);
                double yy = y + h * (0.12 + 0.78 * (0.5 + 0.5 * Math.sin(t * 1.2 + i * 1.9)));
                if (!pt(x + Math.cos(an) * r, yy, z + Math.sin(an) * r)) continue;
                float hh = Math.max(3f, 0.2f * o[2]);
                float spin = (float) Math.abs(Math.cos(t * 2.4 + i));          // the gem turns around its axis
                gem(o[0], o[1], hh * (0.38f + 0.35f * spin), hh, col);
            }
        }

        // ---------- style 1: glass ring ----------
        /** Translucent purple band that slides up and down the body, flaring at the top, with bright rims. */
        void glassRing() {
            final int n = 40;
            double ph = 0.5 + 0.5 * Math.sin(t * 0.9);
            double bh = 0.30 + 0.22 * (0.5 + 0.5 * Math.sin(t * 1.7 + 1.0));
            double y0 = y - 0.05 + (h + 0.1 - bh) * ph, y1 = y0 + bh;
            double rb = w * 0.5 + 0.28 + 0.05 * Math.sin(t * 2.3);
            double rt = rb * (1.0 + 0.22 * (0.5 + 0.5 * Math.sin(t * 0.9 + 0.8)));
            float[][] bot = new float[n + 1][], top = new float[n + 1][];
            for (int i = 0; i <= n; i++) {
                double an = TAU * i / n + t * 0.5, c = Math.cos(an), s = Math.sin(an);
                bot[i] = pt(x + c * rb, y0, z + s * rb) ? new float[]{o[0], o[1]} : null;
                top[i] = pt(x + c * rt, y1, z + s * rt) ? new float[]{o[0], o[1]} : null;
            }
            for (int i = 0; i < n; i++) {
                float[] b0 = bot[i], b1 = bot[i + 1], t0 = top[i], t1 = top[i + 1];
                if (b0 == null || b1 == null || t0 == null || t1 == null) continue;
                double mid = TAU * (i + 0.5) / n + t * 0.5, nx = Math.cos(mid), nz = Math.sin(mid);
                double vx = cam.pos.x - (x + nx * rb), vz = cam.pos.z - (z + nz * rb);
                double face = Math.abs((nx * vx + nz * vz) / Math.max(1e-6, Math.sqrt(vx * vx + vz * vz)));  // 1 = facing us
                float th = Math.max(dist(b0, b1), dist(t0, t1)) + 0.8f;
                float al = (0.07f + 0.20f * (1f - (float) face)) * a;                                      // glass: stronger at the rim
                Predictions.line(ctx, (b0[0] + b1[0]) / 2f, (b0[1] + b1[1]) / 2f, (t0[0] + t1[0]) / 2f, (t0[1] + t1[1]) / 2f,
                        th, argb(al, rgb));
            }
            int rim = mix(rgb, 0xFFFFFF, 0.55f);
            for (int i = 0; i < n; i++) {
                float[][] pair = {bot[i], bot[i + 1], top[i], top[i + 1]};
                for (int k = 0; k < 2; k++) {
                    float[] p0 = pair[k * 2], p1 = pair[k * 2 + 1];
                    if (p0 == null || p1 == null) continue;
                    Predictions.line(ctx, p0[0], p0[1], p1[0], p1[1], 3.0f, argb(0.14f * a, rgb));
                    Predictions.line(ctx, p0[0], p0[1], p1[0], p1[1], 0.9f, argb(0.75f * a, rim));
                }
            }
        }

        // ---------- style 2: comets ----------
        void comets() {
            final int tail = 24;
            double cy = y + h * 0.5;
            int core = mix(rgb, 0xFFFFFF, 0.75f);
            for (int i = 0; i < 3; i++) {
                double tilt = 0.45 + 0.5 * i, yaw = i * 2.1, rad = w * 0.5 + 0.75 + 0.1 * i;
                double a0 = t * (2.1 + 0.4 * i) + i * 2.094;
                float[] prev = null;
                float headSize = 0f;
                for (int k = 0; k <= tail; k++) {
                    double an = a0 - k * 0.06;
                    double ox = Math.cos(an) * rad, oz = Math.sin(an) * rad;
                    double ty = -oz * Math.sin(tilt), tz = oz * Math.cos(tilt);              // tilt the orbit around X
                    double wx = ox * Math.cos(yaw) + tz * Math.sin(yaw), wz = -ox * Math.sin(yaw) + tz * Math.cos(yaw);
                    double wy = cy + ty + 0.25 * Math.sin(t * 1.3 + i + k * 0.02);
                    if (!pt(x + wx, wy, z + wz)) { prev = null; continue; }
                    float fr = 1f - k / (float) tail;
                    float[] cur = {o[0], o[1]};
                    if (k == 0) headSize = Math.max(4f, 0.16f * o[2]);
                    if (prev != null) {
                        float th = Math.max(0.8f, 0.16f * o[2] * (float) Math.pow(fr, 0.8));
                        float al = 0.85f * (float) Math.pow(fr, 1.3) * a;
                        Predictions.line(ctx, prev[0], prev[1], cur[0], cur[1], th * 2.6f, argb(0.25f * al, rgb));
                        Predictions.line(ctx, prev[0], prev[1], cur[0], cur[1], th, argb(al, core));
                    }
                    prev = cur;
                    if (k == 0) {
                        centered(ctx, GLOW, cur[0], cur[1], headSize * 5f, headSize * 5f, argb(0.55f * a, rgb));
                        centered(ctx, DISC, cur[0], cur[1], headSize, headSize, argb(a, 0xFFFFFF));
                    }
                }
            }
        }

        // ---------- style 3: ground circles ----------
        void groundRipples() {
            double gy = y + 0.02, inner = w * 0.5 + 0.22, outer = w * 0.5 + 0.95;
            int pale = mix(rgb, 0xFFFFFF, 0.55f);
            for (double r = 0.12; r < outer; r += 0.13) ringXZ(gy, r, 0, TAU, 0.15f, rgb, 0.05f * a, 0.28);   // glass disc
            for (double r = 0.1; r < inner; r += 0.1) ringXZ(gy, r, 0, TAU, 0.12f, 0xFFFFFF, 0.05f * a, 0.3);  // lighter core
            ringXZ(gy, outer, 0, TAU, 0.035f, pale, 0.45f * a, 0.12);
            for (int i = 0; i < 6; i++) {                                                                       // turning inner arcs
                double s0 = t * 0.9 + i * TAU / 6, s1 = s0 + TAU / 6 * 0.62;
                ringXZ(gy, inner, s0, s1, 0.11f, rgb, 0.22f * a, 0.14);
                ringXZ(gy, inner, s0, s1, 0.06f, pale, a, 0.14);
            }
            for (int j = 0; j < 2; j++) {                                                                       // ripples running outwards
                double ph = (t * 0.45 + j * 0.5) % 1.0;
                ringXZ(gy, inner + (outer + 0.45 - inner) * ph, 0, TAU, 0.05f, pale, (1f - (float) ph) * 0.7f * a, 0.12);
            }
        }

        // ---------- style 4: soft orbs ----------
        void orbs() {
            int col = mix(rgb, 0x8FA8FF, 0.5f);
            for (int i = 0; i < 9; i++) {
                double r = w * 0.5 + 0.35 + 0.45 * (0.5 + 0.5 * Math.sin(t * (0.5 + 0.17 * i) + i * 2.1));
                double an = t * (0.7 + 0.13 * i) * 0.6 + i * 0.7;
                double yy = y + h * (0.5 + 0.5 * Math.sin(t * (0.9 + 0.11 * i) * 0.5 + i * 1.3));
                if (!pt(x + Math.cos(an) * r, yy, z + Math.sin(an) * r)) continue;
                float sz = Math.max(6f, (0.45f + 0.25f * (float) Math.sin(t * 1.6 + i)) * o[2]);
                centered(ctx, GLOW, o[0], o[1], sz * 2.4f, sz * 2.4f, argb(0.30f * a, col));
                centered(ctx, DISC, o[0], o[1], sz, sz, argb(0.22f * a, col));
                centered(ctx, DISC, o[0], o[1], sz * 0.35f, sz * 0.35f, argb(0.5f * a, 0xFFFFFF));
            }
        }

        // ---------- style 5: lock-on brackets ----------
        private float[] rot(float cx, float cy, float dx, float dy, float ca, float sa) {
            return new float[]{cx + dx * ca - dy * sa, cy + dx * sa + dy * ca};
        }

        void brackets() {
            float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
            boolean any = false;
            double hw = w / 2.0;
            for (int i = 0; i < 8; i++) {
                if (!pt(x + ((i & 1) == 0 ? -hw : hw), y + ((i & 2) == 0 ? 0.0 : h), z + ((i & 4) == 0 ? -hw : hw))) continue;
                any = true;
                minX = Math.min(minX, o[0]); maxX = Math.max(maxX, o[0]);
                minY = Math.min(minY, o[1]); maxY = Math.max(maxY, o[1]);
            }
            if (!any) return;
            float cx = (minX + maxX) / 2f, cy = (minY + maxY) / 2f;
            float half = Math.max(maxX - minX, maxY - minY) / 2f * 1.1f + 8f + 2f * (float) Math.sin(t * 3.0);
            half = Math.min(half, ctx.getScaledWindowHeight() * 0.45f);
            float arm = half * 0.42f;
            float ca = (float) Math.cos(t * 1.3), sa = (float) Math.sin(t * 1.3);
            int core = mix(rgb, 0xFFFFFF, 0.55f);
            for (int k = 0; k < 4; k++) {
                float sx = (k & 1) == 0 ? -1f : 1f, sy = (k & 2) == 0 ? -1f : 1f;
                float[] c = rot(cx, cy, sx * half, sy * half, ca, sa);
                float[] hz = rot(cx, cy, sx * (half - arm), sy * half, ca, sa);
                float[] vt = rot(cx, cy, sx * half, sy * (half - arm), ca, sa);
                Predictions.line(ctx, c[0], c[1], hz[0], hz[1], 5f, argb(0.20f * a, rgb));
                Predictions.line(ctx, c[0], c[1], vt[0], vt[1], 5f, argb(0.20f * a, rgb));
                Predictions.line(ctx, c[0], c[1], hz[0], hz[1], 1.8f, argb(0.95f * a, core));
                Predictions.line(ctx, c[0], c[1], vt[0], vt[1], 1.8f, argb(0.95f * a, core));
                centered(ctx, GLOW, c[0], c[1], 14f, 14f, argb(0.40f * a, rgb));
            }
        }

        // ---------- on top of every style ----------
        /** Little pink sparks rising around the target. */
        void sparks() {
            int col = mix(rgb, 0xFF7AC8, 0.45f);
            for (int i = 0; i < 12; i++) {
                double ph = (t * 0.32 + i / 12.0) % 1.0;
                double an = i * 2.4 + t * 0.5;
                double r = w * 0.5 + 0.2 + 0.4 * ((i * 7) % 5) / 4.0;
                if (!pt(x + Math.cos(an) * r, y + h * ph, z + Math.sin(an) * r)) continue;
                float al = (float) Math.sin(Math.PI * ph) * a;
                float sz = Math.max(2f, 0.07f * o[2]);
                centered(ctx, GLOW, o[0], o[1], sz * 4f, sz * 4f, argb(0.35f * al, col));
                centered(ctx, DISC, o[0], o[1], sz, sz, argb(0.9f * al, mix(col, 0xFFFFFF, 0.5f)));
            }
        }

        /** Spark burst flying out of the target for 0.8s after it was hit (age in seconds). */
        void burst(float age) {
            if (age < 0f || age > 0.8f) return;
            Random rnd = new Random(burstAt);
            int col = mix(rgb, 0xFF4FD8, 0.6f);
            float life = 1f - age / 0.8f;
            for (int i = 0; i < 22; i++) {
                double th = rnd.nextDouble() * TAU, ph = rnd.nextDouble() * Math.PI - Math.PI / 2.0, sp = 1.2 + rnd.nextDouble() * 2.2;
                double vx = Math.cos(th) * Math.cos(ph) * sp, vy = Math.sin(ph) * sp + 1.0, vz = Math.sin(th) * Math.cos(ph) * sp;
                if (!pt(x + vx * age, y + h * 0.6 + vy * age - 2.6 * age * age, z + vz * age)) continue;
                float sz = Math.max(2f, 0.09f * o[2] * life);
                centered(ctx, GLOW, o[0], o[1], sz * 4f, sz * 4f, argb(0.45f * life * a, col));
                centered(ctx, DISC, o[0], o[1], sz, sz, argb(life * a, mix(col, 0xFFFFFF, 0.6f)));
            }
        }
    }

    // ---------- target card ----------
    /** Dark card next to the crosshair: face tile, name + WIN / LOSE, HP, health bar and six equipment slots. */
    private static void card(DrawContext ctx, MinecraftClient mc, LivingEntity tg, float a) {
        TextRenderer tr = mc.textRenderer;
        int rgb = color();
        float sw = ctx.getScaledWindowWidth(), sh = ctx.getScaledWindowHeight();
        float w = 120f, h = 32f, x = sw / 2f + 16f, y = sh / 2f + 16f + (1f - a) * 6f;
        box(ctx, RR, x, y, w, h, 10, argb(0.88f * a, 0x120A18));
        box(ctx, RR_RING, x, y, w, h, 10, argb(0.30f * a, rgb));

        String name = tg.getName().getString();
        int tile = mix(ShrineGui.PALETTE[Math.floorMod(name.hashCode(), ShrineGui.PALETTE.length)], 0x000000, 0.45f);
        box(ctx, RR, x + 5, y + 5, 22, 22, 7, argb(a, tile));
        textC(ctx, tr, Fnt.UI_B, name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase(Locale.ROOT), x + 16, y + 16, argb(a, 0xFFFFFF));

        boolean win = mc.player.getHealth() + mc.player.getAbsorptionAmount() >= tg.getHealth();
        String tag = win ? "WIN" : "LOSE";
        float maxW = w - 34f - width(tr, Fnt.TINY_B, tag) - 14f;
        while (name.length() > 1 && width(tr, Fnt.TINY_B, name) > maxW) name = name.substring(0, name.length() - 1);
        text(ctx, tr, Fnt.TINY_B, name, x + 33, y + 9, argb(a, 0xFFFFFF));
        text(ctx, tr, Fnt.TINY_B, tag, x + 33 + width(tr, Fnt.TINY_B, name) + 5, y + 9, argb(a, win ? 0x5DE08A : 0xFF4D5D));

        float max = Math.max(1f, tg.getMaxHealth());
        String hp = String.format(Locale.ROOT, "HP %.1f / %.1f", tg.getHealth(), max);
        text(ctx, tr, Fnt.TINY_B, hp, x + 33, y + 19, argb(0.55f * a, 0xFFFFFF));
        float bx = x + 33, bw = w - 33 - 9, by = y + h - 7;
        float frac = Math.max(0f, Math.min(1f, shownHp / max));
        box(ctx, RR, bx, by, bw, 3, 1.5f, argb(0.14f * a, 0xFFFFFF));
        box(ctx, RR, bx, by, Math.max(3f, bw * frac), 3, 1.5f, argb(a, mix(rgb, 0xFFFFFF, 0.15f)));

        EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET,
                EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND};
        for (int i = 0; i < slots.length; i++) {
            float sx = x + 6 + i * 18, sy = y + h + 4;
            box(ctx, RR, sx, sy, 16, 12, 4, argb(0.82f * a, 0x120A18));
            ItemStack st = tg.getEquippedStack(slots[i]);
            if (st.isEmpty()) {
                textC(ctx, tr, Fnt.TINY_B, "x", sx + 8, sy + 6, argb(0.35f * a, 0xFFFFFF));
            } else {
                var m = ctx.getMatrices();
                m.pushMatrix();
                m.translate(sx + 2.4f, sy + 0.4f);
                m.scale(0.7f, 0.7f);
                ctx.drawItem(st, 0, 0);
                m.popMatrix();
            }
        }
    }
}

package com.shrine;

import com.shrine.Gfx.Fnt;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.option.KeyBinding;
import net.fabricmc.loader.api.FabricLoader;
import org.joml.Matrix3x2f;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFW;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Stream;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static com.shrine.Gfx.*;

/**
 * Visual > "Рабочий стол": a small desktop (wallpaper, menu bar, icons, dock, windows) that opens over the game.
 * Google / Discord / YouTube / Twitch / Spotify / Telegram open in the system browser (the link is also copied),
 * Заметки / Музыка / Проводник / Монитор / Калькулятор / Часы / Настройки work inside the window.
 * With "Парящий 3D экран" on, the monitor floats, swings in when it opens and tilts after the mouse (a flat affine tilt, not a real world quad).
 * To add an app: add a line to {@link App}; native apps are drawn in {@link #drawWindow}.
 */
final class DesktopScreen extends Screen {
    static final String KEY = "visual.desktop", K_WALL = "visual.desktop.wall", K_ACCENT = "visual.desktop.accent", K_3D = "visual.desktop.3d";
    static KeyBinding key;

    static void register(KeyBinding.Category cat) {
        key = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.shrine.desktop", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_CONTROL, cat));
        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            while (key.wasPressed())
                if (ShrineCfg.bool(KEY, false) && c.currentScreen == null && c.world != null) c.setScreen(new DesktopScreen(null));
        });
    }

    static String keyName() {
        try { return key != null ? key.getBoundKeyLocalizedText().getString() : "Right Control"; }
        catch (Throwable t) { return "Right Control"; }
    }

    private enum App {
        GOOGLE("Google", "https://www.google.com", 0xFFFFFF, "G", 0x4285F4),
        DISCORD("Discord", "https://discord.com/app", 0x5865F2, "D", 0xFFFFFF),
        YOUTUBE("YouTube", "https://www.youtube.com", 0xFF0033, null, 0xFFFFFF),
        TWITCH("Twitch", "https://www.twitch.tv", 0x9146FF, "T", 0xFFFFFF),
        SPOTIFY("Spotify", "https://open.spotify.com", 0x1DB954, "S", 0x0B0B0B),
        TELEGRAM("Telegram", "https://web.telegram.org", 0x2AABEE, "Tg", 0xFFFFFF),
        NOTES("Заметки", null, 0xF5B921, null, 0xFFFFFF),
        MUSIC("Музыка", null, 0xFB4F7A, null, 0xFFFFFF),
        FILES("Проводник", null, 0x3B8BF6, null, 0xFFFFFF),
        MONITOR("Монитор", null, 0x16A37F, null, 0xFFFFFF),
        CALC("Калькулятор", null, 0xF59E0B, "=", 0xFFFFFF),
        CLOCK("Часы", null, 0x1F2937, null, 0xFFFFFF),
        SETTINGS("Настройки", null, 0x6B7280, null, 0xFFFFFF);

        final String title, url, glyph; final int color, glyphColor;
        App(String t, String u, int c, String g, int gc) { title = t; url = u; color = c; glyph = g; glyphColor = gc; }
        boolean web() { return url != null; }
    }

    // wallpapers: name, top, bottom, tint of the lower band
    private static final String[] WALL_NAME = {"Закат", "Океан", "Лес", "Полночь", "Неон", "Графит"};
    private static final int[][] WALL = {
        {0x2B1055, 0xD4417B, 0xFF9A5C}, {0x0F2027, 0x2C5364, 0x4DB8FF}, {0x134E5E, 0x71B280, 0xC6FF8A},
        {0x0A0A1F, 0x1B2A5A, 0x6D5DFF}, {0x1A0033, 0xFF2E93, 0x00E5FF}, {0x1B1B1F, 0x3A3A44, 0x9AA0AD}};
    private static final String[] SET_TABS = {"Оформление", "Обои", "О системе"};

    private record Hit(float x, float y, float w, float h, String id) {}
    private final List<Hit> hits = new ArrayList<>();
    private final Screen parent;
    private float k = 1f, vw = 960f;
    private final long openedAt = Util.getMeasuringTimeMs();
    private long winAt, toastAt;
    private App win;
    private int setTab;
    private String toast = "";

    // 3D tilt (affine: x' = ta*dx + tc*dy, y' = tb*dx + td*dy around the monitor centre)
    private float tYaw, tPitch, ta = 1f, tb, tc, td = 1f, bob, tcx, tcy;
    private long lastFrame;

    // notes
    private final StringBuilder notes = new StringBuilder();
    private boolean notesLoaded;
    private static final int NOTES_MAX = 4000;

    // music
    private int musOff;

    // explorer
    private Path fsRoot, fsDir;
    private final List<Path> fsList = new ArrayList<>();
    private final List<String> fsSize = new ArrayList<>();
    private int fsOff;

    // monitor
    private final int[] fpsHist = new int[48];
    private long fpsAt;

    // calculator
    private String disp = "0", op;
    private double acc;
    private boolean fresh = true;

    DesktopScreen(Screen parent) { super(Text.literal("Shrine")); this.parent = parent; }

    @Override protected void init() { k = height / Scene.REF_H; vw = width / k; }
    @Override public boolean shouldPause() { return false; }
    @Override public void renderBackground(DrawContext ctx, int mx, int my, float delta) { }

    private static float ease(long since, float ms) {
        float t = Math.min(1f, Math.max(0f, (Util.getMeasuringTimeMs() - since) / ms));
        return 1f - (1f - t) * (1f - t);
    }
    private static int r(float v) { return Math.round(v); }
    private static int accent() {
        int i = ShrineCfg.integer(K_ACCENT, 4);
        return ShrineGui.PALETTE[Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, i))];
    }

    // ---------------- render ----------------
    @Override
    public void render(DrawContext ctx, int mxReal, int myReal, float delta) {
        float a = ease(openedAt, 300f);
        ctx.fillGradient(0, 0, width, height, argb(0.62f * a, 0x05070B), argb(0.84f * a, 0x0B0F18));
        final float PW = 720f, PH = 420f;
        float px = (vw - PW) / 2f, py = (Scene.REF_H - PH) / 2f - 8f + (1f - a) * 18f;
        updateTilt(mxReal / k, myReal / k, a, px + PW / 2f, py + PH / 2f);
        float[] lm = toLocal(mxReal / k, myReal / k);
        float mx = lm[0], my = lm[1];
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);
        ctx.getMatrices().translate(tcx, tcy + bob);
        ctx.getMatrices().mul(new Matrix3x2f(ta, tb, tc, td, 0f, 0f));
        ctx.getMatrices().translate(-tcx, -tcy);
        hits.clear();

        // monitor: floating shadow + thickness (3D mode), bezel + wallpaper
        if (ShrineCfg.bool(K_3D, true)) {
            box(ctx, RR, px + 26, py + PH + 24, PW - 52, 16, 8, argb(0.28f * a, 0x000000));
            box(ctx, RR, px - 7 + 6, py - 7 + 6, PW + 14, PH + 14, 16, argb(0.9f * a, 0x020306));
        }
        box(ctx, RR, px - 7, py - 7, PW + 14, PH + 14, 16, argb(0.95f * a, 0x07080C));
        box(ctx, RR_RING, px - 7, py - 7, PW + 14, PH + 14, 16, argb(0.14f * a, 0xFFFFFF));
        wallpaper(ctx, ShrineCfg.integer(K_WALL, 0), px, py, PW, PH, a);

        // menu bar
        ctx.fill(r(px), r(py), r(px + PW), r(py + 22), argb(0.40f * a, 0x000000));
        text(ctx, textRenderer, Fnt.TINY_B, "Shrine OS", px + 14, py + 11, argb(a, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.SMALL, win != null ? win.title : "Рабочий стол", px + 96, py + 11, argb(0.75f * a, 0xFFFFFF));
        LocalDateTime now = LocalDateTime.now();
        String clock = now.format(DateTimeFormatter.ofPattern("dd.MM  HH:mm"));
        text(ctx, textRenderer, Fnt.SMALL, clock, px + PW - 14 - width(textRenderer, Fnt.SMALL, clock), py + 11, argb(0.9f * a, 0xFFFFFF));

        // icons
        App[] apps = App.values();
        float x0 = px + (PW - 7 * 96f) / 2f + 48f, y0 = py + 78f;
        for (int i = 0; i < apps.length; i++) {
            float cx = x0 + (i % 7) * 96f, cy = y0 + (i / 7) * 98f;
            boolean hov = inside(mx, my, cx - 44, cy - 34, 88, 84);
            float s = hov ? 60f : 56f;
            icon(ctx, apps[i], cx, cy, s, a);
            textC(ctx, textRenderer, Fnt.SMALL, apps[i].title, cx, cy + 44, argb(0.95f * a, 0xFFFFFF));
            hits.add(new Hit(cx - 44, cy - 34, 88, 84, "app:" + i));
        }

        // dock (icons grow near the cursor)
        float dockY = py + PH - 12f;                     // bottom edge of the icons
        boolean near = my > dockY - 70f && my < py + PH;
        float[] sz = new float[apps.length];
        float baseTotal = apps.length * 30f + (apps.length - 1) * 8f, total = 0f;
        for (int i = 0; i < apps.length; i++) {
            float bc = px + PW / 2f - baseTotal / 2f + i * 38f + 15f;
            sz[i] = 30f * (1f + (near ? 0.5f * Math.max(0f, 1f - Math.abs(mx - bc) / 64f) : 0f));
            total += sz[i];
        }
        total += (apps.length - 1) * 8f;
        float dx = px + PW / 2f - total / 2f;
        box(ctx, RR, dx - 12, dockY - 40, total + 24, 46, 16, argb(0.32f * a, 0xFFFFFF));
        box(ctx, RR_RING, dx - 12, dockY - 40, total + 24, 46, 16, argb(0.18f * a, 0xFFFFFF));
        for (int i = 0; i < apps.length; i++) {
            float cx = dx + sz[i] / 2f, cy = dockY - sz[i] / 2f - 2f;
            icon(ctx, apps[i], cx, cy, sz[i], a);
            if (win == apps[i]) ctx.fill(r(cx - 1.5f), r(dockY + 1), r(cx + 1.5f), r(dockY + 4), argb(a, 0xFFFFFF));
            hits.add(new Hit(cx - sz[i] / 2f, dockY - sz[i] - 4, sz[i], sz[i] + 8, "app:" + i));
            dx += sz[i] + 8f;
        }

        if (win != null) drawWindow(ctx, mx, my, px, py, PW, a);

        if (!toast.isEmpty() && Util.getMeasuringTimeMs() - toastAt < 2600) {
            float tw = width(textRenderer, Fnt.SMALL, toast) + 28f;
            box(ctx, RR, px + (PW - tw) / 2f, py + PH - 98, tw, 28, 12, argb(0.78f * a, 0x000000));
            textC(ctx, textRenderer, Fnt.SMALL, toast, px + PW / 2f, py + PH - 84, argb(a, 0xFFFFFF));
        }
        ctx.getMatrices().popMatrix();
    }

    private void wallpaper(DrawContext ctx, int idx, float x, float y, float w, float h, float a) {
        int[] c = WALL[Math.max(0, Math.min(WALL.length - 1, idx))];
        ctx.fillGradient(r(x), r(y), r(x + w), r(y + h), argb(a, c[0]), argb(a, c[1]));
        ctx.fillGradient(r(x), r(y + h * 0.55f), r(x + w), r(y + h), argb(0f, c[2]), argb(0.30f * a, c[2]));
    }

    /** App icon: rounded tile + glyph, centred on (cx, cy). */
    private void icon(DrawContext ctx, App ap, float cx, float cy, float s, float a) {
        box(ctx, RR, cx - s / 2f + 1, cy - s / 2f + 3, s, s, s * 0.24f, argb(0.30f * a, 0x000000));
        box(ctx, RR, cx - s / 2f, cy - s / 2f, s, s, s * 0.24f, argb(a, ap.color));
        box(ctx, RR_RING, cx - s / 2f, cy - s / 2f, s, s, s * 0.24f, argb(0.16f * a, 0xFFFFFF));
        if (ap == App.SETTINGS) {
            centered(ctx, I_GEAR, cx, cy, s * 0.62f, s * 0.62f, argb(a, 0xFFFFFF));
        } else if (ap == App.CLOCK) {
            centered(ctx, RING, cx, cy, s * 0.64f, s * 0.64f, argb(a, 0xFFFFFF));
            ctx.fill(r(cx) - 1, r(cy - s * 0.22f), r(cx) + 1, r(cy) + 1, argb(a, 0xFFFFFF));
            ctx.fill(r(cx), r(cy) - 1, r(cx + s * 0.16f), r(cy) + 1, argb(a, 0xFFFFFF));
        } else if (ap == App.YOUTUBE) {
            float th = s * 0.40f, tw = s * 0.34f, sx = cx - tw / 3f, sy = cy - th / 2f;
            for (int i = 0; i < Math.round(th); i++) {
                float len = tw * (1f - Math.abs(2f * i / th - 1f));
                ctx.fill(r(sx), r(sy) + i, r(sx + len), r(sy) + i + 1, argb(a, 0xFFFFFF));
            }
        } else if (ap == App.NOTES) {
            for (int i = 0; i < 3; i++) {
                float ly = cy - s * 0.20f + i * s * 0.20f, lw = i == 2 ? s * 0.20f : s * 0.44f;
                ctx.fill(r(cx - s * 0.22f), r(ly), r(cx - s * 0.22f + lw), r(ly) + Math.max(2, r(s * 0.07f)), argb(a, 0xFFFFFF));
            }
        } else if (ap == App.MUSIC) {
            centered(ctx, DISC, cx - s * 0.08f, cy + s * 0.16f, s * 0.28f, s * 0.28f, argb(a, 0xFFFFFF));
            int sx = r(cx + s * 0.04f);
            ctx.fill(sx, r(cy - s * 0.24f), sx + Math.max(2, r(s * 0.06f)), r(cy + s * 0.16f), argb(a, 0xFFFFFF));
            ctx.fill(sx, r(cy - s * 0.24f), sx + r(s * 0.20f), r(cy - s * 0.24f) + Math.max(3, r(s * 0.10f)), argb(a, 0xFFFFFF));
        } else if (ap == App.FILES) {
            ctx.fill(r(cx - s * 0.28f), r(cy - s * 0.22f), r(cx - s * 0.04f), r(cy - s * 0.10f), argb(a, 0xFFFFFF));
            box(ctx, RR, cx - s * 0.28f, cy - s * 0.14f, s * 0.56f, s * 0.38f, s * 0.07f, argb(a, 0xFFFFFF));
        } else if (ap == App.MONITOR) {
            float[] hs = {0.22f, 0.40f, 0.30f, 0.52f};
            for (int i = 0; i < hs.length; i++) {
                float bx = cx - s * 0.30f + i * s * 0.16f;
                ctx.fill(r(bx), r(cy + s * 0.26f - s * hs[i]), r(bx + s * 0.11f), r(cy + s * 0.26f), argb(a, 0xFFFFFF));
            }
        } else if (ap.glyph != null) {
            Fnt f = s >= 48f ? Fnt.TILE_L : Fnt.TILE_S;
            textC(ctx, textRenderer, f, ap.glyph, cx, cy, argb(a, ap.glyphColor));
        }
    }

    // ---------------- window ----------------
    private void drawWindow(DrawContext ctx, float mx, float my, float px, float py, float pw, float a) {
        float wa = ease(winAt, 220f) * a;
        final float WW = 460f, WH = 290f;
        float wx = px + (pw - WW) / 2f, wy = py + 36f + (1f - wa) * 14f;
        int acc = accent();
        box(ctx, RR, wx - 2, wy + 4, WW + 4, WH + 4, 16, argb(0.35f * wa, 0x000000));
        box(ctx, RR, wx, wy, WW, WH, 14, argb(0.97f * wa, 0x1A1D24));
        box(ctx, RR_RING, wx, wy, WW, WH, 14, argb(0.12f * wa, 0xFFFFFF));
        ctx.fill(r(wx + 10), r(wy + 30), r(wx + WW - 10), r(wy + 31), argb(0.08f * wa, 0xFFFFFF));
        // traffic lights (the red one closes the window)
        boolean hovClose = inside(mx, my, wx + 8, wy + 6, 18, 18);
        centered(ctx, DOT, wx + 17, wy + 15, 11, 11, argb(wa, hovClose ? 0xFF8A80 : 0xFF5F57));
        centered(ctx, DOT, wx + 35, wy + 15, 11, 11, argb(wa, 0xFEBC2E));
        centered(ctx, DOT, wx + 53, wy + 15, 11, 11, argb(wa, 0x28C840));
        hits.add(new Hit(wx + 8, wy + 6, 18, 18, "close"));
        textC(ctx, textRenderer, Fnt.SMALL, win == App.SETTINGS ? "Настройки - " + SET_TABS[setTab] : win.title, wx + WW / 2f, wy + 15, argb(0.85f * wa, 0xFFFFFF));

        float cx = wx + 16, cy = wy + 40, cw = WW - 32, ch = WH - 52;
        switch (win) {
            case CALC -> drawCalc(ctx, mx, my, cx, cy, cw, ch, wa, acc);
            case CLOCK -> {
                LocalDateTime n = LocalDateTime.now();
                textC(ctx, textRenderer, Fnt.HUGE, n.format(DateTimeFormatter.ofPattern("HH:mm:ss")), cx + cw / 2f, cy + ch / 2f - 16, argb(wa, 0xFFFFFF));
                String d = n.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.forLanguageTag("ru")) + ", "
                        + n.format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
                textC(ctx, textRenderer, Fnt.LABEL, d, cx + cw / 2f, cy + ch / 2f + 40, argb(0.6f * wa, 0xFFFFFF));
            }
            case SETTINGS -> drawSettings(ctx, mx, my, cx, cy, cw, ch, wa, acc);
            case NOTES -> drawNotes(ctx, mx, my, cx, cy, cw, ch, wa, acc);
            case MUSIC -> drawMusic(ctx, mx, my, cx, cy, cw, ch, wa, acc);
            case FILES -> drawFiles(ctx, mx, my, cx, cy, cw, ch, wa, acc);
            case MONITOR -> drawMonitor(ctx, cx, cy, cw, ch, wa);
            default -> { }
        }
    }

    private void drawSettings(DrawContext ctx, float mx, float my, float cx, float cy, float cw, float ch, float a, int acc) {
        float sw = 112f;
        for (int i = 0; i < SET_TABS.length; i++) {
            float ty = cy + i * 32f;
            boolean sel = i == setTab, hov = inside(mx, my, cx, ty, sw, 28);
            if (sel) box(ctx, RR, cx, ty, sw, 28, 8, argb(0.9f * a, acc));
            else if (hov) box(ctx, RR, cx, ty, sw, 28, 8, argb(0.07f * a, 0xFFFFFF));
            text(ctx, textRenderer, Fnt.SMALL, SET_TABS[i], cx + 10, ty + 14, argb((sel ? 1f : 0.75f) * a, sel && acc == 0xFFFFFF ? 0x000000 : 0xFFFFFF));
            hits.add(new Hit(cx, ty, sw, 28, "tab:" + i));
        }
        float x = cx + sw + 18, w = cw - sw - 18;
        ctx.fill(r(x - 9), r(cy), r(x - 8), r(cy + ch), argb(0.08f * a, 0xFFFFFF));
        if (setTab == 0) {
            text(ctx, textRenderer, Fnt.LABEL, "Цвет акцента", x, cy + 10, argb(a, 0xFFFFFF));
            int sel = Math.max(0, Math.min(ShrineGui.PALETTE.length - 1, ShrineCfg.integer(K_ACCENT, 4)));
            for (int i = 0; i < ShrineGui.PALETTE.length; i++) {
                float sx = x + 14 + i * 34f, sy = cy + 56;
                if (i == sel) centered(ctx, RING, sx, sy, 30, 30, argb(a, 0xFFFFFF));
                centered(ctx, DISC, sx, sy, 22, 22, argb(a, ShrineGui.PALETTE[i]));
                hits.add(new Hit(sx - 16, sy - 16, 32, 32, "acc:" + i));
            }
            text(ctx, textRenderer, Fnt.SMALL, "Цвет выбранных пунктов и кнопок", x, cy + 98, argb(0.55f * a, 0xFFFFFF));
            box(ctx, RR, x, cy + 118, w - 6, 46, 12, argb(0.9f * a, acc));
            textC(ctx, textRenderer, Fnt.SMALL, "Так выглядит акцент", x + (w - 6) / 2f, cy + 141, argb(a, acc == 0xFFFFFF ? 0x000000 : 0xFFFFFF));
        } else if (setTab == 1) {
            text(ctx, textRenderer, Fnt.LABEL, "Обои рабочего стола", x, cy + 10, argb(a, 0xFFFFFF));
            int sel = ShrineCfg.integer(K_WALL, 0);
            float tw = (w - 6 - 2 * 10f) / 3f, th = 56f;
            for (int i = 0; i < WALL.length; i++) {
                float tx = x + (i % 3) * (tw + 10f), ty = cy + 32 + (i / 3) * (th + 28f);
                if (i == sel) box(ctx, RR, tx - 3, ty - 3, tw + 6, th + 6, 8, argb(a, acc));
                wallpaper(ctx, i, tx, ty, tw, th, a);
                textC(ctx, textRenderer, Fnt.TINY_B, WALL_NAME[i], tx + tw / 2f, ty + th + 11, argb(0.8f * a, 0xFFFFFF));
                hits.add(new Hit(tx, ty, tw, th + 20, "wall:" + i));
            }
        } else {
            text(ctx, textRenderer, Fnt.LABEL, "Shrine OS 1.1", x, cy + 12, argb(a, 0xFFFFFF));
            String[] lines = {"Рабочий стол внутри Minecraft.", "Google, Discord, YouTube, Twitch, Spotify,",
                    "Telegram открываются в браузере компьютера", "(ссылка ещё и копируется в буфер).",
                    "Заметки, Музыка, Проводник, Монитор, Калькулятор,", "Часы и Настройки работают здесь."};
            for (int i = 0; i < lines.length; i++)
                text(ctx, textRenderer, Fnt.SMALL, lines[i], x, cy + 44 + i * 19f, argb(0.65f * a, 0xFFFFFF));
        }
    }

    private static final String[][] CALC_ROWS = {{"C", "±", "%", "÷"}, {"7", "8", "9", "×"}, {"4", "5", "6", "−"}, {"1", "2", "3", "+"}, {"0", ".", "="}};

    private void drawCalc(DrawContext ctx, float mx, float my, float cx, float cy, float cw, float ch, float a, int acc) {
        box(ctx, RR, cx, cy, cw, 44, 10, argb(0.35f * a, 0x000000));
        String shown = disp.length() > 14 ? disp.substring(0, 14) : disp;
        text(ctx, textRenderer, Fnt.NAME_B, shown, cx + cw - 14 - width(textRenderer, Fnt.NAME_B, shown), cy + 22, argb(a, 0xFFFFFF));
        float bw = (cw - 3 * 6f) / 4f, bh = (ch - 44 - 8 - 4 * 5f) / 5f, gy = cy + 52;
        for (int row = 0; row < CALC_ROWS.length; row++) {
            String[] rw = CALC_ROWS[row];
            float x = cx;
            for (int c = 0; c < rw.length; c++) {
                String lab = rw[c];
                float w = (row == 4 && c == 0) ? bw * 2 + 6 : bw, y = gy + row * (bh + 5f);
                boolean isOp = "÷×−+=".contains(lab), isTop = "C±%".contains(lab) && !lab.equals("0");
                boolean hov = inside(mx, my, x, y, w, bh);
                int col = isOp ? acc : isTop ? 0x4B5563 : 0x2B303A;
                box(ctx, RR, x, y, w, bh, 9, argb((hov ? 1f : 0.88f) * a, col));
                textC(ctx, textRenderer, Fnt.UI_B, lab, x + w / 2f, y + bh / 2f, argb(a, isOp && acc == 0xFFFFFF ? 0x000000 : 0xFFFFFF));
                hits.add(new Hit(x, y, w, bh, "calc:" + lab));
                x += w + 6f;
            }
        }
    }


    // ---------------- 3D tilt ----------------
    private static float clampf(float v, float lo, float hi) { return Math.max(lo, Math.min(hi, v)); }

    private void updateTilt(float mxk, float myk, float a, float cx, float cy) {
        long now = Util.getMeasuringTimeMs();
        float dt = lastFrame == 0 ? 0.016f : Math.min(0.1f, (now - lastFrame) / 1000f);
        lastFrame = now;
        tcx = cx; tcy = cy;
        if (!ShrineCfg.bool(K_3D, true)) { ta = 1f; tb = 0f; tc = 0f; td = 1f; bob = 0f; return; }
        float t = (now - openedAt) / 1000f;
        float wantYaw = clampf((mxk - cx) / 360f, -1f, 1f) * 9f + (float) Math.sin(t * 0.7f) * 2.5f;
        float wantPitch = -clampf((myk - cy) / 210f, -1f, 1f) * 5f + (float) Math.cos(t * 0.9f) * 1.5f;
        float sm = 1f - (float) Math.exp(-7f * dt);
        tYaw += (wantYaw - tYaw) * sm;
        tPitch += (wantPitch - tPitch) * sm;
        float yaw = (float) Math.toRadians(tYaw - (1f - a) * 32f);     // swings in when opening
        float pit = (float) Math.toRadians(tPitch);
        float sc = 1f - Math.abs((float) Math.sin(yaw)) * 0.04f;
        ta = (float) Math.cos(yaw) * sc;
        tb = (float) Math.sin(yaw) * 0.20f;
        tc = (float) Math.sin(pit) * 0.20f;
        td = (float) Math.cos(pit) * sc;
        bob = (float) Math.sin(t * 1.3f) * 3f;
    }

    /** Mouse position (screen, scaled units) -> position on the flat monitor (undoes the tilt). */
    private float[] toLocal(double mxk, double myk) {
        float ux = (float) mxk - tcx, uy = (float) myk - (tcy + bob);
        float det = ta * td - tb * tc;
        if (Math.abs(det) < 1e-4f) return new float[]{(float) mxk, (float) myk};
        return new float[]{tcx + (td * ux - tc * uy) / det, tcy + (-tb * ux + ta * uy) / det};
    }

    // ---------------- small helpers for the apps ----------------
    private void btn(DrawContext ctx, float mx, float my, float x, float y, float w, float h, String label, String id, int col, float a) {
        boolean hov = inside(mx, my, x, y, w, h);
        box(ctx, RR, x, y, w, h, 8, argb((hov ? 0.98f : 0.80f) * a, col));
        textC(ctx, textRenderer, Fnt.SMALL, label, x + w / 2f, y + h / 2f, argb(a, col == 0xFFFFFF ? 0x000000 : 0xFFFFFF));
        hits.add(new Hit(x, y, w, h, id));
    }

    private String fit(Fnt f, String s, float maxW) {
        if (width(textRenderer, f, s) <= maxW) return s;
        while (s.length() > 1 && width(textRenderer, f, s + "..") > maxW) s = s.substring(0, s.length() - 1);
        return s + "..";
    }

    private static String mmss(float sec) {
        int t = Math.max(0, (int) sec);
        return String.format(Locale.ROOT, "%d:%02d", t / 60, t % 60);
    }

    // ---------------- Заметки ----------------
    private static Path notesFile() { return FabricLoader.getInstance().getConfigDir().resolve("shrine_notes.txt"); }

    private void loadNotes() {
        if (notesLoaded) return;
        notesLoaded = true;
        try {
            if (Files.exists(notesFile())) notes.append(Files.readString(notesFile(), StandardCharsets.UTF_8));
            if (notes.length() > NOTES_MAX) notes.setLength(NOTES_MAX);
        } catch (Throwable ignored) { }
    }

    private void saveNotes() {
        try { Files.writeString(notesFile(), notes.toString(), StandardCharsets.UTF_8); } catch (Throwable ignored) { }
    }

    private List<String> wrap(String text, float maxW) {
        List<String> out = new ArrayList<>();
        for (String para : text.split("\n", -1)) {
            StringBuilder cur = new StringBuilder();
            for (int i = 0; i < para.length(); i++) {
                char c = para.charAt(i);
                cur.append(c);
                if (cur.length() > 1 && width(textRenderer, Fnt.SMALL, cur.toString()) > maxW) {
                    out.add(cur.substring(0, cur.length() - 1));
                    cur = new StringBuilder().append(c);
                }
            }
            out.add(cur.toString());
        }
        return out;
    }

    private void drawNotes(DrawContext ctx, float mx, float my, float cx, float cy, float cw, float ch, float a, int acc) {
        float boxH = ch - 32f;
        box(ctx, RR, cx, cy, cw, boxH, 10, argb(0.35f * a, 0x000000));
        String all = notes.toString();
        String tail = all.length() > 1200 ? all.substring(all.length() - 1200) : all;
        List<String> lines = wrap(tail, cw - 28f);
        int rows = Math.max(1, (int) ((boxH - 14f) / 17f));
        int from = Math.max(0, lines.size() - rows);
        boolean blink = (Util.getMeasuringTimeMs() / 500L) % 2L == 0L;
        if (all.isEmpty()) text(ctx, textRenderer, Fnt.SMALL, "Печатай с клавиатуры...", cx + 14, cy + 16, argb(0.35f * a, 0xFFFFFF));
        for (int i = from; i < lines.size(); i++) {
            boolean last = i == lines.size() - 1;
            text(ctx, textRenderer, Fnt.SMALL, lines.get(i) + (last && blink ? "|" : ""), cx + 14, cy + 16 + (i - from) * 17f, argb(0.92f * a, 0xFFFFFF));
        }
        float by = cy + ch - 24f;
        text(ctx, textRenderer, Fnt.TINY_B, notes.length() + " / " + NOTES_MAX + "   Ctrl+V - вставить, Enter - новая строка", cx + 4, by + 12, argb(0.5f * a, 0xFFFFFF));
        btn(ctx, mx, my, cx + cw - 84, by, 84, 24, "Очистить", "notes:clear", acc, a);
    }

    // ---------------- Музыка ----------------
    private void drawMusic(DrawContext ctx, float mx, float my, float cx, float cy, float cw, float ch, float a, int acc) {
        MusicPlayer.Track t = MusicPlayer.currentTrack();
        String title = t != null ? t.title : "Ничего не играет";
        String sub = t != null ? t.artist : (MusicPlayer.tracks.isEmpty() ? "Положи mp3 в папку «музыка св» в папке игры" : "Выбери трек ниже");
        box(ctx, RR, cx, cy, 60, 60, 14, argb(a, acc));
        centered(ctx, DISC, cx + 24, cy + 38, 20, 20, argb(a, 0xFFFFFF));
        ctx.fill(r(cx + 32), r(cy + 14), r(cx + 35), r(cy + 38), argb(a, 0xFFFFFF));
        ctx.fill(r(cx + 32), r(cy + 14), r(cx + 46), r(cy + 19), argb(a, 0xFFFFFF));
        float tx = cx + 74, tw = cw - 74;
        text(ctx, textRenderer, Fnt.UI_B, fit(Fnt.UI_B, title, tw), tx, cy + 12, argb(a, 0xFFFFFF));
        text(ctx, textRenderer, Fnt.SMALL, fit(Fnt.SMALL, sub == null ? "" : sub, tw), tx, cy + 33, argb(0.6f * a, 0xFFFFFF));
        float el = MusicPlayer.time(), du = MusicPlayer.duration;
        float frac = du > 0f ? clampf(el / du, 0f, 1f) : 0f;
        box(ctx, RR, tx, cy + 48, tw, 5, 2.5f, argb(0.16f * a, 0xFFFFFF));
        if (frac > 0.01f) box(ctx, RR, tx, cy + 48, Math.max(5f, tw * frac), 5, 2.5f, argb(a, acc));
        String time = mmss(el) + " / " + mmss(du);
        text(ctx, textRenderer, Fnt.TINY_B, time, tx + tw - width(textRenderer, Fnt.TINY_B, time), cy + 64, argb(0.55f * a, 0xFFFFFF));

        float by = cy + 74, bw = 78, gap = 8;
        btn(ctx, mx, my, cx, by, bw, 26, "Назад", "mus:prev", 0x2B303A, a);
        btn(ctx, mx, my, cx + (bw + gap), by, bw + 10, 26, MusicPlayer.active() && !MusicPlayer.paused ? "Пауза" : "Играть", "mus:play", acc, a);
        btn(ctx, mx, my, cx + 2 * (bw + gap) + 10, by, bw, 26, "Далее", "mus:next", 0x2B303A, a);
        btn(ctx, mx, my, cx + 3 * (bw + gap) + 10, by, 82, 26, "Обновить", "mus:scan", 0x2B303A, a);
        float vx = cx + 4 * (bw + gap) + 22, vw2 = cx + cw - vx;
        float vol = MusicPlayer.volume();
        text(ctx, textRenderer, Fnt.TINY_B, "Громкость", vx, by - 2, argb(0.5f * a, 0xFFFFFF));
        box(ctx, RR, vx, by + 12, vw2, 6, 3, argb(0.16f * a, 0xFFFFFF));
        box(ctx, RR, vx, by + 12, Math.max(6f, vw2 * vol), 6, 3, argb(a, acc));
        hits.add(new Hit(vx, by + 6, vw2, 18, "mus:vol"));

        float ly = cy + 112, rowH = 22;
        int vis = Math.max(1, (int) ((ch - 112) / rowH));
        int total = MusicPlayer.tracks.size();
        musOff = Math.max(0, Math.min(musOff, Math.max(0, total - vis)));
        for (int i = 0; i < vis && musOff + i < total; i++) {
            int idx = musOff + i;
            MusicPlayer.Track tr = MusicPlayer.tracks.get(idx);
            float ry = ly + i * rowH;
            boolean cur = idx == MusicPlayer.current, hov = inside(mx, my, cx, ry, cw, rowH - 2);
            if (cur) box(ctx, RR, cx, ry, cw, rowH - 2, 7, argb(0.22f * a, acc));
            else if (hov) box(ctx, RR, cx, ry, cw, rowH - 2, 7, argb(0.07f * a, 0xFFFFFF));
            String nm = (idx + 1) + ".  " + tr.title + (tr.artist == null || tr.artist.isEmpty() ? "" : "  -  " + tr.artist);
            text(ctx, textRenderer, Fnt.SMALL, fit(Fnt.SMALL, nm, cw - 20), cx + 10, ry + (rowH - 2) / 2f, argb((cur ? 1f : 0.8f) * a, 0xFFFFFF));
            hits.add(new Hit(cx, ry, cw, rowH - 2, "mus:t:" + idx));
        }
    }

    // ---------------- Проводник ----------------
    private void fsInit() {
        fsRoot = FabricLoader.getInstance().getGameDir().toAbsolutePath().normalize();
        fsDir = fsRoot;
        fsRefresh();
    }

    private void fsRefresh() {
        fsList.clear();
        fsSize.clear();
        fsOff = 0;
        try (Stream<Path> st = Files.list(fsDir)) {
            st.sorted((p, q) -> {
                boolean pd = Files.isDirectory(p), qd = Files.isDirectory(q);
                if (pd != qd) return pd ? -1 : 1;
                return p.getFileName().toString().compareToIgnoreCase(q.getFileName().toString());
            }).limit(1000).forEach(fsList::add);
        } catch (Throwable ignored) { }
        for (Path p : fsList) {
            String sz = "";
            try {
                if (!Files.isDirectory(p)) {
                    long b = Files.size(p);
                    sz = b < 1024 ? b + " Б" : b < 1024 * 1024 ? (b / 1024) + " КБ" : String.format(Locale.ROOT, "%.1f МБ", b / 1048576.0);
                }
            } catch (Throwable ignored) { }
            fsSize.add(sz);
        }
    }

    private void drawFiles(DrawContext ctx, float mx, float my, float cx, float cy, float cw, float ch, float a, int acc) {
        if (fsDir == null) fsInit();
        String rel = fsRoot.relativize(fsDir).toString().replace('\\', '/');
        String crumb = "Игра" + (rel.isEmpty() ? "" : "/" + rel);
        text(ctx, textRenderer, Fnt.SMALL, fit(Fnt.SMALL, crumb, cw - 150), cx + 4, cy + 10, argb(0.75f * a, 0xFFFFFF));
        btn(ctx, mx, my, cx + cw - 140, cy, 140, 22, "Открыть в системе", "fs:open", 0x2B303A, a);

        boolean up = !fsDir.equals(fsRoot);
        int total = fsList.size() + (up ? 1 : 0);
        float ly = cy + 30, rowH = 22;
        int vis = Math.max(1, (int) ((ch - 30) / rowH));
        fsOff = Math.max(0, Math.min(fsOff, Math.max(0, total - vis)));
        if (total == 0) text(ctx, textRenderer, Fnt.SMALL, "Папка пуста", cx + 10, ly + 12, argb(0.5f * a, 0xFFFFFF));
        for (int i = 0; i < vis && fsOff + i < total; i++) {
            int idx = fsOff + i;
            boolean isUp = up && idx == 0;
            int li = idx - (up ? 1 : 0);
            float ry = ly + i * rowH;
            if (inside(mx, my, cx, ry, cw, rowH - 2)) box(ctx, RR, cx, ry, cw, rowH - 2, 7, argb(0.08f * a, 0xFFFFFF));
            boolean dir = isUp || Files.isDirectory(fsList.get(li));
            int ic = dir ? 0x3B8BF6 : 0x9AA0AD;
            ctx.fill(r(cx + 8), r(ry + 5), r(cx + 15), r(ry + 8), argb(a, ic));
            box(ctx, RR, cx + 8, ry + 7, 16, 11, 2.5f, argb(a, ic));
            String nm = isUp ? ".." : fsList.get(li).getFileName().toString();
            text(ctx, textRenderer, Fnt.SMALL, fit(Fnt.SMALL, nm, cw - 130), cx + 32, ry + (rowH - 2) / 2f, argb(0.9f * a, 0xFFFFFF));
            if (!isUp) {
                String sz = fsSize.get(li);
                text(ctx, textRenderer, Fnt.TINY_B, sz, cx + cw - 10 - width(textRenderer, Fnt.TINY_B, sz), ry + (rowH - 2) / 2f, argb(0.5f * a, 0xFFFFFF));
            }
            hits.add(new Hit(cx, ry, cw, rowH - 2, isUp ? "fs:up" : "fs:" + li));
        }
    }

    // ---------------- Монитор ----------------
    private void drawMonitor(DrawContext ctx, float cx, float cy, float cw, float ch, float a) {
        if (client == null) return;
        int fps = client.getCurrentFps();
        long now = Util.getMeasuringTimeMs();
        if (now - fpsAt > 500) {
            System.arraycopy(fpsHist, 1, fpsHist, 0, fpsHist.length - 1);
            fpsHist[fpsHist.length - 1] = fps;
            fpsAt = now;
        }
        String ping = "-", xyz = "-", hp = "-", tod = "-";
        if (client.player != null) {
            try {
                PlayerListEntry e = client.getNetworkHandler() != null ? client.getNetworkHandler().getPlayerListEntry(client.player.getUuid()) : null;
                if (e != null) ping = e.getLatency() + " мс";
            } catch (Throwable ignored) { }
            xyz = (int) Math.floor(client.player.getX()) + " " + (int) Math.floor(client.player.getY()) + " " + (int) Math.floor(client.player.getZ());
            hp = Math.round(client.player.getHealth()) + " / " + Math.round(client.player.getMaxHealth());
        }
        if (client.world != null) {
            long tt = client.world.getTimeOfDay() % 24000L;
            tod = String.format(Locale.ROOT, "%02d:%02d", (tt / 1000 + 6) % 24, (tt % 1000) * 60 / 1000);
        }
        Runtime rt = Runtime.getRuntime();
        String mem = ((rt.totalMemory() - rt.freeMemory()) >> 20) + " / " + (rt.maxMemory() >> 20) + " МБ";
        String[][] tiles = {{"FPS", String.valueOf(fps)}, {"Пинг", ping}, {"Память", mem},
                {"Координаты", xyz}, {"Время в мире", tod}, {"Здоровье", hp}};
        float tw = (cw - 2 * 8f) / 3f, th = 52f;
        for (int i = 0; i < tiles.length; i++) {
            float x = cx + (i % 3) * (tw + 8f), y = cy + (i / 3) * (th + 8f);
            box(ctx, RR, x, y, tw, th, 10, argb(0.35f * a, 0x000000));
            text(ctx, textRenderer, Fnt.TINY_B, tiles[i][0], x + 12, y + 14, argb(0.5f * a, 0xFFFFFF));
            Fnt f = tiles[i][1].length() > 9 ? Fnt.SMALL : Fnt.UI_B;
            text(ctx, textRenderer, f, fit(f, tiles[i][1], tw - 20), x + 12, y + 35, argb(a, 0xFFFFFF));
        }
        float gy = cy + 2 * (th + 8f) + 4f, gh = cy + ch - gy - 14f;
        text(ctx, textRenderer, Fnt.TINY_B, "FPS за последние секунды", cx + 2, gy + 4, argb(0.5f * a, 0xFFFFFF));
        int max = 60;
        for (int v : fpsHist) max = Math.max(max, v);
        float bw = (cw - 4f) / fpsHist.length, base = cy + ch - 2f, top = gy + 16f;
        for (int i = 0; i < fpsHist.length; i++) {
            float bh = (base - top) * Math.min(1f, fpsHist[i] / (float) max);
            ctx.fill(r(cx + 2 + i * bw), r(base - bh), r(cx + 2 + (i + 1) * bw) - 1, r(base), argb(0.85f * a, accent()));
        }
    }

    // ---------------- calculator logic ----------------
    private double parse() { try { return Double.parseDouble(disp); } catch (Exception e) { return 0; } }

    private static String fmt(double v) {
        if (v == Math.rint(v) && Math.abs(v) < 1e12) return String.valueOf((long) v);
        String s = String.format(Locale.ROOT, "%.8f", v).replaceAll("0+$", "").replaceAll("\\.$", "");
        return s.length() > 14 ? String.format(Locale.ROOT, "%.6e", v) : s;
    }

    private void compute() {
        double b = parse();
        double res = switch (op) {
            case "+" -> acc + b;
            case "−" -> acc - b;
            case "×" -> acc * b;
            default -> b == 0 ? Double.NaN : acc / b;
        };
        if (Double.isNaN(res) || Double.isInfinite(res)) { disp = "Ошибка"; op = null; acc = 0; fresh = true; return; }
        acc = res;
        disp = fmt(res);
    }

    private void press(String k) {
        switch (k) {
            case "C" -> { disp = "0"; acc = 0; op = null; fresh = true; }
            case "±" -> { if (!disp.equals("0") && !disp.equals("Ошибка")) disp = disp.startsWith("-") ? disp.substring(1) : "-" + disp; }
            case "%" -> { if (!disp.equals("Ошибка")) disp = fmt(parse() / 100); }
            case "+", "−", "×", "÷" -> {
                if (disp.equals("Ошибка")) return;
                if (op != null && !fresh) compute(); else acc = parse();
                op = k; fresh = true;
            }
            case "=" -> { if (op != null) { compute(); op = null; } fresh = true; }
            case "." -> {
                if (fresh || disp.equals("Ошибка")) { disp = "0."; fresh = false; }
                else if (!disp.contains(".")) disp += ".";
            }
            default -> {
                if (fresh || disp.equals("0") || disp.equals("Ошибка")) disp = k;
                else if (disp.length() < 14) disp += k;
                fresh = false;
            }
        }
    }

    // ---------------- input ----------------
    private void launch(App ap) {
        if (ap.web()) {
            try { Util.getOperatingSystem().open(URI.create(ap.url)); } catch (Throwable ignored) { }
            if (client != null) client.keyboard.setClipboard(ap.url);
            toast = ap.title + ": открываю в браузере, ссылка скопирована";
            toastAt = Util.getMeasuringTimeMs();
        } else {
            win = ap;
            winAt = Util.getMeasuringTimeMs();
            if (ap == App.SETTINGS) setTab = 0;
            if (ap == App.NOTES) loadNotes();
            if (ap == App.MUSIC) { MusicPlayer.rescan(); musOff = 0; }
            if (ap == App.FILES && fsDir == null) fsInit();
        }
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        float[] lm = toLocal(click.x() / k, click.y() / k);
        float mx = lm[0], my = lm[1];
        for (int i = hits.size() - 1; i >= 0; i--) {                 // later hits are drawn on top
            Hit h = hits.get(i);
            if (!inside(mx, my, h.x, h.y, h.w, h.h)) continue;
            String id = h.id;
            if (id.startsWith("app:")) launch(App.values()[Integer.parseInt(id.substring(4))]);
            else if (id.equals("close")) win = null;
            else if (id.startsWith("tab:")) setTab = Integer.parseInt(id.substring(4));
            else if (id.startsWith("wall:")) { ShrineCfg.setInt(K_WALL, Integer.parseInt(id.substring(5))); ShrineCfg.save(); }
            else if (id.startsWith("acc:")) { ShrineCfg.setInt(K_ACCENT, Integer.parseInt(id.substring(4))); ShrineCfg.save(); }
            else if (id.startsWith("calc:")) press(id.substring(5));
            else if (id.equals("notes:clear")) { notes.setLength(0); saveNotes(); }
            else if (id.equals("mus:prev")) MusicPlayer.prev();
            else if (id.equals("mus:play")) MusicPlayer.toggle();
            else if (id.equals("mus:next")) MusicPlayer.next();
            else if (id.equals("mus:scan")) MusicPlayer.rescan();
            else if (id.equals("mus:vol")) { ShrineCfg.setNum("music.volume", clampf((mx - h.x) / h.w, 0f, 1f)); ShrineCfg.save(); }
            else if (id.startsWith("mus:t:")) MusicPlayer.play(Integer.parseInt(id.substring(6)));
            else if (id.equals("fs:up")) { if (fsDir != null && !fsDir.equals(fsRoot) && fsDir.getParent() != null) { fsDir = fsDir.getParent(); fsRefresh(); } }
            else if (id.equals("fs:open")) { try { Util.getOperatingSystem().open(fsDir.toUri()); } catch (Throwable ignored) { } }
            else if (id.startsWith("fs:")) {
                int li = Integer.parseInt(id.substring(3));
                if (li >= 0 && li < fsList.size()) {
                    Path p = fsList.get(li);
                    if (Files.isDirectory(p)) { fsDir = p; fsRefresh(); }
                    else { try { Util.getOperatingSystem().open(p.toUri()); } catch (Throwable ignored) { } }
                }
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int kc = input.key();
        if (kc == GLFW.GLFW_KEY_ESCAPE) {
            if (win != null) win = null; else close();
            return true;
        }
        if (win == App.NOTES) {
            if (kc == GLFW.GLFW_KEY_BACKSPACE) { if (notes.length() > 0) { notes.setLength(notes.length() - 1); saveNotes(); } return true; }
            if (kc == GLFW.GLFW_KEY_ENTER || kc == GLFW.GLFW_KEY_KP_ENTER) { if (notes.length() < NOTES_MAX) { notes.append('\n'); saveNotes(); } return true; }
            if (kc == GLFW.GLFW_KEY_V && (input.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0 && client != null) {
                String clip = client.keyboard.getClipboard();
                if (clip != null) {
                    for (int i = 0; i < clip.length() && notes.length() < NOTES_MAX; i++) {
                        char c = clip.charAt(i);
                        if (c == '\n' || c >= 32) notes.append(c);
                    }
                    saveNotes();
                }
                return true;
            }
        }
        if (win == App.CALC) {
            if (kc >= GLFW.GLFW_KEY_0 && kc <= GLFW.GLFW_KEY_9) { press(String.valueOf(kc - GLFW.GLFW_KEY_0)); return true; }
            if (kc >= GLFW.GLFW_KEY_KP_0 && kc <= GLFW.GLFW_KEY_KP_9) { press(String.valueOf(kc - GLFW.GLFW_KEY_KP_0)); return true; }
            switch (kc) {
                case GLFW.GLFW_KEY_PERIOD, GLFW.GLFW_KEY_KP_DECIMAL -> { press("."); return true; }
                case GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER -> { press("="); return true; }
                case GLFW.GLFW_KEY_KP_ADD -> { press("+"); return true; }
                case GLFW.GLFW_KEY_KP_SUBTRACT -> { press("−"); return true; }
                case GLFW.GLFW_KEY_KP_MULTIPLY -> { press("×"); return true; }
                case GLFW.GLFW_KEY_KP_DIVIDE -> { press("÷"); return true; }
                case GLFW.GLFW_KEY_BACKSPACE -> {
                    if (!fresh && disp.length() > 1 && !disp.equals("Ошибка")) disp = disp.substring(0, disp.length() - 1); else disp = "0";
                    return true;
                }
                default -> { }
            }
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (win == App.NOTES) {
            int cp = input.codepoint();
            if (cp >= 32 && cp != 127 && notes.length() < NOTES_MAX) { notes.appendCodePoint(cp); saveNotes(); }
            return true;
        }
        return super.charTyped(input);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int d = verticalAmount > 0 ? -1 : 1;
        if (win == App.FILES) { fsOff += d; return true; }
        if (win == App.MUSIC) { musOff += d; return true; }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void close() {
        ShrineCfg.save();
        if (client != null) client.setScreen(parent);
    }
}

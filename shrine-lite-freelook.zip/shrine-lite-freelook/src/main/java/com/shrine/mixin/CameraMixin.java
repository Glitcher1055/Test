package com.shrine.mixin;

import com.shrine.FreeLookFx;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Player > FreeLook: animation step before the camera is placed, and our own third-person distance. */
@Mixin(Camera.class)
public abstract class CameraMixin {

    @Inject(method = "update", at = @At("HEAD"))
    private void shrine$freeLookBegin(CallbackInfo ci) { FreeLookFx.frame(); }

    @Inject(method = "update", at = @At("RETURN"))
    private void shrine$freeLookEnd(CallbackInfo ci) { FreeLookFx.endFrame(); }

    /** Vanilla third person: how far behind the head the camera wants to be. */
    @ModifyArg(method = "update", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;clipToSpace(F)F"), index = 0, require = 0)
    private float shrine$distance(float d) { return FreeLookFx.active() ? FreeLookFx.dist() : d; }

    /** Same thing for versions where the 4.0 is a plain constant. */
    @ModifyConstant(method = "update", constant = @Constant(floatValue = 4.0F), require = 0)
    private float shrine$distanceConst(float c) { return FreeLookFx.active() ? FreeLookFx.dist() : c; }

    /** "Push Through Blocks": the camera ignores walls. */
    @Inject(method = "clipToSpace", at = @At("RETURN"), cancellable = true, require = 0)
    private void shrine$noClip(CallbackInfoReturnable<Float> cir) {
        if (FreeLookFx.pushThrough()) cir.setReturnValue(FreeLookFx.dist());
    }
}

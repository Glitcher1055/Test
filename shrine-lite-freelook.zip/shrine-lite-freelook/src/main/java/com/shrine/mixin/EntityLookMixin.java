package com.shrine.mixin;

import com.shrine.FreeLookFx;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Player > FreeLook: the mouse turns the camera, not the player; the camera reads the FreeLook angles. */
@Mixin(Entity.class)
public abstract class EntityLookMixin {

    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void shrine$freeLook(double dx, double dy, CallbackInfo ci) {
        if (FreeLookFx.isPlayer(this) && FreeLookFx.look(dx, dy)) ci.cancel();
    }

    @Inject(method = "getYaw(F)F", at = @At("HEAD"), cancellable = true, require = 0)
    private void shrine$camYaw(float tickProgress, CallbackInfoReturnable<Float> cir) {
        if (FreeLookFx.overriding(this)) cir.setReturnValue(FreeLookFx.yaw());
    }

    @Inject(method = "getPitch(F)F", at = @At("HEAD"), cancellable = true, require = 0)
    private void shrine$camPitch(float tickProgress, CallbackInfoReturnable<Float> cir) {
        if (FreeLookFx.overriding(this)) cir.setReturnValue(FreeLookFx.pitch());
    }

    // some versions read the plain getters instead of the interpolated ones
    @Inject(method = "getYaw()F", at = @At("HEAD"), cancellable = true, require = 0)
    private void shrine$camYaw0(CallbackInfoReturnable<Float> cir) {
        if (FreeLookFx.overriding(this)) cir.setReturnValue(FreeLookFx.yaw());
    }

    @Inject(method = "getPitch()F", at = @At("HEAD"), cancellable = true, require = 0)
    private void shrine$camPitch0(CallbackInfoReturnable<Float> cir) {
        if (FreeLookFx.overriding(this)) cir.setReturnValue(FreeLookFx.pitch());
    }
}

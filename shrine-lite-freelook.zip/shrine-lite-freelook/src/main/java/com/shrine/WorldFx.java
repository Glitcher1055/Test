package com.shrine;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Visual > Мир: Fullbright (client-side night vision) and "no rain / thunder". Both only change what you see. */
final class WorldFx {
    private WorldFx() {}

    static final String K_FULLBRIGHT = "visual.world.fullbright", K_NOWEATHER = "visual.world.noweather";
    private static boolean gaveNightVision;

    static void register() { ClientTickEvents.END_CLIENT_TICK.register(WorldFx::tick); }

    private static void tick(MinecraftClient c) {
        if (c.player == null || c.world == null) { gaveNightVision = false; return; }
        if (ShrineCfg.bool(K_FULLBRIGHT, false)) {
            // kept above the "fading out" threshold, no particles / icon
            c.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
            gaveNightVision = true;
        } else if (gaveNightVision) {
            c.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
            gaveNightVision = false;
        }
        if (ShrineCfg.bool(K_NOWEATHER, false)) {
            c.world.setRainGradient(0f);
            c.world.setThunderGradient(0f);
        }
    }
}

package com.shrine;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/** Player > Движение / Зум: auto-sprint and a hold-to-zoom key (changes the FOV option while the key is held). */
final class QolFx {
    private QolFx() {}

    static final String K_SPRINT = "player.autosprint", K_ZOOM = "player.zoom", K_ZOOM_F = "player.zoom.factor";

    private static KeyBinding zoomKey;
    private static boolean zooming, sprintSet;
    private static int savedFov = 70;

    static void register(KeyBinding.Category cat) {
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.shrine.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, cat));
        ClientTickEvents.END_CLIENT_TICK.register(QolFx::tick);
    }

    private static void tick(MinecraftClient c) {
        if (c.player == null || c.options == null) {
            if (zooming) endZoom(c);
            return;
        }
        // ---- auto sprint ----
        if (ShrineCfg.bool(K_SPRINT, false) && c.currentScreen == null) {
            if (c.options.forwardKey.isPressed() && !c.player.isSneaking()) { c.options.sprintKey.setPressed(true); sprintSet = true; }
            else if (sprintSet) { c.options.sprintKey.setPressed(false); sprintSet = false; }
        } else if (sprintSet) { c.options.sprintKey.setPressed(false); sprintSet = false; }

        // ---- zoom ----
        boolean want = ShrineCfg.bool(K_ZOOM, false) && c.currentScreen == null && zoomKey != null && zoomKey.isPressed();
        if (want) {
            if (!zooming) { savedFov = c.options.getFov().getValue(); zooming = true; }
            float f = Math.max(1.5f, Math.min(4f, ShrineCfg.num(K_ZOOM_F, 2.5f)));
            int target = Math.max(30, Math.round(savedFov / f));      // the FOV option cannot go below 30
            int cur = c.options.getFov().getValue();
            int next = cur + Math.round((target - cur) * 0.5f);
            if (next == cur && cur != target) next += Integer.signum(target - cur);
            c.options.getFov().setValue(next);
        } else if (zooming) {
            int cur = c.options.getFov().getValue();
            int next = cur + Math.round((savedFov - cur) * 0.5f);
            if (next == cur && cur != savedFov) next += Integer.signum(savedFov - cur);
            c.options.getFov().setValue(next);
            if (next == savedFov) zooming = false;
        }
    }

    private static void endZoom(MinecraftClient c) {
        if (c.options != null) c.options.getFov().setValue(savedFov);
        zooming = false;
    }
}

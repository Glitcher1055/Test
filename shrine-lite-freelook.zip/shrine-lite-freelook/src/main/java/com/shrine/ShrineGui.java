package com.shrine;

import com.shrine.Gfx.Fnt;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

import java.util.ArrayList;
import java.util.List;

import static com.shrine.Gfx.*;

/**
 * Settings window of the mod (opened with Right Shift): a glass panel with a tab list on the left and scrolling
 * settings on the right. To add a tab or a setting, edit {@link #TABS} below - the layout is automatic.
 * Values live in {@link ShrineCfg} (config/shrine.properties); read them anywhere with ShrineCfg.bool("visual.particles", true).
 */
public final class ShrineGui extends Screen {

    // ================= content: add new tabs / settings here =================
    static final int[] PALETTE = {0xFF4D5D, 0xFF8A4D, 0xFFD24D, 0x5DE08A, 0x4DB8FF, 0xB07CFF, 0xFFFFFF};

    private static final List<Tab> TABS = List.of(
        tab("Combat", "Бой",
            sec("Crosshair",
                toggle(CrosshairFx.KEY, "Включить", false),
                choice(CrosshairFx.K_STYLE, "Стиль", 0, "Крест", "Точка", "Круг", "Крест и точка"),
                color(CrosshairFx.K_COLOR, "Цвет", 6),
                slider(CrosshairFx.K_SIZE, "Размер", 2f, 14f, 6f, ""),
                slider(CrosshairFx.K_GAP, "Зазор", 0f, 8f, 2f, ""),
                slider(CrosshairFx.K_THICK, "Толщина", 1f, 4f, 2f, "")),
            sec("TargetHud",
                func(TargetHud.KEY, "Панель цели", true, "target"),
                toggle(TargetHud.KEY_ARMOR, "Показывать экипировку", true)),
            soon("HitBox"), soon("Particles"), soon("TNTTimer")),
        tab("Render", "Отображение",
            sec("TargetESP",
                func(TargetEsp.KEY, "TargetESP", false, "esp")),
            sec("ProjectileTrails",
                func(Predictions.KEY, "Предсказания", false, "pred")),
            sec("Chams",
                func(EnchantGlintFx.KEY, "Перелив зачарования", false, "glint")),
            sec("ViewModel",
                func(ViewModelFx.KEY, "ViewModel", false, "viewmodel")),
            sec("FreeLook",
                func(FreeLookFx.KEY, "FreeLook", false, "freelook")),
            sec("WorldTweaks",
                toggle(WorldFx.K_FULLBRIGHT, "Яркость (Fullbright)", false)),
            sec("Blizzard",
                toggle(WorldFx.K_NOWEATHER, "Скрыть дождь и грозу", false)),
            soon("BlockOverlay"), soon("JumpCircles"), soon("NameTags"), soon("Trails"), soon("Waypoints"), soon("WorldLyrics")),
        tab("Misc", "Разное",
            sec("Sounds",
                toggle(HitSoundFx.KEY, "Звук удара", false),
                choice(HitSoundFx.K_SOUND, "Звук", 0, HitSoundFx.NAMES),
                slider(HitSoundFx.K_VOL, "Громкость", 0f, 100f, 60f, ""),
                slider(HitSoundFx.K_PITCH, "Высота", 50f, 200f, 100f, "")),
            sec("Interface",
                func(MusicHud.KEY, "Музыка", false, "music")),
            sec("Desktop",
                func(DesktopScreen.KEY, "Рабочий стол (там же Trainer)", false, "desktop")),
            sec("Information",
                toggle(InfoHud.K_STATS, "FPS, пинг, координаты", false),
                toggle(InfoHud.K_ISLAND, "Dynamic Island", false),
                toggle(InfoHud.K_COMPASS, "Компас", false)),
            sec("Keybinds",
                toggle(InfoHud.K_KEYS, "Клавиши (WASD, мышь)", false)),
            sec("Armor",
                toggle(InfoHud.K_ARMOR, "Броня и прочность", false)),
            sec("Potions",
                toggle(InfoHud.K_POTIONS, "Эффекты", false)),
            sec("Inventory",
                toggle(InfoHud.K_INV, "Инвентарь на экране", false),
                toggle(InfoHud.K_HOTBAR, "Custom hotbar", false)),
            sec("LowHP",
                toggle(InfoHud.K_LOWHP, "Предупреждение о низком здоровье", false)),
            sec("Zoom",
                toggle(QolFx.K_ZOOM, "Зум (клавиша C)", false),
                slider(QolFx.K_ZOOM_F, "Сила зума", 1.5f, 4f, 2.5f, "x")),
            sec("AutoSprint",
                toggle(QolFx.K_SPRINT, "Авто-спринт", false)),
            soon("StorageTracker"), soon("TotemCounter"), soon("TotemSound"), soon("InventorySort"), soon("ItemScroller")),
        tab("Builders", "Строительство",
            soon("Chunk Cache"), soon("Showcase"), soon("Schematics")),
        tab("Themes", "Темы",
            soon("Obsidian"), soon("Outrun"), soon("Neon"), soon("Matrix")),
        tab("Cosmetics", "Косметика",
            soon("Trails"), soon("Hats"), soon("Backpacks"), soon("Wings"), soon("Nametags"), soon("Melee"), soon("Graffiti"))
    );

    /** A module that is on the roadmap but not written yet: only a card with its name. */
    private static Sec soon(String name) { return new Sec(name + " · скоро", List.of()); }
    // =========================================================================

    private enum T { TOGGLE, CHOICE, SLIDER, COLOR }
    private record Opt(T t, String key, String label, float min, float max, float def, String unit, String[] items, String sub) {}
    private record Sec(String title, List<Opt> opts) {}
    private record Tab(String name, String sub, List<Sec> secs) {}

    private static Tab tab(String n, String s, Sec... secs) { return new Tab(n, s, List.of(secs)); }
    private static Sec sec(String t, Opt... o) { return new Sec(t, List.of(o)); }
    private static Opt toggle(String k, String l, boolean d) { return new Opt(T.TOGGLE, k, l, 0, 1, d ? 1 : 0, "", null, null); }
    /** A toggle that also has its own settings page: right-click it. */
    private static Opt func(String k, String l, boolean d, String sub) { return new Opt(T.TOGGLE, k, l, 0, 1, d ? 1 : 0, "", null, sub); }
    private static Opt choice(String k, String l, int d, String... items) { return new Opt(T.CHOICE, k, l, 0, items.length - 1, d, "", items, null); }
    private static Opt slider(String k, String l, float min, float max, float d, String u) { return new Opt(T.SLIDER, k, l, min, max, d, u, null, null); }
    private static Opt color(String k, String l, int d) { return new Opt(T.COLOR, k, l, 0, PALETTE.length - 1, d, "", null, null); }

    // ================= window geometry (virtual 540-high canvas) =================
    private static final float W = 760f, H = 420f, SIDE = 64f, PAD = 18f, ROW_GAP = 6f;
    private static final float HEAD = 66f;      // top bar height above the scrolling area

    private float k = 1f, vw = 960f;
    private final long openedAt = Util.getMeasuringTimeMs();
    private int tab;
    private float scroll, scrollTarget, contentH;
    private float[] tabHover = new float[TABS.size()];
    private float tabAnim;                      // 0..1 content fade after switching a tab
    private float x, y;

    // hit areas rebuilt every frame
    private record Hit(float x, float y, float w, float h, Opt opt, int idx) {}
    private final List<Hit> hits = new ArrayList<>();
    private String subId, subTitle = "";   // open settings page of a function (right click)
    private boolean designOpen;
    private Opt dragging;
    private float dragX, dragW;
    private float[] rClose = new float[4], rView = new float[4], rSearch = new float[4];
    private String query = "";
    private boolean searchFocus;

    public ShrineGui() { super(Text.literal("Shrine")); }

    @Override
    protected void init() {
        k = height / Scene.REF_H;
        vw = width / k;
    }

    @Override public boolean shouldPause() { return false; }

    private float open() {
        float t = Math.min(1f, (Util.getMeasuringTimeMs() - openedAt) / 260f);
        return 1f - (1f - t) * (1f - t);
    }

    private static float ease(float cur, float to, float d) { return cur + (to - cur) * Math.min(1f, d); }

    // ---------- render ----------
    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        // our own backdrop is drawn in render(); the vanilla blur is not wanted
    }

    @Override
    public void render(DrawContext ctx, int mxReal, int myReal, float delta) {
        float a = open();
        // the game stays visible behind the window, only darkened with a red tint
        ctx.fillGradient(0, 0, width, height, argb(0.62f * a, 0x0C0205), argb(0.78f * a, 0x2A0509));
        float mx = mxReal / k, my = myReal / k;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().scale(k, k);

        x = (vw - W) / 2f;
        y = (Scene.REF_H - H) / 2f + (1f - a) * 16f;
        hits.clear();
        tabAnim = ease(tabAnim, 1f, delta * 0.22f);
        scroll = ease(scroll, scrollTarget, delta * 0.4f);

        // window
        box(ctx, RR, x - 1, y - 1, W + 2, H + 2, 27, argb(0.14f * a, 0xFFFFFF));
        box(ctx, RR, x, y, W, H, 26, argb(0.93f * a, 0x150A0F));
        box(ctx, RR, x, y, SIDE, H, 26, argb(0.55f * a, 0x000000));
        ctx.fill(Math.round(x + SIDE), Math.round(y + 22), Math.round(x + SIDE) + 1, Math.round(y + H - 22), argb(0.07f * a, 0xFFFFFF));

        drawContent(ctx, mx, my, a);
        drawSidebar(ctx, mx, my, delta, a);

        ctx.getMatrices().popMatrix();
    }

    private void drawSidebar(DrawContext ctx, float mx, float my, float delta, float a) {
        // logo
        box(ctx, RR, x + 14, y + 14, 36, 36, 12, argb(a, ACCENT));
        textC(ctx, textRenderer, Fnt.TITLE_B, "S", x + 32, y + 32, argb(a, 0xFFFFFF));
        ctx.fill(Math.round(x + 18), Math.round(y + 62), Math.round(x + SIDE - 18), Math.round(y + 62) + 1, argb(0.10f * a, 0xFFFFFF));

        float ty = y + 74;
        int over = -1;
        float overY = 0f;
        for (int i = 0; i < TABS.size(); i++) {
            float bx = x + 10, bw = SIDE - 20, bh = 44;
            boolean hov = inside(mx, my, bx, ty, bw, bh);
            if (hov) { over = i; overY = ty; }
            tabHover[i] = ease(tabHover[i], hov ? 1f : 0f, delta * 0.3f);
            boolean sel = i == tab;
            if (sel) {
                box(ctx, RR, bx, ty, bw, bh, 13, argb(0.30f * a, ACCENT));
                box(ctx, RR_RING, bx, ty, bw, bh, 13, argb(0.55f * a, ACCENT));
            } else if (tabHover[i] > 0.01f) {
                box(ctx, RR, bx, ty, bw, bh, 13, argb(0.08f * tabHover[i] * a, 0xFFFFFF));
            }
            tabIcon(ctx, TABS.get(i).name(), bx + bw / 2f, ty + bh / 2f,
                    argb((sel ? 1f : 0.42f + 0.40f * tabHover[i]) * a, sel ? 0xFFFFFF : 0xE6C4C4));
            hits.add(new Hit(bx, ty, bw, bh, null, i));
            ty += bh + 8;
        }

        // user
        float uy = y + H - 50;
        centered(ctx, DISC, x + SIDE / 2f, uy + 18, 30, 30, argb(0.9f * a, 0x5A2A33));
        String nick = net.minecraft.client.MinecraftClient.getInstance().getSession().getUsername();
        textC(ctx, textRenderer, Fnt.TINY_B, nick.isEmpty() ? "?" : nick.substring(0, 1).toUpperCase(java.util.Locale.ROOT), x + SIDE / 2f, uy + 18, argb(a, 0xFFFFFF));

        // name of the hovered tab
        if (over >= 0) {
            String n = TABS.get(over).name();
            float w = width(textRenderer, Fnt.SMALL, n) + 24;
            box(ctx, RR, x + SIDE + 6, overY + 7, w, 30, 10, argb(0.96f * a, 0x1A0B11));
            box(ctx, RR_RING, x + SIDE + 6, overY + 7, w, 30, 10, argb(0.35f * a, ACCENT));
            text(ctx, textRenderer, Fnt.SMALL, n, x + SIDE + 18, overY + 22, argb(a, 0xFFFFFF));
        }
    }

    private void tabIcon(DrawContext ctx, String n, float cx, float cy, int col) {
        switch (n) {
            case "Combat" -> {
                centered(ctx, RING, cx, cy, 22, 22, col);
                ctx.fill(Math.round(cx) - 1, Math.round(cy) - 11, Math.round(cx) + 1, Math.round(cy) - 5, col);
                ctx.fill(Math.round(cx) - 1, Math.round(cy) + 5, Math.round(cx) + 1, Math.round(cy) + 11, col);
                ctx.fill(Math.round(cx) - 11, Math.round(cy) - 1, Math.round(cx) - 5, Math.round(cy) + 1, col);
                ctx.fill(Math.round(cx) + 5, Math.round(cy) - 1, Math.round(cx) + 11, Math.round(cy) + 1, col);
            }
            case "Render" -> { centered(ctx, RING, cx, cy, 22, 22, col); centered(ctx, DISC, cx, cy, 8, 8, col); }
            case "Misc" -> {
                for (int i = 0; i < 4; i++) centered(ctx, DISC, cx - 5 + (i % 2) * 10, cy - 5 + (i / 2) * 10, 7, 7, col);
            }
            case "Builders" -> { box(ctx, RR_RING, cx - 9, cy - 9, 18, 18, 4, col); box(ctx, RR, cx - 4, cy - 4, 8, 8, 2, col); }
            case "Themes" -> { centered(ctx, DISC, cx - 3, cy, 16, 16, col); centered(ctx, RING, cx + 4, cy, 14, 14, col); }
            case "Cosmetics" -> {
                centered(ctx, DISC, cx, cy - 6, 8, 8, col);
                centered(ctx, DISC, cx - 6, cy + 5, 8, 8, col);
                centered(ctx, DISC, cx + 6, cy + 5, 8, 8, col);
            }
            default -> centered(ctx, DISC, cx, cy, 10, 10, col);
        }
    }

    private int[] counts() {
        int on = 0, all = 0;
        for (Tab tb : TABS) for (Sec s : tb.secs()) for (Opt o : s.opts())
            if (o.t() == T.TOGGLE) { all++; if (ShrineCfg.bool(o.key(), o.def() > 0.5f)) on++; }
        return new int[]{on, all};
    }

    private List<Sec> searchSecs() {
        String q = query.trim().toLowerCase(java.util.Locale.ROOT);
        List<Opt> found = new ArrayList<>();
        for (Tab tb : TABS) for (Sec s : tb.secs()) for (Opt o : s.opts())
            if (o.label().toLowerCase(java.util.Locale.ROOT).contains(q)) found.add(o);
        return List.of(new Sec("Результаты: " + found.size(), found));
    }

    private String tailFit(String s, float maxW) {
        while (s.length() > 1 && width(textRenderer, Fnt.SMALL, s) > maxW) s = s.substring(1);
        return s;
    }

    private void drawContent(DrawContext ctx, float mx, float my, float a) {
        Tab t = TABS.get(tab);
        float cx = x + SIDE + PAD, cw = W - SIDE - PAD * 2;
        float ta = a * tabAnim;

        // ---- scrolling area (drawn first: the top bar stays above it) ----
        float vt = y + HEAD, vb = y + H - 24, vh = vb - vt;
        rView = new float[]{cx - 8, vt, cw + 16, vh};
        float cur = 0f;
        float oy = vt - scroll + (1f - tabAnim) * 10f;

        if (subId != null) {
            cur = drawSub(ctx, cx, oy, cw, mx, my, ta, vt, vb);
        } else {
            List<Sec> secs = query.isBlank() ? t.secs() : searchSecs();
            if (secs.isEmpty()) {
                textC(ctx, textRenderer, Fnt.LABEL, "Пока здесь пусто", cx + cw / 2f, vt + vh / 2f - 10, argb(0.5f * ta, 0xFFFFFF));
                textC(ctx, textRenderer, Fnt.SMALL, "Функции появятся позже", cx + cw / 2f, vt + vh / 2f + 14, argb(0.3f * ta, 0xFFFFFF));
            }
            float gap = 12f, colW = (cw - gap) / 2f;
            float[] colH = {0f, 0f};
            for (Sec s : secs) {
                float inner = 36f;
                for (Opt o : s.opts()) inner += rowHeight(o, colW - 20f) + ROW_GAP;
                inner += 4f;
                int c = colH[0] <= colH[1] ? 0 : 1;
                float sx = cx + c * (colW + gap), top = oy + colH[c];
                float bt = Math.max(top, vt), bb = Math.min(top + inner, vb);
                if (bb - bt > 6f) {
                    box(ctx, RR, sx, bt, colW, bb - bt, 14, argb(0.42f * ta, 0x000000));
                    box(ctx, RR_RING, sx, bt, colW, bb - bt, 14, argb(0.13f * ta, 0xFFFFFF));
                }
                float fa = edgeFade(top + 17, vt, vb) * ta;
                if (fa > 0.01f) {
                    centered(ctx, DISC, sx + 16, top + 18, 7, 7, argb(fa, ACCENT));
                    text(ctx, textRenderer, Fnt.LABEL, s.title(), sx + 28, top + 18, argb(0.95f * fa, 0xFFFFFF));
                }
                float ry = top + 36f;
                for (Opt o : s.opts()) {
                    float h = rowHeight(o, colW - 20f);
                    float f = edgeFade(ry + h / 2f, vt, vb) * ta;
                    if (f > 0.01f) drawOpt(ctx, o, sx + 10, ry, colW - 20f, h, mx, my, f, vt, vb);
                    ry += h + ROW_GAP;
                }
                colH[c] += inner + 10f;
            }
            cur = Math.max(colH[0], colH[1]);
        }
        contentH = cur;
        float max = Math.max(0f, contentH - vh);
        scrollTarget = Math.max(0f, Math.min(max, scrollTarget));
        if (max > 0f) {
            float th = Math.max(26f, vh * vh / contentH), ty = vt + (vh - th) * (scroll / max);
            box(ctx, RR, x + W - 12, ty, 3, th, 1.5f, argb(0.45f * a, ACCENT));
        }

        // ---- top bar ----
        float by0 = y + 14, bh0 = 34f;
        String cat = subId != null ? subTitle : t.name();
        float pw = width(textRenderer, Fnt.UI_B, cat) + 44;
        box(ctx, RR, cx, by0, pw, bh0, 12, argb(0.20f * a, ACCENT));
        box(ctx, RR_RING, cx, by0, pw, bh0, 12, argb(0.50f * a, ACCENT));
        centered(ctx, DISC, cx + 17, by0 + bh0 / 2f, 8, 8, argb(a, ACCENT));
        text(ctx, textRenderer, Fnt.UI_B, cat, cx + 30, by0 + bh0 / 2f, argb(a, 0xFFFFFF));
        float nx = cx + pw + 8;
        if (subId != null) {
            boolean hb = inside(mx, my, nx, by0, 84, bh0);
            box(ctx, RR, nx, by0, 84, bh0, 12, argb((hb ? 0.26f : 0.12f) * a, 0xFFFFFF));
            textC(ctx, textRenderer, Fnt.SMALL, "‹ Назад", nx + 42, by0 + bh0 / 2f, argb(a, 0xFFFFFF));
            hits.add(new Hit(nx, by0, 84, bh0, null, 100));
            rSearch = new float[4];
        } else {
            int[] cnt = counts();
            String cs = cnt[0] + " / " + cnt[1];
            float cwd = width(textRenderer, Fnt.SMALL, cs) + 36;
            box(ctx, RR, nx, by0, cwd, bh0, 12, argb(0.07f * a, 0xFFFFFF));
            centered(ctx, DISC, nx + 15, by0 + bh0 / 2f, 7, 7, argb(a, 0x5DE08A));
            text(ctx, textRenderer, Fnt.SMALL, cs, nx + 26, by0 + bh0 / 2f, argb(0.85f * a, 0xFFFFFF));
            float sw = 190f, sx = x + W - 56 - sw;
            rSearch = new float[]{sx, by0, sw, bh0};
            box(ctx, RR, sx, by0, sw, bh0, 12, argb((searchFocus ? 0.14f : 0.07f) * a, 0xFFFFFF));
            if (searchFocus) box(ctx, RR_RING, sx, by0, sw, bh0, 12, argb(0.55f * a, ACCENT));
            boolean caret = searchFocus && (Util.getMeasuringTimeMs() / 500L) % 2L == 0L;
            String qs = query.isEmpty() ? "Поиск" : tailFit(query, sw - 30) + (caret ? "|" : "");
            text(ctx, textRenderer, Fnt.SMALL, qs, sx + 14, by0 + bh0 / 2f, argb((query.isEmpty() ? 0.35f : 1f) * a, 0xFFFFFF));
        }
        float bx = x + W - 30, byc = by0 + bh0 / 2f;
        boolean hc = inside(mx, my, bx - 15, byc - 15, 30, 30);
        centered(ctx, DISC, bx, byc, 28, 28, argb((hc ? 0.28f : 0.14f) * a, 0xFFFFFF));
        textC(ctx, textRenderer, Fnt.UI_B, "×", bx, byc - 1, argb(a, 0xFFFFFF));
        rClose = new float[]{bx - 15, byc - 15, 30, 30};

        // ---- footer ----
        text(ctx, textRenderer, Fnt.TINY_B, "Shrine 1.0 · 1.21.11", cx, y + H - 12, argb(0.28f * a, 0xFFFFFF));
        String hint = "ПКМ - настройки функции   ·   Right Shift - закрыть";
        text(ctx, textRenderer, Fnt.TINY_B, hint, x + W - PAD - width(textRenderer, Fnt.TINY_B, hint), y + H - 12, argb(0.28f * a, 0xFFFFFF));
    }

    private float drawSub(DrawContext ctx, float cx, float oy, float cw, float mx, float my, float ta, float vt, float vb) {
        if ("music".equals(subId)) return drawMusic(ctx, cx, oy, cw, mx, my, ta, vt, vb);
        if ("esp".equals(subId)) return drawEsp(ctx, cx, oy, cw, mx, my, ta, vt, vb);
        if ("pred".equals(subId)) return drawPred(ctx, cx, oy, cw, mx, my, ta, vt, vb);
        if ("glint".equals(subId)) return drawGlint(ctx, cx, oy, cw, mx, my, ta, vt, vb);
        if ("viewmodel".equals(subId)) return drawViewModel(ctx, cx, oy, cw, mx, my, ta, vt, vb);
        if ("desktop".equals(subId)) return drawDesktop(ctx, cx, oy, cw, mx, my, ta, vt, vb);
        if ("freelook".equals(subId)) return drawFreeLook(ctx, cx, oy, cw, mx, my, ta, vt, vb);
        float cur = 0f;
        boolean gear = ShrineCfg.bool(TargetHud.KEY_ARMOR, true);

        // row: position
        float h = 46f, ry = oy + cur, f = edgeFade(ry + h / 2f, vt, vb) * ta;
        if (f > 0.01f) {
            boolean hov = inside(mx, my, cx, ry, cw, h) && my > vt && my < vb;
            box(ctx, RR, cx, ry, cw, h, 12, argb((hov ? 0.12f : 0.06f) * f, 0xFFFFFF));
            text(ctx, textRenderer, Fnt.SMALL, "Расположение", cx + 16, ry + 16, argb(f, 0xFFFFFF));
            text(ctx, textRenderer, Fnt.TINY_B, "Перетащить панель и менять размер колёсиком", cx + 16, ry + 33, argb(0.4f * f, 0xFFFFFF));
            textC(ctx, textRenderer, Fnt.UI_B, "›", cx + cw - 20, ry + h / 2f, argb(0.7f * f, 0xFFFFFF));
            hits.add(new Hit(cx, ry, cw, h, null, 101));
        }
        cur += h + ROW_GAP;

        // row: design
        ry = oy + cur; f = edgeFade(ry + h / 2f, vt, vb) * ta;
        if (f > 0.01f) {
            boolean hov = inside(mx, my, cx, ry, cw, h) && my > vt && my < vb;
            box(ctx, RR, cx, ry, cw, h, 12, argb((hov ? 0.12f : 0.06f) * f, 0xFFFFFF));
            text(ctx, textRenderer, Fnt.SMALL, "Дизайн", cx + 16, ry + 16, argb(f, 0xFFFFFF));
            text(ctx, textRenderer, Fnt.TINY_B, "Выбрать вид панели", cx + 16, ry + 33, argb(0.4f * f, 0xFFFFFF));
            String cur2 = TargetHud.DESIGNS[TargetHud.design()];
            text(ctx, textRenderer, Fnt.SMALL, cur2, cx + cw - 44 - width(textRenderer, Fnt.SMALL, cur2), ry + h / 2f, argb(0.7f * f, ACCENT));
            textC(ctx, textRenderer, Fnt.UI_B, designOpen ? "-" : "+", cx + cw - 20, ry + h / 2f, argb(0.7f * f, 0xFFFFFF));
            hits.add(new Hit(cx, ry, cw, h, null, 102));
        }
        cur += h + ROW_GAP;

        if (designOpen) {
            TargetHud.Data demo = TargetHud.demo();
            for (int i = 0; i < TargetHud.DESIGNS.length; i++) {
                float rh = 84f;
                ry = oy + cur; f = edgeFade(ry + rh / 2f, vt, vb) * ta;
                if (f > 0.01f) {
                    boolean sel = i == TargetHud.design();
                    boolean hov = inside(mx, my, cx, ry, cw, rh) && my > vt && my < vb;
                    box(ctx, RR, cx + 12, ry, cw - 12, rh, 12, argb((sel ? 0.18f : hov ? 0.10f : 0.05f) * f, sel ? ACCENT : 0xFFFFFF));
                    if (sel) box(ctx, RR_RING, cx + 12, ry, cw - 12, rh, 12, argb(0.6f * f, ACCENT));
                    float[] sz = TargetHud.size(i, gear);
                    float ps = Math.min(68f / sz[1], 190f / sz[0]);
                    ctx.getMatrices().pushMatrix();
                    ctx.getMatrices().translate(cx + 26, ry + (rh - sz[1] * ps) / 2f);
                    ctx.getMatrices().scale(ps, ps);
                    TargetHud.panel(ctx, textRenderer, i, gear, demo, f);
                    ctx.getMatrices().popMatrix();
                    text(ctx, textRenderer, Fnt.UI_B, TargetHud.DESIGNS[i], cx + 240, ry + rh / 2f, argb(f, 0xFFFFFF));
                    centered(ctx, RING, cx + cw - 26, ry + rh / 2f, 16, 16, argb((sel ? 1f : 0.4f) * f, sel ? 0xFFFFFF : 0xE6C4C4));
                    if (sel) centered(ctx, DISC, cx + cw - 26, ry + rh / 2f, 8, 8, argb(f, ACCENT));
                    hits.add(new Hit(cx + 12, ry, cw - 12, rh, null, 110 + i));
                }
                cur += rh + ROW_GAP;
            }
        }
        return cur + 10f;
    }

    private float drawPred(DrawContext ctx, float cx, float oy, float cw, float mx, float my, float ta, float vt, float vb) {
        float cur = 0f;
        float tSec = Util.getMeasuringTimeMs() / 1000f;

        // live preview: dashed trajectory, landing marker and timer card
        float ph = 176f, ry = oy + cur, f = edgeFade(ry + ph / 2f, vt, vb) * ta;
        if (f > 0.01f) {
            box(ctx, RR, cx, ry, cw, ph, 14, argb(0.40f * f, 0x000000));
            box(ctx, RR_RING, cx, ry, cw, ph, 14, argb(0.10f * f, 0xFFFFFF));
            Predictions.preview(ctx, textRenderer, cx, ry, cw, ph, f, tSec);
        }
        cur += ph + ROW_GAP + 6f;

        ry = oy + cur; f = edgeFade(ry + 14, vt, vb) * ta;
        if (f > 0.01f) {
            box(ctx, RR, cx, ry + 3, 3, 14, 1.5f, argb(f, ACCENT));
            text(ctx, textRenderer, Fnt.LABEL, "Что показывать", cx + 12, ry + 10, argb(0.9f * f, 0xFFFFFF));
        }
        cur += 26f;

        Opt[] opts = {
            toggle(Predictions.K_PEARL, "Эндер-пёрл", true),
            toggle(Predictions.K_SNOW, "Снежок и яйцо", true),
            toggle(Predictions.K_POTION, "Зелья и пузырьки опыта", true),
            toggle(Predictions.K_ARROW, "Лук, арбалет, трезубец", true),
            toggle(Predictions.K_OTHERS, "Чужие снаряды", true),
            toggle(Predictions.K_LINE, "Линия траектории", true),
            toggle(Predictions.K_TIME, "Время до падения", true),
            color(Predictions.K_COLOR, "Цвет", 0)
        };
        for (Opt o : opts) {
            float h = rowHeight(o, cw);
            ry = oy + cur; f = edgeFade(ry + h / 2f, vt, vb) * ta;
            if (f > 0.01f) drawOpt(ctx, o, cx, ry, cw, h, mx, my, f, vt, vb);
            cur += h + ROW_GAP;
        }
        return cur + 10f;
    }

    private float drawEsp(DrawContext ctx, float cx, float oy, float cw, float mx, float my, float ta, float vt, float vb) {
        float cur = 0f;
        float tSec = Util.getMeasuringTimeMs() / 1000f;

        // live preview of the chosen effect on a ghost model
        float ph = 164f, ry = oy + cur, f = edgeFade(ry + ph / 2f, vt, vb) * ta;
        if (f > 0.01f) {
            box(ctx, RR, cx, ry, cw, ph, 14, argb(0.40f * f, 0x000000));
            box(ctx, RR_RING, cx, ry, cw, ph, 14, argb(0.10f * f, 0xFFFFFF));
            final float bx = cx + cw / 2f, by = ry + ph - 18f, ppm = 62f;
            TargetEsp.Proj pr = (dx, dy, dz, o) -> {
                o[0] = bx + (float) dx * ppm;
                o[1] = by - (float) dy * ppm + (float) dz * ppm * 0.30f;
                o[2] = ppm;
                return true;
            };
            TargetEsp.Body body = new TargetEsp.Body(1.8f, 0.6f, tSec * 0.6f, true);
            ctx.fill(Math.round(cx + 4), Math.round(by + 1), Math.round(cx + cw - 4), Math.round(by + 2), argb(0.10f * f, 0xFFFFFF));
            TargetEsp.scene(ctx, textRenderer, pr, body, TargetEsp.fx(), ShrineCfg.bool(TargetEsp.K_GHOST, true),
                    ShrineCfg.bool(TargetEsp.K_DIST, true), 3.40f, TargetEsp.color(), f, tSec);
        }
        cur += ph + ROW_GAP;

        // toggles + color
        Opt[] opts = {
            toggle(TargetEsp.K_GHOST, "Призрачная модель", true),
            toggle(TargetEsp.K_DIST, "Число дистанции", true),
            color(TargetEsp.K_COLOR, "Цвет", 6)
        };
        for (Opt o : opts) {
            float h = rowHeight(o, cw);
            ry = oy + cur; f = edgeFade(ry + h / 2f, vt, vb) * ta;
            if (f > 0.01f) drawOpt(ctx, o, cx, ry, cw, h, mx, my, f, vt, vb);
            cur += h + ROW_GAP;
        }
        cur += 8f;

        // list of effects
        ry = oy + cur; f = edgeFade(ry + 14, vt, vb) * ta;
        if (f > 0.01f) {
            box(ctx, RR, cx, ry + 3, 3, 14, 1.5f, argb(f, ACCENT));
            text(ctx, textRenderer, Fnt.LABEL, "Эффект", cx + 12, ry + 10, argb(0.9f * f, 0xFFFFFF));
        }
        cur += 30f;
        for (int i = 0; i < TargetEsp.FX.length; i++) {
            float rh = 46f;
            ry = oy + cur; f = edgeFade(ry + rh / 2f, vt, vb) * ta;
            if (f > 0.01f) {
                boolean sel = i == TargetEsp.fx();
                boolean hov = inside(mx, my, cx, ry, cw, rh) && my > vt && my < vb;
                box(ctx, RR, cx, ry, cw, rh, 12, argb((sel ? 0.18f : hov ? 0.11f : 0.06f) * f, sel ? ACCENT : 0xFFFFFF));
                if (sel) box(ctx, RR_RING, cx, ry, cw, rh, 12, argb(0.55f * f, ACCENT));
                text(ctx, textRenderer, Fnt.SMALL, TargetEsp.FX[i], cx + 16, ry + 16, argb(f, 0xFFFFFF));
                text(ctx, textRenderer, Fnt.TINY_B, TargetEsp.FX_DESC[i], cx + 16, ry + 33, argb(0.4f * f, 0xFFFFFF));
                centered(ctx, RING, cx + cw - 26, ry + rh / 2f, 16, 16, argb((sel ? 1f : 0.4f) * f, sel ? 0xFFFFFF : 0xE6C4C4));
                if (sel) centered(ctx, DISC, cx + cw - 26, ry + rh / 2f, 8, 8, argb(f, ACCENT));
                hits.add(new Hit(cx, ry, cw, rh, null, 1000 + i));
            }
            cur += rh + ROW_GAP;
        }
        return cur + 10f;
    }

    /** A full-width action button on a settings page. */
    private float drawActionButton(DrawContext ctx, String label, int id, float cx, float ry, float cw, float mx, float my, float f, float vt, float vb) {
        float h = 34f;
        if (f > 0.01f) {
            boolean hov = inside(mx, my, cx, ry, cw, h) && my > vt && my < vb;
            box(ctx, RR, cx, ry, cw, h, 12, argb((hov ? 0.14f : 0.07f) * f, 0xFFFFFF));
            textC(ctx, textRenderer, Fnt.SMALL, label, cx + cw / 2f, ry + h / 2f, argb(f, 0xFFFFFF));
            hits.add(new Hit(cx, ry, cw, h, null, id));
        }
        return h;
    }

    private float drawViewModel(DrawContext ctx, float cx, float oy, float cw, float mx, float my, float ta, float vt, float vb) {
        float cur = 0f;
        float ph = 112f, ry = oy + cur, f = edgeFade(ry + ph / 2f, vt, vb) * ta;
        if (f > 0.01f) {
            box(ctx, RR, cx, ry, cw, ph, 14, argb(0.40f * f, 0x000000));
            box(ctx, RR_RING, cx, ry, cw, ph, 14, argb(0.10f * f, 0xFFFFFF));
            boolean on = ViewModelFx.enabled();
            String st = on ? "Включён" : "Выключен";
            text(ctx, textRenderer, Fnt.UI_B, "ViewModel", cx + 16, ry + 22, argb(f, 0xFFFFFF));
            text(ctx, textRenderer, Fnt.SMALL, st, cx + cw - 16 - width(textRenderer, Fnt.SMALL, st), ry + 22,
                    argb((on ? 1f : 0.5f) * f, on ? ACCENT : 0xFFFFFF));
            text(ctx, textRenderer, Fnt.TINY_B, "Откройте чат: двойной клик по предмету в руке, потом тяните мышью", cx + 16, ry + 50, argb(0.55f * f, 0xFFFFFF));
            text(ctx, textRenderer, Fnt.TINY_B, "Колёсико - размер, Shift + колёсико - ближе / дальше", cx + 16, ry + 70, argb(0.55f * f, 0xFFFFFF));
            text(ctx, textRenderer, Fnt.TINY_B, "Команда .viewmodel reset в чате сбрасывает обе руки", cx + 16, ry + 90, argb(0.55f * f, 0xFFFFFF));
        }
        cur += ph + ROW_GAP + 6f;

        boolean right = ShrineCfg.integer(ViewModelFx.K_PAGE, 0) == 0;
        Opt[] opts = {
            choice(ViewModelFx.K_PAGE, "Рука для настройки", 0, "Правая", "Левая"),
            slider(ViewModelFx.key(right, "x"), "Влево / вправо", -150f, 150f, 0f, ""),
            slider(ViewModelFx.key(right, "y"), "Вниз / вверх", -150f, 150f, 0f, ""),
            slider(ViewModelFx.key(right, "z"), "Ближе / дальше", -150f, 150f, 0f, ""),
            slider(ViewModelFx.key(right, "s"), "Размер", 20f, 300f, 100f, "%"),
            slider(ViewModelFx.key(right, "rx"), "Наклон вперёд / назад", -180f, 180f, 0f, "°"),
            slider(ViewModelFx.key(right, "ry"), "Поворот влево / вправо", -180f, 180f, 0f, "°"),
            slider(ViewModelFx.key(right, "rz"), "Вращение", -180f, 180f, 0f, "°")
        };
        for (Opt o : opts) {
            float h = rowHeight(o, cw);
            ry = oy + cur; f = edgeFade(ry + h / 2f, vt, vb) * ta;
            if (f > 0.01f) drawOpt(ctx, o, cx, ry, cw, h, mx, my, f, vt, vb);
            cur += h + ROW_GAP;
        }
        ry = oy + cur; f = edgeFade(ry + 17f, vt, vb) * ta;
        cur += drawActionButton(ctx, "Сбросить обе руки", 124, cx, ry, cw, mx, my, f, vt, vb) + ROW_GAP;
        return cur + 10f;
    }

    private float drawDesktop(DrawContext ctx, float cx, float oy, float cw, float mx, float my, float ta, float vt, float vb) {
        float cur = 0f;
        float ph = 84f, ry = oy + cur, f = edgeFade(ry + ph / 2f, vt, vb) * ta;
        if (f > 0.01f) {
            box(ctx, RR, cx, ry, cw, ph, 14, argb(0.40f * f, 0x000000));
            box(ctx, RR_RING, cx, ry, cw, ph, 14, argb(0.10f * f, 0xFFFFFF));
            boolean on = ShrineCfg.bool(DesktopScreen.KEY, false);
            String st = on ? "Включён" : "Выключен";
            text(ctx, textRenderer, Fnt.UI_B, "Рабочий стол", cx + 16, ry + 22, argb(f, 0xFFFFFF));
            text(ctx, textRenderer, Fnt.SMALL, st, cx + cw - 16 - width(textRenderer, Fnt.SMALL, st), ry + 22,
                    argb((on ? 1f : 0.5f) * f, on ? ACCENT : 0xFFFFFF));
            text(ctx, textRenderer, Fnt.SMALL, "Клавиша: " + DesktopScreen.keyName(), cx + 16, ry + 50, argb(0.9f * f, ACCENT));
            text(ctx, textRenderer, Fnt.TINY_B, "Приложения, док и окна. Клавишу можно сменить в Управлении", cx + 16, ry + 68, argb(0.5f * f, 0xFFFFFF));
        }
        cur += ph + ROW_GAP + 6f;
        ry = oy + cur; f = edgeFade(ry + 17f, vt, vb) * ta;
        cur += drawActionButton(ctx, "Открыть рабочий стол", 126, cx, ry, cw, mx, my, f, vt, vb) + ROW_GAP;
        Opt o3 = toggle(DesktopScreen.K_3D, "Парящий 3D экран", true);
        float h3 = rowHeight(o3, cw);
        ry = oy + cur; f = edgeFade(ry + h3 / 2f, vt, vb) * ta;
        if (f > 0.01f) drawOpt(ctx, o3, cx, ry, cw, h3, mx, my, f, vt, vb);
        cur += h3 + ROW_GAP;
        String[] lines = {"Google, Discord, YouTube, Twitch, Spotify, Telegram", "открываются в браузере (ссылка копируется).",
                "Заметки, Музыка, Проводник, Монитор, Калькулятор, Часы", "и Настройки работают внутри окна."};
        for (String l : lines) {
            ry = oy + cur; f = edgeFade(ry + 9f, vt, vb) * ta;
            if (f > 0.01f) text(ctx, textRenderer, Fnt.SMALL, l, cx + 6, ry + 9, argb(0.55f * f, 0xFFFFFF));
            cur += 20f;
        }
        return cur + 10f;
    }

    private float drawFreeLook(DrawContext ctx, float cx, float oy, float cw, float mx, float my, float ta, float vt, float vb) {
        float cur = 0f;
        float ph = 84f, ry = oy + cur, f = edgeFade(ry + ph / 2f, vt, vb) * ta;
        if (f > 0.01f) {
            box(ctx, RR, cx, ry, cw, ph, 14, argb(0.40f * f, 0x000000));
            box(ctx, RR_RING, cx, ry, cw, ph, 14, argb(0.10f * f, 0xFFFFFF));
            boolean on = FreeLookFx.enabled();
            String st = on ? "Включён" : "Выключен";
            text(ctx, textRenderer, Fnt.UI_B, "FreeLook", cx + 16, ry + 22, argb(f, 0xFFFFFF));
            text(ctx, textRenderer, Fnt.SMALL, st, cx + cw - 16 - width(textRenderer, Fnt.SMALL, st), ry + 22,
                    argb((on ? 1f : 0.5f) * f, on ? ACCENT : 0xFFFFFF));
            text(ctx, textRenderer, Fnt.SMALL, "Клавиша: " + FreeLookFx.keyName(), cx + 16, ry + 50, argb(0.9f * f, ACCENT));
            text(ctx, textRenderer, Fnt.TINY_B, "Свободная камера вокруг игрока. Клавишу можно сменить в Управлении", cx + 16, ry + 68, argb(0.5f * f, 0xFFFFFF));
        }
        cur += ph + ROW_GAP + 6f;

        Opt[] opts = {
            choice(FreeLookFx.K_MODE, "Режим", 0, "Удержание", "Переключение"),
            choice(FreeLookFx.K_VIEW, "Вид", 0, "Сзади", "Спереди", "Из глаз"),
            slider(FreeLookFx.K_DIST, "Дистанция", 1f, 12f, 4f, ""),
            slider(FreeLookFx.K_SMOOTH, "Плавность", 0f, 100f, 51f, ""),
            slider(FreeLookFx.K_RETURN, "Скорость возврата", 1f, 100f, 45f, ""),
            slider(FreeLookFx.K_FLY, "Скорость вылета", 1f, 100f, 89f, ""),
            toggle(FreeLookFx.K_SCROLL, "Колесо мыши меняет дистанцию", true),
            toggle(FreeLookFx.K_INVERT, "Инвертировать наклон", false),
            toggle(FreeLookFx.K_PUSH, "Камера сквозь блоки", false)
        };
        for (Opt o : opts) {
            float h = rowHeight(o, cw);
            ry = oy + cur; f = edgeFade(ry + h / 2f, vt, vb) * ta;
            if (f > 0.01f) drawOpt(ctx, o, cx, ry, cw, h, mx, my, f, vt, vb);
            cur += h + ROW_GAP;
        }
        ry = oy + cur; f = edgeFade(ry + 17f, vt, vb) * ta;
        cur += drawActionButton(ctx, "Сбросить настройки", 125, cx, ry, cw, mx, my, f, vt, vb) + ROW_GAP;
        return cur + 10f;
    }

    private float drawGlint(DrawContext ctx, float cx, float oy, float cw, float mx, float my, float ta, float vt, float vb) {
        float cur = 0f;

        // live preview: the shimmer pattern as it will be drawn on armor
        float ph = 150f, ry = oy + cur, f = edgeFade(ry + ph / 2f, vt, vb) * ta;
        if (f > 0.01f) {
            box(ctx, RR, cx, ry, cw, ph, 14, argb(0.40f * f, 0x000000));
            box(ctx, RR_RING, cx, ry, cw, ph, 14, argb(0.10f * f, 0xFFFFFF));
            float s = ph - 24f;
            box(ctx, RR, cx + 12, ry + 12, s, s, 10, argb(0.5f * f, 0x1A0A10));
            if (EnchantGlintFx.ready()) blit(ctx, EnchantGlintFx.PREVIEW, Math.round(cx + 12), Math.round(ry + 12),
                    Math.round(s), Math.round(s), argb(f, 0xFFFFFF));
            float tx = cx + s + 36f;
            text(ctx, textRenderer, Fnt.UI_B, EnchantGlintFx.STYLES[EnchantGlintFx.style()], tx, ry + 52f, argb(f, 0xFFFFFF));
            text(ctx, textRenderer, Fnt.SMALL, "Перелив на броне и предметах", tx, ry + 76f, argb(0.5f * f, 0xFFFFFF));
            boolean on = EnchantGlintFx.enabled();
            text(ctx, textRenderer, Fnt.SMALL, on ? "Включён" : "Выключен", tx, ry + 104f,
                    argb((on ? 1f : 0.5f) * f, on ? ACCENT : 0xFFFFFF));
        }
        cur += ph + ROW_GAP + 6f;

        Opt[] opts = {
            choice(EnchantGlintFx.K_STYLE, "Стиль", 0, EnchantGlintFx.STYLES),
            color(EnchantGlintFx.K_COLOR, "Цвет", 5),
            color(EnchantGlintFx.K_COLOR2, "Второй цвет (для «Два цвета»)", 4),
            slider(EnchantGlintFx.K_SPEED, "Скорость", 0.2f, 3f, 1f, ""),
            choice(EnchantGlintFx.K_DENSITY, "Плотность", 1, "Частая", "Средняя", "Редкая")
        };
        for (Opt o : opts) {
            float h = rowHeight(o, cw);
            ry = oy + cur; f = edgeFade(ry + h / 2f, vt, vb) * ta;
            if (f > 0.01f) drawOpt(ctx, o, cx, ry, cw, h, mx, my, f, vt, vb);
            cur += h + ROW_GAP;
        }
        return cur + 10f;
    }

    private float drawMusic(DrawContext ctx, float cx, float oy, float cw, float mx, float my, float ta, float vt, float vb) {
        float cur = 0f;
        // position row
        float h = 46f, ry = oy + cur, f = edgeFade(ry + h / 2f, vt, vb) * ta;
        if (f > 0.01f) {
            boolean hov = inside(mx, my, cx, ry, cw, h) && my > vt && my < vb;
            box(ctx, RR, cx, ry, cw, h, 12, argb((hov ? 0.12f : 0.06f) * f, 0xFFFFFF));
            text(ctx, textRenderer, Fnt.SMALL, "Расположение", cx + 16, ry + 16, argb(f, 0xFFFFFF));
            text(ctx, textRenderer, Fnt.TINY_B, "Перетащить карточку и менять размер колёсиком", cx + 16, ry + 33, argb(0.4f * f, 0xFFFFFF));
            textC(ctx, textRenderer, Fnt.UI_B, "›", cx + cw - 20, ry + h / 2f, argb(0.7f * f, 0xFFFFFF));
            hits.add(new Hit(cx, ry, cw, h, null, 101));
        }
        cur += h + ROW_GAP;

        // the player card itself: its buttons work here
        float ph = MusicHud.H + 8f;
        ry = oy + cur; f = edgeFade(ry + ph / 2f, vt, vb) * ta;
        if (f > 0.01f) {
            float px = cx, py = ry + 4f;
            MusicHud.panel(ctx, textRenderer, MusicHud.live(), f, (float) mx - px, (float) my - py);
            for (int i = 0; i < 3; i++) {
                float[] r = MusicHud.ctrl(i);
                hits.add(new Hit(px + r[0], py + r[1], r[2], r[3], null, 120 + i));
            }
        }
        cur += ph + ROW_GAP;

        // volume
        Opt vol = slider("music.volume", "Громкость", 0f, 1f, 0.8f, "");
        float vh = rowHeight(vol, cw);
        ry = oy + cur; f = edgeFade(ry + vh / 2f, vt, vb) * ta;
        if (f > 0.01f) drawOpt(ctx, vol, cx, ry, cw, vh, mx, my, f, vt, vb);
        cur += vh + ROW_GAP + 8f;

        // lyrics settings (World Lyrics + capsule)
        ry = oy + cur; f = edgeFade(ry + 14, vt, vb) * ta;
        if (f > 0.01f) {
            box(ctx, RR, cx, ry + 3, 3, 14, 1.5f, argb(f, ACCENT));
            text(ctx, textRenderer, Fnt.LABEL, "Тексты песен", cx + 12, ry + 10, argb(0.9f * f, 0xFFFFFF));
        }
        cur += 26f;
        ry = oy + cur; f = edgeFade(ry + 8, vt, vb) * ta;
        if (f > 0.01f) text(ctx, textRenderer, Fnt.TINY_B, MusicPlayer.lyricsStatus(), cx + 4, ry + 8, argb(0.55f * f, 0xFFFFFF));
        cur += 20f;
        ry = oy + cur; f = edgeFade(ry + 8, vt, vb) * ta;
        if (f > 0.01f) text(ctx, textRenderer, Fnt.TINY_B, "Нужен файл .lrc с тем же именем, что и mp3 (рядом с ним)", cx + 4, ry + 8, argb(0.4f * f, 0xFFFFFF));
        cur += 22f;
        Opt[] lyr = {
            toggle(LyricsFx.K_WORLD, "Текст в мире", true),
            toggle(LyricsFx.K_PILL, "Текст в плашке сверху", true),
            toggle(LyricsFx.K_NET, "Искать текст в интернете (lrclib.net)", false),
            slider(LyricsFx.K_DIST, "Дистанция", 3f, 20f, 9f, ""),
            slider(LyricsFx.K_SIZE, "Размер", 0.5f, 3f, 1f, ""),
            slider(LyricsFx.K_SCATTER, "Разброс", 0f, 1f, 0.7f, ""),
            slider(LyricsFx.K_SYNC, "Сдвиг синхронизации", -1500f, 1500f, 0f, " мс"),
            toggle(LyricsFx.K_SIDE, "По бокам (центр свободен)", false),
            toggle(LyricsFx.K_GLOW, "Свечение", true),
            slider(LyricsFx.K_GLOWK, "Сила свечения", 0f, 1f, 0.9f, ""),
            toggle(LyricsFx.K_SHADOW, "Тень", true)
        };
        for (Opt lo : lyr) {
            float lh = rowHeight(lo, cw);
            ry = oy + cur; f = edgeFade(ry + lh / 2f, vt, vb) * ta;
            if (f > 0.01f) drawOpt(ctx, lo, cx, ry, cw, lh, mx, my, f, vt, vb);
            cur += lh + ROW_GAP;
        }
        cur += 8f;

        // list header
        ry = oy + cur; f = edgeFade(ry + 14, vt, vb) * ta;
        if (f > 0.01f) {
            box(ctx, RR, cx, ry + 3, 3, 14, 1.5f, argb(f, ACCENT));
            text(ctx, textRenderer, Fnt.LABEL, "Песни (" + MusicPlayer.tracks.size() + ")", cx + 12, ry + 10, argb(0.9f * f, 0xFFFFFF));
            float bw = 96f, bx = cx + cw - bw;
            boolean hov = inside(mx, my, bx, ry, bw, 24) && my > vt && my < vb;
            box(ctx, RR, bx, ry, bw, 24, 12, argb((hov ? 0.22f : 0.12f) * f, 0xFFFFFF));
            textC(ctx, textRenderer, Fnt.SMALL, "Обновить", bx + bw / 2f, ry + 12, argb(f, 0xFFFFFF));
            hits.add(new Hit(bx, ry, bw, 24, null, 123));
        }
        cur += 30f;
        ry = oy + cur; f = edgeFade(ry + 8, vt, vb) * ta;
        if (f > 0.01f) text(ctx, textRenderer, Fnt.TINY_B, "Папка в папке игры: «музыка св» (или shrine_music), файлы .mp3", cx + 4, ry + 8, argb(0.4f * f, 0xFFFFFF));
        cur += 22f;

        if (MusicPlayer.tracks.isEmpty()) {
            ry = oy + cur; f = edgeFade(ry + 20, vt, vb) * ta;
            if (f > 0.01f) textC(ctx, textRenderer, Fnt.SMALL, "Пока пусто: положи mp3 в папку и нажми «Обновить»", cx + cw / 2f, ry + 20, argb(0.5f * f, 0xFFFFFF));
            cur += 50f;
        }
        for (int i = 0; i < MusicPlayer.tracks.size(); i++) {
            MusicPlayer.Track t = MusicPlayer.tracks.get(i);
            float rh = 46f;
            ry = oy + cur; f = edgeFade(ry + rh / 2f, vt, vb) * ta;
            if (f > 0.01f) {
                boolean cur2 = i == MusicPlayer.current;
                boolean hov = inside(mx, my, cx, ry, cw, rh) && my > vt && my < vb;
                box(ctx, RR, cx, ry, cw, rh, 12, argb((cur2 ? 0.18f : hov ? 0.11f : 0.06f) * f, cur2 ? ACCENT : 0xFFFFFF));
                if (cur2) box(ctx, RR_RING, cx, ry, cw, rh, 12, argb(0.55f * f, ACCENT));
                String title = t.title.length() > 40 ? t.title.substring(0, 39) + "…" : t.title;
                text(ctx, textRenderer, Fnt.SMALL, title, cx + 16, ry + (t.artist.isEmpty() ? rh / 2f : 16), argb(f, 0xFFFFFF));
                if (!t.artist.isEmpty()) text(ctx, textRenderer, Fnt.TINY_B, t.artist, cx + 16, ry + 33, argb(0.5f * f, 0xFFFFFF));
                if (cur2) text(ctx, textRenderer, Fnt.TINY_B, MusicPlayer.paused ? "пауза" : "играет", cx + cw - 16 - width(textRenderer, Fnt.TINY_B, MusicPlayer.paused ? "пауза" : "играет"), ry + rh / 2f, argb(0.9f * f, ACCENT));
                hits.add(new Hit(cx, ry, cw, rh, null, 130 + i));
            }
            cur += rh + ROW_GAP;
        }
        return cur + 10f;
    }

    private static float edgeFade(float center, float top, float bottom) {
        float e = Math.min(center - top, bottom - center);
        return Math.max(0f, Math.min(1f, e / 24f));
    }

    private float rowHeight(Opt o, float cw) {
        switch (o.t()) {
            case TOGGLE: return 34f;
            case SLIDER: return 52f;
            case COLOR: return 38f;
            default: {
                int rows = chipRows(o, cw - 28f);
                return 34f + rows * 30f;
            }
        }
    }

    private int chipRows(Opt o, float maxW) {
        float cx = 0f;
        int rows = 1;
        for (String s : o.items()) {
            float w = width(textRenderer, Fnt.SMALL, s) + 36f;
            if (cx + w > maxW && cx > 0f) { rows++; cx = 0f; }
            cx += w + 8f;
        }
        return rows;
    }

    private void drawOpt(DrawContext ctx, Opt o, float cx, float ry, float cw, float h, float mx, float my, float f, float vt, float vb) {
        boolean hov = inside(mx, my, cx, ry, cw, h) && my > vt && my < vb;
        box(ctx, RR, cx, ry, cw, h, 12, argb((hov ? 0.10f : 0.06f) * f, 0xFFFFFF));
        switch (o.t()) {
            case TOGGLE -> {
                boolean on = ShrineCfg.bool(o.key(), o.def() > 0.5f);
                text(ctx, textRenderer, Fnt.SMALL, o.label(), cx + 16, ry + h / 2f, argb(f, 0xFFFFFF));
                float sx = cx + cw - 52, sy = ry + h / 2f - 9;
                if (o.sub() != null) text(ctx, textRenderer, Fnt.TINY_B, "ПКМ - настройки", sx - 14 - width(textRenderer, Fnt.TINY_B, "ПКМ - настройки"), ry + h / 2f, argb(0.35f * f, 0xFFFFFF));
                box(ctx, RR, sx, sy, 36, 18, 9, argb((on ? 0.95f : 0.18f) * f, on ? ACCENT : 0xFFFFFF));
                centered(ctx, DISC, on ? sx + 27 : sx + 9, sy + 9, 12, 12, argb(f, 0xFFFFFF));
                hits.add(new Hit(cx, ry, cw, h, o, 0));
            }
            case SLIDER -> {
                float v = ShrineCfg.num(o.key(), o.def());
                v = Math.max(o.min(), Math.min(o.max(), v));
                String val = (Math.abs(o.max() - o.min()) > 20f ? String.valueOf(Math.round(v)) : String.format("%.1f", v)) + o.unit();
                text(ctx, textRenderer, Fnt.SMALL, o.label(), cx + 16, ry + 16, argb(f, 0xFFFFFF));
                text(ctx, textRenderer, Fnt.SMALL, val, cx + cw - 16 - width(textRenderer, Fnt.SMALL, val), ry + 16, argb(0.7f * f, 0xFFFFFF));
                float sx = cx + 16, sw = cw - 32, sy = ry + 36;
                float p = (v - o.min()) / (o.max() - o.min());
                box(ctx, RR, sx, sy - 2, sw, 4, 2, argb(0.16f * f, 0xFFFFFF));
                box(ctx, RR, sx, sy - 2, Math.max(4f, sw * p), 4, 2, argb(f, ACCENT));
                centered(ctx, GLOW, sx + sw * p, sy, 28, 28, argb(0.5f * f, ACCENT));
                centered(ctx, DISC, sx + sw * p, sy, 13, 13, argb(f, 0xFFFFFF));
                hits.add(new Hit(sx - 6, ry + 22, sw + 12, 28, o, 0));
            }
            case COLOR -> {
                int idx = Math.max(0, Math.min(PALETTE.length - 1, ShrineCfg.integer(o.key(), (int) o.def())));
                int c = PALETTE[idx];
                text(ctx, textRenderer, Fnt.SMALL, o.label(), cx + 16, ry + h / 2f, argb(f, 0xFFFFFF));
                String hex = String.format("#%06X", c);
                float sx = cx + cw - 52;
                text(ctx, textRenderer, Fnt.TINY_B, hex, sx - 14 - width(textRenderer, Fnt.TINY_B, hex), ry + h / 2f, argb(0.45f * f, 0xFFFFFF));
                box(ctx, RR, sx, ry + h / 2f - 11, 36, 22, 8, argb(f, c));
                box(ctx, RR_RING, sx, ry + h / 2f - 11, 36, 22, 8, argb(0.4f * f, 0xFFFFFF));
                hits.add(new Hit(cx, ry, cw, h, o, 0));
            }
            case CHOICE -> {
                text(ctx, textRenderer, Fnt.SMALL, o.label(), cx + 16, ry + 18, argb(0.7f * f, 0xFFFFFF));
                int sel = ShrineCfg.integer(o.key(), (int) o.def());
                float px = cx + 14, py = ry + 34, maxW = cw - 28f;
                float lx = px;
                for (int i = 0; i < o.items().length; i++) {
                    String s = o.items()[i];
                    float w = width(textRenderer, Fnt.SMALL, s) + 36f;
                    if (lx - px + w > maxW && lx > px) { lx = px; py += 30f; }
                    boolean on = i == sel, hv = inside(mx, my, lx, py, w, 24) && my > vt && my < vb;
                    box(ctx, RR, lx, py, w, 24, 12, argb((on ? 0.30f : hv ? 0.14f : 0.08f) * f, on ? ACCENT : 0xFFFFFF));
                    if (on) box(ctx, RR_RING, lx, py, w, 24, 12, argb(0.6f * f, ACCENT));
                    centered(ctx, RING, lx + 14, py + 12, 9, 9, argb((on ? 1f : 0.4f) * f, on ? 0xFFFFFF : 0xE6C4C4));
                    if (on) centered(ctx, DISC, lx + 14, py + 12, 4, 4, argb(f, 0xFFFFFF));
                    text(ctx, textRenderer, Fnt.SMALL, s, lx + 26, py + 12, argb((on ? 1f : 0.7f) * f, 0xFFFFFF));
                    hits.add(new Hit(lx, py, w, 24, o, i));
                    lx += w + 8f;
                }
            }
        }
    }

    // ---------- input ----------
    private double toV(double v) { return v / k; }

    private void setSlider(Opt o, double mx) {
        float p = (float) Math.max(0, Math.min(1, (mx - dragX) / dragW));
        float v = o.min() + p * (o.max() - o.min());
        float step = Math.abs(o.max() - o.min()) > 20f ? 1f : 0.1f;
        v = Math.round(v / step) * step;
        ShrineCfg.setNum(o.key(), v);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = toV(click.x()), my = toV(click.y());
        if (click.button() == 1) {                       // right click on a function: open its settings
            if (subId != null) return true;
            boolean inV = inside(mx, my, rView[0], rView[1], rView[2], rView[3]);
            for (Hit h : hits) {
                if (h.opt != null && h.opt.sub() != null && inV && inside(mx, my, h.x, h.y, h.w, h.h)) {
                    subId = h.opt.sub(); subTitle = h.opt.label(); if ("music".equals(subId)) MusicPlayer.rescan(); scroll = scrollTarget = 0f; tabAnim = 0f; return true;
                }
            }
            return true;
        }
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        searchFocus = rSearch[2] > 0f && inside(mx, my, rSearch[0], rSearch[1], rSearch[2], rSearch[3]);
        if (searchFocus) return true;
        if (inside(mx, my, rClose[0], rClose[1], rClose[2], rClose[3])) { close(); return true; }
        boolean inView = inside(mx, my, rView[0], rView[1], rView[2], rView[3]);
        for (Hit h : hits) {
            if (!inside(mx, my, h.x, h.y, h.w, h.h)) continue;
            if (h.opt == null) {
                if (h.idx == 100) { subId = null; designOpen = false; scroll = scrollTarget = 0f; tabAnim = 0f; return true; }
                if (h.idx >= 101) {
                    if (!inView) continue;
                    int id = h.idx;
                    if (id == 101) { if (client != null) client.setScreen(new HudEditScreen(this, "music".equals(subId))); }
                    else if (id == 102) designOpen = !designOpen;
                    else if (id >= 110 && id < 120) { ShrineCfg.setInt(TargetHud.K_DESIGN, id - 110); ShrineCfg.save(); }
                    else if (id >= 1000) { ShrineCfg.setInt(TargetEsp.K_FX, id - 1000); ShrineCfg.save(); }
                    else if (id == 120) MusicPlayer.prev();
                    else if (id == 121) MusicPlayer.toggle();
                    else if (id == 122) MusicPlayer.next();
                    else if (id == 123) MusicPlayer.rescan();
                    else if (id == 124) ViewModelFx.reset();
                    else if (id == 125) FreeLookFx.reset();
                    else if (id == 126) { if (client != null) client.setScreen(new DesktopScreen(this)); }
                    else if (id >= 130) MusicPlayer.play(id - 130);
                    return true;
                }
                if (tab != h.idx || !query.isEmpty()) { tab = h.idx; query = ""; subId = null; designOpen = false; scroll = scrollTarget = 0f; tabAnim = 0f; }
                return true;
            }
            if (!inView) continue;
            Opt o = h.opt;
            switch (o.t()) {
                case TOGGLE -> ShrineCfg.setBool(o.key(), !ShrineCfg.bool(o.key(), o.def() > 0.5f));
                case CHOICE -> ShrineCfg.setInt(o.key(), h.idx);
                case COLOR -> ShrineCfg.setInt(o.key(), (ShrineCfg.integer(o.key(), (int) o.def()) + 1) % PALETTE.length);
                case SLIDER -> { dragging = o; dragX = h.x + 6; dragW = h.w - 12; setSlider(o, mx); }
            }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (dragging != null) { setSlider(dragging, toV(click.x())); return true; }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (dragging != null) { dragging = null; ShrineCfg.save(); return true; }
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scrollTarget -= (float) verticalAmount * 46f;
        float max = Math.max(0f, contentH - (H - HEAD - 24f));
        scrollTarget = Math.max(0f, Math.min(max, scrollTarget));
        return true;
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (searchFocus && subId == null) {
            int cp = input.codepoint();
            if (cp >= 32 && cp != 127 && query.length() < 40) { query += new String(Character.toChars(cp)); scroll = scrollTarget = 0f; }
            return true;
        }
        return super.charTyped(input);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        if (searchFocus) {
            int kc = input.key();
            if (kc == org.lwjgl.glfw.GLFW.GLFW_KEY_BACKSPACE) { if (!query.isEmpty()) query = query.substring(0, query.length() - 1); return true; }
            if (kc == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE || kc == org.lwjgl.glfw.GLFW.GLFW_KEY_ENTER) { searchFocus = false; if (kc == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE) query = ""; return true; }
        }
        if (input.key() == org.lwjgl.glfw.GLFW.GLFW_KEY_ESCAPE && subId != null) { subId = null; designOpen = false; scroll = scrollTarget = 0f; tabAnim = 0f; return true; }
        if (input.key() == org.lwjgl.glfw.GLFW.GLFW_KEY_RIGHT_SHIFT) { close(); return true; }
        return super.keyPressed(input);
    }

    @Override
    public void close() {
        ShrineCfg.save();
        super.close();
    }
}

package com.shrine;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import net.minecraft.client.gui.Element;
import net.minecraft.client.gui.screen.GameMenuScreen;
import net.minecraft.client.gui.screen.MessageScreen;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.CreateWorldScreen;

public class ShrineClient implements ClientModInitializer {
    private static boolean introDone; // splash + warning play once per launch
    @Override
    public void onInitializeClient() {
        TargetHud.register();
        TargetEsp.register();
        Predictions.register();
        MusicHud.register();
        ViewModelFx.register();
        LyricsFx.register();
        // Right Shift (changeable in Controls) opens the settings window while playing.
        // one category instance for all of our keys (creating the same category twice can throw)
        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of("shrine", "main"));
        KeyBinding openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.shrine.gui", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, cat));
        FreeLookFx.register(cat);   // Player > FreeLook key (Left Alt)
        WorldFx.register();         // Visual > Мир
        HitSoundFx.register();      // Sounds > Звук удара
        InfoHud.register();         // HUD > Информация
        CrosshairFx.register();     // Combat > Crosshair
        QolFx.register(cat);        // Player > Движение, Зум
        DesktopScreen.register(cat); // Visual > Рабочий стол key (Right Control)
        // Music: \ = play / pause, ] = next track (changeable in Controls)
        KeyBinding musicToggle = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.shrine.music_toggle", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_BACKSLASH, cat));
        KeyBinding musicNext = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.shrine.music_next", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_BRACKET, cat));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            EnchantGlintFx.tick();
            while (openGui.wasPressed()) if (client.currentScreen == null && client.world != null) client.setScreen(new ShrineGui());
            while (musicToggle.wasPressed()) if (client.currentScreen == null) MusicPlayer.toggle();
            while (musicNext.wasPressed()) if (client.currentScreen == null) MusicPlayer.next();
        });
        // The last game frame is still in the framebuffer when the connection closes: grab it for the exit animation.
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            WorldCreateFx.active = false;
            ExitFx.capture(client);
        });
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> WorldCreateFx.active = false);

        ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
            // Settings: vanilla buttons become a PS5-style vertical list.
            if (screen instanceof OptionsScreen) WorldCreateFx.layoutSettings(screen);
            // Pause menu: vanilla buttons become PS5 control-center cards.
            if (screen instanceof GameMenuScreen) WorldCreateFx.initPause(screen);
            // Chat open: the music card stays visible and its buttons can be clicked.
            if (screen instanceof ChatScreen) {
                ScreenMouseEvents.allowMouseClick(screen).register((scr, click) -> !(MusicHud.chatClick(click) || ViewModelFx.chatClick(click)));
                // hand selected in the ViewModel editor: the wheel changes size / distance instead of scrolling the chat
                ScreenMouseEvents.allowMouseScroll(screen).register((scr, mx, my, hx, vy) -> !ViewModelFx.chatScroll(vy));
            }
            // "Сохранение мира" and other message screens: the vanilla text widget is replaced by our spinner + title.
            if (screen instanceof MessageScreen) {
                for (Element e : screen.children()) if (e instanceof ClickableWidget cw) cw.visible = false;
            }
            // World creation flow gets the PS5 skin; any Shrine / title screen switches it off again.
            if (screen instanceof CreateWorldScreen) WorldCreateFx.active = true;
            else if (screen instanceof TitleScreen || screen instanceof PsSingleplayerScreen
                    || screen instanceof PsMultiplayerScreen || screen instanceof ShrineMenuScreen) WorldCreateFx.active = false;

            // Every time the vanilla title screen opens, swap it for ours.
            // Leaving a SINGLEPLAYER world lands here: open our "Одиночная игра" with that world selected.
            if (screen instanceof TitleScreen title) {
                client.execute(() -> {
                    if (client.currentScreen == title) {
                        String world = ExitFx.take("world");
                        if (world != null) {
                            introDone = true;
                            client.setScreen(new PsSingleplayerScreen(title, world));
                            return;
                        }
                        Screen menu = new ShrineMenuScreen(title);
                        client.setScreen(introDone ? menu : new WarningScreen(menu));
                        introDone = true;
                    }
                });
            }
            // Leaving a SERVER makes vanilla open ITS OWN server list. Swap it for our "Сетевая игра"
            // with the server we just left selected.
            else if (screen.getClass() == MultiplayerScreen.class) {
                client.execute(() -> {
                    if (client.currentScreen == screen) {
                        introDone = true;
                        client.setScreen(new PsMultiplayerScreen(new TitleScreen(), ExitFx.take("server")));
                    }
                });
            }
        });
    }
}

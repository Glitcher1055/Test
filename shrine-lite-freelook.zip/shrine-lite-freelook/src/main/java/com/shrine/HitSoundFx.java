package com.shrine;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.ActionResult;

/** Sounds > Звук удара: a sound of your choice every time you hit a living entity. */
final class HitSoundFx {
    private HitSoundFx() {}

    static final String KEY = "sounds.hit", K_SOUND = "sounds.hit.sound", K_VOL = "sounds.hit.vol", K_PITCH = "sounds.hit.pitch";
    static final String[] NAMES = {"Опыт", "Уровень", "Наковальня", "Стрела", "Критический"};

    private static SoundEvent sound(int i) {
        return switch (i) {
            case 1 -> SoundEvents.ENTITY_PLAYER_LEVELUP;
            case 2 -> SoundEvents.BLOCK_ANVIL_LAND;
            case 3 -> SoundEvents.ENTITY_ARROW_HIT_PLAYER;
            case 4 -> SoundEvents.ENTITY_PLAYER_ATTACK_CRIT;
            default -> SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP;
        };
    }

    static void register() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient() && entity instanceof LivingEntity && ShrineCfg.bool(KEY, false)) play();
            return ActionResult.PASS;
        });
    }

    static void play() {
        MinecraftClient c = MinecraftClient.getInstance();
        float vol = Math.max(0f, Math.min(1f, ShrineCfg.num(K_VOL, 60f) / 100f));
        float pitch = Math.max(0.5f, Math.min(2f, ShrineCfg.num(K_PITCH, 100f) / 100f));
        int s = Math.max(0, Math.min(NAMES.length - 1, ShrineCfg.integer(K_SOUND, 0)));
        if (c.player != null) c.player.playSound(sound(s), vol, pitch);
    }
}
